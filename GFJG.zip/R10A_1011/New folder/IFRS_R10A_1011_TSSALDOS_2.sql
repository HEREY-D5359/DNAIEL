﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Reclasificaciones. Reclasificaciones en el estado de situación financiera */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: Julio 2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: NA*/
/*TIPO SALDO: SALDOS*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROCEDURE [dbo].[SP_IFRS9_R10A_1011_TSSALDOS_COMP_2]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R10A_1011_TSSALDOS_RESULT_2')
BEGIN
DROP TABLE IFRS9_R10A_1011_TSSALDOS_RESULT_2
END 

BEGIN
SELECT DISTINCT

    /*ID*/

    CONVERT(VARCHAR,ID) AS ID,

	/*Deuda gubernamental*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100601004032')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100601004032')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100601004032) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100601004032) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_101,

/*Deuda bancaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100601004033')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100601004033')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100601004033) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100601004033) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_102,

/*Otros títulos de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100601004034')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100601004034')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100601004034) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100601004034) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_103,

/*Instrumentos financieros para cobrar principal e interés restringidos o dados en garantía en operaciones de préstamo de valores*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100600303011')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100600303011')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600303011) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100600303011) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_104,

/*Deuda gubernamental*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100601104035')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100601104035')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100601104035) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100601104035) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_105,

/*Deuda bancaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100601104036')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100601104036')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100601104036) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100601104036) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_106,

/*Otros títulos de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100601104037')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100601104037')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100601104037) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100601104037) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_107,

/*Instrumentos financieros para cobrar principal e interés restringidos o dados en garantía (otros)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100600303012')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100600303012')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600303012) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100600303012) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_108,

/*Deuda gubernamental*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100601204038')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100601204038')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100601204038) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100601204038) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_109,

/*En posición*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100603805035')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100603805035')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100603805035) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100603805035) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_110,

/*A recibir*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100603805036')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100603805036')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100603805036) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100603805036) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_111,

/*Deuda bancaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100601204039')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100601204039')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100601204039) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100601204039) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_112,

/*En posición*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100603905037')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100603905037')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100603905037) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100603905037) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_113,

/*A recibir*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100603905038')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100603905038')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100603905038) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100603905038) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_114,

/*Otros títulos de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100601204040')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100601204040')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100601204040) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100601204040) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_115,

/*En posición*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100604005039')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100604005039')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100604005039) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100604005039) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_116,

/*A recibir*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100604005040')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100604005040')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100604005040) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100604005040) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_117,

/*Estimación de pérdidas crediticias esperadas para inversiones en instrumentos financieros para cobrar principal e interés (valores)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100800001001')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100800001001')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100800001001) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100800001001) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_118,

/*Instrumentos financieros para cobrar principal e interés sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100800102001')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100800102001')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100800102001) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100800102001) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_119,

/*Deuda gubernamental*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100800103001')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100800103001')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100800103001) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100800103001) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_120,

/*En posición*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100800104001')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100800104001')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100800104001) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100800104001) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_121,

/*Por entregar*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100800104002')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100800104002')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100800104002) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100800104002) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_122,

/*Deuda bancaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100800103002')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100800103002')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100800103002) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100800103002) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_123,

/*En posición*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100800204003')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100800204003')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100800204003) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100800204003) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_124,

/*Por entregar*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100800204004')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100800204004')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100800204004) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100800204004) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_125,

/*Otros títulos de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100800103003')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100800103003')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100800103003) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100800103003) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_126,

/*En posición*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100800304005')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100800304005')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100800304005) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100800304005) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_127,

/*Por entregar*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100800304006')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100800304006')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100800304006) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100800304006) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_128,

/*Instrumentos financieros para cobrar principal e interés restringidos o dados en garantía en operaciones de reporto*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100800102002')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100800102002')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100800102002) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100800102002) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_129,

/*Deuda gubernamental*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100800203004')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100800203004')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100800203004) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100800203004) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_130,

/*Deuda bancaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100800203005')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100800203005')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100800203005) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100800203005) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_131,

/*Otros títulos de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100800203006')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100800203006')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100800203006) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100800203006) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_132,

/*Instrumentos financieros para cobrar principal e interés restringidos o dados en garantía en operaciones de préstamo de valores*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100800102003')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100800102003')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100800102003) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100800102003) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_133,

/*Deuda gubernamental*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100800303007')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100800303007')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100800303007) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100800303007) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_134,

/*Deuda bancaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100800303008')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100800303008')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100800303008) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100800303008) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_135,

/*Otros títulos de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100800303009')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100800303009')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100800303009) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100800303009) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_136,

/*Instrumentos financieros para cobrar principal e interés restringidos o dados en garantía (otros)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100800102004')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100800102004')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100800102004) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100800102004) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_137,

/*Deuda gubernamental*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100800403010')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100800403010')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100800403010) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100800403010) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_138,

/*En posición*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100801004007')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100801004007')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100801004007) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100801004007) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_139,

/*A recibir*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100801004008')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100801004008')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100801004008) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100801004008) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_140,

/*Deuda bancaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100800403011')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100800403011')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100800403011) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100800403011) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_141,

/*En posición*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100801104009')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100801104009')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100801104009) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100801104009) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_142,

/*A recibir*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100801104010')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100801104010')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100801104010) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100801104010) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_143,

/*Otros títulos de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100800403012')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100800403012')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100800403012) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100800403012) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_144,

/*En posición*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100801204011')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100801204011')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100801204011) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100801204011) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_145,

/*A recibir*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('100801204012')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('100801204012')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100801204012) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (100801204012) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_146,

/*Deudores por reporto*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101000001001')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101000001001')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101000001001) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101000001001) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_147,

/*Préstamo de valores*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101200001001')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101200001001')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101200001001) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101200001001) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_148,

/*Instrumentos financieros derivados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400001001')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400001001')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400001001) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400001001) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_149,

/*Con fines de negociación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400102001')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400102001')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400102001) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400102001) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_150,

/*Futuros a recibir*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400103001')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400103001')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400103001) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400103001) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_151,

/*Valuación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400104001')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400104001')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400104001) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400104001) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_152,

/*Contratos adelantados a recibir*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400103002')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400103002')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400103002) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400103002) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_153,

/*Valuación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400204002')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400204002')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400204002) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400204002) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_154,

/*Deterioro*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400204003')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400204003')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400204003) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400204003) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_155,

/*Opciones*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400103003')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400103003')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400103003) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400103003) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_156,

/*Valuación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400304004')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400304004')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400304004) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400304004) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_157,

/*Deterioro*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400304005')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400304005')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400304005) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400304005) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_158,

/*Swaps*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400103004')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400103004')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400103004) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400103004) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_159,

/*Valuación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400404006')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400404006')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400404006) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400404006) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_160,

/*Deterioro*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400404007')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400404007')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400404007) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400404007) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_161,

/*Instrumentos financieros derivados crediticios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400103005')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400103005')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400103005) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400103005) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_162,

/*Valuación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400504008')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400504008')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400504008) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400504008) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_163,

/*Deterioro*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400504009')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400504009')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400504009) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400504009) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_164,

/*Operaciones estructuradas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400103006')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400103006')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400103006) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400103006) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_165,

/*Valuación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400604010')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400604010')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400604010) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400604010) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_166,

/*Deterioro*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400604011')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400604011')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400604011) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400604011) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_167,

/*Paquetes de instrumentos financieros derivados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400103007')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400103007')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400103007) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400103007) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_168,

/*Valuación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400704012')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400704012')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400704012) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400704012) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_169,

/*Deterioro*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400704013')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400704013')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400704013) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400704013) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_170,

/*Con fines de cobertura*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400102002')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400102002')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400102002) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400102002) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_171,

/*Futuros a recibir*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400203008')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400203008')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400203008) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400203008) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_172,

/*Valuación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400804014')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400804014')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400804014) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400804014) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_173,

/*Valuación de la posición primaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400804015')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400804015')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400804015) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400804015) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_174,

/*Contratos adelantados a recibir*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400203009')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400203009')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400203009) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400203009) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_175,

/*Valuación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400904016')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400904016')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400904016) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400904016) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_176,

/*Valuación de la posición primaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400904017')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400904017')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400904017) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400904017) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_177,

/*Deterioro*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400904018')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400904018')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400904018) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400904018) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_178,

/*Opciones*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400203010')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400203010')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400203010) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400203010) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_179,

/*Valuación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101401004019')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101401004019')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101401004019) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101401004019) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_180,

/*Valuación de la posición primaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101401004020')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101401004020')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101401004020) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101401004020) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_181,

/*Deterioro*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101401004021')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101401004021')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101401004021) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101401004021) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_182,

/*Swaps*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400203011')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400203011')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400203011) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400203011) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_183,

/*Valuación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101401104022')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101401104022')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101401104022) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101401104022) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_184,

/*Valuación de la posición primaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101401104023')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101401104023')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101401104023) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101401104023) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_185,

/*Deterioro*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101401104024')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101401104024')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101401104024) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101401104024) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_186,

/*Instrumentos financieros derivados crediticios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400203012')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400203012')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400203012) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400203012) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_187,

/*Valuación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101401204025')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101401204025')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101401204025) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101401204025) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_188,

/*Valuación de la posición primaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101401204026')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101401204026')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101401204026) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101401204026) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_189,

/*Deterioro*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101401204027')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101401204027')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101401204027) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101401204027) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_190,

/*Operaciones estructuradas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400203013')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400203013')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400203013) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400203013) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_191,

/*Valuación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101401304028')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101401304028')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101401304028) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101401304028) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_192,

/*Valuación de la posición primaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101401304029')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101401304029')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101401304029) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101401304029) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_193,

/*Deterioro*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101401304030')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101401304030')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101401304030) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101401304030) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_194,

/*Paquetes de instrumentos financieros derivados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101400203014')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101400203014')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101400203014) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101400203014) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_195,

/*Valuación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101401404031')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101401404031')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101401404031) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101401404031) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_196,

/*Valuación de la posición primaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101401404032')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101401404032')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101401404032) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101401404032) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_197,

/*Deterioro*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101401404033')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101401404033')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101401404033) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101401404033) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_198,

/*Ajustes de valuación por cobertura de activos financieros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101600001001')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101600001001')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101600001001) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101600001001) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_199,

/*Cartera de crédito con riesgo de crédito etapa 1*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800104001')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800104001')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800104001) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800104001) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_200
	
INTO IFRS9_R10A_1011_TSSALDOS_RESULT_2
FROM IFRS9_R10A_1011

END

BEGIN
	INSERT INTO 
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_X01])),
            SUM(CHARINDEX('ERR',[VALIDACION_X02])),
            SUM(CHARINDEX('ERR',[VALIDACION_X03])),
            SUM(CHARINDEX('ERR',[VALIDACION_X04])),
            SUM(CHARINDEX('ERR',[VALIDACION_X05])),
            SUM(CHARINDEX('ERR',[VALIDACION_X06])),
            SUM(CHARINDEX('ERR',[VALIDACION_X07])),
            SUM(CHARINDEX('ERR',[VALIDACION_X08])),
            SUM(CHARINDEX('ERR',[VALIDACION_X09])),
            SUM(CHARINDEX('ERR',[VALIDACION_X10])),
            SUM(CHARINDEX('ERR',[VALIDACION_X11])),
            SUM(CHARINDEX('ERR',[VALIDACION_X12])),
            SUM(CHARINDEX('ERR',[VALIDACION_X13])),
            SUM(CHARINDEX('ERR',[VALIDACION_X14])),
            SUM(CHARINDEX('ERR',[VALIDACION_X15])),
            SUM(CHARINDEX('ERR',[VALIDACION_X16])),
            SUM(CHARINDEX('ERR',[VALIDACION_X17])),
            SUM(CHARINDEX('ERR',[VALIDACION_X18])),
            SUM(CHARINDEX('ERR',[VALIDACION_X19])),
            SUM(CHARINDEX('ERR',[VALIDACION_X20])),
            SUM(CHARINDEX('ERR',[VALIDACION_X21])),
            SUM(CHARINDEX('ERR',[VALIDACION_X22])),
            SUM(CHARINDEX('ERR',[VALIDACION_X23])),
            SUM(CHARINDEX('ERR',[VALIDACION_X24])),
            SUM(CHARINDEX('ERR',[VALIDACION_X25])),
            SUM(CHARINDEX('ERR',[VALIDACION_X26])),
            SUM(CHARINDEX('ERR',[VALIDACION_X27])),
            SUM(CHARINDEX('ERR',[VALIDACION_X28])),
            SUM(CHARINDEX('ERR',[VALIDACION_X29])),
            SUM(CHARINDEX('ERR',[VALIDACION_X30])),
            SUM(CHARINDEX('ERR',[VALIDACION_X31])),
            SUM(CHARINDEX('ERR',[VALIDACION_X32])),
            SUM(CHARINDEX('ERR',[VALIDACION_X33])),
            SUM(CHARINDEX('ERR',[VALIDACION_X34])),
            SUM(CHARINDEX('ERR',[VALIDACION_X35])),
            SUM(CHARINDEX('ERR',[VALIDACION_X36])),
            SUM(CHARINDEX('ERR',[VALIDACION_X37])),
            SUM(CHARINDEX('ERR',[VALIDACION_X38])),
            SUM(CHARINDEX('ERR',[VALIDACION_X39])),
            SUM(CHARINDEX('ERR',[VALIDACION_X40])),
            SUM(CHARINDEX('ERR',[VALIDACION_X41])),
            SUM(CHARINDEX('ERR',[VALIDACION_X42])),
            SUM(CHARINDEX('ERR',[VALIDACION_X43])),
            SUM(CHARINDEX('ERR',[VALIDACION_X44])),
            SUM(CHARINDEX('ERR',[VALIDACION_X45])),
            SUM(CHARINDEX('ERR',[VALIDACION_X46])),
            SUM(CHARINDEX('ERR',[VALIDACION_X47])),
            SUM(CHARINDEX('ERR',[VALIDACION_X48])),
            SUM(CHARINDEX('ERR',[VALIDACION_X49])),
            SUM(CHARINDEX('ERR',[VALIDACION_X50])),
            SUM(CHARINDEX('ERR',[VALIDACION_X51])),
            SUM(CHARINDEX('ERR',[VALIDACION_X52])),
            SUM(CHARINDEX('ERR',[VALIDACION_X53])),
            SUM(CHARINDEX('ERR',[VALIDACION_X54])),
            SUM(CHARINDEX('ERR',[VALIDACION_X55])),
            SUM(CHARINDEX('ERR',[VALIDACION_X56])),
            SUM(CHARINDEX('ERR',[VALIDACION_X57])),
            SUM(CHARINDEX('ERR',[VALIDACION_X58])),
            SUM(CHARINDEX('ERR',[VALIDACION_X59])),
            SUM(CHARINDEX('ERR',[VALIDACION_X60])),
            SUM(CHARINDEX('ERR',[VALIDACION_X61])),
            SUM(CHARINDEX('ERR',[VALIDACION_X62])),
            SUM(CHARINDEX('ERR',[VALIDACION_X63])),
            SUM(CHARINDEX('ERR',[VALIDACION_X64])),
            SUM(CHARINDEX('ERR',[VALIDACION_X65])),
            SUM(CHARINDEX('ERR',[VALIDACION_X66])),
            SUM(CHARINDEX('ERR',[VALIDACION_X67])),
            SUM(CHARINDEX('ERR',[VALIDACION_X68])),
            SUM(CHARINDEX('ERR',[VALIDACION_X69])),
            SUM(CHARINDEX('ERR',[VALIDACION_X70])),
            SUM(CHARINDEX('ERR',[VALIDACION_X71])),
            SUM(CHARINDEX('ERR',[VALIDACION_X72])),
            SUM(CHARINDEX('ERR',[VALIDACION_X73])),
            SUM(CHARINDEX('ERR',[VALIDACION_X74])),
            SUM(CHARINDEX('ERR',[VALIDACION_X75])),
            SUM(CHARINDEX('ERR',[VALIDACION_X76])),
            SUM(CHARINDEX('ERR',[VALIDACION_X77])),
            SUM(CHARINDEX('ERR',[VALIDACION_X78])),
            SUM(CHARINDEX('ERR',[VALIDACION_X79])),
            SUM(CHARINDEX('ERR',[VALIDACION_X80])),
            SUM(CHARINDEX('ERR',[VALIDACION_X81])),
            SUM(CHARINDEX('ERR',[VALIDACION_X82])),
            SUM(CHARINDEX('ERR',[VALIDACION_X83])),
            SUM(CHARINDEX('ERR',[VALIDACION_X84])),
            SUM(CHARINDEX('ERR',[VALIDACION_X85])),
            SUM(CHARINDEX('ERR',[VALIDACION_X86])),
            SUM(CHARINDEX('ERR',[VALIDACION_X87])),
            SUM(CHARINDEX('ERR',[VALIDACION_X88])),
            SUM(CHARINDEX('ERR',[VALIDACION_X89])),
            SUM(CHARINDEX('ERR',[VALIDACION_X90])),
            SUM(CHARINDEX('ERR',[VALIDACION_X91])),
            SUM(CHARINDEX('ERR',[VALIDACION_X92])),
            SUM(CHARINDEX('ERR',[VALIDACION_X93])),
            SUM(CHARINDEX('ERR',[VALIDACION_X94])),
            SUM(CHARINDEX('ERR',[VALIDACION_X95])),
            SUM(CHARINDEX('ERR',[VALIDACION_X96])),
            SUM(CHARINDEX('ERR',[VALIDACION_X97])),
            SUM(CHARINDEX('ERR',[VALIDACION_X98])),
            SUM(CHARINDEX('ERR',[VALIDACION_X99])),
            SUM(CHARINDEX('ERR',[VALIDACION_X00]))
            


		FROMx 
END

BEGIN
	EXEC SP_
END

COMMIT
END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


