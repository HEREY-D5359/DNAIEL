﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Reclasificaciones. Reclasificaciones en el estado de situación financiera */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: Julio 2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: NA*/
/*TIPO SALDO: SALDOS*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROCEDURE [dbo].[SP_IFRS9_R10A_1011_TSSALDOS_COMP_3]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R10A_1011_TSSALDOS_RESULT_3')
BEGIN
DROP TABLE IFRS9_R10A_1011_TSSALDOS_RESULT_3
END 

BEGIN
SELECT DISTINCT

    /*ID*/

    CONVERT(VARCHAR,ID) AS ID,

	/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800105001')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800105001')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800105001) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800105001) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_201,

/*Créditos comerciales sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800106001')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800106001')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800106001) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800106001) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_202,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800107001')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800107001')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800107001) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800107001) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_203,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800108001')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800108001')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800108001) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800108001) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_204,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800109001')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800109001')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800109001) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800109001) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_205,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800109002')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800109002')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800109002) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800109002) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_206,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800108002')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800108002')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800108002) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800108002) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_207,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800209003')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800209003')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800209003) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800209003) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_208,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800209004')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800209004')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800209004) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800209004) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_209,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800209005')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800209005')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800209005) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800209005) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_210,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800108003')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800108003')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800108003) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800108003) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_211,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800309006')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800309006')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800309006) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800309006) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_212,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800309007')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800309007')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800309007) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800309007) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_213,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800108004')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800108004')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800108004) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800108004) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_214,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800108005')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800108005')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800108005) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800108005) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_215,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800108006')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800108006')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800108006) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800108006) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_216,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800108007')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800108007')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800108007) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800108007) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_217,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800108008')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800108008')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800108008) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800108008) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_218,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800107002')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800107002')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800107002) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800107002) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_219,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800208009')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800208009')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800208009) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800208009) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_220,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800909009')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800909009')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800909009) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800909009) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_221,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800909010')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800909010')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800909010) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800909010) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_222,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800909011')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800909011')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800909011) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800909011) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_223,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800208010')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800208010')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800208010) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800208010) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_224,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101801009014')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101801009014')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801009014) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101801009014) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_225,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101801009015')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101801009015')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801009015) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101801009015) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_226,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101801009016')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101801009016')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801009016) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101801009016) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_227,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800107003')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800107003')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800107003) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800107003) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_228,

/*Créditos al gobierno federal*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800308011')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800308011')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800308011) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800308011) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_229,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800308012')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800308012')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800308012) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800308012) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_230,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101801209018')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101801209018')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801209018) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101801209018) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_231,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101801209019')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101801209019')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801209019) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101801209019) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_232,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101801209020')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101801209020')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801209020) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101801209020) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_233,

/*Fideicomisos públicos de contratación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101801209021')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101801209021')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801209021) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101801209021) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_234,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101801209022')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101801209022')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801209022) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101801209022) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_235,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800308013')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800308013')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800308013) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800308013) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_236,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101801309023')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101801309023')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801309023) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101801309023) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_237,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101801309024')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101801309024')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801309024) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101801309024) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_238,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101801309025')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101801309025')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801309025) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101801309025) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_239,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101801309026')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101801309026')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801309026) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101801309026) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_240,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800308014')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800308014')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800308014) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800308014) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_241,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101801409027')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101801409027')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801409027) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101801409027) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_242,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101801409028')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101801409028')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801409028) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101801409028) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_243,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101801409029')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101801409029')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801409029) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101801409029) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_244,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101801409030')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101801409030')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801409030) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101801409030) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_245,

/*Créditos comerciales restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800106002')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800106002')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800106002) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800106002) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_246,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800207004')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800207004')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800207004) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800207004) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_247,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800408015')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800408015')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800408015) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800408015) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_248,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101801509031')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101801509031')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801509031) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101801509031) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_249,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101801509032')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101801509032')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801509032) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101801509032) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_250,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800408016')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800408016')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800408016) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800408016) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_251,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101801609033')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101801609033')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801609033) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101801609033) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_252,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101801609034')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101801609034')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801609034) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101801609034) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_253,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101801609035')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101801609035')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801609035) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101801609035) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_254,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800408017')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800408017')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800408017) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800408017) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_255,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101801709036')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101801709036')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801709036) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101801709036) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_256,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101801709037')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101801709037')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801709037) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101801709037) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_257,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800408018')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800408018')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800408018) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800408018) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_258,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800408019')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800408019')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800408019) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800408019) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_259,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800408020')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800408020')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800408020) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800408020) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_260,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800408021')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800408021')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800408021) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800408021) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_261,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800408022')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800408022')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800408022) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800408022) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_262,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800207005')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800207005')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800207005) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800207005) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_263,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800508023')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800508023')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800508023) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800508023) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_264,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101802309039')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101802309039')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802309039) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101802309039) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_265,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101802309040')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101802309040')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802309040) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101802309040) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_266,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101802309041')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101802309041')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802309041) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101802309041) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_267,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800508024')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800508024')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800508024) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800508024) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_268,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101802409044')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101802409044')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802409044) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101802409044) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_269,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101802409045')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101802409045')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802409045) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101802409045) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_270,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101802409046')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101802409046')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802409046) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101802409046) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_271,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800207006')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800207006')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800207006) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800207006) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_272,

/*Créditos al gobierno federal*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800608025')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800608025')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800608025) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800608025) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_273,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800608026')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800608026')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800608026) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800608026) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_274,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101802609048')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101802609048')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802609048) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101802609048) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_275,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101802609049')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101802609049')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802609049) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101802609049) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_276,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101802609050')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101802609050')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802609050) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101802609050) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_277,

/*Fideicomisos públicos de contratación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101802609051')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101802609051')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802609051) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101802609051) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_278,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101802609052')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101802609052')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802609052) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101802609052) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_279,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800608027')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800608027')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800608027) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800608027) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_280,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101802709053')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101802709053')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802709053) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101802709053) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_281,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101802709054')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101802709054')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802709054) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101802709054) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_282,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101802709055')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101802709055')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802709055) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101802709055) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_283,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101802709056')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101802709056')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802709056) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101802709056) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_284,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800608028')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800608028')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800608028) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800608028) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_285,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101802809057')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101802809057')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802809057) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101802809057) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_286,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101802809058')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101802809058')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802809058) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101802809058) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_287,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101802809059')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101802809059')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802809059) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101802809059) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_288,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101802809060')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101802809060')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802809060) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101802809060) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_289,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800105002')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800105002')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800105002) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800105002) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_290,

/*Créditos de consumo sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800206003')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800206003')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800206003) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800206003) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_291,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800307007')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800307007')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800307007) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800307007) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_292,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800307008')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800307008')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800307008) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800307008) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_293,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800307009')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800307009')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800307009) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800307009) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_294,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800307010')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800307010')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800307010) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800307010) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_295,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800307011')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800307011')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800307011) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800307011) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_296,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800307012')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800307012')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800307012) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800307012) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_297,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800307013')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800307013')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800307013) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800307013) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_298,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800307014')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800307014')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800307014) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800307014) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_299,

/*Créditos de consumo restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800206004')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800206004')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800206004) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800206004) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_300
	
INTO IFRS9_R10A_1011_TSSALDOS_RESULT_3
FROM IFRS9_R10A_1011

END

BEGIN
	INSERT INTO 
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_X01])),
            SUM(CHARINDEX('ERR',[VALIDACION_X02])),
            SUM(CHARINDEX('ERR',[VALIDACION_X03])),
            SUM(CHARINDEX('ERR',[VALIDACION_X04])),
            SUM(CHARINDEX('ERR',[VALIDACION_X05])),
            SUM(CHARINDEX('ERR',[VALIDACION_X06])),
            SUM(CHARINDEX('ERR',[VALIDACION_X07])),
            SUM(CHARINDEX('ERR',[VALIDACION_X08])),
            SUM(CHARINDEX('ERR',[VALIDACION_X09])),
            SUM(CHARINDEX('ERR',[VALIDACION_X10])),
            SUM(CHARINDEX('ERR',[VALIDACION_X11])),
            SUM(CHARINDEX('ERR',[VALIDACION_X12])),
            SUM(CHARINDEX('ERR',[VALIDACION_X13])),
            SUM(CHARINDEX('ERR',[VALIDACION_X14])),
            SUM(CHARINDEX('ERR',[VALIDACION_X15])),
            SUM(CHARINDEX('ERR',[VALIDACION_X16])),
            SUM(CHARINDEX('ERR',[VALIDACION_X17])),
            SUM(CHARINDEX('ERR',[VALIDACION_X18])),
            SUM(CHARINDEX('ERR',[VALIDACION_X19])),
            SUM(CHARINDEX('ERR',[VALIDACION_X20])),
            SUM(CHARINDEX('ERR',[VALIDACION_X21])),
            SUM(CHARINDEX('ERR',[VALIDACION_X22])),
            SUM(CHARINDEX('ERR',[VALIDACION_X23])),
            SUM(CHARINDEX('ERR',[VALIDACION_X24])),
            SUM(CHARINDEX('ERR',[VALIDACION_X25])),
            SUM(CHARINDEX('ERR',[VALIDACION_X26])),
            SUM(CHARINDEX('ERR',[VALIDACION_X27])),
            SUM(CHARINDEX('ERR',[VALIDACION_X28])),
            SUM(CHARINDEX('ERR',[VALIDACION_X29])),
            SUM(CHARINDEX('ERR',[VALIDACION_X30])),
            SUM(CHARINDEX('ERR',[VALIDACION_X31])),
            SUM(CHARINDEX('ERR',[VALIDACION_X32])),
            SUM(CHARINDEX('ERR',[VALIDACION_X33])),
            SUM(CHARINDEX('ERR',[VALIDACION_X34])),
            SUM(CHARINDEX('ERR',[VALIDACION_X35])),
            SUM(CHARINDEX('ERR',[VALIDACION_X36])),
            SUM(CHARINDEX('ERR',[VALIDACION_X37])),
            SUM(CHARINDEX('ERR',[VALIDACION_X38])),
            SUM(CHARINDEX('ERR',[VALIDACION_X39])),
            SUM(CHARINDEX('ERR',[VALIDACION_X40])),
            SUM(CHARINDEX('ERR',[VALIDACION_X41])),
            SUM(CHARINDEX('ERR',[VALIDACION_X42])),
            SUM(CHARINDEX('ERR',[VALIDACION_X43])),
            SUM(CHARINDEX('ERR',[VALIDACION_X44])),
            SUM(CHARINDEX('ERR',[VALIDACION_X45])),
            SUM(CHARINDEX('ERR',[VALIDACION_X46])),
            SUM(CHARINDEX('ERR',[VALIDACION_X47])),
            SUM(CHARINDEX('ERR',[VALIDACION_X48])),
            SUM(CHARINDEX('ERR',[VALIDACION_X49])),
            SUM(CHARINDEX('ERR',[VALIDACION_X50])),
            SUM(CHARINDEX('ERR',[VALIDACION_X51])),
            SUM(CHARINDEX('ERR',[VALIDACION_X52])),
            SUM(CHARINDEX('ERR',[VALIDACION_X53])),
            SUM(CHARINDEX('ERR',[VALIDACION_X54])),
            SUM(CHARINDEX('ERR',[VALIDACION_X55])),
            SUM(CHARINDEX('ERR',[VALIDACION_X56])),
            SUM(CHARINDEX('ERR',[VALIDACION_X57])),
            SUM(CHARINDEX('ERR',[VALIDACION_X58])),
            SUM(CHARINDEX('ERR',[VALIDACION_X59])),
            SUM(CHARINDEX('ERR',[VALIDACION_X60])),
            SUM(CHARINDEX('ERR',[VALIDACION_X61])),
            SUM(CHARINDEX('ERR',[VALIDACION_X62])),
            SUM(CHARINDEX('ERR',[VALIDACION_X63])),
            SUM(CHARINDEX('ERR',[VALIDACION_X64])),
            SUM(CHARINDEX('ERR',[VALIDACION_X65])),
            SUM(CHARINDEX('ERR',[VALIDACION_X66])),
            SUM(CHARINDEX('ERR',[VALIDACION_X67])),
            SUM(CHARINDEX('ERR',[VALIDACION_X68])),
            SUM(CHARINDEX('ERR',[VALIDACION_X69])),
            SUM(CHARINDEX('ERR',[VALIDACION_X70])),
            SUM(CHARINDEX('ERR',[VALIDACION_X71])),
            SUM(CHARINDEX('ERR',[VALIDACION_X72])),
            SUM(CHARINDEX('ERR',[VALIDACION_X73])),
            SUM(CHARINDEX('ERR',[VALIDACION_X74])),
            SUM(CHARINDEX('ERR',[VALIDACION_X75])),
            SUM(CHARINDEX('ERR',[VALIDACION_X76])),
            SUM(CHARINDEX('ERR',[VALIDACION_X77])),
            SUM(CHARINDEX('ERR',[VALIDACION_X78])),
            SUM(CHARINDEX('ERR',[VALIDACION_X79])),
            SUM(CHARINDEX('ERR',[VALIDACION_X80])),
            SUM(CHARINDEX('ERR',[VALIDACION_X81])),
            SUM(CHARINDEX('ERR',[VALIDACION_X82])),
            SUM(CHARINDEX('ERR',[VALIDACION_X83])),
            SUM(CHARINDEX('ERR',[VALIDACION_X84])),
            SUM(CHARINDEX('ERR',[VALIDACION_X85])),
            SUM(CHARINDEX('ERR',[VALIDACION_X86])),
            SUM(CHARINDEX('ERR',[VALIDACION_X87])),
            SUM(CHARINDEX('ERR',[VALIDACION_X88])),
            SUM(CHARINDEX('ERR',[VALIDACION_X89])),
            SUM(CHARINDEX('ERR',[VALIDACION_X90])),
            SUM(CHARINDEX('ERR',[VALIDACION_X91])),
            SUM(CHARINDEX('ERR',[VALIDACION_X92])),
            SUM(CHARINDEX('ERR',[VALIDACION_X93])),
            SUM(CHARINDEX('ERR',[VALIDACION_X94])),
            SUM(CHARINDEX('ERR',[VALIDACION_X95])),
            SUM(CHARINDEX('ERR',[VALIDACION_X96])),
            SUM(CHARINDEX('ERR',[VALIDACION_X97])),
            SUM(CHARINDEX('ERR',[VALIDACION_X98])),
            SUM(CHARINDEX('ERR',[VALIDACION_X99])),
            SUM(CHARINDEX('ERR',[VALIDACION_X00]))
            


		FROMx 
END

BEGIN
	EXEC SP_
END

COMMIT
END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


