﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Reclasificaciones. Reclasificaciones en el estado de situación financiera */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: Julio 2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: NA*/
/*TIPO SALDO: SALDOS*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROCEDURE [dbo].[SP_IFRS9_R10A_1011_TSSALDOS_COMP_7]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R10A_1011_TSSALDOS_RESULT_7')
BEGIN
DROP TABLE IFRS9_R10A_1011_TSSALDOS_RESULT_7
END 

BEGIN
SELECT DISTINCT

    /*ID*/

    CONVERT(VARCHAR,ID) AS ID,

	/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101819510251')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101819510251')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101819510251) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101819510251) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_601,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101819510252')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101819510252')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101819510252) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101819510252) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_602,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101819510253')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101819510253')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101819510253) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101819510253) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_603,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101813009196')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101813009196')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101813009196) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101813009196) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_604,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101819610254')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101819610254')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101819610254) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101819610254) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_605,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101819610255')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101819610255')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101819610255) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101819610255) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_606,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101819610256')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101819610256')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101819610256) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101819610256) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_607,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101819610257')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101819610257')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101819610257) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101819610257) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_608,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101801406056')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101801406056')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801406056) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101801406056) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_609,

/*Créditos de consumo sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101805607084')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101805607084')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805607084) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101805607084) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_610,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101808408131')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101808408131')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101808408131) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101808408131) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_611,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101808408132')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101808408132')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101808408132) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101808408132) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_612,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101808408133')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101808408133')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101808408133) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101808408133) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_613,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101808408134')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101808408134')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101808408134) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101808408134) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_614,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101808408135')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101808408135')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101808408135) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101808408135) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_615,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101808408136')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101808408136')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101808408136) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101808408136) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_616,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101808408137')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101808408137')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101808408137) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101808408137) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_617,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101808408138')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101808408138')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101808408138) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101808408138) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_618,

/*Créditos de consumo restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101805607085')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101805607085')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805607085) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101805607085) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_619,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101808508139')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101808508139')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101808508139) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101808508139) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_620,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101808508140')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101808508140')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101808508140) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101808508140) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_621,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101808508141')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101808508141')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101808508141) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101808508141) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_622,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101808508142')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101808508142')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101808508142) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101808508142) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_623,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101808508143')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101808508143')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101808508143) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101808508143) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_624,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101808508144')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101808508144')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101808508144) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101808508144) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_625,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101808508145')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101808508145')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101808508145) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101808508145) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_626,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101808508146')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101808508146')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101808508146) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101808508146) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_627,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101801406057')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101801406057')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801406057) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101801406057) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_628,

/*Créditos a la vivienda sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101805707086')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101805707086')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805707086) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101805707086) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_629,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101808608147')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101808608147')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101808608147) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101808608147) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_630,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101808608148')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101808608148')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101808608148) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101808608148) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_631,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101808608149')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101808608149')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101808608149) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101808608149) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_632,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101814909297')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101814909297')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101814909297) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101814909297) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_633,

/*Cartera en prórroga*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101814909298')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101814909298')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101814909298) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101814909298) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_634,

/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101814909299')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101814909299')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101814909299) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101814909299) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_635,

/*Remodelación o mejoramiento con garantía otorgada por la banca de desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101808608150')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101808608150')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101808608150) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101808608150) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_636,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101808608151')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101808608151')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101808608151) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101808608151) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_637,

/*Créditos a la vivienda restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101805707087')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101805707087')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805707087) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101805707087) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_638,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101808708152')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101808708152')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101808708152) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101808708152) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_639,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101808708153')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101808708153')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101808708153) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101808708153) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_640,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101808708154')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101808708154')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101808708154) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101808708154) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_641,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101815409320')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101815409320')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101815409320) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101815409320) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_642,

/*Cartera en prórroga*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101815409321')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101815409321')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101815409321) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101815409321) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_643,

/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101815409322')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101815409322')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101815409322) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101815409322) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_644,

/*Remodelación o mejoramiento con garantía otorgada por la banca de desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101808708155')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101808708155')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101808708155) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101808708155) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_645,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101808708156')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101808708156')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101808708156) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101808708156) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_646,

/*Cartera con riesgo de crédito etapa 2*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101800505016')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101800505016')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800505016) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101800505016) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_647,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101801606061')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101801606061')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801606061) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101801606061) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_648,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101806107119')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101806107119')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806107119) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101806107119) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_649,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101811908157')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101811908157')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101811908157) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101811908157) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_650,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101815709323')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101815709323')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101815709323) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101815709323) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_651,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101815709324')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101815709324')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101815709324) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101815709324) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_652,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101811908158')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101811908158')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101811908158) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101811908158) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_653,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101815809325')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101815809325')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101815809325) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101815809325) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_654,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101815809326')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101815809326')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101815809326) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101815809326) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_655,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101815809327')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101815809327')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101815809327) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101815809327) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_656,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101811908159')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101811908159')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101811908159) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101811908159) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_657,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101815909328')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101815909328')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101815909328) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101815909328) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_658,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101815909329')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101815909329')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101815909329) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101815909329) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_659,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101811908160')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101811908160')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101811908160) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101811908160) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_660,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101811908161')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101811908161')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101811908161) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101811908161) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_661,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101811908162')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101811908162')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101811908162) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101811908162) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_662,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101811908163')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101811908163')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101811908163) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101811908163) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_663,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101811908164')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101811908164')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101811908164) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101811908164) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_664,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101806107120')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101806107120')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806107120) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101806107120) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_665,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101812008165')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101812008165')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101812008165) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101812008165) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_666,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101816509380')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101816509380')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101816509380) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101816509380) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_667,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101816509381')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101816509381')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101816509381) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101816509381) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_668,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101816509382')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101816509382')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101816509382) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101816509382) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_669,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101812008166')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101812008166')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101812008166) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101812008166) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_670,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101816609383')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101816609383')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101816609383) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101816609383) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_671,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101816609384')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101816609384')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101816609384) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101816609384) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_672,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101816609385')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101816609385')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101816609385) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101816609385) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_673,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101806107121')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101806107121')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806107121) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101806107121) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_674,

/*Créditos al gobierno federal*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101812108167')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101812108167')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101812108167) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101812108167) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_675,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101812108168')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101812108168')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101812108168) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101812108168) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_676,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101816809397')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101816809397')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101816809397) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101816809397) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_677,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101816809398')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101816809398')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101816809398) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101816809398) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_678,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101816809399')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101816809399')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101816809399) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101816809399) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_679,

/*Fideicomisos públicos de contratación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101816809400')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101816809400')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101816809400) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101816809400) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_680,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101816809401')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101816809401')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101816809401) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101816809401) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_681,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101812108169')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101812108169')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101812108169) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101812108169) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_682,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101816909402')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101816909402')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101816909402) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101816909402) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_683,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101816909403')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101816909403')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101816909403) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101816909403) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_684,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101816909404')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101816909404')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101816909404) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101816909404) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_685,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101816909405')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101816909405')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101816909405) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101816909405) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_686,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101812108170')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101812108170')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101812108170) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101812108170) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_687,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101817009406')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101817009406')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101817009406) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101817009406) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_688,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101817009407')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101817009407')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101817009407) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101817009407) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_689,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101817009408')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101817009408')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101817009408) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101817009408) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_690,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101817009409')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101817009409')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101817009409) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101817009409) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_691,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101801606062')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101801606062')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801606062) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101801606062) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_692,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101806207122')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101806207122')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806207122) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101806207122) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_693,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101806207123')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101806207123')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806207123) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101806207123) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_694,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101806207124')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101806207124')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806207124) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101806207124) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_695,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101806207125')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101806207125')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806207125) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101806207125) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_696,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101806207126')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101806207126')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806207126) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101806207126) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_697,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101806207127')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101806207127')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806207127) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101806207127) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_698,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101806207128')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101806207128')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806207128) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101806207128) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_699,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1011   
WHERE [c04_concepto] IN ('101806207129')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1011     
WHERE [c04_concepto] IN ('101806207129')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806207129) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (101806207129) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_700
	
INTO IFRS9_R10A_1011_TSSALDOS_RESULT_7
FROM IFRS9_R10A_1011

END

BEGIN
	INSERT INTO 
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_X01])),
            SUM(CHARINDEX('ERR',[VALIDACION_X02])),
            SUM(CHARINDEX('ERR',[VALIDACION_X03])),
            SUM(CHARINDEX('ERR',[VALIDACION_X04])),
            SUM(CHARINDEX('ERR',[VALIDACION_X05])),
            SUM(CHARINDEX('ERR',[VALIDACION_X06])),
            SUM(CHARINDEX('ERR',[VALIDACION_X07])),
            SUM(CHARINDEX('ERR',[VALIDACION_X08])),
            SUM(CHARINDEX('ERR',[VALIDACION_X09])),
            SUM(CHARINDEX('ERR',[VALIDACION_X10])),
            SUM(CHARINDEX('ERR',[VALIDACION_X11])),
            SUM(CHARINDEX('ERR',[VALIDACION_X12])),
            SUM(CHARINDEX('ERR',[VALIDACION_X13])),
            SUM(CHARINDEX('ERR',[VALIDACION_X14])),
            SUM(CHARINDEX('ERR',[VALIDACION_X15])),
            SUM(CHARINDEX('ERR',[VALIDACION_X16])),
            SUM(CHARINDEX('ERR',[VALIDACION_X17])),
            SUM(CHARINDEX('ERR',[VALIDACION_X18])),
            SUM(CHARINDEX('ERR',[VALIDACION_X19])),
            SUM(CHARINDEX('ERR',[VALIDACION_X20])),
            SUM(CHARINDEX('ERR',[VALIDACION_X21])),
            SUM(CHARINDEX('ERR',[VALIDACION_X22])),
            SUM(CHARINDEX('ERR',[VALIDACION_X23])),
            SUM(CHARINDEX('ERR',[VALIDACION_X24])),
            SUM(CHARINDEX('ERR',[VALIDACION_X25])),
            SUM(CHARINDEX('ERR',[VALIDACION_X26])),
            SUM(CHARINDEX('ERR',[VALIDACION_X27])),
            SUM(CHARINDEX('ERR',[VALIDACION_X28])),
            SUM(CHARINDEX('ERR',[VALIDACION_X29])),
            SUM(CHARINDEX('ERR',[VALIDACION_X30])),
            SUM(CHARINDEX('ERR',[VALIDACION_X31])),
            SUM(CHARINDEX('ERR',[VALIDACION_X32])),
            SUM(CHARINDEX('ERR',[VALIDACION_X33])),
            SUM(CHARINDEX('ERR',[VALIDACION_X34])),
            SUM(CHARINDEX('ERR',[VALIDACION_X35])),
            SUM(CHARINDEX('ERR',[VALIDACION_X36])),
            SUM(CHARINDEX('ERR',[VALIDACION_X37])),
            SUM(CHARINDEX('ERR',[VALIDACION_X38])),
            SUM(CHARINDEX('ERR',[VALIDACION_X39])),
            SUM(CHARINDEX('ERR',[VALIDACION_X40])),
            SUM(CHARINDEX('ERR',[VALIDACION_X41])),
            SUM(CHARINDEX('ERR',[VALIDACION_X42])),
            SUM(CHARINDEX('ERR',[VALIDACION_X43])),
            SUM(CHARINDEX('ERR',[VALIDACION_X44])),
            SUM(CHARINDEX('ERR',[VALIDACION_X45])),
            SUM(CHARINDEX('ERR',[VALIDACION_X46])),
            SUM(CHARINDEX('ERR',[VALIDACION_X47])),
            SUM(CHARINDEX('ERR',[VALIDACION_X48])),
            SUM(CHARINDEX('ERR',[VALIDACION_X49])),
            SUM(CHARINDEX('ERR',[VALIDACION_X50])),
            SUM(CHARINDEX('ERR',[VALIDACION_X51])),
            SUM(CHARINDEX('ERR',[VALIDACION_X52])),
            SUM(CHARINDEX('ERR',[VALIDACION_X53])),
            SUM(CHARINDEX('ERR',[VALIDACION_X54])),
            SUM(CHARINDEX('ERR',[VALIDACION_X55])),
            SUM(CHARINDEX('ERR',[VALIDACION_X56])),
            SUM(CHARINDEX('ERR',[VALIDACION_X57])),
            SUM(CHARINDEX('ERR',[VALIDACION_X58])),
            SUM(CHARINDEX('ERR',[VALIDACION_X59])),
            SUM(CHARINDEX('ERR',[VALIDACION_X60])),
            SUM(CHARINDEX('ERR',[VALIDACION_X61])),
            SUM(CHARINDEX('ERR',[VALIDACION_X62])),
            SUM(CHARINDEX('ERR',[VALIDACION_X63])),
            SUM(CHARINDEX('ERR',[VALIDACION_X64])),
            SUM(CHARINDEX('ERR',[VALIDACION_X65])),
            SUM(CHARINDEX('ERR',[VALIDACION_X66])),
            SUM(CHARINDEX('ERR',[VALIDACION_X67])),
            SUM(CHARINDEX('ERR',[VALIDACION_X68])),
            SUM(CHARINDEX('ERR',[VALIDACION_X69])),
            SUM(CHARINDEX('ERR',[VALIDACION_X70])),
            SUM(CHARINDEX('ERR',[VALIDACION_X71])),
            SUM(CHARINDEX('ERR',[VALIDACION_X72])),
            SUM(CHARINDEX('ERR',[VALIDACION_X73])),
            SUM(CHARINDEX('ERR',[VALIDACION_X74])),
            SUM(CHARINDEX('ERR',[VALIDACION_X75])),
            SUM(CHARINDEX('ERR',[VALIDACION_X76])),
            SUM(CHARINDEX('ERR',[VALIDACION_X77])),
            SUM(CHARINDEX('ERR',[VALIDACION_X78])),
            SUM(CHARINDEX('ERR',[VALIDACION_X79])),
            SUM(CHARINDEX('ERR',[VALIDACION_X80])),
            SUM(CHARINDEX('ERR',[VALIDACION_X81])),
            SUM(CHARINDEX('ERR',[VALIDACION_X82])),
            SUM(CHARINDEX('ERR',[VALIDACION_X83])),
            SUM(CHARINDEX('ERR',[VALIDACION_X84])),
            SUM(CHARINDEX('ERR',[VALIDACION_X85])),
            SUM(CHARINDEX('ERR',[VALIDACION_X86])),
            SUM(CHARINDEX('ERR',[VALIDACION_X87])),
            SUM(CHARINDEX('ERR',[VALIDACION_X88])),
            SUM(CHARINDEX('ERR',[VALIDACION_X89])),
            SUM(CHARINDEX('ERR',[VALIDACION_X90])),
            SUM(CHARINDEX('ERR',[VALIDACION_X91])),
            SUM(CHARINDEX('ERR',[VALIDACION_X92])),
            SUM(CHARINDEX('ERR',[VALIDACION_X93])),
            SUM(CHARINDEX('ERR',[VALIDACION_X94])),
            SUM(CHARINDEX('ERR',[VALIDACION_X95])),
            SUM(CHARINDEX('ERR',[VALIDACION_X96])),
            SUM(CHARINDEX('ERR',[VALIDACION_X97])),
            SUM(CHARINDEX('ERR',[VALIDACION_X98])),
            SUM(CHARINDEX('ERR',[VALIDACION_X99])),
            SUM(CHARINDEX('ERR',[VALIDACION_X00]))
            


		FROMx 
END

BEGIN
	EXEC SP_
END

COMMIT
END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


