﻿
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Reclasificaciones. Reclasificaciones en el estado de situación financiera */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: Julio 2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: NA*/
/*TIPO SALDO: 125*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: 0*/


CREATE OR ALTER PROCEDURE [dbo].[SP_IFRS9_R10A_1011_TS125TM0_VIEW_4]
AS
BEGIN
	SELECT *
		
	FROM IFRS9_R10A_1011_TS125TM0_RESULT_4
	WHERE

        (VALIDACION_X01 <> '' ) OR
        (VALIDACION_X02 <> '' ) OR
        (VALIDACION_X03 <> '' ) OR
        (VALIDACION_X04 <> '' ) OR
        (VALIDACION_X05 <> '' ) OR
        (VALIDACION_X06 <> '' ) OR
        (VALIDACION_X07 <> '' ) OR
        (VALIDACION_X08 <> '' ) OR
        (VALIDACION_X09 <> '' ) OR
        (VALIDACION_X10 <> '' ) OR
        (VALIDACION_X11 <> '' ) OR
        (VALIDACION_X12 <> '' ) OR
        (VALIDACION_X13 <> '' ) OR
        (VALIDACION_X14 <> '' ) OR
        (VALIDACION_X15 <> '' ) OR
        (VALIDACION_X16 <> '' ) OR
        (VALIDACION_X17 <> '' ) OR
        (VALIDACION_X18 <> '' ) OR
        (VALIDACION_X19 <> '' ) OR
        (VALIDACION_X20 <> '' ) OR
        (VALIDACION_X21 <> '' ) OR
        (VALIDACION_X22 <> '' ) OR
        (VALIDACION_X23 <> '' ) OR
        (VALIDACION_X24 <> '' ) OR
        (VALIDACION_X25 <> '' ) OR
        (VALIDACION_X26 <> '' ) OR
        (VALIDACION_X27 <> '' ) OR
        (VALIDACION_X28 <> '' ) OR
        (VALIDACION_X29 <> '' ) OR
        (VALIDACION_X30 <> '' ) OR
        (VALIDACION_X31 <> '' ) OR
        (VALIDACION_X32 <> '' ) OR
        (VALIDACION_X33 <> '' ) OR
        (VALIDACION_X34 <> '' ) OR
        (VALIDACION_X35 <> '' ) OR
        (VALIDACION_X36 <> '' ) OR
        (VALIDACION_X37 <> '' ) OR
        (VALIDACION_X38 <> '' ) OR
        (VALIDACION_X39 <> '' ) OR
        (VALIDACION_X40 <> '' ) OR
        (VALIDACION_X41 <> '' ) OR
        (VALIDACION_X42 <> '' ) OR
        (VALIDACION_X43 <> '' ) OR
        (VALIDACION_X44 <> '' ) OR
        (VALIDACION_X45 <> '' ) OR
        (VALIDACION_X46 <> '' ) OR
        (VALIDACION_X47 <> '' ) OR
        (VALIDACION_X48 <> '' ) OR
        (VALIDACION_X49 <> '' ) OR
        (VALIDACION_X50 <> '' ) OR
        (VALIDACION_X51 <> '' ) OR
        (VALIDACION_X52 <> '' ) OR
        (VALIDACION_X53 <> '' ) OR
        (VALIDACION_X54 <> '' ) OR
        (VALIDACION_X55 <> '' ) OR
        (VALIDACION_X56 <> '' ) OR
        (VALIDACION_X57 <> '' ) OR
        (VALIDACION_X58 <> '' ) OR
        (VALIDACION_X59 <> '' ) OR
        (VALIDACION_X60 <> '' ) OR
        (VALIDACION_X61 <> '' ) OR
        (VALIDACION_X62 <> '' ) OR
        (VALIDACION_X63 <> '' ) OR
        (VALIDACION_X64 <> '' ) OR
        (VALIDACION_X65 <> '' ) OR
        (VALIDACION_X66 <> '' ) OR
        (VALIDACION_X67 <> '' ) OR
        (VALIDACION_X68 <> '' ) OR
        (VALIDACION_X69 <> '' ) OR
        (VALIDACION_X70 <> '' ) OR
        (VALIDACION_X71 <> '' ) OR
        (VALIDACION_X72 <> '' ) OR
        (VALIDACION_X73 <> '' ) OR
        (VALIDACION_X74 <> '' ) OR
        (VALIDACION_X75 <> '' ) OR
        (VALIDACION_X76 <> '' ) OR
        (VALIDACION_X77 <> '' ) OR
        (VALIDACION_X78 <> '' ) OR
        (VALIDACION_X79 <> '' ) OR
        (VALIDACION_X80 <> '' ) OR
        (VALIDACION_X81 <> '' ) OR
        (VALIDACION_X82 <> '' ) OR
        (VALIDACION_X83 <> '' ) OR
        (VALIDACION_X84 <> '' ) OR
        (VALIDACION_X85 <> '' ) OR
        (VALIDACION_X86 <> '' ) OR
        (VALIDACION_X87 <> '' ) OR
        (VALIDACION_X88 <> '' ) OR
        (VALIDACION_X89 <> '' ) OR
        (VALIDACION_X90 <> '' ) OR
        (VALIDACION_X91 <> '' ) OR
        (VALIDACION_X92 <> '' ) OR
        (VALIDACION_X93 <> '' ) OR
        (VALIDACION_X94 <> '' ) OR
        (VALIDACION_X95 <> '' ) OR
        (VALIDACION_X96 <> '' ) OR
        (VALIDACION_X97 <> '' ) OR
        (VALIDACION_X98 <> '' ) OR
        (VALIDACION_X99 <> '' ) OR
        (VALIDACION_x00 <> '' ) 
ORDER BY 1
END

