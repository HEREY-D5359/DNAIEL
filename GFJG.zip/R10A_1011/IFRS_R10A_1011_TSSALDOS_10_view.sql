﻿
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Reclasificaciones. Reclasificaciones en el estado de situación financiera */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: Julio 2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: NA*/
/*TIPO SALDO: SALDOS*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/


CREATE OR ALTER PROCEDURE [dbo].[SP_IFRS9_R10A_1011_TSSALDOS_VIEW_10]
AS
BEGIN
	SELECT *
		
	FROM IFRS9_R10A_1011_TSSALDOS_RESULT_10
	WHERE

        (VALIDACION_901 <> '' ) OR
        (VALIDACION_902 <> '' ) OR
        (VALIDACION_903 <> '' ) OR
        (VALIDACION_904 <> '' ) OR
        (VALIDACION_905 <> '' ) OR
        (VALIDACION_906 <> '' ) OR
        (VALIDACION_907 <> '' ) OR
        (VALIDACION_908 <> '' ) OR
        (VALIDACION_909 <> '' ) OR
        (VALIDACION_910 <> '' ) OR
        (VALIDACION_911 <> '' ) OR
        (VALIDACION_912 <> '' ) OR
        (VALIDACION_913 <> '' ) OR
        (VALIDACION_914 <> '' ) OR
        (VALIDACION_915 <> '' ) OR
        (VALIDACION_916 <> '' ) OR
        (VALIDACION_917 <> '' ) OR
        (VALIDACION_918 <> '' ) OR
        (VALIDACION_919 <> '' ) OR
        (VALIDACION_920 <> '' ) OR
        (VALIDACION_921 <> '' ) OR
        (VALIDACION_922 <> '' ) OR
        (VALIDACION_923 <> '' ) OR
        (VALIDACION_924 <> '' ) OR
        (VALIDACION_925 <> '' ) OR
        (VALIDACION_926 <> '' ) OR
        (VALIDACION_927 <> '' ) OR
        (VALIDACION_928 <> '' ) OR
        (VALIDACION_929 <> '' ) OR
        (VALIDACION_930 <> '' ) OR
        (VALIDACION_931 <> '' ) OR
        (VALIDACION_932 <> '' ) OR
        (VALIDACION_933 <> '' ) OR
        (VALIDACION_934 <> '' ) OR
        (VALIDACION_935 <> '' ) OR
        (VALIDACION_936 <> '' ) OR
        (VALIDACION_937 <> '' ) OR
        (VALIDACION_938 <> '' ) OR
        (VALIDACION_939 <> '' ) OR
        (VALIDACION_940 <> '' ) OR
        (VALIDACION_941 <> '' ) OR
        (VALIDACION_942 <> '' ) OR
        (VALIDACION_943 <> '' ) OR
        (VALIDACION_944 <> '' ) OR
        (VALIDACION_945 <> '' ) OR
        (VALIDACION_946 <> '' ) OR
        (VALIDACION_947 <> '' ) OR
        (VALIDACION_948 <> '' ) OR
        (VALIDACION_949 <> '' ) OR
        (VALIDACION_950 <> '' ) OR
        (VALIDACION_951 <> '' ) OR
        (VALIDACION_952 <> '' ) OR
        (VALIDACION_953 <> '' ) OR
        (VALIDACION_954 <> '' ) OR
        (VALIDACION_955 <> '' ) OR
        (VALIDACION_956 <> '' ) OR
        (VALIDACION_957 <> '' ) OR
        (VALIDACION_958 <> '' ) OR
        (VALIDACION_959 <> '' ) OR
        (VALIDACION_960 <> '' ) OR
        (VALIDACION_961 <> '' ) OR
        (VALIDACION_962 <> '' ) OR
        (VALIDACION_963 <> '' ) OR
        (VALIDACION_964 <> '' ) OR
        (VALIDACION_965 <> '' ) OR
        (VALIDACION_966 <> '' ) OR
        (VALIDACION_967 <> '' ) OR
        (VALIDACION_968 <> '' ) OR
        (VALIDACION_969 <> '' ) OR
        (VALIDACION_970 <> '' ) OR
        (VALIDACION_971 <> '' ) OR
        (VALIDACION_972 <> '' ) OR
        (VALIDACION_973 <> '' ) OR
        (VALIDACION_974 <> '' ) OR
        (VALIDACION_975 <> '' ) OR
        (VALIDACION_976 <> '' ) OR
        (VALIDACION_977 <> '' ) OR
        (VALIDACION_978 <> '' ) OR
        (VALIDACION_979 <> '' ) OR
        (VALIDACION_980 <> '' ) OR
        (VALIDACION_981 <> '' ) OR
        (VALIDACION_982 <> '' ) OR
        (VALIDACION_983 <> '' ) OR
        (VALIDACION_984 <> '' ) OR
        (VALIDACION_985 <> '' ) OR
        (VALIDACION_986 <> '' ) OR
        (VALIDACION_987 <> '' ) OR
        (VALIDACION_988 <> '' ) OR
        (VALIDACION_989 <> '' ) OR
        (VALIDACION_990 <> '' ) OR
        (VALIDACION_991 <> '' ) OR
        (VALIDACION_992 <> '' ) OR
        (VALIDACION_993 <> '' ) OR
        (VALIDACION_994 <> '' ) OR
        (VALIDACION_995 <> '' ) OR
        (VALIDACION_996 <> '' ) OR
        (VALIDACION_997 <> '' ) OR
        (VALIDACION_998 <> '' ) OR
        (VALIDACION_999 <> '' ) OR
        (VALIDACION_1000 <> '' ) 
ORDER BY 1
END

