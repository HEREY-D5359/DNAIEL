﻿
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Reclasificaciones. Reclasificaciones en el estado de situación financiera */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: Julio 2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: NA*/
/*TIPO SALDO: 62*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: 0*/


CREATE OR ALTER PROCEDURE [dbo].[SP_IFRS9_R10A_1011_TS62TM0_VIEW_4]
AS
BEGIN
	SELECT *
		
	FROM IFRS9_R10A_1011_TS62TM0_RESULT_4
	WHERE

        (VALIDACION_301 <> '' ) OR
        (VALIDACION_302 <> '' ) OR
        (VALIDACION_303 <> '' ) OR
        (VALIDACION_304 <> '' ) OR
        (VALIDACION_305 <> '' ) OR
        (VALIDACION_306 <> '' ) OR
        (VALIDACION_307 <> '' ) OR
        (VALIDACION_308 <> '' ) OR
        (VALIDACION_309 <> '' ) OR
        (VALIDACION_310 <> '' ) OR
        (VALIDACION_311 <> '' ) OR
        (VALIDACION_312 <> '' ) OR
        (VALIDACION_313 <> '' ) OR
        (VALIDACION_314 <> '' ) OR
        (VALIDACION_315 <> '' ) OR
        (VALIDACION_316 <> '' ) OR
        (VALIDACION_317 <> '' ) OR
        (VALIDACION_318 <> '' ) OR
        (VALIDACION_319 <> '' ) OR
        (VALIDACION_320 <> '' ) OR
        (VALIDACION_321 <> '' ) OR
        (VALIDACION_322 <> '' ) OR
        (VALIDACION_323 <> '' ) OR
        (VALIDACION_324 <> '' ) OR
        (VALIDACION_325 <> '' ) OR
        (VALIDACION_326 <> '' ) OR
        (VALIDACION_327 <> '' ) OR
        (VALIDACION_328 <> '' ) OR
        (VALIDACION_329 <> '' ) OR
        (VALIDACION_330 <> '' ) OR
        (VALIDACION_331 <> '' ) OR
        (VALIDACION_332 <> '' ) OR
        (VALIDACION_333 <> '' ) OR
        (VALIDACION_334 <> '' ) OR
        (VALIDACION_335 <> '' ) OR
        (VALIDACION_336 <> '' ) OR
        (VALIDACION_337 <> '' ) OR
        (VALIDACION_338 <> '' ) OR
        (VALIDACION_339 <> '' ) OR
        (VALIDACION_340 <> '' ) OR
        (VALIDACION_341 <> '' ) OR
        (VALIDACION_342 <> '' ) OR
        (VALIDACION_343 <> '' ) OR
        (VALIDACION_344 <> '' ) OR
        (VALIDACION_345 <> '' ) OR
        (VALIDACION_346 <> '' ) OR
        (VALIDACION_347 <> '' ) OR
        (VALIDACION_348 <> '' ) OR
        (VALIDACION_349 <> '' ) OR
        (VALIDACION_350 <> '' ) OR
        (VALIDACION_351 <> '' ) OR
        (VALIDACION_352 <> '' ) OR
        (VALIDACION_353 <> '' ) OR
        (VALIDACION_354 <> '' ) OR
        (VALIDACION_355 <> '' ) OR
        (VALIDACION_356 <> '' ) OR
        (VALIDACION_357 <> '' ) OR
        (VALIDACION_358 <> '' ) OR
        (VALIDACION_359 <> '' ) OR
        (VALIDACION_360 <> '' ) OR
        (VALIDACION_361 <> '' ) OR
        (VALIDACION_362 <> '' ) OR
        (VALIDACION_363 <> '' ) OR
        (VALIDACION_364 <> '' ) OR
        (VALIDACION_365 <> '' ) OR
        (VALIDACION_366 <> '' ) OR
        (VALIDACION_367 <> '' ) OR
        (VALIDACION_368 <> '' ) OR
        (VALIDACION_369 <> '' ) OR
        (VALIDACION_370 <> '' ) OR
        (VALIDACION_371 <> '' ) OR
        (VALIDACION_372 <> '' ) OR
        (VALIDACION_373 <> '' ) OR
        (VALIDACION_374 <> '' ) OR
        (VALIDACION_375 <> '' ) OR
        (VALIDACION_376 <> '' ) OR
        (VALIDACION_377 <> '' ) OR
        (VALIDACION_378 <> '' ) OR
        (VALIDACION_379 <> '' ) OR
        (VALIDACION_380 <> '' ) OR
        (VALIDACION_381 <> '' ) OR
        (VALIDACION_382 <> '' ) OR
        (VALIDACION_383 <> '' ) OR
        (VALIDACION_384 <> '' ) OR
        (VALIDACION_385 <> '' ) OR
        (VALIDACION_386 <> '' ) OR
        (VALIDACION_387 <> '' ) OR
        (VALIDACION_388 <> '' ) OR
        (VALIDACION_389 <> '' ) OR
        (VALIDACION_390 <> '' ) OR
        (VALIDACION_391 <> '' ) OR
        (VALIDACION_392 <> '' ) OR
        (VALIDACION_393 <> '' ) OR
        (VALIDACION_394 <> '' ) OR
        (VALIDACION_395 <> '' ) OR
        (VALIDACION_396 <> '' ) OR
        (VALIDACION_397 <> '' ) OR
        (VALIDACION_398 <> '' ) OR
        (VALIDACION_399 <> '' ) OR
        (VALIDACION_400 <> '' ) 
ORDER BY 1
END

