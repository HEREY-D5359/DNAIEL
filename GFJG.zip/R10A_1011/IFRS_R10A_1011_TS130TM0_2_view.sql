﻿
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Reclasificaciones. Reclasificaciones en el estado de situación financiera */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: Julio 2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: NA*/
/*TIPO SALDO: 130*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: 0*/


CREATE OR ALTER PROCEDURE [dbo].[SP_IFRS9_R10A_1011_TS130TM0_VIEW_2]
AS
BEGIN
	SELECT *
		
	FROM IFRS9_R10A_1011_TS130TM0_RESULT_2
	WHERE

        (VALIDACION_101 <> '' ) OR
        (VALIDACION_102 <> '' ) OR
        (VALIDACION_103 <> '' ) OR
        (VALIDACION_104 <> '' ) OR
        (VALIDACION_105 <> '' ) OR
        (VALIDACION_106 <> '' ) OR
        (VALIDACION_107 <> '' ) OR
        (VALIDACION_108 <> '' ) OR
        (VALIDACION_109 <> '' ) OR
        (VALIDACION_110 <> '' ) OR
        (VALIDACION_111 <> '' ) OR
        (VALIDACION_112 <> '' ) OR
        (VALIDACION_113 <> '' ) OR
        (VALIDACION_114 <> '' ) OR
        (VALIDACION_115 <> '' ) OR
        (VALIDACION_116 <> '' ) OR
        (VALIDACION_117 <> '' ) OR
        (VALIDACION_118 <> '' ) OR
        (VALIDACION_119 <> '' ) OR
        (VALIDACION_120 <> '' ) OR
        (VALIDACION_121 <> '' ) OR
        (VALIDACION_122 <> '' ) OR
        (VALIDACION_123 <> '' ) OR
        (VALIDACION_124 <> '' ) OR
        (VALIDACION_125 <> '' ) OR
        (VALIDACION_126 <> '' ) OR
        (VALIDACION_127 <> '' ) OR
        (VALIDACION_128 <> '' ) OR
        (VALIDACION_129 <> '' ) OR
        (VALIDACION_130 <> '' ) OR
        (VALIDACION_131 <> '' ) OR
        (VALIDACION_132 <> '' ) OR
        (VALIDACION_133 <> '' ) OR
        (VALIDACION_134 <> '' ) OR
        (VALIDACION_135 <> '' ) OR
        (VALIDACION_136 <> '' ) OR
        (VALIDACION_137 <> '' ) OR
        (VALIDACION_138 <> '' ) OR
        (VALIDACION_139 <> '' ) OR
        (VALIDACION_140 <> '' ) OR
        (VALIDACION_141 <> '' ) OR
        (VALIDACION_142 <> '' ) OR
        (VALIDACION_143 <> '' ) OR
        (VALIDACION_144 <> '' ) OR
        (VALIDACION_145 <> '' ) OR
        (VALIDACION_146 <> '' ) OR
        (VALIDACION_147 <> '' ) OR
        (VALIDACION_148 <> '' ) OR
        (VALIDACION_149 <> '' ) OR
        (VALIDACION_150 <> '' ) OR
        (VALIDACION_151 <> '' ) OR
        (VALIDACION_152 <> '' ) OR
        (VALIDACION_153 <> '' ) OR
        (VALIDACION_154 <> '' ) OR
        (VALIDACION_155 <> '' ) OR
        (VALIDACION_156 <> '' ) OR
        (VALIDACION_157 <> '' ) OR
        (VALIDACION_158 <> '' ) OR
        (VALIDACION_159 <> '' ) OR
        (VALIDACION_160 <> '' ) OR
        (VALIDACION_161 <> '' ) OR
        (VALIDACION_162 <> '' ) OR
        (VALIDACION_163 <> '' ) OR
        (VALIDACION_164 <> '' ) OR
        (VALIDACION_165 <> '' ) OR
        (VALIDACION_166 <> '' ) OR
        (VALIDACION_167 <> '' ) OR
        (VALIDACION_168 <> '' ) OR
        (VALIDACION_169 <> '' ) OR
        (VALIDACION_170 <> '' ) OR
        (VALIDACION_171 <> '' ) OR
        (VALIDACION_172 <> '' ) OR
        (VALIDACION_173 <> '' ) OR
        (VALIDACION_174 <> '' ) OR
        (VALIDACION_175 <> '' ) OR
        (VALIDACION_176 <> '' ) OR
        (VALIDACION_177 <> '' ) OR
        (VALIDACION_178 <> '' ) OR
        (VALIDACION_179 <> '' ) OR
        (VALIDACION_180 <> '' ) OR
        (VALIDACION_181 <> '' ) OR
        (VALIDACION_182 <> '' ) OR
        (VALIDACION_183 <> '' ) OR
        (VALIDACION_184 <> '' ) OR
        (VALIDACION_185 <> '' ) OR
        (VALIDACION_186 <> '' ) OR
        (VALIDACION_187 <> '' ) OR
        (VALIDACION_188 <> '' ) OR
        (VALIDACION_189 <> '' ) OR
        (VALIDACION_190 <> '' ) OR
        (VALIDACION_191 <> '' ) OR
        (VALIDACION_192 <> '' ) OR
        (VALIDACION_193 <> '' ) OR
        (VALIDACION_194 <> '' ) OR
        (VALIDACION_195 <> '' ) OR
        (VALIDACION_196 <> '' ) OR
        (VALIDACION_197 <> '' ) OR
        (VALIDACION_198 <> '' ) OR
        (VALIDACION_199 <> '' ) OR
        (VALIDACION_200 <> '' ) 
ORDER BY 1
END

