﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Consolidación. Consolidación del estado de situación financiera de la institución de crédito con sus subsidiarias */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: AGOSTO 2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: NA*/
/*TIPO SALDO: SALDOS*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/
/*SUBSIDIARIA: 0*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R12A_1219_TSSALDOSSUBS0_COMP_6]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R12A_1219_TSSALDOSSUBS0_RESULT_6')
BEGIN
DROP TABLE IFRS9_R12A_1219_TSSALDOSSUBS0_RESULT_6
END 

BEGIN
SELECT DISTINCT

    /*ID*/

    CONVERT(VARCHAR,ID) AS ID,                                    /*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801206045')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801206045')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801206045')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801206045) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101801206045) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101801206045) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_501,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801206046')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801206046')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801206046')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801206046) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101801206046) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101801206046) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_502,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801206047')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801206047')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801206047')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801206047) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101801206047) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101801206047) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_503,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801206048')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801206048')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801206048')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801206048) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101801206048) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101801206048) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_504,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801206049')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801206049')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801206049')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801206049) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101801206049) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101801206049) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_505,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800405013')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800405013')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800405013')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800405013) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101800405013) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101800405013) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_506,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801306050')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801306050')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801306050')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801306050) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101801306050) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101801306050) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_507,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801306051')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801306051')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801306051')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801306051) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101801306051) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101801306051) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_508,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801306052')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801306052')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801306052')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801306052) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101801306052) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101801306052) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_509,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101805207079')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805207079')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805207079')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805207079) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101805207079) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101805207079) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_510,

/*Cartera en prórroga*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101805207080')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805207080')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805207080')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805207080) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101805207080) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101805207080) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_511,

/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101805207081')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805207081')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805207081')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805207081) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101805207081) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101805207081) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_512,

/*Remodelación o mejoramiento con garantía otorgada por la banca de desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801306053')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801306053')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801306053')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801306053) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101801306053) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101801306053) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_513,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801306054')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801306054')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801306054')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801306054) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101801306054) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101801306054) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_514,

/*Cartera de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('131800103001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('131800103001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('131800103001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (131800103001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (131800103001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (131800103001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_515,

/*Partidas diferidas (2)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('131800103002')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('131800103002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('131800103002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (131800103002) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (131800103002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (131800103002) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_516,

/*Estimación preventiva para riesgos crediticios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800103003')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800103003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800103003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800103003) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101800103003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101800103003) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_517,

/*Estimación preventiva para riesgos crediticios derivada de la calificación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800304005')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800304005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800304005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800304005) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101800304005) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101800304005) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_518,

/*Cartera con riesgo de crédito etapa 1*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800505014')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800505014')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800505014')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800505014) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101800505014) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101800505014) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_519,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801406055')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801406055')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801406055')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801406055) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101801406055) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101801406055) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_520,

/*Créditos comerciales sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101805507082')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805507082')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805507082')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805507082) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101805507082) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101805507082) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_521,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101808208125')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101808208125')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101808208125')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101808208125) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101808208125) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101808208125) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_522,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812509169')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812509169')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812509169')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101812509169) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101812509169) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101812509169) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_523,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101816910145')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101816910145')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101816910145')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101816910145) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101816910145) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101816910145) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_524,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101816910146')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101816910146')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101816910146')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101816910146) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101816910146) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101816910146) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_525,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812509170')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812509170')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812509170')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101812509170) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101812509170) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101812509170) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_526,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101817010147')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101817010147')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101817010147')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101817010147) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101817010147) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101817010147) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_527,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101817010148')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101817010148')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101817010148')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101817010148) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101817010148) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101817010148) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_528,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101817010149')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101817010149')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101817010149')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101817010149) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101817010149) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101817010149) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_529,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812509171')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812509171')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812509171')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101812509171) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101812509171) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101812509171) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_530,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101817110150')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101817110150')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101817110150')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101817110150) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101817110150) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101817110150) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_531,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101817110151')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101817110151')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101817110151')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101817110151) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101817110151) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101817110151) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_532,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812509172')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812509172')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812509172')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101812509172) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101812509172) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101812509172) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_533,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812509173')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812509173')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812509173')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101812509173) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101812509173) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101812509173) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_534,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812509174')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812509174')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812509174')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101812509174) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101812509174) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101812509174) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_535,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812509175')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812509175')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812509175')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101812509175) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101812509175) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101812509175) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_536,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812509176')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812509176')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812509176')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101812509176) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101812509176) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101812509176) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_537,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101808208126')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101808208126')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101808208126')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101808208126) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101808208126) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101808208126) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_538,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812609177')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812609177')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812609177')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101812609177) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101812609177) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101812609177) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_539,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101817710202')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101817710202')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101817710202')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101817710202) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101817710202) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101817710202) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_540,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101817710203')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101817710203')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101817710203')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101817710203) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101817710203) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101817710203) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_541,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101817710204')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101817710204')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101817710204')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101817710204) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101817710204) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101817710204) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_542,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812609178')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812609178')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812609178')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101812609178) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101812609178) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101812609178) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_543,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101817810205')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101817810205')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101817810205')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101817810205) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101817810205) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101817810205) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_544,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101817810206')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101817810206')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101817810206')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101817810206) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101817810206) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101817810206) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_545,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101817810207')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101817810207')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101817810207')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101817810207) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101817810207) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101817810207) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_546,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101808208127')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101808208127')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101808208127')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101808208127) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101808208127) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101808208127) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_547,

/*Créditos al gobierno federal*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812709179')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812709179')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812709179')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101812709179) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101812709179) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101812709179) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_548,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812709180')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812709180')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812709180')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101812709180) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101812709180) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101812709180) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_549,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101818010219')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818010219')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818010219')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101818010219) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101818010219) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101818010219) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_550,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101818010220')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818010220')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818010220')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101818010220) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101818010220) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101818010220) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_551,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101818010221')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818010221')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818010221')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101818010221) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101818010221) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101818010221) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_552,

/*Fideicomisos públicos de contratación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101818010222')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818010222')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818010222')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101818010222) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101818010222) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101818010222) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_553,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101818010223')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818010223')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818010223')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101818010223) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101818010223) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101818010223) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_554,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812709181')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812709181')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812709181')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101812709181) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101812709181) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101812709181) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_555,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101818110224')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818110224')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818110224')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101818110224) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101818110224) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101818110224) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_556,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101818110225')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818110225')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818110225')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101818110225) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101818110225) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101818110225) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_557,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101818110226')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818110226')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818110226')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101818110226) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101818110226) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101818110226) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_558,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101818110227')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818110227')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818110227')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101818110227) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101818110227) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101818110227) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_559,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812709182')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812709182')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812709182')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101812709182) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101812709182) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101812709182) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_560,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101818210228')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818210228')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818210228')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101818210228) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101818210228) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101818210228) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_561,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101818210229')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818210229')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818210229')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101818210229) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101818210229) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101818210229) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_562,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101818210230')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818210230')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818210230')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101818210230) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101818210230) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101818210230) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_563,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101818210231')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818210231')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818210231')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101818210231) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101818210231) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101818210231) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_564,

/*Créditos comerciales restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101805507083')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805507083')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805507083')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805507083) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101805507083) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101805507083) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_565,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101808308128')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101808308128')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101808308128')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101808308128) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101808308128) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101808308128) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_566,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812809183')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812809183')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812809183')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101812809183) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101812809183) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101812809183) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_567,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101818310232')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818310232')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818310232')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101818310232) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101818310232) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101818310232) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_568,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101818310233')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818310233')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818310233')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101818310233) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101818310233) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101818310233) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_569,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812809184')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812809184')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812809184')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101812809184) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101812809184) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101812809184) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_570,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101818410234')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818410234')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818410234')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101818410234) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101818410234) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101818410234) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_571,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101818410235')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818410235')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818410235')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101818410235) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101818410235) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101818410235) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_572,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101818410236')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818410236')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818410236')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101818410236) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101818410236) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101818410236) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_573,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812809185')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812809185')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812809185')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101812809185) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101812809185) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101812809185) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_574,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101818510237')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818510237')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818510237')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101818510237) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101818510237) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101818510237) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_575,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101818510238')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818510238')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818510238')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101818510238) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101818510238) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101818510238) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_576,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812809186')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812809186')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812809186')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101812809186) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101812809186) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101812809186) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_577,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812809187')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812809187')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812809187')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101812809187) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101812809187) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101812809187) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_578,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812809188')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812809188')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812809188')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101812809188) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101812809188) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101812809188) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_579,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812809189')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812809189')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812809189')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101812809189) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101812809189) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101812809189) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_580,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812809190')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812809190')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812809190')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101812809190) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101812809190) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101812809190) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_581,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101808308129')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101808308129')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101808308129')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101808308129) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101808308129) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101808308129) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_582,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812909191')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812909191')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812909191')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101812909191) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101812909191) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101812909191) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_583,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101819110239')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101819110239')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101819110239')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101819110239) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101819110239) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101819110239) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_584,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101819110240')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101819110240')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101819110240')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101819110240) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101819110240) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101819110240) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_585,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101819110241')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101819110241')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101819110241')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101819110241) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101819110241) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101819110241) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_586,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812909192')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812909192')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812909192')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101812909192) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101812909192) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101812909192) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_587,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101819210242')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101819210242')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101819210242')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101819210242) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101819210242) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101819210242) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_588,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101819210243')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101819210243')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101819210243')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101819210243) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101819210243) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101819210243) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_589,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101819210244')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101819210244')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101819210244')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101819210244) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101819210244) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101819210244) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_590,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101808308130')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101808308130')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101808308130')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101808308130) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101808308130) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101808308130) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_591,

/*Créditos al gobierno federal*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101813009193')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101813009193')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101813009193')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101813009193) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101813009193) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101813009193) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_592,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101813009194')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101813009194')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101813009194')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101813009194) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101813009194) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101813009194) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_593,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101819410245')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101819410245')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101819410245')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101819410245) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101819410245) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101819410245) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_594,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101819410246')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101819410246')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101819410246')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101819410246) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101819410246) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101819410246) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_595,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101819410247')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101819410247')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101819410247')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101819410247) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101819410247) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101819410247) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_596,

/*Fideicomisos públicos de contratación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101819410248')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101819410248')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101819410248')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101819410248) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101819410248) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101819410248) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_597,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101819410249')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101819410249')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101819410249')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101819410249) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101819410249) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101819410249) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_598,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101813009195')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101813009195')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101813009195')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101813009195) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101813009195) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101813009195) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_599,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101819510250')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101819510250')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101819510250')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101819510250) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101819510250) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101819510250) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_600
	
INTO IFRS9_R12A_1219_TSSALDOSSUBS0_RESULT_6
FROM IFRS9_R12A_1219

END

BEGIN
	INSERT INTO IFRS9_R12A_1219_TSSALDOSSUBS0_RESULT_6 IFRS9_R12A_1219_TSSALDOSSUBS0_RESULT_6 
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_501])),
            SUM(CHARINDEX('ERR',[VALIDACION_502])),
            SUM(CHARINDEX('ERR',[VALIDACION_503])),
            SUM(CHARINDEX('ERR',[VALIDACION_504])),
            SUM(CHARINDEX('ERR',[VALIDACION_505])),
            SUM(CHARINDEX('ERR',[VALIDACION_506])),
            SUM(CHARINDEX('ERR',[VALIDACION_507])),
            SUM(CHARINDEX('ERR',[VALIDACION_508])),
            SUM(CHARINDEX('ERR',[VALIDACION_509])),
            SUM(CHARINDEX('ERR',[VALIDACION_510])),
            SUM(CHARINDEX('ERR',[VALIDACION_511])),
            SUM(CHARINDEX('ERR',[VALIDACION_512])),
            SUM(CHARINDEX('ERR',[VALIDACION_513])),
            SUM(CHARINDEX('ERR',[VALIDACION_514])),
            SUM(CHARINDEX('ERR',[VALIDACION_515])),
            SUM(CHARINDEX('ERR',[VALIDACION_516])),
            SUM(CHARINDEX('ERR',[VALIDACION_517])),
            SUM(CHARINDEX('ERR',[VALIDACION_518])),
            SUM(CHARINDEX('ERR',[VALIDACION_519])),
            SUM(CHARINDEX('ERR',[VALIDACION_520])),
            SUM(CHARINDEX('ERR',[VALIDACION_521])),
            SUM(CHARINDEX('ERR',[VALIDACION_522])),
            SUM(CHARINDEX('ERR',[VALIDACION_523])),
            SUM(CHARINDEX('ERR',[VALIDACION_524])),
            SUM(CHARINDEX('ERR',[VALIDACION_525])),
            SUM(CHARINDEX('ERR',[VALIDACION_526])),
            SUM(CHARINDEX('ERR',[VALIDACION_527])),
            SUM(CHARINDEX('ERR',[VALIDACION_528])),
            SUM(CHARINDEX('ERR',[VALIDACION_529])),
            SUM(CHARINDEX('ERR',[VALIDACION_530])),
            SUM(CHARINDEX('ERR',[VALIDACION_531])),
            SUM(CHARINDEX('ERR',[VALIDACION_532])),
            SUM(CHARINDEX('ERR',[VALIDACION_533])),
            SUM(CHARINDEX('ERR',[VALIDACION_534])),
            SUM(CHARINDEX('ERR',[VALIDACION_535])),
            SUM(CHARINDEX('ERR',[VALIDACION_536])),
            SUM(CHARINDEX('ERR',[VALIDACION_537])),
            SUM(CHARINDEX('ERR',[VALIDACION_538])),
            SUM(CHARINDEX('ERR',[VALIDACION_539])),
            SUM(CHARINDEX('ERR',[VALIDACION_540])),
            SUM(CHARINDEX('ERR',[VALIDACION_541])),
            SUM(CHARINDEX('ERR',[VALIDACION_542])),
            SUM(CHARINDEX('ERR',[VALIDACION_543])),
            SUM(CHARINDEX('ERR',[VALIDACION_544])),
            SUM(CHARINDEX('ERR',[VALIDACION_545])),
            SUM(CHARINDEX('ERR',[VALIDACION_546])),
            SUM(CHARINDEX('ERR',[VALIDACION_547])),
            SUM(CHARINDEX('ERR',[VALIDACION_548])),
            SUM(CHARINDEX('ERR',[VALIDACION_549])),
            SUM(CHARINDEX('ERR',[VALIDACION_550])),
            SUM(CHARINDEX('ERR',[VALIDACION_551])),
            SUM(CHARINDEX('ERR',[VALIDACION_552])),
            SUM(CHARINDEX('ERR',[VALIDACION_553])),
            SUM(CHARINDEX('ERR',[VALIDACION_554])),
            SUM(CHARINDEX('ERR',[VALIDACION_555])),
            SUM(CHARINDEX('ERR',[VALIDACION_556])),
            SUM(CHARINDEX('ERR',[VALIDACION_557])),
            SUM(CHARINDEX('ERR',[VALIDACION_558])),
            SUM(CHARINDEX('ERR',[VALIDACION_559])),
            SUM(CHARINDEX('ERR',[VALIDACION_560])),
            SUM(CHARINDEX('ERR',[VALIDACION_561])),
            SUM(CHARINDEX('ERR',[VALIDACION_562])),
            SUM(CHARINDEX('ERR',[VALIDACION_563])),
            SUM(CHARINDEX('ERR',[VALIDACION_564])),
            SUM(CHARINDEX('ERR',[VALIDACION_565])),
            SUM(CHARINDEX('ERR',[VALIDACION_566])),
            SUM(CHARINDEX('ERR',[VALIDACION_567])),
            SUM(CHARINDEX('ERR',[VALIDACION_568])),
            SUM(CHARINDEX('ERR',[VALIDACION_569])),
            SUM(CHARINDEX('ERR',[VALIDACION_570])),
            SUM(CHARINDEX('ERR',[VALIDACION_571])),
            SUM(CHARINDEX('ERR',[VALIDACION_572])),
            SUM(CHARINDEX('ERR',[VALIDACION_573])),
            SUM(CHARINDEX('ERR',[VALIDACION_574])),
            SUM(CHARINDEX('ERR',[VALIDACION_575])),
            SUM(CHARINDEX('ERR',[VALIDACION_576])),
            SUM(CHARINDEX('ERR',[VALIDACION_577])),
            SUM(CHARINDEX('ERR',[VALIDACION_578])),
            SUM(CHARINDEX('ERR',[VALIDACION_579])),
            SUM(CHARINDEX('ERR',[VALIDACION_580])),
            SUM(CHARINDEX('ERR',[VALIDACION_581])),
            SUM(CHARINDEX('ERR',[VALIDACION_582])),
            SUM(CHARINDEX('ERR',[VALIDACION_583])),
            SUM(CHARINDEX('ERR',[VALIDACION_584])),
            SUM(CHARINDEX('ERR',[VALIDACION_585])),
            SUM(CHARINDEX('ERR',[VALIDACION_586])),
            SUM(CHARINDEX('ERR',[VALIDACION_587])),
            SUM(CHARINDEX('ERR',[VALIDACION_588])),
            SUM(CHARINDEX('ERR',[VALIDACION_589])),
            SUM(CHARINDEX('ERR',[VALIDACION_590])),
            SUM(CHARINDEX('ERR',[VALIDACION_591])),
            SUM(CHARINDEX('ERR',[VALIDACION_592])),
            SUM(CHARINDEX('ERR',[VALIDACION_593])),
            SUM(CHARINDEX('ERR',[VALIDACION_594])),
            SUM(CHARINDEX('ERR',[VALIDACION_595])),
            SUM(CHARINDEX('ERR',[VALIDACION_596])),
            SUM(CHARINDEX('ERR',[VALIDACION_597])),
            SUM(CHARINDEX('ERR',[VALIDACION_598])),
            SUM(CHARINDEX('ERR',[VALIDACION_599])),
            SUM(CHARINDEX('ERR',[VALIDACION_600]))
            


		FROM IFRS9_R12A_1219_TSSALDOSSUBS0_RESULT_6 
END

BEGIN
	EXEC SP_IFRS9_R12A_1219_TSSALDOSSUBS0_VIEW_6IFRS9_R12A_1219_TSSALDOSSUBS0_VIEW_6
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


