﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Consolidación. Consolidación del estado de situación financiera de la institución de crédito con sus subsidiarias */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: AGOSTO 2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: NA*/
/*TIPO SALDO: 136*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: 0*/
/*SUBSIDIARIA: 0*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R12A_1219_TS136TM0SUBS0_COMP_2]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R12A_1219_TS136TM0SUBS0_RESULT_2')
BEGIN
DROP TABLE IFRS9_R12A_1219_TS136TM0SUBS0_RESULT_2
END 

BEGIN
SELECT DISTINCT

	/*ID*/

	CONVERT(VARCHAR,ID)  AS ID,   
	/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800105003')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800306005','101800306006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800105003) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800306005 + 101800306006) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_101,

/*Créditos a la vivienda sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800306005')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800507023','101800507024','101800507025','101800507026','101800507027')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800306005) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800507023 + 101800507024 + 101800507025 + 101800507026 + 101800507027) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_102,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800507025')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101802508029','101802508030','101802508031')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800507025) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101802508029 + 101802508030 + 101802508031) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_103,

/*Créditos a la vivienda restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800306006')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800607028','101800607029','101800607030','101800607031','101800607032')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800306006) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800607028 + 101800607029 + 101800607030 + 101800607031 + 101800607032) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_104,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800607030')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101803008032','101803008033','101803008034')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800607030) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101803008032 + 101803008033 + 101803008034) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_105,

/*Cartera de crédito con riesgo de crédito etapa 2*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800104002')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800205005','101800205006','101800205007')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800104002) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800205005 + 101800205006 + 101800205007) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_106,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800205005')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800506007','101800506008','101800506009')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800205005) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800506007 + 101800506008 + 101800506009) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_107,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800506007')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800707033','101800707034','101800707035','101800707036','101800707037','101800707038','101800707039','101800707040')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800506007) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800707033 + 101800707034 + 101800707035 + 101800707036 + 101800707037 + 101800707038 + 101800707039 + 101800707040) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_108,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800707033')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101803308035','101803308036')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800707033) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101803308035 + 101803308036) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_109,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800707034')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101803408037','101803408038','101803408039')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800707034) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101803408037 + 101803408038 + 101803408039) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_110,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800707035')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101803508040','101803508041')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800707035) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101803508040 + 101803508041) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_111,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800506008')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800807041','101800807042')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800506008) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800807041 + 101800807042) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_112,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800807041')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101804108043','101804108044','101804108045')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800807041) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101804108043 + 101804108044 + 101804108045) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_113,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800807042')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101804208048','101804208049','101804208050')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800807042) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101804208048 + 101804208049 + 101804208050) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_114,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800506009')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800907043','101800907044','101800907045','101800907046')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800506009) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800907043 + 101800907044 + 101800907045 + 101800907046) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_115,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800907044')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101804408052','101804408053','101804408054','101804408055','101804408056')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800907044) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101804408052 + 101804408053 + 101804408054 + 101804408055 + 101804408056) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_116,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800907045')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101804508057','101804508058','101804508059','101804508060')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800907045) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101804508057 + 101804508058 + 101804508059 + 101804508060) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_117,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800907046')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101804608061','101804608062','101804608063','101804608064')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800907046) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101804608061 + 101804608062 + 101804608063 + 101804608064) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_118,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800205006')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800606010','101800606011','101800606012','101800606013','101800606014','101800606015','101800606016','101800606017')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800205006) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800606010 + 101800606011 + 101800606012 + 101800606013 + 101800606014 + 101800606015 + 101800606016 + 101800606017) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_119,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800205007')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800706018','101800706019','101800706020','101800706021','101800706022')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800205007) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800706018 + 101800706019 + 101800706020 + 101800706021 + 101800706022) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_120,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800706020')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101802007047','101802007048')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800706020) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101802007047 + 101802007048) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_121,

/*Cartera de crédito con riesgo de crédito etapa 3*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800104003')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800305008','101800305009','101800305010')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800104003) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800305008 + 101800305009 + 101800305010) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_122,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800305008')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800806023','101800806024','101800806025')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800305008) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800806023 + 101800806024 + 101800806025) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_123,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800806023')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101802307049','101802307050','101802307051','101802307052','101802307053','101802307054','101802307055','101802307056')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800806023) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101802307049 + 101802307050 + 101802307051 + 101802307052 + 101802307053 + 101802307054 + 101802307055 + 101802307056) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_124,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101802307049')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101804908065','101804908066')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101802307049) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101804908065 + 101804908066) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_125,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101802307050')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805008067','101805008068','101805008069')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101802307050) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101805008067 + 101805008068 + 101805008069) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_126,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101802307051')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805108070','101805108071')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101802307051) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101805108070 + 101805108071) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_127,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800806024')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101802407057','101802407058')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800806024) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101802407057 + 101802407058) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_128,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101802407057')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805708073','101805708074','101805708075')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101802407057) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101805708073 + 101805708074 + 101805708075) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_129,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101802407058')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805808078','101805808079','101805808080')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101802407058) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101805808078 + 101805808079 + 101805808080) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_130,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800806025')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101802507059','101802507060','101802507061','101802507062')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800806025) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101802507059 + 101802507060 + 101802507061 + 101802507062) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_131,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101802507060')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806008082','101806008083','101806008084','101806008085','101806008086')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101802507060) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101806008082 + 101806008083 + 101806008084 + 101806008085 + 101806008086) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_132,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101802507061')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806108087','101806108088','101806108089','101806108090')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101802507061) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101806108087 + 101806108088 + 101806108089 + 101806108090) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_133,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101802507062')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806208091','101806208092','101806208093','101806208094')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101802507062) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101806208091 + 101806208092 + 101806208093 + 101806208094) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_134,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800305009')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800906026','101800906027','101800906028','101800906029','101800906030','101800906031','101800906032','101800906033')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800305009) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800906026 + 101800906027 + 101800906028 + 101800906029 + 101800906030 + 101800906031 + 101800906032 + 101800906033) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_135,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800305010')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801006034','101801006035','101801006036','101801006037','101801006038')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800305010) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101801006034 + 101801006035 + 101801006036 + 101801006037 + 101801006038) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_136,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801006036')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101803607063','101803607064')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101801006036) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101803607063 + 101803607064) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_137,

/*Cartera de crédito valuada a valor razonable*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800104004')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800405011','101800405012','101800405013')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800104004) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800405011 + 101800405012 + 101800405013) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_138,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800405011')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801106039','101801106040','101801106041')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800405011) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101801106039 + 101801106040 + 101801106041) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_139,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801106039')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101803907065','101803907066','101803907067','101803907068','101803907069','101803907070','101803907071','101803907072')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101801106039) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101803907065 + 101803907066 + 101803907067 + 101803907068 + 101803907069 + 101803907070 + 101803907071 + 101803907072) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_140,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101803907065')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806508095','101806508096')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101803907065) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101806508095 + 101806508096) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_141,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101803907066')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806608097','101806608098','101806608099')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101803907066) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101806608097 + 101806608098 + 101806608099) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_142,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101803907067')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806708100','101806708101')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101803907067) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101806708100 + 101806708101) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_143,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801106040')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101804007073','101804007074')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101801106040) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101804007073 + 101804007074) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_144,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101804007073')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807308103','101807308104','101807308105')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101804007073) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101807308103 + 101807308104 + 101807308105) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_145,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101804007074')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807408108','101807408109','101807408110')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101804007074) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101807408108 + 101807408109 + 101807408110) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_146,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801106041')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101804107075','101804107076','101804107077','101804107078')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101801106041) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101804107075 + 101804107076 + 101804107077 + 101804107078) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_147,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101804107076')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807608112','101807608113','101807608114','101807608115','101807608116')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101804107076) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101807608112 + 101807608113 + 101807608114 + 101807608115 + 101807608116) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_148,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101804107077')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807708117','101807708118','101807708119','101807708120')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101804107077) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101807708117 + 101807708118 + 101807708119 + 101807708120) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_149,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101804107078')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807808121','101807808122','101807808123','101807808124')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101804107078) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101807808121 + 101807808122 + 101807808123 + 101807808124) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_150,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800405012')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801206042','101801206043','101801206044','101801206045','101801206046','101801206047','101801206048','101801206049')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800405012) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101801206042 + 101801206043 + 101801206044 + 101801206045 + 101801206046 + 101801206047 + 101801206048 + 101801206049) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_151,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800405013')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801306050','101801306051','101801306052','101801306053','101801306054')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800405013) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101801306050 + 101801306051 + 101801306052 + 101801306053 + 101801306054) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_152,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801306052')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805207079','101805207080','101805207081')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101801306052) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101805207079 + 101805207080 + 101805207081) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_153,

/*Estimación preventiva para riesgos crediticios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800103003')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800304005','101800304006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800103003) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800304005 + 101800304006) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_154,

/*Estimación preventiva para riesgos crediticios derivada de la calificación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800304005')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800505014','101800505016','101800505018','101800505020')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800304005) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800505014 + 101800505016 + 101800505018 + 101800505020) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_155,

/*Cartera con riesgo de crédito etapa 1*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800505014')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801406055','101801406056','101801406057')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800505014) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101801406055 + 101801406056 + 101801406057) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_156,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801406055')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805507082','101805507083')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101801406055) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101805507082 + 101805507083) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_157,

/*Créditos comerciales sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101805507082')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101808208125','101808208126','101808208127')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101805507082) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101808208125 + 101808208126 + 101808208127) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_158,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101808208125')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812509169','101812509170','101812509171','101812509172','101812509173','101812509174','101812509175','101812509176')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101808208125) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101812509169 + 101812509170 + 101812509171 + 101812509172 + 101812509173 + 101812509174 + 101812509175 + 101812509176) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_159,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812509169')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101816910145','101816910146')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812509169) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101816910145 + 101816910146) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_160,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812509170')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101817010147','101817010148','101817010149')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812509170) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101817010147 + 101817010148 + 101817010149) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_161,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812509171')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101817110150','101817110151')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812509171) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101817110150 + 101817110151) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_162,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101808208126')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812609177','101812609178')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101808208126) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101812609177 + 101812609178) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_163,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812609177')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101817710202','101817710203','101817710204')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812609177) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101817710202 + 101817710203 + 101817710204) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_164,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812609178')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101817810205','101817810206','101817810207')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812609178) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101817810205 + 101817810206 + 101817810207) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_165,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101808208127')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812709179','101812709180','101812709181','101812709182')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101808208127) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101812709179 + 101812709180 + 101812709181 + 101812709182) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_166,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812709180')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818010219','101818010220','101818010221','101818010222','101818010223')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812709180) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101818010219 + 101818010220 + 101818010221 + 101818010222 + 101818010223) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_167,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812709181')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818110224','101818110225','101818110226','101818110227')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812709181) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101818110224 + 101818110225 + 101818110226 + 101818110227) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_168,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812709182')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818210228','101818210229','101818210230','101818210231')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812709182) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101818210228 + 101818210229 + 101818210230 + 101818210231) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_169,

/*Créditos comerciales restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101805507083')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101808308128','101808308129','101808308130')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101805507083) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101808308128 + 101808308129 + 101808308130) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_170,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101808308128')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812809183','101812809184','101812809185','101812809186','101812809187','101812809188','101812809189','101812809190')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101808308128) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101812809183 + 101812809184 + 101812809185 + 101812809186 + 101812809187 + 101812809188 + 101812809189 + 101812809190) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_171,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812809183')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818310232','101818310233')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812809183) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101818310232 + 101818310233) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_172,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812809184')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818410234','101818410235','101818410236')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812809184) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101818410234 + 101818410235 + 101818410236) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_173,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812809185')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101818510237','101818510238')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812809185) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101818510237 + 101818510238) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_174,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101808308129')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812909191','101812909192')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101808308129) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101812909191 + 101812909192) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_175,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812909191')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101819110239','101819110240','101819110241')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812909191) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101819110239 + 101819110240 + 101819110241) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_176,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812909192')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101819210242','101819210243','101819210244')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812909192) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101819210242 + 101819210243 + 101819210244) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_177,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101808308130')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101813009193','101813009194','101813009195','101813009196')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101808308130) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101813009193 + 101813009194 + 101813009195 + 101813009196) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_178,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101813009194')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101819410245','101819410246','101819410247','101819410248','101819410249')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101813009194) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101819410245 + 101819410246 + 101819410247 + 101819410248 + 101819410249) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_179,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101813009195')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101819510250','101819510251','101819510252','101819510253')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101813009195) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101819510250 + 101819510251 + 101819510252 + 101819510253) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_180,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101813009196')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101819610254','101819610255','101819610256','101819610257')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101813009196) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101819610254 + 101819610255 + 101819610256 + 101819610257) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_181,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801406056')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805607084','101805607085')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101801406056) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101805607084 + 101805607085) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_182,

/*Créditos de consumo sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101805607084')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101808408131','101808408132','101808408133','101808408134','101808408135','101808408136','101808408137','101808408138')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101805607084) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101808408131 + 101808408132 + 101808408133 + 101808408134 + 101808408135 + 101808408136 + 101808408137 + 101808408138) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_183,

/*Créditos de consumo restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101805607085')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101808508139','101808508140','101808508141','101808508142','101808508143','101808508144','101808508145','101808508146')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101805607085) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101808508139 + 101808508140 + 101808508141 + 101808508142 + 101808508143 + 101808508144 + 101808508145 + 101808508146) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_184,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801406057')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805707086','101805707087')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101801406057) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101805707086 + 101805707087) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_185,

/*Créditos a la vivienda sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101805707086')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101808608147','101808608148','101808608149','101808608150','101808608151')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101805707086) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101808608147 + 101808608148 + 101808608149 + 101808608150 + 101808608151) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_186,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101808608149')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101814909297','101814909298','101814909299')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101808608149) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101814909297 + 101814909298 + 101814909299) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_187,

/*Créditos a la vivienda restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101805707087')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101808708152','101808708153','101808708154','101808708155','101808708156')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101805707087) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101808708152 + 101808708153 + 101808708154 + 101808708155 + 101808708156) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_188,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101808708154')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815409320','101815409321','101815409322')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101808708154) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101815409320 + 101815409321 + 101815409322) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_189,

/*Cartera con riesgo de crédito etapa 2*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800505016')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801606061','101801606062','101801606063')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800505016) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101801606061 + 101801606062 + 101801606063) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_190,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801606061')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806107119','101806107120','101806107121')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101801606061) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101806107119 + 101806107120 + 101806107121) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_191,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806107119')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101811908157','101811908158','101811908159','101811908160','101811908161','101811908162','101811908163','101811908164')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101806107119) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101811908157 + 101811908158 + 101811908159 + 101811908160 + 101811908161 + 101811908162 + 101811908163 + 101811908164) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_192,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101811908157')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815709323','101815709324')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101811908157) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101815709323 + 101815709324) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_193,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101811908158')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815809325','101815809326','101815809327')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101811908158) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101815809325 + 101815809326 + 101815809327) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_194,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101811908159')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815909328','101815909329')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101811908159) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101815909328 + 101815909329) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_195,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806107120')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812008165','101812008166')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101806107120) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101812008165 + 101812008166) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_196,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812008165')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101816509380','101816509381','101816509382')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812008165) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101816509380 + 101816509381 + 101816509382) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_197,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812008166')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101816609383','101816609384','101816609385')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812008166) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101816609383 + 101816609384 + 101816609385) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_198,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806107121')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101812108167','101812108168','101812108169','101812108170')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101806107121) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101812108167 + 101812108168 + 101812108169 + 101812108170) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_199,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812108168')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101816809397','101816809398','101816809399','101816809400','101816809401')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('136')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812108168) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101816809397 + 101816809398 + 101816809399 + 101816809400 + 101816809401) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0.')    
AS VALIDACION_200
	
INTO IFRS9_R12A_1219_TS136TM0SUBS0_RESULT_2
FROM IFRS9_R12A_1219

END

BEGIN
	INSERT INTO IFRS9_R12A_1219_TS136TM0SUBS0_RESULT_2 IFRS9_R12A_1219_TS136TM0SUBS0_RESULT_2 
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_101])),
            SUM(CHARINDEX('ERR',[VALIDACION_102])),
            SUM(CHARINDEX('ERR',[VALIDACION_103])),
            SUM(CHARINDEX('ERR',[VALIDACION_104])),
            SUM(CHARINDEX('ERR',[VALIDACION_105])),
            SUM(CHARINDEX('ERR',[VALIDACION_106])),
            SUM(CHARINDEX('ERR',[VALIDACION_107])),
            SUM(CHARINDEX('ERR',[VALIDACION_108])),
            SUM(CHARINDEX('ERR',[VALIDACION_109])),
            SUM(CHARINDEX('ERR',[VALIDACION_110])),
            SUM(CHARINDEX('ERR',[VALIDACION_111])),
            SUM(CHARINDEX('ERR',[VALIDACION_112])),
            SUM(CHARINDEX('ERR',[VALIDACION_113])),
            SUM(CHARINDEX('ERR',[VALIDACION_114])),
            SUM(CHARINDEX('ERR',[VALIDACION_115])),
            SUM(CHARINDEX('ERR',[VALIDACION_116])),
            SUM(CHARINDEX('ERR',[VALIDACION_117])),
            SUM(CHARINDEX('ERR',[VALIDACION_118])),
            SUM(CHARINDEX('ERR',[VALIDACION_119])),
            SUM(CHARINDEX('ERR',[VALIDACION_120])),
            SUM(CHARINDEX('ERR',[VALIDACION_121])),
            SUM(CHARINDEX('ERR',[VALIDACION_122])),
            SUM(CHARINDEX('ERR',[VALIDACION_123])),
            SUM(CHARINDEX('ERR',[VALIDACION_124])),
            SUM(CHARINDEX('ERR',[VALIDACION_125])),
            SUM(CHARINDEX('ERR',[VALIDACION_126])),
            SUM(CHARINDEX('ERR',[VALIDACION_127])),
            SUM(CHARINDEX('ERR',[VALIDACION_128])),
            SUM(CHARINDEX('ERR',[VALIDACION_129])),
            SUM(CHARINDEX('ERR',[VALIDACION_130])),
            SUM(CHARINDEX('ERR',[VALIDACION_131])),
            SUM(CHARINDEX('ERR',[VALIDACION_132])),
            SUM(CHARINDEX('ERR',[VALIDACION_133])),
            SUM(CHARINDEX('ERR',[VALIDACION_134])),
            SUM(CHARINDEX('ERR',[VALIDACION_135])),
            SUM(CHARINDEX('ERR',[VALIDACION_136])),
            SUM(CHARINDEX('ERR',[VALIDACION_137])),
            SUM(CHARINDEX('ERR',[VALIDACION_138])),
            SUM(CHARINDEX('ERR',[VALIDACION_139])),
            SUM(CHARINDEX('ERR',[VALIDACION_140])),
            SUM(CHARINDEX('ERR',[VALIDACION_141])),
            SUM(CHARINDEX('ERR',[VALIDACION_142])),
            SUM(CHARINDEX('ERR',[VALIDACION_143])),
            SUM(CHARINDEX('ERR',[VALIDACION_144])),
            SUM(CHARINDEX('ERR',[VALIDACION_145])),
            SUM(CHARINDEX('ERR',[VALIDACION_146])),
            SUM(CHARINDEX('ERR',[VALIDACION_147])),
            SUM(CHARINDEX('ERR',[VALIDACION_148])),
            SUM(CHARINDEX('ERR',[VALIDACION_149])),
            SUM(CHARINDEX('ERR',[VALIDACION_150])),
            SUM(CHARINDEX('ERR',[VALIDACION_151])),
            SUM(CHARINDEX('ERR',[VALIDACION_152])),
            SUM(CHARINDEX('ERR',[VALIDACION_153])),
            SUM(CHARINDEX('ERR',[VALIDACION_154])),
            SUM(CHARINDEX('ERR',[VALIDACION_155])),
            SUM(CHARINDEX('ERR',[VALIDACION_156])),
            SUM(CHARINDEX('ERR',[VALIDACION_157])),
            SUM(CHARINDEX('ERR',[VALIDACION_158])),
            SUM(CHARINDEX('ERR',[VALIDACION_159])),
            SUM(CHARINDEX('ERR',[VALIDACION_160])),
            SUM(CHARINDEX('ERR',[VALIDACION_161])),
            SUM(CHARINDEX('ERR',[VALIDACION_162])),
            SUM(CHARINDEX('ERR',[VALIDACION_163])),
            SUM(CHARINDEX('ERR',[VALIDACION_164])),
            SUM(CHARINDEX('ERR',[VALIDACION_165])),
            SUM(CHARINDEX('ERR',[VALIDACION_166])),
            SUM(CHARINDEX('ERR',[VALIDACION_167])),
            SUM(CHARINDEX('ERR',[VALIDACION_168])),
            SUM(CHARINDEX('ERR',[VALIDACION_169])),
            SUM(CHARINDEX('ERR',[VALIDACION_170])),
            SUM(CHARINDEX('ERR',[VALIDACION_171])),
            SUM(CHARINDEX('ERR',[VALIDACION_172])),
            SUM(CHARINDEX('ERR',[VALIDACION_173])),
            SUM(CHARINDEX('ERR',[VALIDACION_174])),
            SUM(CHARINDEX('ERR',[VALIDACION_175])),
            SUM(CHARINDEX('ERR',[VALIDACION_176])),
            SUM(CHARINDEX('ERR',[VALIDACION_177])),
            SUM(CHARINDEX('ERR',[VALIDACION_178])),
            SUM(CHARINDEX('ERR',[VALIDACION_179])),
            SUM(CHARINDEX('ERR',[VALIDACION_180])),
            SUM(CHARINDEX('ERR',[VALIDACION_181])),
            SUM(CHARINDEX('ERR',[VALIDACION_182])),
            SUM(CHARINDEX('ERR',[VALIDACION_183])),
            SUM(CHARINDEX('ERR',[VALIDACION_184])),
            SUM(CHARINDEX('ERR',[VALIDACION_185])),
            SUM(CHARINDEX('ERR',[VALIDACION_186])),
            SUM(CHARINDEX('ERR',[VALIDACION_187])),
            SUM(CHARINDEX('ERR',[VALIDACION_188])),
            SUM(CHARINDEX('ERR',[VALIDACION_189])),
            SUM(CHARINDEX('ERR',[VALIDACION_190])),
            SUM(CHARINDEX('ERR',[VALIDACION_191])),
            SUM(CHARINDEX('ERR',[VALIDACION_192])),
            SUM(CHARINDEX('ERR',[VALIDACION_193])),
            SUM(CHARINDEX('ERR',[VALIDACION_194])),
            SUM(CHARINDEX('ERR',[VALIDACION_195])),
            SUM(CHARINDEX('ERR',[VALIDACION_196])),
            SUM(CHARINDEX('ERR',[VALIDACION_197])),
            SUM(CHARINDEX('ERR',[VALIDACION_198])),
            SUM(CHARINDEX('ERR',[VALIDACION_199])),
            SUM(CHARINDEX('ERR',[VALIDACION_200]))
            


		FROM IFRS9_R12A_1219_TS136TM0SUBS0_RESULT_2 
END

BEGIN
	EXEC SP_IFRS9_R12A_1219_TS136TM0SUBS0_VIEW_2IFRS9_R12A_1219_TS136TM0SUBS0_VIEW_2
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


