﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Consolidación. Consolidación del estado de situación financiera de la institución de crédito con sus subsidiarias */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: AGOSTO 2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: NA*/
/*TIPO SALDO: SALDOS*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/
/*SUBSIDIARIA: 0*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R12A_1219_TSSALDOSSUBS0_COMP_5]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R12A_1219_TSSALDOSSUBS0_RESULT_5')
BEGIN
DROP TABLE IFRS9_R12A_1219_TSSALDOSSUBS0_RESULT_5
END 

BEGIN
SELECT DISTINCT

	/*ID*/

	CONVERT(VARCHAR,ID)  AS ID,   
	/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101805108070')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805108070')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805108070')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805108070) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101805108070) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101805108070) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_401,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101805108071')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805108071')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805108071')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805108071) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101805108071) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101805108071) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_402,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101802307052')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101802307052')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101802307052')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802307052) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101802307052) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101802307052) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_403,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101802307053')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101802307053')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101802307053')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802307053) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101802307053) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101802307053) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_404,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101802307054')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101802307054')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101802307054')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802307054) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101802307054) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101802307054) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_405,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101802307055')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101802307055')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101802307055')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802307055) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101802307055) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101802307055) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_406,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101802307056')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101802307056')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101802307056')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802307056) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101802307056) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101802307056) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_407,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800806024')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800806024')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800806024')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800806024) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101800806024) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101800806024) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_408,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101802407057')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101802407057')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101802407057')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802407057) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101802407057) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101802407057) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_409,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101805708073')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805708073')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805708073')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805708073) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101805708073) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101805708073) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_410,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101805708074')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805708074')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805708074')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805708074) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101805708074) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101805708074) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_411,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101805708075')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805708075')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805708075')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805708075) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101805708075) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101805708075) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_412,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101802407058')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101802407058')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101802407058')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802407058) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101802407058) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101802407058) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_413,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101805808078')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805808078')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805808078')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805808078) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101805808078) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101805808078) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_414,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101805808079')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805808079')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805808079')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805808079) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101805808079) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101805808079) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_415,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101805808080')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805808080')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101805808080')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805808080) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101805808080) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101805808080) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_416,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800806025')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800806025')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800806025')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800806025) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101800806025) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101800806025) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_417,

/*Créditos al gobierno federal*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101802507059')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101802507059')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101802507059')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802507059) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101802507059) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101802507059) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_418,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101802507060')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101802507060')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101802507060')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802507060) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101802507060) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101802507060) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_419,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806008082')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806008082')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806008082')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806008082) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806008082) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806008082) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_420,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806008083')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806008083')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806008083')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806008083) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806008083) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806008083) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_421,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806008084')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806008084')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806008084')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806008084) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806008084) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806008084) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_422,

/*Fideicomisos públicos de contratación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806008085')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806008085')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806008085')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806008085) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806008085) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806008085) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_423,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806008086')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806008086')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806008086')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806008086) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806008086) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806008086) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_424,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101802507061')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101802507061')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101802507061')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802507061) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101802507061) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101802507061) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_425,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806108087')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806108087')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806108087')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806108087) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806108087) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806108087) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_426,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806108088')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806108088')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806108088')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806108088) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806108088) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806108088) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_427,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806108089')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806108089')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806108089')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806108089) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806108089) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806108089) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_428,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806108090')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806108090')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806108090')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806108090) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806108090) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806108090) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_429,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101802507062')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101802507062')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101802507062')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802507062) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101802507062) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101802507062) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_430,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806208091')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806208091')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806208091')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806208091) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806208091) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806208091) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_431,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806208092')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806208092')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806208092')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806208092) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806208092) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806208092) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_432,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806208093')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806208093')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806208093')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806208093) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806208093) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806208093) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_433,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806208094')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806208094')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806208094')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806208094) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806208094) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806208094) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_434,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800305009')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800305009')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800305009')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800305009) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101800305009) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101800305009) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_435,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800906026')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800906026')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800906026')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800906026) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101800906026) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101800906026) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_436,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800906027')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800906027')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800906027')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800906027) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101800906027) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101800906027) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_437,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800906028')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800906028')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800906028')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800906028) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101800906028) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101800906028) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_438,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800906029')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800906029')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800906029')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800906029) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101800906029) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101800906029) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_439,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800906030')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800906030')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800906030')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800906030) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101800906030) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101800906030) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_440,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800906031')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800906031')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800906031')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800906031) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101800906031) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101800906031) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_441,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800906032')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800906032')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800906032')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800906032) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101800906032) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101800906032) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_442,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800906033')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800906033')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800906033')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800906033) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101800906033) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101800906033) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_443,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800305010')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800305010')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800305010')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800305010) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101800305010) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101800305010) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_444,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801006034')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801006034')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801006034')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801006034) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101801006034) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101801006034) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_445,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801006035')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801006035')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801006035')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801006035) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101801006035) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101801006035) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_446,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801006036')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801006036')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801006036')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801006036) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101801006036) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101801006036) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_447,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101803607063')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101803607063')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101803607063')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101803607063) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101803607063) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101803607063) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_448,

/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101803607064')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101803607064')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101803607064')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101803607064) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101803607064) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101803607064) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_449,

/*Remodelación o mejoramiento con garantía otorgada por la banca de desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801006037')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801006037')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801006037')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801006037) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101801006037) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101801006037) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_450,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801006038')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801006038')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801006038')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801006038) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101801006038) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101801006038) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_451,

/*Cartera de crédito valuada a valor razonable*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800104004')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800104004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800104004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800104004) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101800104004) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101800104004) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_452,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800405011')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800405011')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800405011')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800405011) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101800405011) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101800405011) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_453,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801106039')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801106039')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801106039')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801106039) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101801106039) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101801106039) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_454,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101803907065')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101803907065')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101803907065')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101803907065) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101803907065) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101803907065) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_455,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806508095')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806508095')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806508095')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806508095) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806508095) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806508095) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_456,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806508096')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806508096')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806508096')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806508096) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806508096) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806508096) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_457,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101803907066')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101803907066')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101803907066')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101803907066) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101803907066) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101803907066) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_458,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806608097')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806608097')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806608097')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806608097) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806608097) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806608097) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_459,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806608098')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806608098')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806608098')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806608098) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806608098) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806608098) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_460,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806608099')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806608099')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806608099')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806608099) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806608099) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806608099) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_461,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101803907067')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101803907067')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101803907067')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101803907067) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101803907067) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101803907067) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_462,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806708100')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806708100')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806708100')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806708100) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806708100) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806708100) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_463,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806708101')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806708101')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806708101')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806708101) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806708101) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806708101) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_464,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101803907068')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101803907068')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101803907068')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101803907068) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101803907068) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101803907068) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_465,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101803907069')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101803907069')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101803907069')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101803907069) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101803907069) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101803907069) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_466,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101803907070')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101803907070')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101803907070')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101803907070) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101803907070) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101803907070) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_467,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101803907071')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101803907071')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101803907071')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101803907071) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101803907071) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101803907071) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_468,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101803907072')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101803907072')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101803907072')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101803907072) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101803907072) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101803907072) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_469,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801106040')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801106040')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801106040')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801106040) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101801106040) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101801106040) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_470,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101804007073')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101804007073')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101804007073')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804007073) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101804007073) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101804007073) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_471,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101807308103')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807308103')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807308103')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807308103) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101807308103) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101807308103) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_472,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101807308104')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807308104')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807308104')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807308104) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101807308104) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101807308104) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_473,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101807308105')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807308105')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807308105')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807308105) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101807308105) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101807308105) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_474,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101804007074')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101804007074')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101804007074')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804007074) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101804007074) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101804007074) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_475,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101807408108')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807408108')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807408108')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807408108) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101807408108) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101807408108) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_476,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101807408109')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807408109')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807408109')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807408109) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101807408109) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101807408109) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_477,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101807408110')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807408110')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807408110')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807408110) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101807408110) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101807408110) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_478,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801106041')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801106041')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801106041')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801106041) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101801106041) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101801106041) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_479,

/*Créditos al gobierno federal*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101804107075')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101804107075')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101804107075')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804107075) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101804107075) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101804107075) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_480,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101804107076')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101804107076')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101804107076')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804107076) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101804107076) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101804107076) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_481,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101807608112')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807608112')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807608112')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807608112) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101807608112) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101807608112) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_482,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101807608113')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807608113')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807608113')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807608113) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101807608113) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101807608113) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_483,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101807608114')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807608114')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807608114')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807608114) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101807608114) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101807608114) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_484,

/*Fideicomisos públicos de contratación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101807608115')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807608115')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807608115')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807608115) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101807608115) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101807608115) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_485,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101807608116')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807608116')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807608116')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807608116) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101807608116) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101807608116) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_486,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101804107077')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101804107077')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101804107077')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804107077) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101804107077) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101804107077) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_487,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101807708117')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807708117')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807708117')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807708117) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101807708117) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101807708117) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_488,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101807708118')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807708118')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807708118')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807708118) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101807708118) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101807708118) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_489,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101807708119')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807708119')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807708119')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807708119) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101807708119) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101807708119) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_490,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101807708120')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807708120')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807708120')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807708120) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101807708120) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101807708120) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_491,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101804107078')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101804107078')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101804107078')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804107078) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101804107078) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101804107078) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_492,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101807808121')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807808121')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807808121')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807808121) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101807808121) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101807808121) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_493,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101807808122')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807808122')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807808122')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807808122) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101807808122) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101807808122) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_494,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101807808123')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807808123')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807808123')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807808123) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101807808123) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101807808123) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_495,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101807808124')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807808124')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101807808124')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807808124) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101807808124) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101807808124) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_496,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800405012')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800405012')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800405012')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800405012) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101800405012) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101800405012) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_497,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801206042')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801206042')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801206042')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801206042) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101801206042) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101801206042) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_498,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801206043')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801206043')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801206043')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801206043) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101801206043) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101801206043) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_499,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801206044')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801206044')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801206044')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801206044) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101801206044) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101801206044) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_500
	
INTO IFRS9_R12A_1219_TSSALDOSSUBS0_RESULT_5
FROM IFRS9_R12A_1219

END

BEGIN
	INSERT INTO IFRS9_R12A_1219_TSSALDOSSUBS0_RESULT_5 IFRS9_R12A_1219_TSSALDOSSUBS0_RESULT_5 
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_401])),
            SUM(CHARINDEX('ERR',[VALIDACION_402])),
            SUM(CHARINDEX('ERR',[VALIDACION_403])),
            SUM(CHARINDEX('ERR',[VALIDACION_404])),
            SUM(CHARINDEX('ERR',[VALIDACION_405])),
            SUM(CHARINDEX('ERR',[VALIDACION_406])),
            SUM(CHARINDEX('ERR',[VALIDACION_407])),
            SUM(CHARINDEX('ERR',[VALIDACION_408])),
            SUM(CHARINDEX('ERR',[VALIDACION_409])),
            SUM(CHARINDEX('ERR',[VALIDACION_410])),
            SUM(CHARINDEX('ERR',[VALIDACION_411])),
            SUM(CHARINDEX('ERR',[VALIDACION_412])),
            SUM(CHARINDEX('ERR',[VALIDACION_413])),
            SUM(CHARINDEX('ERR',[VALIDACION_414])),
            SUM(CHARINDEX('ERR',[VALIDACION_415])),
            SUM(CHARINDEX('ERR',[VALIDACION_416])),
            SUM(CHARINDEX('ERR',[VALIDACION_417])),
            SUM(CHARINDEX('ERR',[VALIDACION_418])),
            SUM(CHARINDEX('ERR',[VALIDACION_419])),
            SUM(CHARINDEX('ERR',[VALIDACION_420])),
            SUM(CHARINDEX('ERR',[VALIDACION_421])),
            SUM(CHARINDEX('ERR',[VALIDACION_422])),
            SUM(CHARINDEX('ERR',[VALIDACION_423])),
            SUM(CHARINDEX('ERR',[VALIDACION_424])),
            SUM(CHARINDEX('ERR',[VALIDACION_425])),
            SUM(CHARINDEX('ERR',[VALIDACION_426])),
            SUM(CHARINDEX('ERR',[VALIDACION_427])),
            SUM(CHARINDEX('ERR',[VALIDACION_428])),
            SUM(CHARINDEX('ERR',[VALIDACION_429])),
            SUM(CHARINDEX('ERR',[VALIDACION_430])),
            SUM(CHARINDEX('ERR',[VALIDACION_431])),
            SUM(CHARINDEX('ERR',[VALIDACION_432])),
            SUM(CHARINDEX('ERR',[VALIDACION_433])),
            SUM(CHARINDEX('ERR',[VALIDACION_434])),
            SUM(CHARINDEX('ERR',[VALIDACION_435])),
            SUM(CHARINDEX('ERR',[VALIDACION_436])),
            SUM(CHARINDEX('ERR',[VALIDACION_437])),
            SUM(CHARINDEX('ERR',[VALIDACION_438])),
            SUM(CHARINDEX('ERR',[VALIDACION_439])),
            SUM(CHARINDEX('ERR',[VALIDACION_440])),
            SUM(CHARINDEX('ERR',[VALIDACION_441])),
            SUM(CHARINDEX('ERR',[VALIDACION_442])),
            SUM(CHARINDEX('ERR',[VALIDACION_443])),
            SUM(CHARINDEX('ERR',[VALIDACION_444])),
            SUM(CHARINDEX('ERR',[VALIDACION_445])),
            SUM(CHARINDEX('ERR',[VALIDACION_446])),
            SUM(CHARINDEX('ERR',[VALIDACION_447])),
            SUM(CHARINDEX('ERR',[VALIDACION_448])),
            SUM(CHARINDEX('ERR',[VALIDACION_449])),
            SUM(CHARINDEX('ERR',[VALIDACION_450])),
            SUM(CHARINDEX('ERR',[VALIDACION_451])),
            SUM(CHARINDEX('ERR',[VALIDACION_452])),
            SUM(CHARINDEX('ERR',[VALIDACION_453])),
            SUM(CHARINDEX('ERR',[VALIDACION_454])),
            SUM(CHARINDEX('ERR',[VALIDACION_455])),
            SUM(CHARINDEX('ERR',[VALIDACION_456])),
            SUM(CHARINDEX('ERR',[VALIDACION_457])),
            SUM(CHARINDEX('ERR',[VALIDACION_458])),
            SUM(CHARINDEX('ERR',[VALIDACION_459])),
            SUM(CHARINDEX('ERR',[VALIDACION_460])),
            SUM(CHARINDEX('ERR',[VALIDACION_461])),
            SUM(CHARINDEX('ERR',[VALIDACION_462])),
            SUM(CHARINDEX('ERR',[VALIDACION_463])),
            SUM(CHARINDEX('ERR',[VALIDACION_464])),
            SUM(CHARINDEX('ERR',[VALIDACION_465])),
            SUM(CHARINDEX('ERR',[VALIDACION_466])),
            SUM(CHARINDEX('ERR',[VALIDACION_467])),
            SUM(CHARINDEX('ERR',[VALIDACION_468])),
            SUM(CHARINDEX('ERR',[VALIDACION_469])),
            SUM(CHARINDEX('ERR',[VALIDACION_470])),
            SUM(CHARINDEX('ERR',[VALIDACION_471])),
            SUM(CHARINDEX('ERR',[VALIDACION_472])),
            SUM(CHARINDEX('ERR',[VALIDACION_473])),
            SUM(CHARINDEX('ERR',[VALIDACION_474])),
            SUM(CHARINDEX('ERR',[VALIDACION_475])),
            SUM(CHARINDEX('ERR',[VALIDACION_476])),
            SUM(CHARINDEX('ERR',[VALIDACION_477])),
            SUM(CHARINDEX('ERR',[VALIDACION_478])),
            SUM(CHARINDEX('ERR',[VALIDACION_479])),
            SUM(CHARINDEX('ERR',[VALIDACION_480])),
            SUM(CHARINDEX('ERR',[VALIDACION_481])),
            SUM(CHARINDEX('ERR',[VALIDACION_482])),
            SUM(CHARINDEX('ERR',[VALIDACION_483])),
            SUM(CHARINDEX('ERR',[VALIDACION_484])),
            SUM(CHARINDEX('ERR',[VALIDACION_485])),
            SUM(CHARINDEX('ERR',[VALIDACION_486])),
            SUM(CHARINDEX('ERR',[VALIDACION_487])),
            SUM(CHARINDEX('ERR',[VALIDACION_488])),
            SUM(CHARINDEX('ERR',[VALIDACION_489])),
            SUM(CHARINDEX('ERR',[VALIDACION_490])),
            SUM(CHARINDEX('ERR',[VALIDACION_491])),
            SUM(CHARINDEX('ERR',[VALIDACION_492])),
            SUM(CHARINDEX('ERR',[VALIDACION_493])),
            SUM(CHARINDEX('ERR',[VALIDACION_494])),
            SUM(CHARINDEX('ERR',[VALIDACION_495])),
            SUM(CHARINDEX('ERR',[VALIDACION_496])),
            SUM(CHARINDEX('ERR',[VALIDACION_497])),
            SUM(CHARINDEX('ERR',[VALIDACION_498])),
            SUM(CHARINDEX('ERR',[VALIDACION_499])),
            SUM(CHARINDEX('ERR',[VALIDACION_500]))
            


		FROM IFRS9_R12A_1219_TSSALDOSSUBS0_RESULT_5 
END

BEGIN
	EXEC SP_IFRS9_R12A_1219_TSSALDOSSUBS0_VIEW_5IFRS9_R12A_1219_TSSALDOSSUBS0_VIEW_5
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


