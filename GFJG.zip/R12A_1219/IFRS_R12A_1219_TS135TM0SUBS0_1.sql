﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Consolidación. Consolidación del estado de situación financiera de la institución de crédito con sus subsidiarias */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: AGOSTO 2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: NA*/
/*TIPO SALDO: 135*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: 0*/
/*SUBSIDIARIA: 0*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R12A_1219_TS135TM0SUBS0_COMP_1]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R12A_1219_TS135TM0SUBS0_RESULT_1')
BEGIN
DROP TABLE IFRS9_R12A_1219_TS135TM0SUBS0_RESULT_1
END 

BEGIN
SELECT DISTINCT

    /*ID*/

    CONVERT(VARCHAR,ID) AS ID,                                    /*ACTIVO*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100000000000')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200001001','100400001001','100600001001','100800001001','101000001001','101200001001','101400001001','101600001001','131800001001','102000001001','102200001001','132400001001','132600001001','102800001001','103000001001','103200001001','133400001001','133600001001','103800001001','104000001001','134200001001','134400001001','104600001001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100000000000) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100200001001 + 100400001001 + 100600001001 + 100800001001 + 101000001001 + 101200001001 + 101400001001 + 101600001001 + 131800001001 + 102000001001 + 102200001001 + 132400001001 + 132600001001 + 102800001001 + 103000001001 + 103200001001 + 133400001001 + 133600001001 + 103800001001 + 104000001001 + 134200001001 + 134400001001 + 104600001001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_1,

/*Efectivo y equivalentes de efectivo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100200001001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200102001','100200102002','100200102003','100200102004','100200102005','100200102006','100200102007')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100200001001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100200102001 + 100200102002 + 100200102003 + 100200102004 + 100200102005 + 100200102006 + 100200102007) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_2,

/*Bancos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100200102002')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200203001','100200203002','100200203003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100200102002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100200203001 + 100200203002 + 100200203003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_3,

/*Efectivo y equivalentes de efectivo restringidos o dados en garantía*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100200102006')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200603004','100200603005','100200603006','100200603007','100200603008')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100200102006) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100200603004 + 100200603005 + 100200603006 + 100200603007 + 100200603008) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_4,

/*Cuentas de margen (instrumentos financieros derivados)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100400001001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100400102001','100400102002','100400102003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100400001001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100400102001 + 100400102002 + 100400102003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_5,

/*Inversiones en instrumentos financieros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600001001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600102001','100600102002','100600102003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600001001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100600102001 + 100600102002 + 100600102003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_6,

/*Instrumentos financieros negociables*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600102001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600103001','100600103002','100600103003','100600103004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600102001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100600103001 + 100600103002 + 100600103003 + 100600103004) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_7,

/*Instrumentos financieros negociables sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600103001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600104001','100600104002','100600104003','100600104004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600103001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100600104001 + 100600104002 + 100600104003 + 100600104004) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_8,

/*Deuda gubernamental*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600104001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600105001','100600105002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600104001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100600105001 + 100600105002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_9,

/*Deuda bancaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600104002')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600205003','100600205004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600104002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100600205003 + 100600205004) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_10,

/*Otros títulos de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600104003')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600305005','100600305006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600104003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100600305005 + 100600305006) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_11,

/*Instrumentos financieros de capital*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600104004')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600405007','100600405008')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600104004) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100600405007 + 100600405008) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_12,

/*Instrumentos financieros negociables restringidos o dados en garantía en operaciones de reporto*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600103002')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600204005','100600204006','100600204007','100600204008')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600103002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100600204005 + 100600204006 + 100600204007 + 100600204008) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_13,

/*Instrumentos financieros negociables restringidos o dados en garantía en operaciones de préstamo de valores*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600103003')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600304009','100600304010','100600304011','100600304012')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600103003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100600304009 + 100600304010 + 100600304011 + 100600304012) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_14,

/*Instrumentos financieros negociables restringidos o dados en garantía (otros)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600103004')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600404013','100600404014','100600404015','100600404016')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600103004) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100600404013 + 100600404014 + 100600404015 + 100600404016) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_15,

/*Deuda gubernamental*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600404013')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601305009','100601305010')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600404013) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100601305009 + 100601305010) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_16,

/*Deuda bancaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600404014')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601405011','100601405012')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600404014) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100601405011 + 100601405012) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_17,

/*Otros títulos de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600404015')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601505013','100601505014')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600404015) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100601505013 + 100601505014) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_18,

/*Instrumentos financieros de capital*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600404016')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601605015','100601605016')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600404016) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100601605015 + 100601605016) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_19,

/*Instrumentos financieros para cobrar o vender*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600102002')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600203005','100600203006','100600203007','100600203008')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600102002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100600203005 + 100600203006 + 100600203007 + 100600203008) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_20,

/*Instrumentos financieros para cobrar o vender sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600203005')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600504017','100600504018','100600504019')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600203005) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100600504017 + 100600504018 + 100600504019) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_21,

/*Deuda gubernamental*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600504017')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601705017','100601705018')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600504017) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100601705017 + 100601705018) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_22,

/*Deuda bancaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600504018')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601805019','100601805020')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600504018) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100601805019 + 100601805020) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_23,

/*Otros títulos de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600504019')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601905021','100601905022')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600504019) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100601905021 + 100601905022) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_24,

/*Instrumentos financieros para cobrar o vender restringidos o dados en garantía en operaciones de reporto*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600203006')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600604020','100600604021','100600604022')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600203006) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100600604020 + 100600604021 + 100600604022) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_25,

/*Instrumentos financieros para cobrar o vender restringidos o dados en garantía en operaciones de préstamo de valores*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600203007')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600704023','100600704024','100600704025')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600203007) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100600704023 + 100600704024 + 100600704025) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_26,

/*Instrumentos financieros para cobrar o vender restringidos o dados en garantía (otros)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600203008')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600804026','100600804027','100600804028')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600203008) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100600804026 + 100600804027 + 100600804028) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_27,

/*Deuda gubernamental*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600804026')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100602605023','100602605024')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600804026) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100602605023 + 100602605024) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_28,

/*Deuda bancaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600804027')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100602705025','100602705026')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600804027) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100602705025 + 100602705026) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_29,

/*Otros títulos de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600804028')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100602805027','100602805028')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600804028) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100602805027 + 100602805028) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_30,

/*Instrumentos financieros para cobrar principal e interés (valores)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600102003')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600303009','100600303010','100600303011','100600303012')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600102003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100600303009 + 100600303010 + 100600303011 + 100600303012) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_31,

/*Instrumentos financieros para cobrar principal e interés sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600303009')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600904029','100600904030','100600904031')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600303009) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100600904029 + 100600904030 + 100600904031) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_32,

/*Deuda gubernamental*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600904029')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100602905029','100602905030')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600904029) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100602905029 + 100602905030) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_33,

/*Deuda bancaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600904030')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100603005031','100603005032')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600904030) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100603005031 + 100603005032) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_34,

/*Otros títulos de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600904031')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100603105033','100603105034')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600904031) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100603105033 + 100603105034) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_35,

/*Instrumentos financieros para cobrar principal e interés restringidos o dados en garantía en operaciones de reporto*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600303010')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601004032','100601004033','100601004034')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600303010) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100601004032 + 100601004033 + 100601004034) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_36,

/*Instrumentos financieros para cobrar principal e interés restringidos o dados en garantía en operaciones de préstamo de valores*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600303011')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601104035','100601104036','100601104037')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600303011) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100601104035 + 100601104036 + 100601104037) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_37,

/*Instrumentos financieros para cobrar principal e interés restringidos o dados en garantía (otros)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600303012')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601204038','100601204039','100601204040')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600303012) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100601204038 + 100601204039 + 100601204040) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_38,

/*Deuda gubernamental*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100601204038')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100603805035','100603805036')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100601204038) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100603805035 + 100603805036) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_39,

/*Deuda bancaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100601204039')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100603905037','100603905038')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100601204039) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100603905037 + 100603905038) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_40,

/*Otros títulos de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100601204040')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100604005039','100604005040')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100601204040) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100604005039 + 100604005040) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_41,

/*Estimación de pérdidas crediticias esperadas para inversiones en instrumentos financieros para cobrar principal e interés (valores)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100800001001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100800102001','100800102002','100800102003','100800102004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100800001001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100800102001 + 100800102002 + 100800102003 + 100800102004) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_42,

/*Instrumentos financieros para cobrar principal e interés sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100800102001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100800103001','100800103002','100800103003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100800102001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100800103001 + 100800103002 + 100800103003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_43,

/*Deuda gubernamental*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100800103001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100800104001','100800104002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100800103001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100800104001 + 100800104002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_44,

/*Deuda bancaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100800103002')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100800204003','100800204004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100800103002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100800204003 + 100800204004) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_45,

/*Otros títulos de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100800103003')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100800304005','100800304006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100800103003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100800304005 + 100800304006) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_46,

/*Instrumentos financieros para cobrar principal e interés restringidos o dados en garantía en operaciones de reporto*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100800102002')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100800203004','100800203005','100800203006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100800102002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100800203004 + 100800203005 + 100800203006) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_47,

/*Instrumentos financieros para cobrar principal e interés restringidos o dados en garantía en operaciones de préstamo de valores*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100800102003')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100800303007','100800303008','100800303009')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100800102003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100800303007 + 100800303008 + 100800303009) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_48,

/*Instrumentos financieros para cobrar principal e interés restringidos o dados en garantía (otros)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100800102004')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100800403010','100800403011','100800403012')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100800102004) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100800403010 + 100800403011 + 100800403012) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_49,

/*Deuda gubernamental*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100800403010')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100801004007','100801004008')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100800403010) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100801004007 + 100801004008) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_50,

/*Deuda bancaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100800403011')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100801104009','100801104010')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100800403011) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100801104009 + 100801104010) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_51,

/*Otros títulos de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100800403012')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100801204011','100801204012')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100800403012) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 100801204011 + 100801204012) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_52,

/*Instrumentos financieros derivados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101400001001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101400102001','101400102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400001001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101400102001 + 101400102002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_53,

/*Con fines de negociación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101400102001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101400103001','101400103002','101400103003','101400103004','101400103005','101400103006','101400103007')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400102001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101400103001 + 101400103002 + 101400103003 + 101400103004 + 101400103005 + 101400103006 + 101400103007) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_54,

/*Futuros a recibir*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101400103001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101400104001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400103001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101400104001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_55,

/*Contratos adelantados a recibir*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101400103002')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101400204002','101400204003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400103002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101400204002 + 101400204003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_56,

/*Opciones*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101400103003')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101400304004','101400304005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400103003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101400304004 + 101400304005) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_57,

/*Swaps*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101400103004')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101400404006','101400404007')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400103004) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101400404006 + 101400404007) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_58,

/*Instrumentos financieros derivados crediticios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101400103005')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101400504008','101400504009')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400103005) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101400504008 + 101400504009) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_59,

/*Operaciones estructuradas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101400103006')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101400604010','101400604011')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400103006) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101400604010 + 101400604011) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_60,

/*Paquetes de instrumentos financieros derivados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101400103007')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101400704012','101400704013')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400103007) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101400704012 + 101400704013) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_61,

/*Con fines de cobertura*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101400102002')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101400203008','101400203009','101400203010','101400203011','101400203012','101400203013','101400203014')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400102002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101400203008 + 101400203009 + 101400203010 + 101400203011 + 101400203012 + 101400203013 + 101400203014) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_62,

/*Futuros a recibir*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101400203008')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101400804014','101400804015')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400203008) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101400804014 + 101400804015) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_63,

/*Contratos adelantados a recibir*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101400203009')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101400904016','101400904017','101400904018')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400203009) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101400904016 + 101400904017 + 101400904018) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_64,

/*Opciones*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101400203010')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101401004019','101401004020','101401004021')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400203010) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101401004019 + 101401004020 + 101401004021) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_65,

/*Swaps*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101400203011')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101401104022','101401104023','101401104024')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400203011) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101401104022 + 101401104023 + 101401104024) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_66,

/*Instrumentos financieros derivados crediticios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101400203012')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101401204025','101401204026','101401204027')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400203012) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101401204025 + 101401204026 + 101401204027) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_67,

/*Operaciones estructuradas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101400203013')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101401304028','101401304029','101401304030')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400203013) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101401304028 + 101401304029 + 101401304030) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_68,

/*Paquetes de instrumentos financieros derivados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101400203014')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101401404031','101401404032','101401404033')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400203014) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101401404031 + 101401404032 + 101401404033) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_69,

/*Ajustes de valuación por cobertura de activos financieros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101600001001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800104001','101800104002','101800104003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101600001001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800104001 + 101800104002 + 101800104003 ) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_70,

/*Cartera de crédito con riesgo de crédito etapa 1*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800104001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800105001','101800105002','101800105003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800104001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800105001 + 101800105002 + 101800105003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_71,

/*Estimación preventiva para riesgos crediticios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800103003')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800304005','101800304006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800103003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800304005 + 101800304006) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_72,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800105001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800106001','101800106002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800105001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800106001 + 101800106002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_73,

/*Créditos comerciales sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800106001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800107001','101800107002','101800107003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800106001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800107001 + 101800107002 + 101800107003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_74,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800107001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800108001','101800108002','101800108003','101800108004','101800108005','101800108006','101800108007','101800108008')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800107001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800108001 + 101800108002 + 101800108003 + 101800108004 + 101800108005 + 101800108006 + 101800108007 + 101800108008) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_75,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800108001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800109001','101800109002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800108001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800109001 + 101800109002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_76,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800108002')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800209003','101800209004','101800209005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800108002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800209003 + 101800209004 + 101800209005) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_77,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800108003')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800309006','101800309007')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800108003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800309006 + 101800309007) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_78,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800107002')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800208009','101800208010')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800107002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800208009 + 101800208010) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_79,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800208009')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800909009','101800909010','101800909011')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800208009) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800909009 + 101800909010 + 101800909011) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_80,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800208010')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801009014','101801009015','101801009016')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800208010) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101801009014 + 101801009015 + 101801009016) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_81,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800107003')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800308011','101800308012','101800308013','101800308014')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800107003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800308011 + 101800308012 + 101800308013 + 101800308014) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_82,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800308012')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801209018','101801209019','101801209020','101801209021','101801209022')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800308012) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101801209018 + 101801209019 + 101801209020 + 101801209021 + 101801209022) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_83,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800308013')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801309023','101801309024','101801309025','101801309026')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800308013) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101801309023 + 101801309024 + 101801309025 + 101801309026) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_84,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800308014')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801409027','101801409028','101801409029','101801409030')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800308014) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101801409027 + 101801409028 + 101801409029 + 101801409030) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_85,

/*Créditos comerciales restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800106002')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800207004','101800207005','101800207006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800106002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800207004 + 101800207005 + 101800207006) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_86,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800207004')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800408015','101800408016','101800408017','101800408018','101800408019','101800408020','101800408021','101800408022')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800207004) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800408015 + 101800408016 + 101800408017 + 101800408018 + 101800408019 + 101800408020 + 101800408021 + 101800408022) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_87,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800408015')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801509031','101801509032')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800408015) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101801509031 + 101801509032) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_88,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800408016')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801609033','101801609034','101801609035')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800408016) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101801609033 + 101801609034 + 101801609035) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_89,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800408017')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801709036','101801709037')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800408017) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101801709036 + 101801709037) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_90,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800207005')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800508023','101800508024')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800207005) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800508023 + 101800508024) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_91,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800508023')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101802309039','101802309040','101802309041')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800508023) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101802309039 + 101802309040 + 101802309041) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_92,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800508024')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101802409044','101802409045','101802409046')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800508024) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101802409044 + 101802409045 + 101802409046) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_93,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800207006')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800608025','101800608026','101800608027','101800608028')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800207006) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800608025 + 101800608026 + 101800608027 + 101800608028) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_94,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800608026')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101802609048','101802609049','101802609050','101802609051','101802609052')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800608026) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101802609048 + 101802609049 + 101802609050 + 101802609051 + 101802609052) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_95,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800608027')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101802709053','101802709054','101802709055','101802709056')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800608027) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101802709053 + 101802709054 + 101802709055 + 101802709056) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_96,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800608028')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101802809057','101802809058','101802809059','101802809060')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800608028) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101802809057 + 101802809058 + 101802809059 + 101802809060) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_97,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800105002')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800206003','101800206004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800105002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800206003 + 101800206004) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_98,

/*Créditos de consumo sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800206003')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800307007','101800307008','101800307009','101800307010','101800307011','101800307012','101800307013','101800307014')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800206003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800307007 + 101800307008 + 101800307009 + 101800307010 + 101800307011 + 101800307012 + 101800307013 + 101800307014) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_99,

/*Créditos de consumo restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800206004')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800407015','101800407016','101800407017','101800407018','101800407019','101800407020','101800407021','101800407022')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800206004) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 101800407015 + 101800407016 + 101800407017 + 101800407018 + 101800407019 + 101800407020 + 101800407021 + 101800407022) con Clave de Subsidiaria 0, Tipo de Saldo 135 y Tipo de Movimiento 0.')    
AS VALIDACION_100
	
INTO IFRS9_R12A_1219_TS135TM0SUBS0_RESULT_1
FROM IFRS9_R12A_1219

END

BEGIN
	INSERT INTO IFRS9_R12A_1219_TS135TM0SUBS0_RESULT_1 IFRS9_R12A_1219_TS135TM0SUBS0_RESULT_1 IFRS9_R12A_1219_TS135TM0SUBS0_RESULT_1  
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_1])),
            SUM(CHARINDEX('ERR',[VALIDACION_2])),
            SUM(CHARINDEX('ERR',[VALIDACION_3])),
            SUM(CHARINDEX('ERR',[VALIDACION_4])),
            SUM(CHARINDEX('ERR',[VALIDACION_5])),
            SUM(CHARINDEX('ERR',[VALIDACION_6])),
            SUM(CHARINDEX('ERR',[VALIDACION_7])),
            SUM(CHARINDEX('ERR',[VALIDACION_8])),
            SUM(CHARINDEX('ERR',[VALIDACION_9])),
            SUM(CHARINDEX('ERR',[VALIDACION_10])),
            SUM(CHARINDEX('ERR',[VALIDACION_11])),
            SUM(CHARINDEX('ERR',[VALIDACION_12])),
            SUM(CHARINDEX('ERR',[VALIDACION_13])),
            SUM(CHARINDEX('ERR',[VALIDACION_14])),
            SUM(CHARINDEX('ERR',[VALIDACION_15])),
            SUM(CHARINDEX('ERR',[VALIDACION_16])),
            SUM(CHARINDEX('ERR',[VALIDACION_17])),
            SUM(CHARINDEX('ERR',[VALIDACION_18])),
            SUM(CHARINDEX('ERR',[VALIDACION_19])),
            SUM(CHARINDEX('ERR',[VALIDACION_20])),
            SUM(CHARINDEX('ERR',[VALIDACION_21])),
            SUM(CHARINDEX('ERR',[VALIDACION_22])),
            SUM(CHARINDEX('ERR',[VALIDACION_23])),
            SUM(CHARINDEX('ERR',[VALIDACION_24])),
            SUM(CHARINDEX('ERR',[VALIDACION_25])),
            SUM(CHARINDEX('ERR',[VALIDACION_26])),
            SUM(CHARINDEX('ERR',[VALIDACION_27])),
            SUM(CHARINDEX('ERR',[VALIDACION_28])),
            SUM(CHARINDEX('ERR',[VALIDACION_29])),
            SUM(CHARINDEX('ERR',[VALIDACION_30])),
            SUM(CHARINDEX('ERR',[VALIDACION_31])),
            SUM(CHARINDEX('ERR',[VALIDACION_32])),
            SUM(CHARINDEX('ERR',[VALIDACION_33])),
            SUM(CHARINDEX('ERR',[VALIDACION_34])),
            SUM(CHARINDEX('ERR',[VALIDACION_35])),
            SUM(CHARINDEX('ERR',[VALIDACION_36])),
            SUM(CHARINDEX('ERR',[VALIDACION_37])),
            SUM(CHARINDEX('ERR',[VALIDACION_38])),
            SUM(CHARINDEX('ERR',[VALIDACION_39])),
            SUM(CHARINDEX('ERR',[VALIDACION_40])),
            SUM(CHARINDEX('ERR',[VALIDACION_41])),
            SUM(CHARINDEX('ERR',[VALIDACION_42])),
            SUM(CHARINDEX('ERR',[VALIDACION_43])),
            SUM(CHARINDEX('ERR',[VALIDACION_44])),
            SUM(CHARINDEX('ERR',[VALIDACION_45])),
            SUM(CHARINDEX('ERR',[VALIDACION_46])),
            SUM(CHARINDEX('ERR',[VALIDACION_47])),
            SUM(CHARINDEX('ERR',[VALIDACION_48])),
            SUM(CHARINDEX('ERR',[VALIDACION_49])),
            SUM(CHARINDEX('ERR',[VALIDACION_50])),
            SUM(CHARINDEX('ERR',[VALIDACION_51])),
            SUM(CHARINDEX('ERR',[VALIDACION_52])),
            SUM(CHARINDEX('ERR',[VALIDACION_53])),
            SUM(CHARINDEX('ERR',[VALIDACION_54])),
            SUM(CHARINDEX('ERR',[VALIDACION_55])),
            SUM(CHARINDEX('ERR',[VALIDACION_56])),
            SUM(CHARINDEX('ERR',[VALIDACION_57])),
            SUM(CHARINDEX('ERR',[VALIDACION_58])),
            SUM(CHARINDEX('ERR',[VALIDACION_59])),
            SUM(CHARINDEX('ERR',[VALIDACION_60])),
            SUM(CHARINDEX('ERR',[VALIDACION_61])),
            SUM(CHARINDEX('ERR',[VALIDACION_62])),
            SUM(CHARINDEX('ERR',[VALIDACION_63])),
            SUM(CHARINDEX('ERR',[VALIDACION_64])),
            SUM(CHARINDEX('ERR',[VALIDACION_65])),
            SUM(CHARINDEX('ERR',[VALIDACION_66])),
            SUM(CHARINDEX('ERR',[VALIDACION_67])),
            SUM(CHARINDEX('ERR',[VALIDACION_68])),
            SUM(CHARINDEX('ERR',[VALIDACION_69])),
            SUM(CHARINDEX('ERR',[VALIDACION_70])),
            SUM(CHARINDEX('ERR',[VALIDACION_71])),
            SUM(CHARINDEX('ERR',[VALIDACION_72])),
            SUM(CHARINDEX('ERR',[VALIDACION_73])),
            SUM(CHARINDEX('ERR',[VALIDACION_74])),
            SUM(CHARINDEX('ERR',[VALIDACION_75])),
            SUM(CHARINDEX('ERR',[VALIDACION_76])),
            SUM(CHARINDEX('ERR',[VALIDACION_77])),
            SUM(CHARINDEX('ERR',[VALIDACION_78])),
            SUM(CHARINDEX('ERR',[VALIDACION_79])),
            SUM(CHARINDEX('ERR',[VALIDACION_80])),
            SUM(CHARINDEX('ERR',[VALIDACION_81])),
            SUM(CHARINDEX('ERR',[VALIDACION_82])),
            SUM(CHARINDEX('ERR',[VALIDACION_83])),
            SUM(CHARINDEX('ERR',[VALIDACION_84])),
            SUM(CHARINDEX('ERR',[VALIDACION_85])),
            SUM(CHARINDEX('ERR',[VALIDACION_86])),
            SUM(CHARINDEX('ERR',[VALIDACION_87])),
            SUM(CHARINDEX('ERR',[VALIDACION_88])),
            SUM(CHARINDEX('ERR',[VALIDACION_89])),
            SUM(CHARINDEX('ERR',[VALIDACION_90])),
            SUM(CHARINDEX('ERR',[VALIDACION_91])),
            SUM(CHARINDEX('ERR',[VALIDACION_92])),
            SUM(CHARINDEX('ERR',[VALIDACION_93])),
            SUM(CHARINDEX('ERR',[VALIDACION_94])),
            SUM(CHARINDEX('ERR',[VALIDACION_95])),
            SUM(CHARINDEX('ERR',[VALIDACION_96])),
            SUM(CHARINDEX('ERR',[VALIDACION_97])),
            SUM(CHARINDEX('ERR',[VALIDACION_98])),
            SUM(CHARINDEX('ERR',[VALIDACION_99])),
            SUM(CHARINDEX('ERR',[VALIDACION_100]))
            


		FROM IFRS9_R12A_1219_TS135TM0SUBS0_RESULT_1 
END

BEGIN
	EXEC SP_IFRS9_R12A_1219_TS135TM0SUBS0_VIEW_1IFRS9_R12A_1219_TS135TM0SUBS0_VIEW_1IFRS9_R12A_1219_TS135TM0SUBS0_VIEW_1
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


