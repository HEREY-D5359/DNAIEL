﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Consolidación. Consolidación del estado de situación financiera de la institución de crédito con sus subsidiarias */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: AGOSTO 2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: NA*/
/*TIPO SALDO: 130*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: 0*/
/*SUBSIDIARIA: 040112*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R12A_1219_TS130TM0SUBS040112_COMP_4]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R12A_1219_TS130TM0SUBS040112_RESULT_4')
BEGIN
DROP TABLE IFRS9_R12A_1219_TS130TM0SUBS040112_RESULT_4
END 

BEGIN
SELECT DISTINCT
         /*id*/
CONVERT(VARCHAR,ID) AS ID, 
	/*Operaciones estructuradas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('201400203013')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('201401304011','201401304012')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (201400203013) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 201401304011 + 201401304012) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_301,

/*Paquetes de instrumentos financieros derivados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('201400203014')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('201401404013','201401404014')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (201400203014) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 201401404013 + 201401404014) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_302,

/*Obligaciones en operaciones de bursatilización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('201800001001')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('201800102001')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (201800001001) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 201800102001) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_303,

/*Otras cuentas por pagar*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('202400001001')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202400102001','202400102002','202400102003','202400102004','202400102005')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (202400001001) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 202400102001 + 202400102002 + 202400102003 + 202400102004 + 202400102005) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_304,

/*Acreedores por liquidación de operaciones*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('202400102001')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202400103001','202400103002','202400103003','202400103004','202400103005','202400103006')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (202400102001) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 202400103001 + 202400103002 + 202400103003 + 202400103004 + 202400103005 + 202400103006) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_305,

/*Acreedores por colaterales recibidos en efectivo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('202400102003')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202400303007','202400303008','202400303009','202400303010','202400303011')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (202400102003) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 202400303007 + 202400303008 + 202400303009 + 202400303010 + 202400303011) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_306,

/*Contribuciones por pagar*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('202400102004')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202400403012','202400403013','202400403014')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (202400102004) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 202400403012 + 202400403013 + 202400403014) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_307,

/*Acreedores diversos y otras cuentas por pagar*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('202400102005')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202400503015','202400503016','202400503017','202400503018','202400503019','202400503020','202400503021','202400503022')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (202400102005) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 202400503015 + 202400503016 + 202400503017 + 202400503018 + 202400503019 + 202400503020 + 202400503021 + 202400503022) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_308,

/*Pasivos derivados de la prestación de servicios bancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('202400503015')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202401504001','202401504002','202401504003','202401504004','202401504005','202401504006','202401504007','202401504008','202401504009','202401504010')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (202400503015) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 202401504001 + 202401504002 + 202401504003 + 202401504004 + 202401504005 + 202401504006 + 202401504007 + 202401504008 + 202401504009 + 202401504010) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_309,

/*Provisiones para obligaciones diversas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('202400503021')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202402104011','202402104012','202402104013','202402104014','202402104015','202402104016')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (202400503021) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 202402104011 + 202402104012 + 202402104013 + 202402104014 + 202402104015 + 202402104016) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_310,

/*Instrumentos financieros que califican como pasivo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203000001001')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000102001','203000102002','203000102003')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (203000001001) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 203000102001 + 203000102002 + 203000102003) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_311,

/*Obligaciones subordinadas en circulación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203000102001')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000103001','203000103002','203000103003','203000103004')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (203000102001) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 203000103001 + 203000103002 + 203000103003 + 203000103004) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_312,

/*De conversión forzosa*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203000103001')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000104001','203000104002','203000104003')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (203000103001) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 203000104001 + 203000104002 + 203000104003) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_313,

/*De conversión por decisión del tenedor*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203000103002')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000204004','203000204005','203000204006')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (203000103002) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 203000204004 + 203000204005 + 203000204006) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_314,

/*De conversión por decisión de la entidad emisora*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203000103003')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000304007','203000304008','203000304009')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (203000103003) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 203000304007 + 203000304008 + 203000304009) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_315,

/*No convertibles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203000103004')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000404010','203000404011','203000404012')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (203000103004) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 203000404010 + 203000404011 + 203000404012) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_316,

/*Pasivo por impuestos a la utilidad*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203400001001')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203400102001','203400102002')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (203400001001) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 203400102001 + 203400102002) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_317,

/*Impuestos causados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203400102001')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203400103001','203400103002')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (203400102001) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 203400103001 + 203400103002) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_318,

/*Impuestos diferidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203400102002')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203400203003')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (203400102002) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 203400203003) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_319,

/*Pasivo por beneficios a los empleados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203600001001')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203600102001','203600102002','203600102003','203600102004','203600102005','203600102006')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (203600001001) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 203600102001 + 203600102002 + 203600102003 + 203600102004 + 203600102005 + 203600102006) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_320,

/*Beneficios post-empleo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203600102003')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203600303001','203600303002','203600303003')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (203600102003) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 203600303001 + 203600303002 + 203600303003) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_321,

/*Beneficios por terminación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203600102004')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203600403004','203600403005')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (203600102004) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 203600403004 + 203600403005) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_322,

/*Créditos diferidos y cobros anticipados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203800001001')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800102001','203800102002')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (203800001001) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 203800102001 + 203800102002) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_323,

/*Créditos diferidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203800102001')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800103001','203800103002','203800103003','203800103004','203800103005','203800103006','203800103007','203800103008')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (203800102001) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 203800103001 + 203800103002 + 203800103003 + 203800103004 + 203800103005 + 203800103006 + 203800103007 + 203800103008) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_324,

/*Cobros anticipados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203800102002')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800203009','203800203010','203800203011','203800203012','203800203013','203800203014')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (203800102002) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 203800203009 + 203800203010 + 203800203011 + 203800203012 + 203800203013 + 203800203014) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_325,

/*ACTIVO = PASIVO + CAPITAL CONTABLE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100000000000')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('200000000000','400000000000')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100000000000) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 200000000000 + 400000000000 ) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_326,

/*CAPITAL CONTABLE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400000000000')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('440200001001','440400001001')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400000000000) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 440200001001 + 440400001001) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_327,

/*Participación controladora*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('440200001001')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200102001','400200102002')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (440200001001) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 400200102001 + 400200102002) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_328,

/*Capital contribuido*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400200102001')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200103001','400200103002','400200103003','400200103004','400200103005','400200103006','400200103007','400200103008','400200103009')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400200102001) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 400200103001 + 400200103002 + 400200103003 + 400200103004 + 400200103005 + 400200103006 + 400200103007 + 400200103008 + 400200103009) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_329,

/*Capital ganado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400200102002')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200203010','400200203011','400200203012','400200203013','400200203014','400200203015')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400200102002) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 400200203010 + 400200203011 + 400200203012 + 400200203013 + 400200203014 + 400200203015) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_330,

/*Reservas de capital*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400200203010')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400201004001','400201004002')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400200203010) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 400201004001 + 400201004002) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_331,

/*Resultados acumulados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400200203012')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400201204003','400201204004','430201204005')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400200203012) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 400201204003 + 400201204004 + 430201204005) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_332,

/*Resultado de ejercicios anteriores*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400201204003')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200305001','400200305002')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400201204003) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 400200305001 + 400200305002) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_333,

/*Otros resultados integrales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400200203013')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400201304006','400201304007','400201304008','400201304009','400201304010','400201304011','400201304012','400201304013','400201304014','400201304015','400201304016','400201304017')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400200203013) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 400201304006 + 400201304007 + 400201304008 + 400201304009 + 400201304010 + 400201304011 + 400201304012 + 400201304013 + 400201304014 + 400201304015 + 400201304016 + 400201304017) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_334,

/*Valuación de instrumentos financieros para cobrar o vender*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400201304006')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200605003','400200605004')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400201304006) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 400200605003 + 400200605004) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_335,

/*Instrumentos financieros (valores)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400200605003')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200306001','400200306002','400200306003')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400200605003) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 400200306001 + 400200306002 + 400200306003) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_336,

/*Cartera de crédito valuada a valor razonable*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400200605004')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200406004','400200406005','400200406006')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400200605004) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 400200406004 + 400200406005 + 400200406006) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_337,

/*Valuación de instrumentos financieros derivados de cobertura de flujos de efectivo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400201304008')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200805005','400200805006','400200805007')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400201304008) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 400200805005 + 400200805006 + 400200805007) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_338,

/*Ingresos y gastos relacionados con activos mantenidos para su disposición*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400201304010')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400201005008','400201005009','400201005010')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400201304010) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 400201005008 + 400201005009 + 400201005010) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_339,

/*Remedición de beneficios definidos a los empleados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400201304012')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400201205011','400201205012')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400201304012) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 400201205011 + 400201205012) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_340,

/*Resultados actuariales en obligaciones*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400201205011')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400201106007','400201106008','400201106009')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400201205011) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 400201106007 + 400201106008 + 400201106009) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_341,

/*Resultado en el retorno de los activos del plan*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400201205012')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400201206010','400201206011','400201206012')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400201205012) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 400201206010 + 400201206011 + 400201206012) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_342,

/*Efecto acumulado por conversión*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400201304014')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400201405013','400201405014','400201405015')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400201304014) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 400201405013 + 400201405014 + 400201405015) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_343,

/*Resultado por tenencia de activos no monetarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400201304016')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400201605016','400201605017')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400201304016) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 400201605016 + 400201605017) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_344,

/*Participación en ORI de otras entidades*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400200203014')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400201404018','400201404019','400201404020')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400200203014) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 400201404018 + 400201404019 + 400201404020) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_345,

/*Participación no controladora*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('440400001001')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('440400102001','440400102002','440400102003')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (440400001001) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 440400102001 + 440400102002 + 440400102003) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_346,

/*CUENTAS DE ORDEN*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('700000000000')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('700200001001','700400001001','700600001001','700800001001','701200001001','701400001001','701600001001','701800001001','702000001001')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (700000000000) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 700200001001 + 700400001001 + 700600001001 + 700800001001 + 701200001001 + 701400001001 + 701600001001 + 701800001001 + 702000001001) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_347,

/*Activos y pasivos contingentes*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('700400001001')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('700400102001','700400102002','700400102003')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (700400001001) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 700400102001 + 700400102002 + 700400102003) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_348,

/*Líneas de crédito irrevocables no ejercidas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('700400102001')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('700400103001','700400103002','700400103003')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (700400102001) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 700400103001 + 700400103002 + 700400103003) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_349,

/*Compromisos crediticios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('700600001001')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('700600102001','700600102002','700600102003')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (700600001001) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 700600102001 + 700600102002 + 700600102003) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_350,

/*Líneas de crédito revocables no ejercidas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('700600102002')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('700600203001','700600203002','700600203003')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (700600102002) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 700600203001 + 700600203002 + 700600203003) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_351,

/*Bienes en fideicomiso o mandato*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('700800001001')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('700800102001','700800102002')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (700800001001) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 700800102001 + 700800102002) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_352,

/*Fideicomisos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('700800102001')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('700800103001','700800103002','700800103003','700800103004','700800103005')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (700800102001) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 700800103001 + 700800103002 + 700800103003 + 700800103004 + 700800103005) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_353,

/*Bienes en custodia o en administración*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('701200001001')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('701200102001','701200102002')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (701200001001) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 701200102001 + 701200102002) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_354,

/*Bienes en custodia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('701200102001')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('701200103001','701200103002','701200103003','701200103004','701200103005')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (701200102001) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 701200103001 + 701200103002 + 701200103003 + 701200103004 + 701200103005) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_355,

/*Bienes en administración*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('701200102002')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('701200203006','701200203007')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (701200102002) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 701200203006 + 701200203007) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_356,

/*Operaciones de banca de inversión por cuenta de terceros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('701200203006')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('701200604001','701200604002','701200604003')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (701200203006) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 701200604001 + 701200604002 + 701200604003) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_357,

/*Colaterales recibidos por la entidad*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('701400001001')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('701400102001','701400102002','701400102003','701400102004','701400102005','701400102006')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (701400001001) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 701400102001 + 701400102002 + 701400102003 + 701400102004 + 701400102005 + 701400102006) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_358,

/*Colaterales recibidos y vendidos o entregados en garantía por la entidad*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('701600001001')  
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('701600102001','701600102002','701600102003','701600102004','701600102005')
AND c05_clave_subsidiaria IN ('040112') 
AND c07_tipo_saldo IN ('130')     
AND c08_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (701600001001) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas ( 701600102001 + 701600102002 + 701600102003 + 701600102004 + 701600102005) con Clave de Subsidiaria 040112, Tipo de Saldo 130 y Tipo de Movimiento 0.')    
AS VALIDACION_359
	
INTO IFRS9_R12A_1219_TS130TM0SUBS040112_RESULT_4
FROM IFRS9_R12A_1219

END

BEGIN
	INSERT INTO IFRS9_R12A_1219_TS130TM0SUBS040112_RESULT_4 IFRS9_R12A_1219_TS130TM0SUBS040112_RESULT_4 IFRS9_R12A_1219_TS130TM0SUBS040112_RESULT_4  
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_301])),
            SUM(CHARINDEX('ERR',[VALIDACION_302])),
            SUM(CHARINDEX('ERR',[VALIDACION_303])),
            SUM(CHARINDEX('ERR',[VALIDACION_304])),
            SUM(CHARINDEX('ERR',[VALIDACION_305])),
            SUM(CHARINDEX('ERR',[VALIDACION_306])),
            SUM(CHARINDEX('ERR',[VALIDACION_307])),
            SUM(CHARINDEX('ERR',[VALIDACION_308])),
            SUM(CHARINDEX('ERR',[VALIDACION_309])),
            SUM(CHARINDEX('ERR',[VALIDACION_310])),
            SUM(CHARINDEX('ERR',[VALIDACION_311])),
            SUM(CHARINDEX('ERR',[VALIDACION_312])),
            SUM(CHARINDEX('ERR',[VALIDACION_313])),
            SUM(CHARINDEX('ERR',[VALIDACION_314])),
            SUM(CHARINDEX('ERR',[VALIDACION_315])),
            SUM(CHARINDEX('ERR',[VALIDACION_316])),
            SUM(CHARINDEX('ERR',[VALIDACION_317])),
            SUM(CHARINDEX('ERR',[VALIDACION_318])),
            SUM(CHARINDEX('ERR',[VALIDACION_319])),
            SUM(CHARINDEX('ERR',[VALIDACION_320])),
            SUM(CHARINDEX('ERR',[VALIDACION_321])),
            SUM(CHARINDEX('ERR',[VALIDACION_322])),
            SUM(CHARINDEX('ERR',[VALIDACION_323])),
            SUM(CHARINDEX('ERR',[VALIDACION_324])),
            SUM(CHARINDEX('ERR',[VALIDACION_325])),
            SUM(CHARINDEX('ERR',[VALIDACION_326])),
            SUM(CHARINDEX('ERR',[VALIDACION_327])),
            SUM(CHARINDEX('ERR',[VALIDACION_328])),
            SUM(CHARINDEX('ERR',[VALIDACION_329])),
            SUM(CHARINDEX('ERR',[VALIDACION_330])),
            SUM(CHARINDEX('ERR',[VALIDACION_331])),
            SUM(CHARINDEX('ERR',[VALIDACION_332])),
            SUM(CHARINDEX('ERR',[VALIDACION_333])),
            SUM(CHARINDEX('ERR',[VALIDACION_334])),
            SUM(CHARINDEX('ERR',[VALIDACION_335])),
            SUM(CHARINDEX('ERR',[VALIDACION_336])),
            SUM(CHARINDEX('ERR',[VALIDACION_337])),
            SUM(CHARINDEX('ERR',[VALIDACION_338])),
            SUM(CHARINDEX('ERR',[VALIDACION_339])),
            SUM(CHARINDEX('ERR',[VALIDACION_340])),
            SUM(CHARINDEX('ERR',[VALIDACION_341])),
            SUM(CHARINDEX('ERR',[VALIDACION_342])),
            SUM(CHARINDEX('ERR',[VALIDACION_343])),
            SUM(CHARINDEX('ERR',[VALIDACION_344])),
            SUM(CHARINDEX('ERR',[VALIDACION_345])),
            SUM(CHARINDEX('ERR',[VALIDACION_346])),
            SUM(CHARINDEX('ERR',[VALIDACION_347])),
            SUM(CHARINDEX('ERR',[VALIDACION_348])),
            SUM(CHARINDEX('ERR',[VALIDACION_349])),
            SUM(CHARINDEX('ERR',[VALIDACION_350])),
            SUM(CHARINDEX('ERR',[VALIDACION_351])),
            SUM(CHARINDEX('ERR',[VALIDACION_352])),
            SUM(CHARINDEX('ERR',[VALIDACION_353])),
            SUM(CHARINDEX('ERR',[VALIDACION_354])),
            SUM(CHARINDEX('ERR',[VALIDACION_355])),
            SUM(CHARINDEX('ERR',[VALIDACION_356])),
            SUM(CHARINDEX('ERR',[VALIDACION_357])),
            SUM(CHARINDEX('ERR',[VALIDACION_358])),
            SUM(CHARINDEX('ERR',[VALIDACION_359])),
            SUM(CHARINDEX('ERR',[VALIDACION_360])),
            SUM(CHARINDEX('ERR',[VALIDACION_361])),
            SUM(CHARINDEX('ERR',[VALIDACION_362])),
            SUM(CHARINDEX('ERR',[VALIDACION_363])),
            SUM(CHARINDEX('ERR',[VALIDACION_364])),
            SUM(CHARINDEX('ERR',[VALIDACION_365])),
            SUM(CHARINDEX('ERR',[VALIDACION_366])),
            SUM(CHARINDEX('ERR',[VALIDACION_367])),
            SUM(CHARINDEX('ERR',[VALIDACION_368])),
            SUM(CHARINDEX('ERR',[VALIDACION_369])),
            SUM(CHARINDEX('ERR',[VALIDACION_370])),
            SUM(CHARINDEX('ERR',[VALIDACION_371])),
            SUM(CHARINDEX('ERR',[VALIDACION_372])),
            SUM(CHARINDEX('ERR',[VALIDACION_373])),
            SUM(CHARINDEX('ERR',[VALIDACION_374])),
            SUM(CHARINDEX('ERR',[VALIDACION_375])),
            SUM(CHARINDEX('ERR',[VALIDACION_376])),
            SUM(CHARINDEX('ERR',[VALIDACION_377])),
            SUM(CHARINDEX('ERR',[VALIDACION_378])),
            SUM(CHARINDEX('ERR',[VALIDACION_379])),
            SUM(CHARINDEX('ERR',[VALIDACION_380])),
            SUM(CHARINDEX('ERR',[VALIDACION_381])),
            SUM(CHARINDEX('ERR',[VALIDACION_382])),
            SUM(CHARINDEX('ERR',[VALIDACION_383])),
            SUM(CHARINDEX('ERR',[VALIDACION_384])),
            SUM(CHARINDEX('ERR',[VALIDACION_385])),
            SUM(CHARINDEX('ERR',[VALIDACION_386])),
            SUM(CHARINDEX('ERR',[VALIDACION_387])),
            SUM(CHARINDEX('ERR',[VALIDACION_388])),
            SUM(CHARINDEX('ERR',[VALIDACION_389])),
            SUM(CHARINDEX('ERR',[VALIDACION_390])),
            SUM(CHARINDEX('ERR',[VALIDACION_391])),
            SUM(CHARINDEX('ERR',[VALIDACION_392])),
            SUM(CHARINDEX('ERR',[VALIDACION_393])),
            SUM(CHARINDEX('ERR',[VALIDACION_394])),
            SUM(CHARINDEX('ERR',[VALIDACION_395])),
            SUM(CHARINDEX('ERR',[VALIDACION_396])),
            SUM(CHARINDEX('ERR',[VALIDACION_397])),
            SUM(CHARINDEX('ERR',[VALIDACION_398])),
            SUM(CHARINDEX('ERR',[VALIDACION_399])),
            SUM(CHARINDEX('ERR',[VALIDACION_400]))
            


		FROM IFRS9_R12A_1219_TS130TM0SUBS040112_RESULT_4 
END

BEGIN
	EXEC SP_IFRS9_R12A_1219_TS130TM0SUBS040112_VIEW_4IFRS9_R12A_1219_TS130TM0SUBS040112_VIEW_4IFRS9_R12A_1219_TS130TM0SUBS040112_VIEW_4
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


