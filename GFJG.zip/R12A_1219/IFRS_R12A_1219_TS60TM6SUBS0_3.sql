﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Consolidación. Consolidación del estado de situación financiera de la institución de crédito con sus subsidiarias */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: AGOSTO 2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: NA*/
/*TIPO SALDO: 60*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: 6*/
/*SUBSIDIARIA: 0*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R12A_1219_TS60TM6SUBS0_COMP_3]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R12A_1219_TS60TM6SUBS0_RESULT_3')
BEGIN
DROP TABLE IFRS9_R12A_1219_TS60TM6SUBS0_RESULT_3
END 

BEGIN
SELECT DISTINCT

	/*ID*/

	CONVERT(VARCHAR,ID)  AS ID,   
	/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812108169')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101816909402','101816909403','101816909404','101816909405')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812108169) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 101816909402 + 101816909403 + 101816909404 + 101816909405) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_201,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101812108170')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101817009406','101817009407','101817009408','101817009409')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812108170) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 101817009406 + 101817009407 + 101817009408 + 101817009409) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_202,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801606062')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806207122','101806207123','101806207124','101806207125','101806207126','101806207127','101806207128','101806207129')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101801606062) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 101806207122 + 101806207123 + 101806207124 + 101806207125 + 101806207126 + 101806207127 + 101806207128 + 101806207129) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_203,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801606063')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806307130','101806307131','101806307132','101806307133','101806307134')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101801606063) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 101806307130 + 101806307131 + 101806307132 + 101806307133 + 101806307134) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_204,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806307132')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101813208271','101813208272')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101806307132) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 101813208271 + 101813208272) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_205,

/*Cartera con riesgo de crédito etapa 3*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800505018')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801806066','101801806067','101801806068')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800505018) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 101801806066 + 101801806067 + 101801806068) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_206,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801806066')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806607155','101806607156','101806607157')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101801806066) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 101806607155 + 101806607156 + 101806607157) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_207,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806607155')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815508293','101815508294','101815508295','101815508296','101815508297','101815508298','101815508299','101815508300')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101806607155) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 101815508293 + 101815508294 + 101815508295 + 101815508296 + 101815508297 + 101815508298 + 101815508299 + 101815508300) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_208,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101815508293')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101829309430','101829309431')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101815508293) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 101829309430 + 101829309431) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_209,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101815508294')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101829409432','101829409433','101829409434')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101815508294) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 101829409432 + 101829409433 + 101829409434) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_210,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101815508295')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101829509435','101829509436')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101815508295) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 101829509435 + 101829509436) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_211,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806607156')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815608301','101815608302')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101806607156) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 101815608301 + 101815608302) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_212,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101815608301')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830109487','101830109488','101830109489')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101815608301) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 101830109487 + 101830109488 + 101830109489) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_213,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101815608302')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830209490','101830209491','101830209492')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101815608302) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 101830209490 + 101830209491 + 101830209492) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_214,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806607157')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815708303','101815708304','101815708305','101815708306')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101806607157) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 101815708303 + 101815708304 + 101815708305 + 101815708306) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_215,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101815708304')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830409504','101830409505','101830409506','101830409507','101830409508')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101815708304) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 101830409504 + 101830409505 + 101830409506 + 101830409507 + 101830409508) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_216,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101815708305')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830509509','101830509510','101830509511','101830509512')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101815708305) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 101830509509 + 101830509510 + 101830509511 + 101830509512) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_217,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101815708306')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830609513','101830609514','101830609515','101830609516')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101815708306) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 101830609513 + 101830609514 + 101830609515 + 101830609516) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_218,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801806067')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806707158','101806707159','101806707160','101806707161','101806707162','101806707163','101806707164','101806707165')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101801806067) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 101806707158 + 101806707159 + 101806707160 + 101806707161 + 101806707162 + 101806707163 + 101806707164 + 101806707165) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_219,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801806068')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806807166','101806807167','101806807168','101806807169','101806807170')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101801806068) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 101806807166 + 101806807167 + 101806807168 + 101806807169 + 101806807170) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_220,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806807168')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101816808407','101816808408')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101806807168) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 101816808407 + 101816808408) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_221,

/*Estimación preventiva para riesgos crediticios adicional*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800304006')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800605021','101800605022','101800605023','101800605024','101800605025','101800605026')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800304006) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 101800605021 + 101800605022 + 101800605023 + 101800605024 + 101800605025 + 101800605026) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_222,

/*Cartera de crédito (neto)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('131800102001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800203004','101800203005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (131800102001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 101800203004 + 101800203005) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_223,

/*Activos virtuales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102000001001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102000102001','102000102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (102000001001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 102000102001 + 102000102002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_224,

/*Beneficios por recibir en operaciones de bursatilización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102200001001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102200102001','102200102002','102400102001','102400102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (102200001001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 102200102001 + 102200102002 + 102400102001 + 102400102002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_225,

/*Otras cuentas por cobrar*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102400102001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102400103001','102400103002','102400103003','102400103004','102400103005','102400103006','102400103007','102400103008','102400103009')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (102400102001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 102400103001 + 102400103002 + 102400103003 + 102400103004 + 102400103005 + 102400103006 + 102400103007 + 102400103008 + 102400103009) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_226,

/*Deudores por liquidación de operaciones*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102400103001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102400104001','102400104002','102400104003','102400104004','102400104005','102400104006','102400104007')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (102400103001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 102400104001 + 102400104002 + 102400104003 + 102400104004 + 102400104005 + 102400104006 + 102400104007) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_227,

/*Deudores por colaterales otorgados en efectivo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102400103003')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102400304008','102400304009','102400304010','102400304011')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (102400103003) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 102400304008 + 102400304009 + 102400304010 + 102400304011) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_228,

/*Derechos de cobro*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102400103004')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102400404012','102400404013')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (102400103004) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 102400404012 + 102400404013) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_229,

/*Deudores diversos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102400103005')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102400504014','102400504015','102400504016','102400504017','102400504018','102400504019','102400504020')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (102400103005) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 102400504014 + 102400504015 + 102400504016 + 102400504017 + 102400504018 + 102400504019 + 102400504020) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_230,

/*Estimación de pérdidas crediticias esperadas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102400102002')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102400203010','102400203011','102400203012')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (102400102002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 102400203010 + 102400203011 + 102400203012) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_231,

/*Otras cuentas por cobrar (neto)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('132400001001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102600102001','102600102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (132400001001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 102600102001 + 102600102002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_232,

/*Bienes adjudicados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102600102001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102600103001','102600103002','102600103003','102600103004','102600103005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (102600102001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 102600103001 + 102600103002 + 102600103003 + 102600103004 + 102600103005) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_233,

/*Estimación de bienes adjudicados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102600102002')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102600203006','102600203007','102600203008')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (102600102002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 102600203006 + 102600203007 + 102600203008) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_234,

/*Activos de larga duración mantenidos para la venta o para distribuir a los propietarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102800001001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102800102001','102800102002','102800102003','102800102004','102800102005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (102800001001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 102800102001 + 102800102002 + 102800102003 + 102800102004 + 102800102005) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_235,

/*Subsidiarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102800102001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102800103001','102800103002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (102800102001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 102800103001 + 102800103002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_236,

/*Asociadas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102800102002')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102800203003','102800203004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (102800102002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 102800203003 + 102800203004) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_237,

/*Negocios conjuntos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102800102003')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102800303005','102800303006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (102800102003) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 102800303005 + 102800303006) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_238,

/*Otras inversiones permanentes*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102800102004')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102800403007','102800403008')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (102800102004) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 102800403007 + 102800403008) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_239,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102800102005')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102800503009','102800503010')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (102800102005) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 102800503009 + 102800503010) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_240,

/*Pagos anticipados y otros activos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('103200001001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('103200102001','103200102002','103200102003','103200102004','103200102005','103400102001','103400102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (103200001001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 103200102001 + 103200102002 + 103200102003 + 103200102004 + 103200102005 + 103400102001 + 103400102002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_241,

/*Cargos diferidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('103200102001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('103200103001','103200103002','103200103003','103200103004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (103200102001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 103200103001 + 103200103002 + 103200103003 + 103200103004) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_242,

/*Pagos anticipados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('103200102002')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('103200203005','103200203006','103200203007','103200203008','103200203009')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (103200102002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 103200203005 + 103200203006 + 103200203007 + 103200203008 + 103200203009) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_243,

/*Activos por beneficios a los empleados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('103200102004')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('103200403010','103200403011','103200403012')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (103200102004) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 103200403010 + 103200403011 + 103200403012) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_244,

/*Activos del plan para cubrir beneficios a los empleados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('103200403010')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('103201004001','103201004002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (103200403010) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 103201004001 + 103201004002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_245,

/*Beneficios post-empleo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('103201004002')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('103200205001','103200205002','103200205003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (103201004002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 103200205001 + 103200205002 + 103200205003) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_246,

/*Propiedades, mobiliario y equipo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('103400102001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('103400103001','103400103002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (103400102001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 103400103001 + 103400103002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_247,

/*Propiedades, mobiliario y equipo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('103400103001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('103400104001','103400104002','103400104003','103400104004','103400104005','103400104006','103400104007','103400104008')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (103400103001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 103400104001 + 103400104002 + 103400104003 + 103400104004 + 103400104005 + 103400104006 + 103400104007 + 103400104008) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_248,

/*Revaluación de propiedades, mobiliario y equipo (1)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('103400103002')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('103400204009','103400204010','103400204011','103400204012','103400204013','103400204014','103400204015','103400204016')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (103400103002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 103400204009 + 103400204010 + 103400204011 + 103400204012 + 103400204013 + 103400204014 + 103400204015 + 103400204016) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_249,

/*Depreciación acumulada de propiedades, mobiliario y equipo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('103400102002')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('103400203003','103400203004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (103400102002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 103400203003 + 103400203004) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_250,

/*Depreciación acumulada de propiedades, mobiliario y equipo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('103400203003')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('103400304017','103400304018','103400304019','103400304020','103400304021','103400304022')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (103400203003) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 103400304017 + 103400304018 + 103400304019 + 103400304020 + 103400304021 + 103400304022) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_251,

/*Revaluación de la depreciación acumulada de propiedades, mobiliario y equipo (1)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('103400203004')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('103400404023','103400404024','103400404025','103400404026','103400404027','103400404028')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (103400203004) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 103400404023 + 103400404024 + 103400404025 + 103400404026 + 103400404027 + 103400404028) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_252,

/*Propiedades, mobiliario y equipo (neto)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('133400001001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('103600102001','103600102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (133400001001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 103600102001 + 103600102002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_253,

/*Activos por derechos de uso de propiedades, mobiliario y equipo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('103600102001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('103600103001','103600103002','103600103003','103600103004','103600103005','103600103006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (103600102001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 103600103001 + 103600103002 + 103600103003 + 103600103004 + 103600103005 + 103600103006) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_254,

/*Depreciación de activos por derechos de uso de propiedades, mobiliario y equipo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('103600102002')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('103600203007','103600203008','103600203009','103600203010','103600203011','103600203012')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (103600102002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 103600203007 + 103600203008 + 103600203009 + 103600203010 + 103600203011 + 103600203012) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_255,

/*Inversiones permanentes*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('103800001001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('103800102001','103800102002','103800102003','103800102004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (103800001001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 103800102001 + 103800102002 + 103800102003 + 103800102004) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_256,

/*Subsidiarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('103800102001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('103800103001','103800103002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (103800102001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 103800103001 + 103800103002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_257,

/*Asociadas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('103800102002')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('103800203003','103800203004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (103800102002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 103800203003 + 103800203004) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_258,

/*Negocios conjuntos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('103800102003')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('103800303005','103800303006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (103800102003) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 103800303005 + 103800303006) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_259,

/*Otras inversiones permanentes*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('103800102004')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('103800403007','103800403008')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (103800102004) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 103800403007 + 103800403008) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_260,

/*Activo por impuestos a la utilidad diferidos (neto)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('104000001001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('104000102001','104000102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (104000001001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 104000102001 + 104000102002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_261,

/*Impuestos a la utilidad diferidos (a favor)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('104000102001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('104000103001','104000103002','104000103003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (104000102001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 104000103001 + 104000103002 + 104000103003) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_262,

/*Estimación por impuestos a la utilidad diferidos no recuperables*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('104000102002')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('104000203004','104000203005','104000203006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (104000102002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 104000203004 + 104000203005 + 104000203006) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_263,

/*Activos intangibles (neto)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('134200001001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('104200102001','104200102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (134200001001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 104200102001 + 104200102002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_264,

/*Activos intangibles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('104200102001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('104200103001','104200103002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (104200102001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 104200103001 + 104200103002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_265,

/*Amortización acumulada de otros activos intangibles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('104200102002')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('104200203003','104200203004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (104200102002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 104200203003 + 104200203004) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_266,

/*Activos por derechos de uso de activos intangibles (neto)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('134400001001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('104400102001','104400102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (134400001001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 104400102001 + 104400102002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_267,

/*Crédito mercantil*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('104600001001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('104600102001','104600102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (104600001001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 104600102001 + 104600102002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_268,

/*Crédito mercantil*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('104600102001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('104600103001','104600103002','104600103003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (104600102001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 104600103001 + 104600103002 + 104600103003) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_269,

/*Revaluación del crédito mercantil (1)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('104600102002')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('104600203004','104600203005','104600203006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (104600102002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 104600203004 + 104600203005 + 104600203006) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_270,

/*PASIVO*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('200000000000')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('200200001001','200400001001','230600001001','200800001001','201000001001','201200001001','201400001001','201600001001','201800001001','202000001001','202400001001','202600001001','202800001001','203000001001','203200001001','203400001001','203600001001','203800001001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (200000000000) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 200200001001 + 200400001001 + 230600001001 + 200800001001 + 201000001001 + 201200001001 + 201400001001 + 201600001001 + 201800001001 + 202000001001 + 202400001001 + 202600001001 + 202800001001 + 203000001001 + 203200001001 + 203400001001 + 203600001001 + 203800001001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_271,

/*Captación tradicional*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('200200001001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('200200102001','200200102002','200200102003','200200102004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (200200001001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 200200102001 + 200200102002 + 200200102003 + 200200102004) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_272,

/*Depósitos de exigibilidad inmediata*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('200200102001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('200200103001','200200103002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (200200102001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 200200103001 + 200200103002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_273,

/*Depósitos a plazo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('200200102002')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('200200203003','200200203004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (200200102002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 200200203003 + 200200203004) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_274,

/*Títulos de crédito emitidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('200200102003')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('200200303006','200200303007','200200303008')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (200200102003) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 200200303006 + 200200303007 + 200200303008) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_275,

/*Bonos bancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('200200303006')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('200200604045','200200604046','200200604047')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (200200303006) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 200200604045 + 200200604046 + 200200604047) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_276,

/*Certificados bursátiles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('200200303007')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('200200704053','200200704054','200200704055')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (200200303007) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 200200704053 + 200200704054 + 200200704055) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_277,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('200200303008')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('200200804061','200200804062','200200804063')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (200200303008) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 200200804061 + 200200804062 + 200200804063) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_278,

/*Préstamos interbancarios y de otros organismos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('200400001001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('200400102001','200400102002','200400102003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (200400001001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 200400102001 + 200400102002 + 200400102003) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_279,

/*De corto plazo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('200400102002')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('200400203001','200400203002','200400203003','200400203004','200400203005','200400203006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (200400102002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 200400203001 + 200400203002 + 200400203003 + 200400203004 + 200400203005 + 200400203006) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_280,

/*De largo plazo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('200400102003')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('200400303009','200400303010','200400303011','200400303012','200400303013','200400303014')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (200400102003) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 200400303009 + 200400303010 + 200400303011 + 200400303012 + 200400303013 + 200400303014) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_281,

/*Colaterales vendidos o dados en garantía*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('201200001001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('201200102001','201200102002','201200102003','201200102004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (201200001001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 201200102001 + 201200102002 + 201200102003 + 201200102004) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_282,

/*Reportos (saldo acreedor)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('201200102001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('201200103001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (201200102001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 201200103001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_283,

/*Obligación de la reportadora por restitución del colateral a la reportada*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('201200103001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('201200104001','201200104002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (201200103001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 201200104001 + 201200104002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_284,

/*Colaterales vendidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('201200104001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('201200105001','201200105002','201200105003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (201200104001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 201200105001 + 201200105002 + 201200105003) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_285,

/*Préstamo de valores*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('201200102002')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('201200203002','201200203003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (201200102002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 201200203002 + 201200203003) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_286,

/*Obligación del prestatario por restitución de valores objeto de la operación al prestamista*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('201200203002')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('201200204003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (201200203002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 201200204003) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_287,

/*Colaterales vendidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('201200204003')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('201200305004','201200305005','201200305006','201200305007')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (201200204003) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 201200305004 + 201200305005 + 201200305006 + 201200305007) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_288,

/*Obligación del prestamista por restitución del colateral al prestatario*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('201200203003')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('201200304004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (201200203003) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 201200304004) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_289,

/*Colaterales vendidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('201200304004')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('201200405008','201200405009','201200405010','201200405011')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (201200304004) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 201200405008 + 201200405009 + 201200405010 + 201200405011) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_290,

/*Instrumentos financieros derivados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('201200102003')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('201200303004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (201200102003) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 201200303004) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_291,

/*Colaterales vendidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('201200303004')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('201200404005','201200404006','201200404007','201200404008','201200404009')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (201200303004) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 201200404005 + 201200404006 + 201200404007 + 201200404008 + 201200404009) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_292,

/*Instrumentos financieros derivados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('201400001001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('201400102001','201400102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (201400001001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 201400102001 + 201400102002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_293,

/*Con fines de negociación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('201400102001')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('201400103001','201400103002','201400103003','201400103004','201400103005','201400103006','201400103007')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (201400102001) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 201400103001 + 201400103002 + 201400103003 + 201400103004 + 201400103005 + 201400103006 + 201400103007) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_294,

/*Con fines de cobertura*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('201400102002')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('201400203008','201400203009','201400203010','201400203011','201400203012','201400203013','201400203014')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (201400102002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 201400203008 + 201400203009 + 201400203010 + 201400203011 + 201400203012 + 201400203013 + 201400203014) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_295,

/*Futuros a entregar*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('201400203008')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('201400804001','201400804002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (201400203008) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 201400804001 + 201400804002) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_296,

/*Contratos adelantados a entregar*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('201400203009')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('201400904003','201400904004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (201400203009) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 201400904003 + 201400904004) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_297,

/*Opciones*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('201400203010')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('201401004005','201401004006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (201400203010) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 201401004005 + 201401004006) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_298,

/*Swaps*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('201400203011')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('201401104007','201401104008')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (201400203011) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 201401104007 + 201401104008) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_299,

/*Instrumentos financieros derivados crediticios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('201400203012')  
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')    
AND c08_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('201401204009','201401204010')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('60')     
AND c08_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (201400203012) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas ( 201401204009 + 201401204010) con Clave de Subsidiaria 0, Tipo de Saldo 60 y Tipo de Movimiento 6.')    
AS VALIDACION_300
	
INTO IFRS9_R12A_1219_TS60TM6SUBS0_RESULT_3
FROM IFRS9_R12A_1219

END

BEGIN
	INSERT INTO IFRS9_R12A_1219_TS60TM6SUBS0_RESULT_3 IFRS9_R12A_1219_TS60TM6SUBS0_RESULT_3 
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_201])),
            SUM(CHARINDEX('ERR',[VALIDACION_202])),
            SUM(CHARINDEX('ERR',[VALIDACION_203])),
            SUM(CHARINDEX('ERR',[VALIDACION_204])),
            SUM(CHARINDEX('ERR',[VALIDACION_205])),
            SUM(CHARINDEX('ERR',[VALIDACION_206])),
            SUM(CHARINDEX('ERR',[VALIDACION_207])),
            SUM(CHARINDEX('ERR',[VALIDACION_208])),
            SUM(CHARINDEX('ERR',[VALIDACION_209])),
            SUM(CHARINDEX('ERR',[VALIDACION_210])),
            SUM(CHARINDEX('ERR',[VALIDACION_211])),
            SUM(CHARINDEX('ERR',[VALIDACION_212])),
            SUM(CHARINDEX('ERR',[VALIDACION_213])),
            SUM(CHARINDEX('ERR',[VALIDACION_214])),
            SUM(CHARINDEX('ERR',[VALIDACION_215])),
            SUM(CHARINDEX('ERR',[VALIDACION_216])),
            SUM(CHARINDEX('ERR',[VALIDACION_217])),
            SUM(CHARINDEX('ERR',[VALIDACION_218])),
            SUM(CHARINDEX('ERR',[VALIDACION_219])),
            SUM(CHARINDEX('ERR',[VALIDACION_220])),
            SUM(CHARINDEX('ERR',[VALIDACION_221])),
            SUM(CHARINDEX('ERR',[VALIDACION_222])),
            SUM(CHARINDEX('ERR',[VALIDACION_223])),
            SUM(CHARINDEX('ERR',[VALIDACION_224])),
            SUM(CHARINDEX('ERR',[VALIDACION_225])),
            SUM(CHARINDEX('ERR',[VALIDACION_226])),
            SUM(CHARINDEX('ERR',[VALIDACION_227])),
            SUM(CHARINDEX('ERR',[VALIDACION_228])),
            SUM(CHARINDEX('ERR',[VALIDACION_229])),
            SUM(CHARINDEX('ERR',[VALIDACION_230])),
            SUM(CHARINDEX('ERR',[VALIDACION_231])),
            SUM(CHARINDEX('ERR',[VALIDACION_232])),
            SUM(CHARINDEX('ERR',[VALIDACION_233])),
            SUM(CHARINDEX('ERR',[VALIDACION_234])),
            SUM(CHARINDEX('ERR',[VALIDACION_235])),
            SUM(CHARINDEX('ERR',[VALIDACION_236])),
            SUM(CHARINDEX('ERR',[VALIDACION_237])),
            SUM(CHARINDEX('ERR',[VALIDACION_238])),
            SUM(CHARINDEX('ERR',[VALIDACION_239])),
            SUM(CHARINDEX('ERR',[VALIDACION_240])),
            SUM(CHARINDEX('ERR',[VALIDACION_241])),
            SUM(CHARINDEX('ERR',[VALIDACION_242])),
            SUM(CHARINDEX('ERR',[VALIDACION_243])),
            SUM(CHARINDEX('ERR',[VALIDACION_244])),
            SUM(CHARINDEX('ERR',[VALIDACION_245])),
            SUM(CHARINDEX('ERR',[VALIDACION_246])),
            SUM(CHARINDEX('ERR',[VALIDACION_247])),
            SUM(CHARINDEX('ERR',[VALIDACION_248])),
            SUM(CHARINDEX('ERR',[VALIDACION_249])),
            SUM(CHARINDEX('ERR',[VALIDACION_250])),
            SUM(CHARINDEX('ERR',[VALIDACION_251])),
            SUM(CHARINDEX('ERR',[VALIDACION_252])),
            SUM(CHARINDEX('ERR',[VALIDACION_253])),
            SUM(CHARINDEX('ERR',[VALIDACION_254])),
            SUM(CHARINDEX('ERR',[VALIDACION_255])),
            SUM(CHARINDEX('ERR',[VALIDACION_256])),
            SUM(CHARINDEX('ERR',[VALIDACION_257])),
            SUM(CHARINDEX('ERR',[VALIDACION_258])),
            SUM(CHARINDEX('ERR',[VALIDACION_259])),
            SUM(CHARINDEX('ERR',[VALIDACION_260])),
            SUM(CHARINDEX('ERR',[VALIDACION_261])),
            SUM(CHARINDEX('ERR',[VALIDACION_262])),
            SUM(CHARINDEX('ERR',[VALIDACION_263])),
            SUM(CHARINDEX('ERR',[VALIDACION_264])),
            SUM(CHARINDEX('ERR',[VALIDACION_265])),
            SUM(CHARINDEX('ERR',[VALIDACION_266])),
            SUM(CHARINDEX('ERR',[VALIDACION_267])),
            SUM(CHARINDEX('ERR',[VALIDACION_268])),
            SUM(CHARINDEX('ERR',[VALIDACION_269])),
            SUM(CHARINDEX('ERR',[VALIDACION_270])),
            SUM(CHARINDEX('ERR',[VALIDACION_271])),
            SUM(CHARINDEX('ERR',[VALIDACION_272])),
            SUM(CHARINDEX('ERR',[VALIDACION_273])),
            SUM(CHARINDEX('ERR',[VALIDACION_274])),
            SUM(CHARINDEX('ERR',[VALIDACION_275])),
            SUM(CHARINDEX('ERR',[VALIDACION_276])),
            SUM(CHARINDEX('ERR',[VALIDACION_277])),
            SUM(CHARINDEX('ERR',[VALIDACION_278])),
            SUM(CHARINDEX('ERR',[VALIDACION_279])),
            SUM(CHARINDEX('ERR',[VALIDACION_280])),
            SUM(CHARINDEX('ERR',[VALIDACION_281])),
            SUM(CHARINDEX('ERR',[VALIDACION_282])),
            SUM(CHARINDEX('ERR',[VALIDACION_283])),
            SUM(CHARINDEX('ERR',[VALIDACION_284])),
            SUM(CHARINDEX('ERR',[VALIDACION_285])),
            SUM(CHARINDEX('ERR',[VALIDACION_286])),
            SUM(CHARINDEX('ERR',[VALIDACION_287])),
            SUM(CHARINDEX('ERR',[VALIDACION_288])),
            SUM(CHARINDEX('ERR',[VALIDACION_289])),
            SUM(CHARINDEX('ERR',[VALIDACION_290])),
            SUM(CHARINDEX('ERR',[VALIDACION_291])),
            SUM(CHARINDEX('ERR',[VALIDACION_292])),
            SUM(CHARINDEX('ERR',[VALIDACION_293])),
            SUM(CHARINDEX('ERR',[VALIDACION_294])),
            SUM(CHARINDEX('ERR',[VALIDACION_295])),
            SUM(CHARINDEX('ERR',[VALIDACION_296])),
            SUM(CHARINDEX('ERR',[VALIDACION_297])),
            SUM(CHARINDEX('ERR',[VALIDACION_298])),
            SUM(CHARINDEX('ERR',[VALIDACION_299])),
            SUM(CHARINDEX('ERR',[VALIDACION_300]))
            


		FROM IFRS9_R12A_1219_TS60TM6SUBS0_RESULT_3 
END

BEGIN
	EXEC SP_IFRS9_R12A_1219_TS60TM6SUBS0_VIEW_3IFRS9_R12A_1219_TS60TM6SUBS0_VIEW_3
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


