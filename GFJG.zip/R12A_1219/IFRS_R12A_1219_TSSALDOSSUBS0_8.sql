﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Consolidación. Consolidación del estado de situación financiera de la institución de crédito con sus subsidiarias */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: AGOSTO 2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: NA*/
/*TIPO SALDO: SALDOS*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/
/*SUBSIDIARIA: 0*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R12A_1219_TSSALDOSSUBS0_COMP_8]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R12A_1219_TSSALDOSSUBS0_RESULT_8')
BEGIN
DROP TABLE IFRS9_R12A_1219_TSSALDOSSUBS0_RESULT_8
END 

BEGIN
SELECT DISTINCT

	/*ID*/

	CONVERT(VARCHAR,ID)  AS ID,   
	/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801606063')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801606063')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801606063')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801606063) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101801606063) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101801606063) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_701,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806307130')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806307130')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806307130')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806307130) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806307130) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806307130) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_702,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806307131')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806307131')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806307131')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806307131) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806307131) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806307131) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_703,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806307132')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806307132')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806307132')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806307132) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806307132) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806307132) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_704,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101813208271')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101813208271')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101813208271')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101813208271) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101813208271) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101813208271) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_705,

/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101813208272')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101813208272')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101813208272')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101813208272) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101813208272) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101813208272) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_706,

/*Remodelación o mejoramiento con garantía otorgada por la banca de desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806307133')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806307133')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806307133')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806307133) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806307133) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806307133) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_707,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806307134')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806307134')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806307134')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806307134) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806307134) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806307134) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_708,

/*Cartera con riesgo de crédito etapa 3*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800505018')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800505018')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800505018')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800505018) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101800505018) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101800505018) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_709,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801806066')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801806066')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801806066')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801806066) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101801806066) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101801806066) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_710,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806607155')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806607155')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806607155')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806607155) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806607155) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806607155) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_711,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101815508293')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815508293')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815508293')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101815508293) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101815508293) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101815508293) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_712,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101829309430')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101829309430')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101829309430')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101829309430) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101829309430) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101829309430) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_713,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101829309431')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101829309431')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101829309431')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101829309431) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101829309431) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101829309431) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_714,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101815508294')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815508294')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815508294')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101815508294) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101815508294) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101815508294) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_715,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101829409432')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101829409432')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101829409432')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101829409432) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101829409432) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101829409432) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_716,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101829409433')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101829409433')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101829409433')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101829409433) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101829409433) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101829409433) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_717,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101829409434')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101829409434')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101829409434')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101829409434) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101829409434) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101829409434) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_718,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101815508295')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815508295')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815508295')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101815508295) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101815508295) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101815508295) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_719,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101829509435')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101829509435')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101829509435')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101829509435) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101829509435) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101829509435) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_720,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101829509436')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101829509436')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101829509436')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101829509436) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101829509436) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101829509436) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_721,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101815508296')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815508296')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815508296')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101815508296) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101815508296) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101815508296) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_722,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101815508297')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815508297')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815508297')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101815508297) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101815508297) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101815508297) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_723,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101815508298')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815508298')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815508298')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101815508298) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101815508298) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101815508298) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_724,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101815508299')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815508299')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815508299')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101815508299) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101815508299) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101815508299) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_725,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101815508300')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815508300')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815508300')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101815508300) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101815508300) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101815508300) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_726,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806607156')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806607156')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806607156')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806607156) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806607156) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806607156) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_727,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101815608301')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815608301')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815608301')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101815608301) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101815608301) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101815608301) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_728,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101830109487')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830109487')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830109487')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101830109487) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101830109487) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101830109487) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_729,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101830109488')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830109488')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830109488')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101830109488) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101830109488) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101830109488) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_730,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101830109489')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830109489')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830109489')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101830109489) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101830109489) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101830109489) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_731,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101815608302')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815608302')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815608302')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101815608302) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101815608302) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101815608302) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_732,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101830209490')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830209490')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830209490')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101830209490) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101830209490) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101830209490) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_733,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101830209491')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830209491')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830209491')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101830209491) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101830209491) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101830209491) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_734,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101830209492')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830209492')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830209492')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101830209492) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101830209492) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101830209492) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_735,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806607157')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806607157')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806607157')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806607157) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806607157) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806607157) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_736,

/*Créditos al gobierno federal*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101815708303')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815708303')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815708303')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101815708303) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101815708303) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101815708303) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_737,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101815708304')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815708304')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815708304')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101815708304) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101815708304) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101815708304) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_738,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101830409504')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830409504')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830409504')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101830409504) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101830409504) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101830409504) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_739,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101830409505')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830409505')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830409505')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101830409505) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101830409505) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101830409505) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_740,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101830409506')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830409506')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830409506')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101830409506) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101830409506) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101830409506) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_741,

/*Fideicomisos públicos de contratación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101830409507')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830409507')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830409507')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101830409507) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101830409507) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101830409507) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_742,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101830409508')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830409508')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830409508')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101830409508) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101830409508) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101830409508) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_743,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101815708305')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815708305')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815708305')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101815708305) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101815708305) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101815708305) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_744,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101830509509')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830509509')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830509509')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101830509509) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101830509509) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101830509509) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_745,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101830509510')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830509510')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830509510')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101830509510) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101830509510) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101830509510) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_746,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101830509511')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830509511')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830509511')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101830509511) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101830509511) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101830509511) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_747,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101830509512')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830509512')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830509512')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101830509512) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101830509512) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101830509512) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_748,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101815708306')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815708306')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101815708306')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101815708306) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101815708306) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101815708306) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_749,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101830609513')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830609513')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830609513')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101830609513) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101830609513) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101830609513) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_750,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101830609514')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830609514')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830609514')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101830609514) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101830609514) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101830609514) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_751,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101830609515')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830609515')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830609515')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101830609515) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101830609515) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101830609515) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_752,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101830609516')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830609516')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101830609516')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101830609516) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101830609516) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101830609516) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_753,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801806067')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801806067')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801806067')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801806067) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101801806067) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101801806067) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_754,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806707158')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806707158')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806707158')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806707158) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806707158) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806707158) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_755,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806707159')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806707159')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806707159')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806707159) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806707159) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806707159) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_756,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806707160')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806707160')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806707160')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806707160) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806707160) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806707160) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_757,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806707161')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806707161')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806707161')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806707161) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806707161) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806707161) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_758,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806707162')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806707162')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806707162')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806707162) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806707162) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806707162) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_759,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806707163')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806707163')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806707163')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806707163) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806707163) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806707163) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_760,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806707164')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806707164')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806707164')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806707164) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806707164) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806707164) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_761,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806707165')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806707165')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806707165')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806707165) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806707165) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806707165) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_762,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101801806068')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801806068')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101801806068')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801806068) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101801806068) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101801806068) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_763,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806807166')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806807166')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806807166')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806807166) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806807166) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806807166) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_764,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806807167')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806807167')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806807167')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806807167) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806807167) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806807167) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_765,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806807168')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806807168')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806807168')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806807168) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806807168) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806807168) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_766,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101816808407')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101816808407')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101816808407')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101816808407) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101816808407) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101816808407) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_767,

/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101816808408')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101816808408')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101816808408')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101816808408) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101816808408) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101816808408) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_768,

/*Remodelación o mejoramiento con garantía otorgada por la banca de desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806807169')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806807169')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806807169')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806807169) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806807169) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806807169) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_769,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101806807170')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806807170')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101806807170')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806807170) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101806807170) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101806807170) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_770,

/*Operaciones contingentes y avales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800505020')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800505020')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800505020')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800505020) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101800505020) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101800505020) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_771,

/*Estimación preventiva para riesgos crediticios adicional*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800304006')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800304006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800304006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800304006) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101800304006) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101800304006) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_772,

/*Para cobertura de riesgo sobre cartera de vivienda con riesgo de crédito etapa 3*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800605021')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800605021')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800605021')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800605021) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101800605021) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101800605021) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_773,

/*Por sobretasa en bonos gubernamentales esquema de descuentos en los pagos oportunos y anticipados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800605022')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800605022')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800605022')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800605022) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101800605022) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101800605022) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_774,

/*Por riesgos operativos (Sociedades de Información Crediticia)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800605023')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800605023')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800605023')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800605023) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101800605023) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101800605023) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_775,

/*Por intereses devengados sobre créditos con riesgo de crédito etapa 3*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800605024')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800605024')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800605024')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800605024) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101800605024) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101800605024) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_776,

/*Ordenada por la Comisión Nacional Bancaria y de Valores*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800605025')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800605025')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800605025')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800605025) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101800605025) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101800605025) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_777,

/*Reconocida por la Comisión Nacional Bancaria y de Valores*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800605026')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800605026')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800605026')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800605026) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101800605026) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101800605026) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_778,

/*Cartera de crédito (neto)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('131800102001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('131800102001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('131800102001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (131800102001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (131800102001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (131800102001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_779,

/*Derechos de cobro adquiridos (créditos deteriorados)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800203004')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800203004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800203004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800203004) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101800203004) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101800203004) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_780,

/*Estimación preventiva para riesgos crediticios derivada de derechos de cobro adquiridos (créditos deteriorados)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('101800203005')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800203005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('101800203005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800203005) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (101800203005) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (101800203005) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_781,

/*Derechos de cobro adquiridos (neto)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('131800102002')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('131800102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('131800102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (131800102002) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (131800102002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (131800102002) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_782,

/*Total de cartera de crédito (neto)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('131800001001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('131800001001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('131800001001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (131800001001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (131800001001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (131800001001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_783,

/*Activos virtuales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102000001001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102000001001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102000001001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (102000001001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (102000001001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (102000001001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_784,

/*Activos virtuales restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102000102001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102000102001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102000102001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (102000102001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (102000102001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (102000102001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_785,

/*Activos virtuales no restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102000102002')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102000102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102000102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (102000102002) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (102000102002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (102000102002) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_786,

/*Beneficios por recibir en operaciones de bursatilización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102200001001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102200001001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102200001001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (102200001001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (102200001001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (102200001001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_787,

/*Beneficios sobre el remanente en operaciones de bursatilización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102200102001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102200102001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102200102001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (102200102001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (102200102001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (102200102001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_788,

/*Activo por administración de activos financieros transferidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102200102002')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102200102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102200102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (102200102002) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (102200102002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (102200102002) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_789,

/*Otras cuentas por cobrar*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102400102001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102400102001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102400102001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (102400102001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (102400102001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (102400102001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_790,

/*Deudores por liquidación de operaciones*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102400103001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102400103001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102400103001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (102400103001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (102400103001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (102400103001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_791,

/*Compraventa de divisas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102400104001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102400104001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102400104001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (102400104001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (102400104001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (102400104001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_792,

/*Inversiones en instrumentos financieros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102400104002')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102400104002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102400104002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (102400104002) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (102400104002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (102400104002) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_793,

/*Reportos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102400104003')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102400104003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102400104003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (102400104003) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (102400104003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (102400104003) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_794,

/*Préstamo de valores*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102400104004')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102400104004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102400104004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (102400104004) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (102400104004) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (102400104004) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_795,

/*Instrumentos financieros derivados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102400104005')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102400104005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102400104005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (102400104005) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (102400104005) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (102400104005) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_796,

/*Por emisión de títulos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102400104006')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102400104006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102400104006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (102400104006) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (102400104006) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (102400104006) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_797,

/*Activos virtuales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102400104007')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102400104007')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102400104007')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (102400104007) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (102400104007) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (102400104007) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_798,

/*Deudores por cuentas de margen*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102400103002')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102400103002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102400103002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (102400103002) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (102400103002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (102400103002) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_799,

/*Deudores por colaterales otorgados en efectivo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('102400103003')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102400103003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('102400103003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (102400103003) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (102400103003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (102400103003) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_800
	
INTO IFRS9_R12A_1219_TSSALDOSSUBS0_RESULT_8
FROM IFRS9_R12A_1219

END

BEGIN
	INSERT INTO IFRS9_R12A_1219_TSSALDOSSUBS0_RESULT_8 IFRS9_R12A_1219_TSSALDOSSUBS0_RESULT_8 
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_701])),
            SUM(CHARINDEX('ERR',[VALIDACION_702])),
            SUM(CHARINDEX('ERR',[VALIDACION_703])),
            SUM(CHARINDEX('ERR',[VALIDACION_704])),
            SUM(CHARINDEX('ERR',[VALIDACION_705])),
            SUM(CHARINDEX('ERR',[VALIDACION_706])),
            SUM(CHARINDEX('ERR',[VALIDACION_707])),
            SUM(CHARINDEX('ERR',[VALIDACION_708])),
            SUM(CHARINDEX('ERR',[VALIDACION_709])),
            SUM(CHARINDEX('ERR',[VALIDACION_710])),
            SUM(CHARINDEX('ERR',[VALIDACION_711])),
            SUM(CHARINDEX('ERR',[VALIDACION_712])),
            SUM(CHARINDEX('ERR',[VALIDACION_713])),
            SUM(CHARINDEX('ERR',[VALIDACION_714])),
            SUM(CHARINDEX('ERR',[VALIDACION_715])),
            SUM(CHARINDEX('ERR',[VALIDACION_716])),
            SUM(CHARINDEX('ERR',[VALIDACION_717])),
            SUM(CHARINDEX('ERR',[VALIDACION_718])),
            SUM(CHARINDEX('ERR',[VALIDACION_719])),
            SUM(CHARINDEX('ERR',[VALIDACION_720])),
            SUM(CHARINDEX('ERR',[VALIDACION_721])),
            SUM(CHARINDEX('ERR',[VALIDACION_722])),
            SUM(CHARINDEX('ERR',[VALIDACION_723])),
            SUM(CHARINDEX('ERR',[VALIDACION_724])),
            SUM(CHARINDEX('ERR',[VALIDACION_725])),
            SUM(CHARINDEX('ERR',[VALIDACION_726])),
            SUM(CHARINDEX('ERR',[VALIDACION_727])),
            SUM(CHARINDEX('ERR',[VALIDACION_728])),
            SUM(CHARINDEX('ERR',[VALIDACION_729])),
            SUM(CHARINDEX('ERR',[VALIDACION_730])),
            SUM(CHARINDEX('ERR',[VALIDACION_731])),
            SUM(CHARINDEX('ERR',[VALIDACION_732])),
            SUM(CHARINDEX('ERR',[VALIDACION_733])),
            SUM(CHARINDEX('ERR',[VALIDACION_734])),
            SUM(CHARINDEX('ERR',[VALIDACION_735])),
            SUM(CHARINDEX('ERR',[VALIDACION_736])),
            SUM(CHARINDEX('ERR',[VALIDACION_737])),
            SUM(CHARINDEX('ERR',[VALIDACION_738])),
            SUM(CHARINDEX('ERR',[VALIDACION_739])),
            SUM(CHARINDEX('ERR',[VALIDACION_740])),
            SUM(CHARINDEX('ERR',[VALIDACION_741])),
            SUM(CHARINDEX('ERR',[VALIDACION_742])),
            SUM(CHARINDEX('ERR',[VALIDACION_743])),
            SUM(CHARINDEX('ERR',[VALIDACION_744])),
            SUM(CHARINDEX('ERR',[VALIDACION_745])),
            SUM(CHARINDEX('ERR',[VALIDACION_746])),
            SUM(CHARINDEX('ERR',[VALIDACION_747])),
            SUM(CHARINDEX('ERR',[VALIDACION_748])),
            SUM(CHARINDEX('ERR',[VALIDACION_749])),
            SUM(CHARINDEX('ERR',[VALIDACION_750])),
            SUM(CHARINDEX('ERR',[VALIDACION_751])),
            SUM(CHARINDEX('ERR',[VALIDACION_752])),
            SUM(CHARINDEX('ERR',[VALIDACION_753])),
            SUM(CHARINDEX('ERR',[VALIDACION_754])),
            SUM(CHARINDEX('ERR',[VALIDACION_755])),
            SUM(CHARINDEX('ERR',[VALIDACION_756])),
            SUM(CHARINDEX('ERR',[VALIDACION_757])),
            SUM(CHARINDEX('ERR',[VALIDACION_758])),
            SUM(CHARINDEX('ERR',[VALIDACION_759])),
            SUM(CHARINDEX('ERR',[VALIDACION_760])),
            SUM(CHARINDEX('ERR',[VALIDACION_761])),
            SUM(CHARINDEX('ERR',[VALIDACION_762])),
            SUM(CHARINDEX('ERR',[VALIDACION_763])),
            SUM(CHARINDEX('ERR',[VALIDACION_764])),
            SUM(CHARINDEX('ERR',[VALIDACION_765])),
            SUM(CHARINDEX('ERR',[VALIDACION_766])),
            SUM(CHARINDEX('ERR',[VALIDACION_767])),
            SUM(CHARINDEX('ERR',[VALIDACION_768])),
            SUM(CHARINDEX('ERR',[VALIDACION_769])),
            SUM(CHARINDEX('ERR',[VALIDACION_770])),
            SUM(CHARINDEX('ERR',[VALIDACION_771])),
            SUM(CHARINDEX('ERR',[VALIDACION_772])),
            SUM(CHARINDEX('ERR',[VALIDACION_773])),
            SUM(CHARINDEX('ERR',[VALIDACION_774])),
            SUM(CHARINDEX('ERR',[VALIDACION_775])),
            SUM(CHARINDEX('ERR',[VALIDACION_776])),
            SUM(CHARINDEX('ERR',[VALIDACION_777])),
            SUM(CHARINDEX('ERR',[VALIDACION_778])),
            SUM(CHARINDEX('ERR',[VALIDACION_779])),
            SUM(CHARINDEX('ERR',[VALIDACION_780])),
            SUM(CHARINDEX('ERR',[VALIDACION_781])),
            SUM(CHARINDEX('ERR',[VALIDACION_782])),
            SUM(CHARINDEX('ERR',[VALIDACION_783])),
            SUM(CHARINDEX('ERR',[VALIDACION_784])),
            SUM(CHARINDEX('ERR',[VALIDACION_785])),
            SUM(CHARINDEX('ERR',[VALIDACION_786])),
            SUM(CHARINDEX('ERR',[VALIDACION_787])),
            SUM(CHARINDEX('ERR',[VALIDACION_788])),
            SUM(CHARINDEX('ERR',[VALIDACION_789])),
            SUM(CHARINDEX('ERR',[VALIDACION_790])),
            SUM(CHARINDEX('ERR',[VALIDACION_791])),
            SUM(CHARINDEX('ERR',[VALIDACION_792])),
            SUM(CHARINDEX('ERR',[VALIDACION_793])),
            SUM(CHARINDEX('ERR',[VALIDACION_794])),
            SUM(CHARINDEX('ERR',[VALIDACION_795])),
            SUM(CHARINDEX('ERR',[VALIDACION_796])),
            SUM(CHARINDEX('ERR',[VALIDACION_797])),
            SUM(CHARINDEX('ERR',[VALIDACION_798])),
            SUM(CHARINDEX('ERR',[VALIDACION_799])),
            SUM(CHARINDEX('ERR',[VALIDACION_800]))
            


		FROM IFRS9_R12A_1219_TSSALDOSSUBS0_RESULT_8 
END

BEGIN
	EXEC SP_IFRS9_R12A_1219_TSSALDOSSUBS0_VIEW_8IFRS9_R12A_1219_TSSALDOSSUBS0_VIEW_8
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


