﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Consolidación. Consolidación del estado de situación financiera de la institución de crédito con sus subsidiarias */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: AGOSTO 2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: NA*/
/*TIPO SALDO: SALDOS*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/
/*SUBSIDIARIA: 0*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R12A_1219_TSSALDOSSUBS0_COMP_1]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R12A_1219_TSSALDOSSUBS0_RESULT_1')
BEGIN
DROP TABLE IFRS9_R12A_1219_TSSALDOSSUBS0_RESULT_1
END 

BEGIN
SELECT DISTINCT

    /*ID*/

    CONVERT(VARCHAR,ID) AS ID,                                    /*ACTIVO*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100000000000')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100000000000')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100000000000')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100000000000) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100000000000) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100000000000) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1,

/*Efectivo y equivalentes de efectivo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100200001001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200001001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200001001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100200001001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100200001001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100200001001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_2,

/*Caja*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100200102001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200102001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200102001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100200102001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100200102001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100200102001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_3,

/*Bancos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100200102002')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100200102002) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100200102002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100200102002) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_4,

/*Depósitos en Banco de México*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100200203001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200203001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200203001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100200203001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100200203001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100200203001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_5,

/*Depósitos en otras entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100200203002')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200203002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200203002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100200203002) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100200203002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100200203002) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_6,

/*Divisas a entregar*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100200203003')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200203003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200203003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100200203003) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100200203003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100200203003) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_7,

/*Documentos de cobro inmediato*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100200102003')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200102003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200102003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100200102003) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100200102003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100200102003) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_8,

/*Metales preciosos amonedados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100200102004')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200102004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200102004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100200102004) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100200102004) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100200102004) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_9,

/*Inversiones disponibles a la vista*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100200102005')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200102005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200102005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100200102005) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100200102005) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100200102005) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_10,

/*Efectivo y equivalentes de efectivo restringidos o dados en garantía*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100200102006')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200102006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200102006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100200102006) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100200102006) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100200102006) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_11,

/*Banco de México*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100200603004')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200603004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200603004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100200603004) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100200603004) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100200603004) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_12,

/*Préstamos interbancarios (Call Money)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100200603005')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200603005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200603005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100200603005) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100200603005) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100200603005) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_13,

/*Divisas a recibir*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100200603006')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200603006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200603006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100200603006) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100200603006) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100200603006) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_14,

/*Efectivo administrado en fideicomiso*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100200603007')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200603007')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200603007')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100200603007) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100200603007) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100200603007) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_15,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100200603008')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200603008')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200603008')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100200603008) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100200603008) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100200603008) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_16,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100200102007')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200102007')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100200102007')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100200102007) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100200102007) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100200102007) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_17,

/*Cuentas de margen (instrumentos financieros derivados)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100400001001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100400001001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100400001001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100400001001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100400001001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100400001001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_18,

/*Efectivo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100400102001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100400102001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100400102001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100400102001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100400102001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100400102001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_19,

/*Inversiones en instrumentos financieros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100400102002')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100400102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100400102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100400102002) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100400102002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100400102002) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_20,

/*Otros activos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100400102003')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100400102003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100400102003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100400102003) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100400102003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100400102003) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_21,

/*Inversiones en instrumentos financieros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600001001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600001001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600001001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600001001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600001001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600001001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_22,

/*Instrumentos financieros negociables*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600102001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600102001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600102001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600102001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600102001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600102001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_23,

/*Instrumentos financieros negociables sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600103001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600103001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600103001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600103001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600103001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600103001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_24,

/*Deuda gubernamental*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600104001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600104001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600104001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600104001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600104001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600104001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_25,

/*En posición*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600105001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600105001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600105001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600105001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600105001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600105001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_26,

/*Por entregar*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600105002')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600105002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600105002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600105002) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600105002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600105002) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_27,

/*Deuda bancaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600104002')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600104002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600104002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600104002) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600104002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600104002) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_28,

/*En posición*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600205003')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600205003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600205003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600205003) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600205003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600205003) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_29,

/*Por entregar*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600205004')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600205004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600205004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600205004) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600205004) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600205004) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_30,

/*Otros títulos de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600104003')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600104003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600104003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600104003) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600104003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600104003) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_31,

/*En posición*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600305005')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600305005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600305005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600305005) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600305005) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600305005) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_32,

/*Por entregar*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600305006')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600305006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600305006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600305006) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600305006) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600305006) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_33,

/*Instrumentos financieros de capital*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600104004')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600104004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600104004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600104004) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600104004) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600104004) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_34,

/*En posición*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600405007')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600405007')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600405007')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600405007) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600405007) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600405007) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_35,

/*Por entregar*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600405008')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600405008')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600405008')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600405008) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600405008) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600405008) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_36,

/*Instrumentos financieros negociables restringidos o dados en garantía en operaciones de reporto*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600103002')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600103002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600103002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600103002) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600103002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600103002) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_37,

/*Deuda gubernamental*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600204005')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600204005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600204005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600204005) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600204005) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600204005) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_38,

/*Deuda bancaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600204006')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600204006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600204006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600204006) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600204006) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600204006) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_39,

/*Otros títulos de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600204007')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600204007')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600204007')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600204007) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600204007) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600204007) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_40,

/*Instrumentos financieros de capital*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600204008')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600204008')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600204008')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600204008) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600204008) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600204008) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_41,

/*Instrumentos financieros negociables restringidos o dados en garantía en operaciones de préstamo de valores*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600103003')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600103003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600103003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600103003) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600103003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600103003) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_42,

/*Deuda gubernamental*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600304009')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600304009')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600304009')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600304009) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600304009) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600304009) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_43,

/*Deuda bancaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600304010')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600304010')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600304010')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600304010) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600304010) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600304010) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_44,

/*Otros títulos de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600304011')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600304011')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600304011')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600304011) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600304011) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600304011) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_45,

/*Instrumentos financieros de capital*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600304012')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600304012')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600304012')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600304012) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600304012) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600304012) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_46,

/*Instrumentos financieros negociables restringidos o dados en garantía (otros)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600103004')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600103004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600103004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600103004) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600103004) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600103004) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_47,

/*Deuda gubernamental*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600404013')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600404013')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600404013')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600404013) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600404013) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600404013) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_48,

/*En posición*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100601305009')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601305009')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601305009')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100601305009) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100601305009) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100601305009) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_49,

/*A recibir*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100601305010')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601305010')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601305010')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100601305010) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100601305010) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100601305010) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_50,

/*Deuda bancaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600404014')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600404014')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600404014')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600404014) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600404014) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600404014) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_51,

/*En posición*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100601405011')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601405011')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601405011')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100601405011) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100601405011) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100601405011) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_52,

/*A recibir*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100601405012')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601405012')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601405012')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100601405012) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100601405012) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100601405012) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_53,

/*Otros títulos de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600404015')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600404015')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600404015')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600404015) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600404015) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600404015) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_54,

/*En posición*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100601505013')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601505013')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601505013')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100601505013) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100601505013) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100601505013) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_55,

/*A recibir*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100601505014')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601505014')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601505014')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100601505014) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100601505014) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100601505014) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_56,

/*Instrumentos financieros de capital*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600404016')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600404016')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600404016')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600404016) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600404016) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600404016) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_57,

/*En posición*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100601605015')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601605015')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601605015')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100601605015) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100601605015) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100601605015) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_58,

/*A recibir*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100601605016')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601605016')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601605016')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100601605016) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100601605016) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100601605016) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_59,

/*Instrumentos financieros para cobrar o vender*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600102002')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600102002) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600102002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600102002) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_60,

/*Instrumentos financieros para cobrar o vender sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600203005')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600203005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600203005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600203005) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600203005) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600203005) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_61,

/*Deuda gubernamental*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600504017')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600504017')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600504017')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600504017) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600504017) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600504017) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_62,

/*En posición*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100601705017')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601705017')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601705017')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100601705017) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100601705017) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100601705017) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_63,

/*Por entregar*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100601705018')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601705018')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601705018')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100601705018) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100601705018) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100601705018) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_64,

/*Deuda bancaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600504018')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600504018')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600504018')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600504018) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600504018) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600504018) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_65,

/*En posición*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100601805019')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601805019')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601805019')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100601805019) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100601805019) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100601805019) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_66,

/*Por entregar*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100601805020')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601805020')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601805020')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100601805020) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100601805020) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100601805020) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_67,

/*Otros títulos de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600504019')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600504019')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600504019')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600504019) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600504019) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600504019) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_68,

/*En posición*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100601905021')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601905021')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601905021')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100601905021) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100601905021) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100601905021) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_69,

/*Por entregar*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100601905022')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601905022')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100601905022')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100601905022) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100601905022) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100601905022) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_70,

/*Instrumentos financieros para cobrar o vender restringidos o dados en garantía en operaciones de reporto*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600203006')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600203006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600203006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600203006) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600203006) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600203006) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_71,

/*Deuda gubernamental*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600604020')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600604020')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600604020')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600604020) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600604020) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600604020) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_72,

/*Deuda bancaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600604021')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600604021')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600604021')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600604021) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600604021) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600604021) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_73,

/*Otros títulos de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600604022')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600604022')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600604022')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600604022) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600604022) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600604022) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_74,

/*Instrumentos financieros para cobrar o vender restringidos o dados en garantía en operaciones de préstamo de valores*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600203007')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600203007')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600203007')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600203007) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600203007) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600203007) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_75,

/*Deuda gubernamental*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600704023')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600704023')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600704023')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600704023) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600704023) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600704023) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_76,

/*Deuda bancaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600704024')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600704024')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600704024')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600704024) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600704024) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600704024) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_77,

/*Otros títulos de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600704025')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600704025')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600704025')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600704025) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600704025) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600704025) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_78,

/*Instrumentos financieros para cobrar o vender restringidos o dados en garantía (otros)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600203008')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600203008')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600203008')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600203008) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600203008) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600203008) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_79,

/*Deuda gubernamental*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600804026')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600804026')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600804026')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600804026) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600804026) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600804026) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_80,

/*En posición*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100602605023')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100602605023')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100602605023')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100602605023) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100602605023) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100602605023) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_81,

/*A recibir*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100602605024')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100602605024')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100602605024')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100602605024) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100602605024) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100602605024) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_82,

/*Deuda bancaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600804027')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600804027')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600804027')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600804027) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600804027) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600804027) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_83,

/*En posición*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100602705025')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100602705025')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100602705025')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100602705025) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100602705025) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100602705025) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_84,

/*A recibir*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100602705026')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100602705026')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100602705026')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100602705026) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100602705026) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100602705026) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_85,

/*Otros títulos de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600804028')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600804028')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600804028')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600804028) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600804028) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600804028) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_86,

/*En posición*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100602805027')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100602805027')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100602805027')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100602805027) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100602805027) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100602805027) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_87,

/*A recibir*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100602805028')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100602805028')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100602805028')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100602805028) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100602805028) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100602805028) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_88,

/*Instrumentos financieros para cobrar principal e interés (valores)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600102003')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600102003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600102003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600102003) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600102003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600102003) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_89,

/*Instrumentos financieros para cobrar principal e interés sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600303009')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600303009')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600303009')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600303009) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600303009) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600303009) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_90,

/*Deuda gubernamental*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600904029')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600904029')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600904029')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600904029) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600904029) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600904029) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_91,

/*En posición*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100602905029')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100602905029')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100602905029')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100602905029) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100602905029) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100602905029) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_92,

/*Por entregar*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100602905030')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100602905030')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100602905030')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100602905030) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100602905030) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100602905030) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_93,

/*Deuda bancaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600904030')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600904030')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600904030')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600904030) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600904030) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600904030) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_94,

/*En posición*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100603005031')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100603005031')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100603005031')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100603005031) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100603005031) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100603005031) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_95,

/*Por entregar*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100603005032')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100603005032')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100603005032')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100603005032) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100603005032) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100603005032) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_96,

/*Otros títulos de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600904031')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600904031')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600904031')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600904031) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600904031) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600904031) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_97,

/*En posición*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100603105033')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100603105033')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100603105033')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100603105033) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100603105033) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100603105033) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_98,

/*Por entregar*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100603105034')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100603105034')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100603105034')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100603105034) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100603105034) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100603105034) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_99,

/*Instrumentos financieros para cobrar principal e interés restringidos o dados en garantía en operaciones de reporto*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('100600303010')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600303010')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('100600303010')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (100600303010) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (100600303010) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (100600303010) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_100
	
INTO IFRS9_R12A_1219_TSSALDOSSUBS0_RESULT_1
FROM IFRS9_R12A_1219

END

BEGIN
	INSERT INTO IFRS9_R12A_1219_TSSALDOSSUBS0_RESULT_1 IFRS9_R12A_1219_TSSALDOSSUBS0_RESULT_1 
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_1])),
            SUM(CHARINDEX('ERR',[VALIDACION_2])),
            SUM(CHARINDEX('ERR',[VALIDACION_3])),
            SUM(CHARINDEX('ERR',[VALIDACION_4])),
            SUM(CHARINDEX('ERR',[VALIDACION_5])),
            SUM(CHARINDEX('ERR',[VALIDACION_6])),
            SUM(CHARINDEX('ERR',[VALIDACION_7])),
            SUM(CHARINDEX('ERR',[VALIDACION_8])),
            SUM(CHARINDEX('ERR',[VALIDACION_9])),
            SUM(CHARINDEX('ERR',[VALIDACION_10])),
            SUM(CHARINDEX('ERR',[VALIDACION_11])),
            SUM(CHARINDEX('ERR',[VALIDACION_12])),
            SUM(CHARINDEX('ERR',[VALIDACION_13])),
            SUM(CHARINDEX('ERR',[VALIDACION_14])),
            SUM(CHARINDEX('ERR',[VALIDACION_15])),
            SUM(CHARINDEX('ERR',[VALIDACION_16])),
            SUM(CHARINDEX('ERR',[VALIDACION_17])),
            SUM(CHARINDEX('ERR',[VALIDACION_18])),
            SUM(CHARINDEX('ERR',[VALIDACION_19])),
            SUM(CHARINDEX('ERR',[VALIDACION_20])),
            SUM(CHARINDEX('ERR',[VALIDACION_21])),
            SUM(CHARINDEX('ERR',[VALIDACION_22])),
            SUM(CHARINDEX('ERR',[VALIDACION_23])),
            SUM(CHARINDEX('ERR',[VALIDACION_24])),
            SUM(CHARINDEX('ERR',[VALIDACION_25])),
            SUM(CHARINDEX('ERR',[VALIDACION_26])),
            SUM(CHARINDEX('ERR',[VALIDACION_27])),
            SUM(CHARINDEX('ERR',[VALIDACION_28])),
            SUM(CHARINDEX('ERR',[VALIDACION_29])),
            SUM(CHARINDEX('ERR',[VALIDACION_30])),
            SUM(CHARINDEX('ERR',[VALIDACION_31])),
            SUM(CHARINDEX('ERR',[VALIDACION_32])),
            SUM(CHARINDEX('ERR',[VALIDACION_33])),
            SUM(CHARINDEX('ERR',[VALIDACION_34])),
            SUM(CHARINDEX('ERR',[VALIDACION_35])),
            SUM(CHARINDEX('ERR',[VALIDACION_36])),
            SUM(CHARINDEX('ERR',[VALIDACION_37])),
            SUM(CHARINDEX('ERR',[VALIDACION_38])),
            SUM(CHARINDEX('ERR',[VALIDACION_39])),
            SUM(CHARINDEX('ERR',[VALIDACION_40])),
            SUM(CHARINDEX('ERR',[VALIDACION_41])),
            SUM(CHARINDEX('ERR',[VALIDACION_42])),
            SUM(CHARINDEX('ERR',[VALIDACION_43])),
            SUM(CHARINDEX('ERR',[VALIDACION_44])),
            SUM(CHARINDEX('ERR',[VALIDACION_45])),
            SUM(CHARINDEX('ERR',[VALIDACION_46])),
            SUM(CHARINDEX('ERR',[VALIDACION_47])),
            SUM(CHARINDEX('ERR',[VALIDACION_48])),
            SUM(CHARINDEX('ERR',[VALIDACION_49])),
            SUM(CHARINDEX('ERR',[VALIDACION_50])),
            SUM(CHARINDEX('ERR',[VALIDACION_51])),
            SUM(CHARINDEX('ERR',[VALIDACION_52])),
            SUM(CHARINDEX('ERR',[VALIDACION_53])),
            SUM(CHARINDEX('ERR',[VALIDACION_54])),
            SUM(CHARINDEX('ERR',[VALIDACION_55])),
            SUM(CHARINDEX('ERR',[VALIDACION_56])),
            SUM(CHARINDEX('ERR',[VALIDACION_57])),
            SUM(CHARINDEX('ERR',[VALIDACION_58])),
            SUM(CHARINDEX('ERR',[VALIDACION_59])),
            SUM(CHARINDEX('ERR',[VALIDACION_60])),
            SUM(CHARINDEX('ERR',[VALIDACION_61])),
            SUM(CHARINDEX('ERR',[VALIDACION_62])),
            SUM(CHARINDEX('ERR',[VALIDACION_63])),
            SUM(CHARINDEX('ERR',[VALIDACION_64])),
            SUM(CHARINDEX('ERR',[VALIDACION_65])),
            SUM(CHARINDEX('ERR',[VALIDACION_66])),
            SUM(CHARINDEX('ERR',[VALIDACION_67])),
            SUM(CHARINDEX('ERR',[VALIDACION_68])),
            SUM(CHARINDEX('ERR',[VALIDACION_69])),
            SUM(CHARINDEX('ERR',[VALIDACION_70])),
            SUM(CHARINDEX('ERR',[VALIDACION_71])),
            SUM(CHARINDEX('ERR',[VALIDACION_72])),
            SUM(CHARINDEX('ERR',[VALIDACION_73])),
            SUM(CHARINDEX('ERR',[VALIDACION_74])),
            SUM(CHARINDEX('ERR',[VALIDACION_75])),
            SUM(CHARINDEX('ERR',[VALIDACION_76])),
            SUM(CHARINDEX('ERR',[VALIDACION_77])),
            SUM(CHARINDEX('ERR',[VALIDACION_78])),
            SUM(CHARINDEX('ERR',[VALIDACION_79])),
            SUM(CHARINDEX('ERR',[VALIDACION_80])),
            SUM(CHARINDEX('ERR',[VALIDACION_81])),
            SUM(CHARINDEX('ERR',[VALIDACION_82])),
            SUM(CHARINDEX('ERR',[VALIDACION_83])),
            SUM(CHARINDEX('ERR',[VALIDACION_84])),
            SUM(CHARINDEX('ERR',[VALIDACION_85])),
            SUM(CHARINDEX('ERR',[VALIDACION_86])),
            SUM(CHARINDEX('ERR',[VALIDACION_87])),
            SUM(CHARINDEX('ERR',[VALIDACION_88])),
            SUM(CHARINDEX('ERR',[VALIDACION_89])),
            SUM(CHARINDEX('ERR',[VALIDACION_90])),
            SUM(CHARINDEX('ERR',[VALIDACION_91])),
            SUM(CHARINDEX('ERR',[VALIDACION_92])),
            SUM(CHARINDEX('ERR',[VALIDACION_93])),
            SUM(CHARINDEX('ERR',[VALIDACION_94])),
            SUM(CHARINDEX('ERR',[VALIDACION_95])),
            SUM(CHARINDEX('ERR',[VALIDACION_96])),
            SUM(CHARINDEX('ERR',[VALIDACION_97])),
            SUM(CHARINDEX('ERR',[VALIDACION_98])),
            SUM(CHARINDEX('ERR',[VALIDACION_99])),
            SUM(CHARINDEX('ERR',[VALIDACION_100]))
            


		FROM IFRS9_R12A_1219_TSSALDOSSUBS0_RESULT_1 
END

BEGIN
	EXEC SP_IFRS9_R12A_1219_TSSALDOSSUBS0_VIEW_1IFRS9_R12A_1219_TSSALDOSSUBS0_VIEW_1
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


