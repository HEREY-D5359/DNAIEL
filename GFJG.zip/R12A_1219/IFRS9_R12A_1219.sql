SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE:  Validaciones Estructura Contables*/
/*CREADO POR: Héctor Daniel García Sánchez*/
/*FECHA CREACION: 01/08/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


CREATE OR ALTER PROCEDURE  [dbo].[SP_IFRS9_R12A_1219_COMP_1]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R12A_1219_COMP_RESULT_1')
BEGIN
DROP TABLE IFRS9_R12A_1219_COMP_RESULT_1
END 

BEGIN
SELECT DISTINCT

    /*ID*/

    CONVERT(VARCHAR,ID) AS ID,
    
    

    /* VALIDACION Tipo de Dato */

    IIF(ISNUMERIC(c04_numero_subsidiarias)=0,   CONCAT('ERROR: EN LA FILA: ',ID,', El campo NUMERO_SUBSIDIARIAS (',[c04_numero_subsidiarias],') no es numerico.'),'') as VALIDACION_1,	

    /* VALIDACION Longitud */

    IIF(LEN([c04_numero_subsidiarias])>2, CONCAT('ERROR: EN LA FILA: ',ID,', El campo NUMERO_SUBSIDIARIAS (',[c04_numero_subsidiarias],') tiene una longitud mayor a 2 caracteres.'), '')  AS VALIDACION_2,	

    /* VALIDACION Decimales */

    IIF(CHARINDEX('.',[c04_numero_subsidiarias])>0, CONCAT('ERROR: EN LA FILA: ',ID,', El campo NUMERO_SUBSIDIARIAS (',[c04_numero_subsidiarias],') no puede tener mas de 0 decimales.'),'')  AS VALIDACION_3,	

    /* VALIDACION Obligatorio */

    IIF([c04_numero_subsidiarias] IS NULL or [c04_numero_subsidiarias] = '' ,   CONCAT('ERROR: EN LA FILA: ',ID,', El campo NUMERO_SUBSIDIARIAS (',[c04_numero_subsidiarias],') es obligatorio, no puede estar vacío.'),'')  AS VALIDACION_4,	

    /* VALIDACION Caracteres especiales */

    IIF(PATINDEX('%[^0-9].%', [c04_numero_subsidiarias]) <> 0 ,   CONCAT('ERROR: EN LA FILA: ',ID,',  El campo NUMERO_SUBSIDIARIAS (',[c04_numero_subsidiarias],') no puede tener caracteres especiales ni espacios en blanco.'),'')  AS VALIDACION_5,	
        

    /* VALIDACION Longitud */

    IIF(LEN([c05_clave_subsidiaria])>6, CONCAT('ERROR: EN LA FILA: ',ID,', El campo CLAVE_SUBSIDIARIA (',[c05_clave_subsidiaria],') tiene una longitud mayor a 6 caracteres.'), '')  AS VALIDACION_6,		

    /* VALIDACION Obligatorio */

    IIF([c05_clave_subsidiaria] IS NULL or [c05_clave_subsidiaria] = '' ,   CONCAT('ERROR: EN LA FILA: ',ID,', El campo CLAVE_SUBSIDIARIA (',[c05_clave_subsidiaria],') es obligatorio, no puede estar vacío.'),'')  AS VALIDACION_7,

    /* VALIDACION Caracteres especiales */

    IIF(PATINDEX('%[^0-9].%', [c05_clave_subsidiaria]) <> 0 ,   CONCAT('ERROR: EN LA FILA: ',ID,',  El campo CLAVE_SUBSIDIARIA (',[c05_clave_subsidiaria],') no puede tener caracteres especiales ni espacios en blanco.'),'')  AS VALIDACION_8,	

    /* VALIDACION Catalogo */

    IIF(CONVERT(decimal,[c05_clave_subsidiaria]) not in (0),   CONCAT('ERROR: EN LA FILA: ',ID,', El campo CLAVE_SUBSIDIARIA (',[c05_clave_subsidiaria],') no está dentro de los valores permitidos (0).'),'') as VALIDACION_9,


    /* VALIDACION Tipo de Dato */

    IIF(ISNUMERIC([c05_clave_subsidiaria])=0,   CONCAT('ERROR: EN LA FILA: ',ID,', El campo CONCEPTO (',[c06_concepto],') no es numerico.'),'') as VALIDACION_10,	

    /* VALIDACION Longitud */

    IIF(LEN([c06_concepto])>12, CONCAT('ERROR: EN LA FILA: ',ID,', El campo CONCEPTO (',[c06_concepto],') tiene una longitud mayor a 12 caracteres.'), '')  AS VALIDACION_11,	

    /* VALIDACION Decimales */

    IIF(CHARINDEX('.',[c06_concepto])>2, CONCAT('ERROR: EN LA FILA: ',ID,', El campo CONCEPTO (',[c06_concepto],') no puede tener mas de 2 decimales.'),'')  AS VALIDACION_12,	

    /* VALIDACION Obligatorio */

    IIF([c06_concepto] IS NULL or [c06_concepto] = '' ,   CONCAT('ERROR: EN LA FILA: ',ID,', El campo CONCEPTO (',[c06_concepto],') es obligatorio, no puede estar vacío.'),'')  AS VALIDACION_13,	

    /* VALIDACION Caracteres especiales */

    IIF(PATINDEX('%[^0-9].%', [c06_concepto]) <> 0 ,   CONCAT('ERROR: EN LA FILA: ',ID,',  El campo CONCEPTO (',[c06_concepto],') no puede tener caracteres especiales ni espacios en blanco.'),'')  AS VALIDACION_14,	


    /* VALIDACION Tipo de Dato */

    IIF(ISNUMERIC([c06_concepto])=0,   CONCAT('ERROR: EN LA FILA: ',ID,', El campo TIPO_SALDO (',[c07_tipo_saldo],') no es numerico.'),'') as VALIDACION_15,	

    /* VALIDACION Longitud */

    IIF(LEN([c07_tipo_saldo])>4, CONCAT('ERROR: EN LA FILA: ',ID,', El campo TIPO_SALDO (',[c07_tipo_saldo],') tiene una longitud mayor a 4 caracteres.'), '')  AS VALIDACION_16,	

    /* VALIDACION Decimales */

    IIF(CHARINDEX('.',[c07_tipo_saldo])>0, CONCAT('ERROR: EN LA FILA: ',ID,', El campo TIPO_SALDO (',[c07_tipo_saldo],') no puede tener mas de 0 decimales.'),'')  AS VALIDACION_17,	

    /* VALIDACION Obligatorio */

    IIF([c07_tipo_saldo] IS NULL or [c07_tipo_saldo] = '' ,   CONCAT('ERROR: EN LA FILA: ',ID,', El campo TIPO_SALDO (',[c07_tipo_saldo],') es obligatorio, no puede estar vacío.'),'')  AS VALIDACION_18,	

    /* VALIDACION Caracteres especiales */

    IIF(PATINDEX('%[^0-9].%', [c07_tipo_saldo]) <> 0 ,   CONCAT('ERROR: EN LA FILA: ',ID,',  El campo TIPO_SALDO (',[c07_tipo_saldo],') no puede tener caracteres especiales ni espacios en blanco.'),'')  AS VALIDACION_19,	

    /* VALIDACION Catalogo */

    IIF(CONVERT(decimal,[c07_tipo_saldo]) not in ('130','131','132','60','133','134','137','135','61','136'),   CONCAT('ERROR: EN LA FILA: ',ID,', El campo TIPO_SALDO (',[c07_tipo_saldo],') no está dentro de los valores permitidos (130,131,132,60,133,134,137,135,61,136).'),'') as VALIDACION_20,


    /* VALIDACION Tipo de Dato */

    IIF(ISNUMERIC([c07_tipo_saldo])=0,   CONCAT('ERROR: EN LA FILA: ',ID,', El campo TIPO_MOVIMIENTO (',[c08_tipo_movimiento],') no es numerico.'),'') as VALIDACION_21,	

    /* VALIDACION Longitud */

    IIF(LEN([c08_tipo_movimiento])>4, CONCAT('ERROR: EN LA FILA: ',ID,', El campo TIPO_MOVIMIENTO (',[c08_tipo_movimiento],') tiene una longitud mayor a 4 caracteres.'), '')  AS VALIDACION_22,	

    /* VALIDACION Decimales */

    IIF(CHARINDEX('.',[c08_tipo_movimiento])>0, CONCAT('ERROR: EN LA FILA: ',ID,', El campo TIPO_MOVIMIENTO (',[c08_tipo_movimiento],') no puede tener mas de 0 decimales.'),'')  AS VALIDACION_23,	

    /* VALIDACION Obligatorio */

    IIF([c08_tipo_movimiento] IS NULL or [c08_tipo_movimiento] = '' ,   CONCAT('ERROR: EN LA FILA: ',ID,', El campo TIPO_MOVIMIENTO (',[c08_tipo_movimiento],') es obligatorio, no puede estar vacío.'),'')  AS VALIDACION_24,	

    /* VALIDACION Caracteres especiales */

    IIF(PATINDEX('%[^0-9].%', [c08_tipo_movimiento]) <> 0 ,   CONCAT('ERROR: EN LA FILA: ',ID,',  El campo TIPO_MOVIMIENTO (',[c08_tipo_movimiento],') no puede tener caracteres especiales ni espacios en blanco.'),'')  AS VALIDACION_25,	

    /* VALIDACION Catalogo */

    IIF(CONVERT(decimal,[c08_tipo_movimiento]) not in (0,5,6),   CONCAT('ERROR: EN LA FILA: ',ID,', El campo TIPO_MOVIMIENTO (',[c08_tipo_movimiento],') no está dentro de los valores permitidos (0,5,6).'),'') as VALIDACION_26,


    /* VALIDACION Tipo de Dato */

    IIF(ISNUMERIC([c08_tipo_movimiento])=0,   CONCAT('ERROR: EN LA FILA: ',ID,', El campo DATO (',[c09_dato],') no es numerico.'),'') as VALIDACION_27,	

    /* VALIDACION Longitud */

    IIF(LEN([c09_dato])>4, CONCAT('ERROR: EN LA FILA: ',ID,', El campo DATO (',[c09_dato],') tiene una longitud mayor a 4 caracteres.'), '')  AS VALIDACION_28,	

    /* VALIDACION Decimales */

    IIF(CHARINDEX('.',[c09_dato])>0, CONCAT('ERROR: EN LA FILA: ',ID,', El campo DATO (',[c09_dato],') no puede tener mas de 0 decimales.'),'')  AS VALIDACION_29,	

    /* VALIDACION Obligatorio */

    IIF([c09_dato] IS NULL or [c09_dato] = '' ,   CONCAT('ERROR: EN LA FILA: ',ID,', El campo DATO (',[c09_dato],') es obligatorio, no puede estar vacío.'),'')  AS VALIDACION_30,	

    /* VALIDACION Caracteres especiales */

    IIF(PATINDEX('%[^0-9].%', [c09_dato]) <> 0 ,   CONCAT('ERROR: EN LA FILA: ',ID,',  El campo DATO (',[c09_dato],') no puede tener caracteres especiales ni espacios en blanco.'),'')  AS VALIDACION_31	



INTO IFRS9_R12A_1219_COMP_RESULT_1
FROM IFRS9_R12A_1219

END

BEGIN
	INSERT INTO IFRS9_R12A_1219_COMP_RESULT_1
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_1])),
            SUM(CHARINDEX('ERR',[VALIDACION_2])),
            SUM(CHARINDEX('ERR',[VALIDACION_3])),
            SUM(CHARINDEX('ERR',[VALIDACION_4])),
            SUM(CHARINDEX('ERR',[VALIDACION_5])),
            SUM(CHARINDEX('ERR',[VALIDACION_6])),
            SUM(CHARINDEX('ERR',[VALIDACION_7])),
            SUM(CHARINDEX('ERR',[VALIDACION_8])),
            SUM(CHARINDEX('ERR',[VALIDACION_9])),
            SUM(CHARINDEX('ERR',[VALIDACION_10])),
            SUM(CHARINDEX('ERR',[VALIDACION_11])),
            SUM(CHARINDEX('ERR',[VALIDACION_12])),
            SUM(CHARINDEX('ERR',[VALIDACION_13])),
            SUM(CHARINDEX('ERR',[VALIDACION_14])),
            SUM(CHARINDEX('ERR',[VALIDACION_15])),
            SUM(CHARINDEX('ERR',[VALIDACION_16])),
            SUM(CHARINDEX('ERR',[VALIDACION_17])),
            SUM(CHARINDEX('ERR',[VALIDACION_18])),
            SUM(CHARINDEX('ERR',[VALIDACION_19])),
            SUM(CHARINDEX('ERR',[VALIDACION_20])),
            SUM(CHARINDEX('ERR',[VALIDACION_21])),
            SUM(CHARINDEX('ERR',[VALIDACION_22])),
            SUM(CHARINDEX('ERR',[VALIDACION_23])),
            SUM(CHARINDEX('ERR',[VALIDACION_24])),
            SUM(CHARINDEX('ERR',[VALIDACION_25])),
            SUM(CHARINDEX('ERR',[VALIDACION_26])),
            SUM(CHARINDEX('ERR',[VALIDACION_27])),
            SUM(CHARINDEX('ERR',[VALIDACION_28])),
            SUM(CHARINDEX('ERR',[VALIDACION_29])),
            SUM(CHARINDEX('ERR',[VALIDACION_30])),
            SUM(CHARINDEX('ERR',[VALIDACION_31]))
        

		from IFRS9_R12A_1219_COMP_RESULT_1
END

BEGIN
	EXEC SP_IFRS9_R12A_1219_COMP_VIEW_1
END

COMMIT
END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH