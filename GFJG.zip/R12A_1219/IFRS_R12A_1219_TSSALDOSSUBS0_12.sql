﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Consolidación. Consolidación del estado de situación financiera de la institución de crédito con sus subsidiarias */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: AGOSTO 2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: NA*/
/*TIPO SALDO: SALDOS*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/
/*SUBSIDIARIA: 0*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R12A_1219_TSSALDOSSUBS0_COMP_12]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R12A_1219_TSSALDOSSUBS0_RESULT_12')
BEGIN
DROP TABLE IFRS9_R12A_1219_TSSALDOSSUBS0_RESULT_12
END 

BEGIN
SELECT DISTINCT
         /*id*/
CONVERT(VARCHAR,ID) AS ID, 
	/*Recaudación de aportaciones de seguridad social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('202401504009')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202401504009')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202401504009')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (202401504009) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (202401504009) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (202401504009) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1101,

/*Otros pasivos derivados de la prestación de servicios bancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('202401504010')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202401504010')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202401504010')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (202401504010) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (202401504010) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (202401504010) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1102,

/*Comisiones por pagar sobre operaciones vigentes*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('202400503016')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202400503016')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202400503016')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (202400503016) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (202400503016) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (202400503016) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1103,

/*Aforo derivado de operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('202400503017')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202400503017')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202400503017')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (202400503017) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (202400503017) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (202400503017) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1104,

/*Acreedores por adquisición de activos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('202400503018')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202400503018')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202400503018')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (202400503018) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (202400503018) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (202400503018) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1105,

/*Dividendos por pagar*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('202400503019')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202400503019')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202400503019')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (202400503019) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (202400503019) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (202400503019) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1106,

/*Acreedores por servicio de mantenimiento*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('202400503020')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202400503020')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202400503020')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (202400503020) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (202400503020) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (202400503020) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1107,

/*Provisiones para obligaciones diversas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('202400503021')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202400503021')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202400503021')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (202400503021) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (202400503021) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (202400503021) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1108,

/*Honorarios y rentas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('202402104011')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202402104011')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202402104011')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (202402104011) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (202402104011) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (202402104011) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1109,

/*Gastos de promoción y publicidad*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('202402104012')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202402104012')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202402104012')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (202402104012) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (202402104012) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (202402104012) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1110,

/*Aportaciones al IPAB*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('202402104013')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202402104013')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202402104013')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (202402104013) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (202402104013) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (202402104013) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1111,

/*Gastos en tecnología*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('202402104014')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202402104014')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202402104014')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (202402104014) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (202402104014) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (202402104014) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1112,

/*Ordenadas por la CONDUSEF*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('202402104015')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202402104015')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202402104015')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (202402104015) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (202402104015) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (202402104015) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1113,

/*Otras provisiones*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('202402104016')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202402104016')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202402104016')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (202402104016) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (202402104016) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (202402104016) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1114,

/*Otros acreedores diversos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('202400503022')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202400503022')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202400503022')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (202400503022) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (202400503022) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (202400503022) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1115,

/*Pasivos relacionados con grupos de activos mantenidos para la venta*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('202600001001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202600001001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202600001001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (202600001001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (202600001001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (202600001001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1116,

/*Pasivos relacionados con operaciones discontinuadas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('202800001001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202800001001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('202800001001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (202800001001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (202800001001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (202800001001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1117,

/*Instrumentos financieros que califican como pasivo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203000001001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000001001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000001001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203000001001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203000001001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203000001001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1118,

/*Obligaciones subordinadas en circulación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203000102001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000102001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000102001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203000102001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203000102001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203000102001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1119,

/*De conversión forzosa*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203000103001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000103001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000103001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203000103001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203000103001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203000103001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1120,

/*Valor nominal e intereses*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203000104001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000104001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000104001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203000104001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203000104001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203000104001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1121,

/*Costos de transacción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203000104002')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000104002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000104002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203000104002) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203000104002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203000104002) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1122,

/*Prima o descuento por colocación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203000104003')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000104003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000104003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203000104003) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203000104003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203000104003) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1123,

/*De conversión por decisión del tenedor*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203000103002')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000103002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000103002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203000103002) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203000103002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203000103002) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1124,

/*Valor nominal e intereses*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203000204004')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000204004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000204004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203000204004) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203000204004) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203000204004) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1125,

/*Costos de transacción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203000204005')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000204005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000204005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203000204005) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203000204005) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203000204005) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1126,

/*Prima o descuento por colocación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203000204006')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000204006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000204006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203000204006) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203000204006) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203000204006) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1127,

/*De conversión por decisión de la entidad emisora*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203000103003')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000103003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000103003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203000103003) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203000103003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203000103003) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1128,

/*Valor nominal e intereses*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203000304007')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000304007')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000304007')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203000304007) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203000304007) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203000304007) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1129,

/*Costos de transacción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203000304008')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000304008')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000304008')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203000304008) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203000304008) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203000304008) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1130,

/*Prima o descuento por colocación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203000304009')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000304009')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000304009')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203000304009) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203000304009) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203000304009) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1131,

/*No convertibles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203000103004')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000103004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000103004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203000103004) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203000103004) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203000103004) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1132,

/*Valor nominal e intereses*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203000404010')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000404010')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000404010')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203000404010) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203000404010) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203000404010) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1133,

/*Costos de transacción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203000404011')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000404011')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000404011')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203000404011) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203000404011) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203000404011) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1134,

/*Prima o descuento por colocación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203000404012')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000404012')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000404012')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203000404012) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203000404012) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203000404012) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1135,

/*Aportaciones para futuros aumentos de capital pendientes de formalizar por su órgano de gobierno*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203000102002')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203000102002) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203000102002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203000102002) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1136,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203000102003')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000102003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203000102003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203000102003) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203000102003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203000102003) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1137,

/*Obligaciones asociadas con el retiro de componentes de propiedades, mobiliario y equipo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203200001001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203200001001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203200001001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203200001001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203200001001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203200001001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1138,

/*Pasivo por impuestos a la utilidad*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203400001001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203400001001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203400001001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203400001001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203400001001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203400001001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1139,

/*Impuestos causados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203400102001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203400102001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203400102001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203400102001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203400102001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203400102001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1140,

/*Impuestos a la utilidad (provisión)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203400103001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203400103001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203400103001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203400103001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203400103001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203400103001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1141,

/*Impuestos a la utilidad (ajuste impuesto definitivo)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203400103002')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203400103002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203400103002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203400103002) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203400103002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203400103002) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1142,

/*Impuestos diferidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203400102002')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203400102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203400102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203400102002) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203400102002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203400102002) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1143,

/*Diferencias temporales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203400203003')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203400203003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203400203003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203400203003) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203400203003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203400203003) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1144,

/*Pasivo por beneficios a los empleados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203600001001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203600001001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203600001001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203600001001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203600001001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203600001001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1145,

/*Beneficios directos a corto plazo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203600102001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203600102001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203600102001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203600102001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203600102001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203600102001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1146,

/*Beneficios directos a largo plazo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203600102002')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203600102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203600102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203600102002) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203600102002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203600102002) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1147,

/*Beneficios post-empleo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203600102003')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203600102003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203600102003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203600102003) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203600102003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203600102003) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1148,

/*Pensiones*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203600303001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203600303001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203600303001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203600303001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203600303001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203600303001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1149,

/*Prima de antigüedad*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203600303002')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203600303002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203600303002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203600303002) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203600303002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203600303002) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1150,

/*Otros beneficios post-empleo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203600303003')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203600303003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203600303003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203600303003) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203600303003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203600303003) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1151,

/*Beneficios por terminación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203600102004')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203600102004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203600102004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203600102004) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203600102004) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203600102004) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1152,

/*Beneficios por terminación por causas distintas a la reestructuración*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203600403004')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203600403004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203600403004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203600403004) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203600403004) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203600403004) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1153,

/*Beneficios por terminación por causa de reestructuración*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203600403005')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203600403005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203600403005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203600403005) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203600403005) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203600403005) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1154,

/*Participación de los trabajadores en las utilidades causada*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203600102005')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203600102005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203600102005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203600102005) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203600102005) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203600102005) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1155,

/*Participación de los trabajadores en las utilidades diferida*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203600102006')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203600102006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203600102006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203600102006) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203600102006) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203600102006) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1156,

/*Créditos diferidos y cobros anticipados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203800001001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800001001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800001001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203800001001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203800001001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203800001001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1157,

/*Créditos diferidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203800102001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800102001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800102001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203800102001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203800102001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203800102001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1158,

/*Comisiones por el otorgamiento del crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203800103001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800103001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800103001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203800103001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203800103001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203800103001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1159,

/*Comisiones por anualidad y subsecuentes de tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203800103002')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800103002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800103002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203800103002) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203800103002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203800103002) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1160,

/*Ingreso financiero por devengar en operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203800103003')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800103003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800103003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203800103003) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203800103003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203800103003) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1161,

/*Ingreso financiero por devengar en operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203800103004')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800103004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800103004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203800103004) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203800103004) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203800103004) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1162,

/*Ingreso por opción de compra a precio reducido en operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203800103005')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800103005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800103005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203800103005) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203800103005) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203800103005) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1163,

/*Otros ingresos por aplicar*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203800103006')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800103006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800103006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203800103006) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203800103006) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203800103006) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1164,

/*Excedente por amortizar en adquisiciones de cartera de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203800103007')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800103007')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800103007')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203800103007) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203800103007) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203800103007) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1165,

/*Otros créditos diferidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203800103008')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800103008')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800103008')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203800103008) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203800103008) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203800103008) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1166,

/*Cobros anticipados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203800102002')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203800102002) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203800102002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203800102002) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1167,

/*Intereses cobrados por anticipado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203800203009')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800203009')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800203009')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203800203009) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203800203009) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203800203009) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1168,

/*Comisiones cobradas por anticipado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203800203010')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800203010')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800203010')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203800203010) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203800203010) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203800203010) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1169,

/*Rentas cobradas por anticipado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203800203011')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800203011')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800203011')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203800203011) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203800203011) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203800203011) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1170,

/*Cobros anticipados de bienes prometidos en venta o con reserva de dominio*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203800203012')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800203012')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800203012')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203800203012) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203800203012) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203800203012) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1171,

/*Ingresos por aplicar derivados de programas de apoyo a deudores*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203800203013')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800203013')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800203013')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203800203013) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203800203013) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203800203013) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1172,

/*Otros cobros anticipados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('203800203014')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800203014')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('203800203014')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (203800203014) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (203800203014) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (203800203014) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1173,

/*CAPITAL CONTABLE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400000000000')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400000000000')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400000000000')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (400000000000) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (400000000000) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (400000000000) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1174,

/*Participación controladora*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('440200001001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('440200001001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('440200001001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (440200001001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (440200001001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (440200001001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1175,

/*Capital contribuido*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400200102001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200102001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200102001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (400200102001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (400200102001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (400200102001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1176,

/*Capital social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400200103001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200103001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200103001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (400200103001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (400200103001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (400200103001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1177,

/*Capital social no exhibido*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400200103002')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200103002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200103002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (400200103002) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (400200103002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (400200103002) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1178,

/*Incremento por actualización del capital social pagado (1)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400200103003')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200103003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200103003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (400200103003) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (400200103003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (400200103003) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1179,

/*Aportaciones para futuros aumentos de capital formalizadas por su órgano de gobierno*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400200103004')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200103004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200103004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (400200103004) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (400200103004) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (400200103004) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1180,

/*Incremento por actualización de las aportaciones para futuros aumentos de capital formalizadas por su órgano de gobierno (1)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400200103005')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200103005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200103005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (400200103005) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (400200103005) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (400200103005) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1181,

/*Prima en venta de acciones*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400200103006')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200103006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200103006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (400200103006) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (400200103006) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (400200103006) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1182,

/*Incremento por actualización de la prima en venta de acciones (1)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400200103007')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200103007')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200103007')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (400200103007) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (400200103007) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (400200103007) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1183,

/*Instrumentos financieros que califican como capital*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400200103008')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200103008')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200103008')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (400200103008) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (400200103008) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (400200103008) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1184,

/*Incremento por actualización de instrumentos financieros que califican como capital (1)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400200103009')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200103009')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200103009')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (400200103009) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (400200103009) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (400200103009) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1185,

/*Capital ganado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400200102002')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200102002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (400200102002) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (400200102002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (400200102002) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1186,

/*Reservas de capital*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400200203010')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200203010')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200203010')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (400200203010) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (400200203010) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (400200203010) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1187,

/*Reserva legal*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400201004001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400201004001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400201004001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (400201004001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (400201004001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (400201004001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1188,

/*Otras reservas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400201004002')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400201004002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400201004002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (400201004002) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (400201004002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (400201004002) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1189,

/*Incremento por actualización de reservas de capital (1)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400200203011')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200203011')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200203011')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (400200203011) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (400200203011) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (400200203011) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1190,

/*Resultados acumulados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400200203012')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200203012')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200203012')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (400200203012) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (400200203012) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (400200203012) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1191,

/*Resultado de ejercicios anteriores*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400201204003')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400201204003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400201204003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (400201204003) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (400201204003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (400201204003) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1192,

/*Resultado por aplicar*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400200305001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200305001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200305001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (400200305001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (400200305001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (400200305001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1193,

/*Resultado por cambios contables y correcciones de errores*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400200305002')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200305002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200305002')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (400200305002) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (400200305002) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (400200305002) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1194,

/*Incremento por actualización del resultado de ejercicios anteriores (1)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400201204004')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400201204004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400201204004')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (400201204004) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (400201204004) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (400201204004) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1195,

/*Resultado neto*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('430201204005')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('430201204005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('430201204005')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (430201204005) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (430201204005) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (430201204005) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1196,

/*Otros resultados integrales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400200203013')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200203013')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200203013')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (400200203013) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (400200203013) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (400200203013) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1197,

/*Valuación de instrumentos financieros para cobrar o vender*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400201304006')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400201304006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400201304006')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (400201304006) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (400201304006) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (400201304006) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1198,

/*Instrumentos financieros (valores)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400200605003')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200605003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200605003')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (400200605003) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (400200605003) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (400200605003) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1199,

/*Valuación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)     
FROM IFRS9_R12A_1219   
WHERE [c06_concepto] IN ('400200306001')
AND c05_clave_subsidiaria IN ('0')    
AND c07_tipo_saldo IN ('136')    
AND c08_tipo_movimiento IN ('0')), 0)     
-      
(ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200306001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('135','61')     
AND c08_tipo_movimiento IN ('0','5')), 0)
-
ISNULL((SELECT ISNULL(SUM(CAST(c09_dato AS DECIMAL)),0)      
FROM IFRS9_R12A_1219     
WHERE [c06_concepto] IN ('400200306001')
AND c05_clave_subsidiaria IN ('0') 
AND c07_tipo_saldo IN ('61')     
AND c08_tipo_movimiento IN ('6')), 0)))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (400200306001) con Clave de Subsidiaria 0, Tipo de Saldo 136 y Tipo de Movimiento 0 sea igual a la suma del Concepto (400200306001) con Clave de Subsidiaria 0, Tipo de Saldo 135 y 61 y Tipo de Movimiento 0 y 5 menos el Concepto (400200306001) con Clave de Subsidiaria 0, Tipo de Saldo 61 y Tipo de Movimiento 6. ')    
AS VALIDACION_1200
	
INTO IFRS9_R12A_1219_TSSALDOSSUBS0_RESULT_12
FROM IFRS9_R12A_1219

END

BEGIN
	INSERT INTO IFRS9_R12A_1219_TSSALDOSSUBS0_RESULT_12 IFRS9_R12A_1219_TSSALDOSSUBS0_RESULT_12 
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_1101])),
            SUM(CHARINDEX('ERR',[VALIDACION_1102])),
            SUM(CHARINDEX('ERR',[VALIDACION_1103])),
            SUM(CHARINDEX('ERR',[VALIDACION_1104])),
            SUM(CHARINDEX('ERR',[VALIDACION_1105])),
            SUM(CHARINDEX('ERR',[VALIDACION_1106])),
            SUM(CHARINDEX('ERR',[VALIDACION_1107])),
            SUM(CHARINDEX('ERR',[VALIDACION_1108])),
            SUM(CHARINDEX('ERR',[VALIDACION_1109])),
            SUM(CHARINDEX('ERR',[VALIDACION_1110])),
            SUM(CHARINDEX('ERR',[VALIDACION_1111])),
            SUM(CHARINDEX('ERR',[VALIDACION_1112])),
            SUM(CHARINDEX('ERR',[VALIDACION_1113])),
            SUM(CHARINDEX('ERR',[VALIDACION_1114])),
            SUM(CHARINDEX('ERR',[VALIDACION_1115])),
            SUM(CHARINDEX('ERR',[VALIDACION_1116])),
            SUM(CHARINDEX('ERR',[VALIDACION_1117])),
            SUM(CHARINDEX('ERR',[VALIDACION_1118])),
            SUM(CHARINDEX('ERR',[VALIDACION_1119])),
            SUM(CHARINDEX('ERR',[VALIDACION_1120])),
            SUM(CHARINDEX('ERR',[VALIDACION_1121])),
            SUM(CHARINDEX('ERR',[VALIDACION_1122])),
            SUM(CHARINDEX('ERR',[VALIDACION_1123])),
            SUM(CHARINDEX('ERR',[VALIDACION_1124])),
            SUM(CHARINDEX('ERR',[VALIDACION_1125])),
            SUM(CHARINDEX('ERR',[VALIDACION_1126])),
            SUM(CHARINDEX('ERR',[VALIDACION_1127])),
            SUM(CHARINDEX('ERR',[VALIDACION_1128])),
            SUM(CHARINDEX('ERR',[VALIDACION_1129])),
            SUM(CHARINDEX('ERR',[VALIDACION_1130])),
            SUM(CHARINDEX('ERR',[VALIDACION_1131])),
            SUM(CHARINDEX('ERR',[VALIDACION_1132])),
            SUM(CHARINDEX('ERR',[VALIDACION_1133])),
            SUM(CHARINDEX('ERR',[VALIDACION_1134])),
            SUM(CHARINDEX('ERR',[VALIDACION_1135])),
            SUM(CHARINDEX('ERR',[VALIDACION_1136])),
            SUM(CHARINDEX('ERR',[VALIDACION_1137])),
            SUM(CHARINDEX('ERR',[VALIDACION_1138])),
            SUM(CHARINDEX('ERR',[VALIDACION_1139])),
            SUM(CHARINDEX('ERR',[VALIDACION_1140])),
            SUM(CHARINDEX('ERR',[VALIDACION_1141])),
            SUM(CHARINDEX('ERR',[VALIDACION_1142])),
            SUM(CHARINDEX('ERR',[VALIDACION_1143])),
            SUM(CHARINDEX('ERR',[VALIDACION_1144])),
            SUM(CHARINDEX('ERR',[VALIDACION_1145])),
            SUM(CHARINDEX('ERR',[VALIDACION_1146])),
            SUM(CHARINDEX('ERR',[VALIDACION_1147])),
            SUM(CHARINDEX('ERR',[VALIDACION_1148])),
            SUM(CHARINDEX('ERR',[VALIDACION_1149])),
            SUM(CHARINDEX('ERR',[VALIDACION_1150])),
            SUM(CHARINDEX('ERR',[VALIDACION_1151])),
            SUM(CHARINDEX('ERR',[VALIDACION_1152])),
            SUM(CHARINDEX('ERR',[VALIDACION_1153])),
            SUM(CHARINDEX('ERR',[VALIDACION_1154])),
            SUM(CHARINDEX('ERR',[VALIDACION_1155])),
            SUM(CHARINDEX('ERR',[VALIDACION_1156])),
            SUM(CHARINDEX('ERR',[VALIDACION_1157])),
            SUM(CHARINDEX('ERR',[VALIDACION_1158])),
            SUM(CHARINDEX('ERR',[VALIDACION_1159])),
            SUM(CHARINDEX('ERR',[VALIDACION_1160])),
            SUM(CHARINDEX('ERR',[VALIDACION_1161])),
            SUM(CHARINDEX('ERR',[VALIDACION_1162])),
            SUM(CHARINDEX('ERR',[VALIDACION_1163])),
            SUM(CHARINDEX('ERR',[VALIDACION_1164])),
            SUM(CHARINDEX('ERR',[VALIDACION_1165])),
            SUM(CHARINDEX('ERR',[VALIDACION_1166])),
            SUM(CHARINDEX('ERR',[VALIDACION_1167])),
            SUM(CHARINDEX('ERR',[VALIDACION_1168])),
            SUM(CHARINDEX('ERR',[VALIDACION_1169])),
            SUM(CHARINDEX('ERR',[VALIDACION_1170])),
            SUM(CHARINDEX('ERR',[VALIDACION_1171])),
            SUM(CHARINDEX('ERR',[VALIDACION_1172])),
            SUM(CHARINDEX('ERR',[VALIDACION_1173])),
            SUM(CHARINDEX('ERR',[VALIDACION_1174])),
            SUM(CHARINDEX('ERR',[VALIDACION_1175])),
            SUM(CHARINDEX('ERR',[VALIDACION_1176])),
            SUM(CHARINDEX('ERR',[VALIDACION_1177])),
            SUM(CHARINDEX('ERR',[VALIDACION_1178])),
            SUM(CHARINDEX('ERR',[VALIDACION_1179])),
            SUM(CHARINDEX('ERR',[VALIDACION_1180])),
            SUM(CHARINDEX('ERR',[VALIDACION_1181])),
            SUM(CHARINDEX('ERR',[VALIDACION_1182])),
            SUM(CHARINDEX('ERR',[VALIDACION_1183])),
            SUM(CHARINDEX('ERR',[VALIDACION_1184])),
            SUM(CHARINDEX('ERR',[VALIDACION_1185])),
            SUM(CHARINDEX('ERR',[VALIDACION_1186])),
            SUM(CHARINDEX('ERR',[VALIDACION_1187])),
            SUM(CHARINDEX('ERR',[VALIDACION_1188])),
            SUM(CHARINDEX('ERR',[VALIDACION_1189])),
            SUM(CHARINDEX('ERR',[VALIDACION_1190])),
            SUM(CHARINDEX('ERR',[VALIDACION_1191])),
            SUM(CHARINDEX('ERR',[VALIDACION_1192])),
            SUM(CHARINDEX('ERR',[VALIDACION_1193])),
            SUM(CHARINDEX('ERR',[VALIDACION_1194])),
            SUM(CHARINDEX('ERR',[VALIDACION_1195])),
            SUM(CHARINDEX('ERR',[VALIDACION_1196])),
            SUM(CHARINDEX('ERR',[VALIDACION_1197])),
            SUM(CHARINDEX('ERR',[VALIDACION_1198])),
            SUM(CHARINDEX('ERR',[VALIDACION_1199])),
            SUM(CHARINDEX('ERR',[VALIDACION_1200]))
            


		FROM IFRS9_R12A_1219_TSSALDOSSUBS0_RESULT_12 
END

BEGIN
	EXEC SP_IFRS9_R12A_1219_TSSALDOSSUBS0_VIEW_12IFRS9_R12A_1219_TSSALDOSSUBS0_VIEW_12
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


