﻿
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Consolidación. Consolidación del estado de situación financiera de la institución de crédito con sus subsidiarias */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: AGOSTO 2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: NA*/
/*TIPO SALDO: SALDOS*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/
/*SUBSIDIARIA: 0*/


CREATE OR ALTER PROC [dbo].[SP_IFRS9_R12A_1219_TSSALDOSSUBS0_VIEW_3]
AS
BEGIN
	SELECT *
		
	FROM IFRS9_R12A_1219_TSSALDOSSUBS0_RESULT_3
	WHERE

        (VALIDACION_201 <> '' ) OR
        (VALIDACION_202 <> '' ) OR
        (VALIDACION_203 <> '' ) OR
        (VALIDACION_204 <> '' ) OR
        (VALIDACION_205 <> '' ) OR
        (VALIDACION_206 <> '' ) OR
        (VALIDACION_207 <> '' ) OR
        (VALIDACION_208 <> '' ) OR
        (VALIDACION_209 <> '' ) OR
        (VALIDACION_210 <> '' ) OR
        (VALIDACION_211 <> '' ) OR
        (VALIDACION_212 <> '' ) OR
        (VALIDACION_213 <> '' ) OR
        (VALIDACION_214 <> '' ) OR
        (VALIDACION_215 <> '' ) OR
        (VALIDACION_216 <> '' ) OR
        (VALIDACION_217 <> '' ) OR
        (VALIDACION_218 <> '' ) OR
        (VALIDACION_219 <> '' ) OR
        (VALIDACION_220 <> '' ) OR
        (VALIDACION_221 <> '' ) OR
        (VALIDACION_222 <> '' ) OR
        (VALIDACION_223 <> '' ) OR
        (VALIDACION_224 <> '' ) OR
        (VALIDACION_225 <> '' ) OR
        (VALIDACION_226 <> '' ) OR
        (VALIDACION_227 <> '' ) OR
        (VALIDACION_228 <> '' ) OR
        (VALIDACION_229 <> '' ) OR
        (VALIDACION_230 <> '' ) OR
        (VALIDACION_231 <> '' ) OR
        (VALIDACION_232 <> '' ) OR
        (VALIDACION_233 <> '' ) OR
        (VALIDACION_234 <> '' ) OR
        (VALIDACION_235 <> '' ) OR
        (VALIDACION_236 <> '' ) OR
        (VALIDACION_237 <> '' ) OR
        (VALIDACION_238 <> '' ) OR
        (VALIDACION_239 <> '' ) OR
        (VALIDACION_240 <> '' ) OR
        (VALIDACION_241 <> '' ) OR
        (VALIDACION_242 <> '' ) OR
        (VALIDACION_243 <> '' ) OR
        (VALIDACION_244 <> '' ) OR
        (VALIDACION_245 <> '' ) OR
        (VALIDACION_246 <> '' ) OR
        (VALIDACION_247 <> '' ) OR
        (VALIDACION_248 <> '' ) OR
        (VALIDACION_249 <> '' ) OR
        (VALIDACION_250 <> '' ) OR
        (VALIDACION_251 <> '' ) OR
        (VALIDACION_252 <> '' ) OR
        (VALIDACION_253 <> '' ) OR
        (VALIDACION_254 <> '' ) OR
        (VALIDACION_255 <> '' ) OR
        (VALIDACION_256 <> '' ) OR
        (VALIDACION_257 <> '' ) OR
        (VALIDACION_258 <> '' ) OR
        (VALIDACION_259 <> '' ) OR
        (VALIDACION_260 <> '' ) OR
        (VALIDACION_261 <> '' ) OR
        (VALIDACION_262 <> '' ) OR
        (VALIDACION_263 <> '' ) OR
        (VALIDACION_264 <> '' ) OR
        (VALIDACION_265 <> '' ) OR
        (VALIDACION_266 <> '' ) OR
        (VALIDACION_267 <> '' ) OR
        (VALIDACION_268 <> '' ) OR
        (VALIDACION_269 <> '' ) OR
        (VALIDACION_270 <> '' ) OR
        (VALIDACION_271 <> '' ) OR
        (VALIDACION_272 <> '' ) OR
        (VALIDACION_273 <> '' ) OR
        (VALIDACION_274 <> '' ) OR
        (VALIDACION_275 <> '' ) OR
        (VALIDACION_276 <> '' ) OR
        (VALIDACION_277 <> '' ) OR
        (VALIDACION_278 <> '' ) OR
        (VALIDACION_279 <> '' ) OR
        (VALIDACION_280 <> '' ) OR
        (VALIDACION_281 <> '' ) OR
        (VALIDACION_282 <> '' ) OR
        (VALIDACION_283 <> '' ) OR
        (VALIDACION_284 <> '' ) OR
        (VALIDACION_285 <> '' ) OR
        (VALIDACION_286 <> '' ) OR
        (VALIDACION_287 <> '' ) OR
        (VALIDACION_288 <> '' ) OR
        (VALIDACION_289 <> '' ) OR
        (VALIDACION_290 <> '' ) OR
        (VALIDACION_291 <> '' ) OR
        (VALIDACION_292 <> '' ) OR
        (VALIDACION_293 <> '' ) OR
        (VALIDACION_294 <> '' ) OR
        (VALIDACION_295 <> '' ) OR
        (VALIDACION_296 <> '' ) OR
        (VALIDACION_297 <> '' ) OR
        (VALIDACION_298 <> '' ) OR
        (VALIDACION_299 <> '' ) OR
        (VALIDACION_300 <> '' ) 
ORDER BY 1
END


