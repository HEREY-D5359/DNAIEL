﻿
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Consolidación. Consolidación del estado de situación financiera de la institución de crédito con sus subsidiarias */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: AGOSTO 2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: NA*/
/*TIPO SALDO: SALDOS*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/
/*SUBSIDIARIA: 0*/


CREATE OR ALTER PROC [dbo].[SP_IFRS9_R12A_1219_TSSALDOSSUBS0_VIEW_8]
AS
BEGIN
	SELECT *
		
	FROM IFRS9_R12A_1219_TSSALDOSSUBS0_RESULT_8
	WHERE

        (VALIDACION_701 <> '' ) OR
        (VALIDACION_702 <> '' ) OR
        (VALIDACION_703 <> '' ) OR
        (VALIDACION_704 <> '' ) OR
        (VALIDACION_705 <> '' ) OR
        (VALIDACION_706 <> '' ) OR
        (VALIDACION_707 <> '' ) OR
        (VALIDACION_708 <> '' ) OR
        (VALIDACION_709 <> '' ) OR
        (VALIDACION_710 <> '' ) OR
        (VALIDACION_711 <> '' ) OR
        (VALIDACION_712 <> '' ) OR
        (VALIDACION_713 <> '' ) OR
        (VALIDACION_714 <> '' ) OR
        (VALIDACION_715 <> '' ) OR
        (VALIDACION_716 <> '' ) OR
        (VALIDACION_717 <> '' ) OR
        (VALIDACION_718 <> '' ) OR
        (VALIDACION_719 <> '' ) OR
        (VALIDACION_720 <> '' ) OR
        (VALIDACION_721 <> '' ) OR
        (VALIDACION_722 <> '' ) OR
        (VALIDACION_723 <> '' ) OR
        (VALIDACION_724 <> '' ) OR
        (VALIDACION_725 <> '' ) OR
        (VALIDACION_726 <> '' ) OR
        (VALIDACION_727 <> '' ) OR
        (VALIDACION_728 <> '' ) OR
        (VALIDACION_729 <> '' ) OR
        (VALIDACION_730 <> '' ) OR
        (VALIDACION_731 <> '' ) OR
        (VALIDACION_732 <> '' ) OR
        (VALIDACION_733 <> '' ) OR
        (VALIDACION_734 <> '' ) OR
        (VALIDACION_735 <> '' ) OR
        (VALIDACION_736 <> '' ) OR
        (VALIDACION_737 <> '' ) OR
        (VALIDACION_738 <> '' ) OR
        (VALIDACION_739 <> '' ) OR
        (VALIDACION_740 <> '' ) OR
        (VALIDACION_741 <> '' ) OR
        (VALIDACION_742 <> '' ) OR
        (VALIDACION_743 <> '' ) OR
        (VALIDACION_744 <> '' ) OR
        (VALIDACION_745 <> '' ) OR
        (VALIDACION_746 <> '' ) OR
        (VALIDACION_747 <> '' ) OR
        (VALIDACION_748 <> '' ) OR
        (VALIDACION_749 <> '' ) OR
        (VALIDACION_750 <> '' ) OR
        (VALIDACION_751 <> '' ) OR
        (VALIDACION_752 <> '' ) OR
        (VALIDACION_753 <> '' ) OR
        (VALIDACION_754 <> '' ) OR
        (VALIDACION_755 <> '' ) OR
        (VALIDACION_756 <> '' ) OR
        (VALIDACION_757 <> '' ) OR
        (VALIDACION_758 <> '' ) OR
        (VALIDACION_759 <> '' ) OR
        (VALIDACION_760 <> '' ) OR
        (VALIDACION_761 <> '' ) OR
        (VALIDACION_762 <> '' ) OR
        (VALIDACION_763 <> '' ) OR
        (VALIDACION_764 <> '' ) OR
        (VALIDACION_765 <> '' ) OR
        (VALIDACION_766 <> '' ) OR
        (VALIDACION_767 <> '' ) OR
        (VALIDACION_768 <> '' ) OR
        (VALIDACION_769 <> '' ) OR
        (VALIDACION_770 <> '' ) OR
        (VALIDACION_771 <> '' ) OR
        (VALIDACION_772 <> '' ) OR
        (VALIDACION_773 <> '' ) OR
        (VALIDACION_774 <> '' ) OR
        (VALIDACION_775 <> '' ) OR
        (VALIDACION_776 <> '' ) OR
        (VALIDACION_777 <> '' ) OR
        (VALIDACION_778 <> '' ) OR
        (VALIDACION_779 <> '' ) OR
        (VALIDACION_780 <> '' ) OR
        (VALIDACION_781 <> '' ) OR
        (VALIDACION_782 <> '' ) OR
        (VALIDACION_783 <> '' ) OR
        (VALIDACION_784 <> '' ) OR
        (VALIDACION_785 <> '' ) OR
        (VALIDACION_786 <> '' ) OR
        (VALIDACION_787 <> '' ) OR
        (VALIDACION_788 <> '' ) OR
        (VALIDACION_789 <> '' ) OR
        (VALIDACION_790 <> '' ) OR
        (VALIDACION_791 <> '' ) OR
        (VALIDACION_792 <> '' ) OR
        (VALIDACION_793 <> '' ) OR
        (VALIDACION_794 <> '' ) OR
        (VALIDACION_795 <> '' ) OR
        (VALIDACION_796 <> '' ) OR
        (VALIDACION_797 <> '' ) OR
        (VALIDACION_798 <> '' ) OR
        (VALIDACION_799 <> '' ) OR
        (VALIDACION_800 <> '' ) 
ORDER BY 1
END


