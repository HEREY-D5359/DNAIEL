﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Reclasificaciones. Reclasificaciones en el estado de resultado integral */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: JULIO 2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: NA*/
/*TIPO SALDO: 141*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: 6*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R10A_1012_TS141TM6_COMP_3]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R10A_1012_TS141TM6_RESULT_3')
BEGIN
DROP TABLE IFRS9_R10A_1012_TS141TM6_RESULT_3
END 

BEGIN
SELECT DISTINCT

    /*ID*/

    CONVERT(VARCHAR,ID) AS ID,                                    /*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010105149')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501014906229','501014906230','501014906231','501014906232','501014906233','501014906234','501014906235','501014906236')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501010105149) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501014906229 + 501014906230 + 501014906231 + 501014906232 + 501014906233 + 501014906234 + 501014906235 + 501014906236) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_201,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501014906229')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501022907139','501022907140')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501014906229) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501022907139 + 501022907140) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_202,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501014906230')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501023007141','501023007142','501023007143')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501014906230) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501023007141 + 501023007142 + 501023007143) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_203,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501014906231')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501023107144','501023107145')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501014906231) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501023107144 + 501023107145) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_204,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010105150')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501015006237','501015006238')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501010105150) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501015006237 + 501015006238) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_205,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501015006237')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501023707146','501023707147','501023707148')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501015006237) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501023707146 + 501023707147 + 501023707148) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_206,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501015006238')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501023807149','501023807150','501023807151')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501015006238) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501023807149 + 501023807150 + 501023807151) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_207,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010105151')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501015106239','501015106240','501015106241','501015106242')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501010105151) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501015106239 + 501015106240 + 501015106241 + 501015106242) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_208,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501015106240')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501024007152','501024007153','501024007154','501024007155','501024007156')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501015106240) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501024007152 + 501024007153 + 501024007154 + 501024007155 + 501024007156) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_209,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501015106241')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501024107157','501024107158','501024107159','501024107160')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501015106241) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501024107157 + 501024107158 + 501024107159 + 501024107160) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_210,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501015106242')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501024207161','501024207162','501024207163','501024207164')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501015106242) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501024207161 + 501024207162 + 501024207163 + 501024207164) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_211,

/*Créditos comerciales restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501005304102')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010205152','501010205153','501010205154')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501005304102) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501010205152 + 501010205153 + 501010205154) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_212,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010205152')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501015206243','501015206244','501015206245','501015206246','501015206247','501015206248','501015206249','501015206250')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501010205152) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501015206243 + 501015206244 + 501015206245 + 501015206246 + 501015206247 + 501015206248 + 501015206249 + 501015206250) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_213,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501015206243')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501024307165','501024307166')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501015206243) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501024307165 + 501024307166) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_214,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501015206244')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501024407167','501024407168','501024407169')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501015206244) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501024407167 + 501024407168 + 501024407169) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_215,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501015206245')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501024507170','501024507171')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501015206245) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501024507170 + 501024507171) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_216,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010205153')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501015306251','501015306252')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501010205153) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501015306251 + 501015306252) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_217,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501015306251')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501025107172','501025107173','501025107174')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501015306251) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501025107172 + 501025107173 + 501025107174) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_218,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501015306252')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501025207175','501025207176','501025207177')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501015306252) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501025207175 + 501025207176 + 501025207177) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_219,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010205154')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501015406253','501015406254','501015406255','501015406256')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501010205154) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501015406253 + 501015406254 + 501015406255 + 501015406256) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_220,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501015406254')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501025407178','501025407179','501025407180','501025407181','501025407182')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501015406254) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501025407178 + 501025407179 + 501025407180 + 501025407181 + 501025407182) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_221,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501015406255')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501025507183','501025507184','501025507185','501025507186')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501015406255) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501025507183 + 501025507184 + 501025507185 + 501025507186) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_222,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501015406256')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501025607187','501025607188','501025607189','501025607190')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501015406256) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501025607187 + 501025607188 + 501025607189 + 501025607190) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_223,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501003803054')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501005404103','501005404104')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501003803054) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501005404103 + 501005404104) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_224,

/*Créditos de consumo sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501005404103')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010305155','501010305156','501010305157','501010305158','501010305159','501010305160','501010305161','501010305162')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501005404103) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501010305155 + 501010305156 + 501010305157 + 501010305158 + 501010305159 + 501010305160 + 501010305161 + 501010305162) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_225,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010305155')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501015506257','501015506258')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501010305155) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501015506257 + 501015506258) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_226,

/*Créditos de consumo restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501005404104')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010405163','501010405164','501010405165','501010405166','501010405167','501010405168','501010405169','501010405170')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501005404104) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501010405163 + 501010405164 + 501010405165 + 501010405166 + 501010405167 + 501010405168 + 501010405169 + 501010405170) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_227,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010405163')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501016306259','501016306260')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501010405163) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501016306259 + 501016306260) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_228,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501003803055')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501005504105','501005504106')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501003803055) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501005504105 + 501005504106) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_229,

/*Créditos a la vivienda sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501005504105')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010505171','501010505172','501010505173','501010505174','501010505175')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501005504105) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501010505171 + 501010505172 + 501010505173 + 501010505174 + 501010505175) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_230,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010505173')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501017306261','501017306262','501017306263')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501010505173) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501017306261 + 501017306262 + 501017306263) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_231,

/*Créditos a la vivienda restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501005504106')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010605176','501010605177','501010605178','501010605179','501010605180')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501005504106) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501010605176 + 501010605177 + 501010605178 + 501010605179 + 501010605180) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_232,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010605178')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501017806264','501017806265','501017806266')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501010605178) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501017806264 + 501017806265 + 501017806266) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_233,

/*Comisiones y tarifas pagadas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('601200301006')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('601200602057','601200602058','601200602059','601200602060','601200602061','601200602062','601200602063','601200602064')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (601200301006) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (601200602057 + 601200602058 + 601200602059 + 601200602060 + 601200602061 + 601200602062 + 601200602063 + 601200602064) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_234,

/*Resultado por intermediación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501400301007')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501400702065','501400702066','501400702067','501400702068','501400702069','501400702070','501400702071','501400702072','501400702073','501400702074','501400702075','501400702076','501400702077','501400702078')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501400301007) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501400702065 + 501400702066 + 501400702067 + 501400702068 + 501400702069 + 501400702070 + 501400702071 + 501400702072 + 501400702073 + 501400702074 + 501400702075 + 501400702076 + 501400702077 + 501400702078) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_235,

/*Resultado por valuación de instrumentos financieros a valor razonable*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501400702065')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501406503057','501406503058','501406503059','501406503060','501406503061','501406503062')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501400702065) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501406503057 + 501406503058 + 501406503059 + 501406503060 + 501406503061 + 501406503062) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_236,

/*Estimación de pérdidas crediticias esperadas para inversiones en instrumentos financieros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501400702066')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501406603063','501406603064')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501400702066) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501406603063 + 501406603064) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_237,

/*Resultado por compraventa de instrumentos financieros e instrumentos financieros derivados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501400702071')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501407103065','501407103066','501407103067','501407103068','501407103069')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501400702071) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501407103065 + 501407103066 + 501407103067 + 501407103068 + 501407103069) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_238,

/*Costos de transacción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501400702076')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501407603070','501407603071','501407603072','501407603073')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501400702076) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501407603070 + 501407603071 + 501407603072 + 501407603073) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_239,

/*Otros ingresos (egresos) de la operación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501600301008')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501600802079','501600802080','501600802081','501600802082','501600802083','501600802084','501600802085','501600802086','501600802087','501600802088','501600802089','501600802090','501600802091','501600802092','501600802093','501600802094','501600802095','501600802096','501600802097','501600802098','501600802099','501600802100','501600802101','501600802102','501600802103','501600802104','501600802105','501600802106','501600802107','501600802108','501600802109','501600802110','501600802111')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501600301008) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501600802079 + 501600802080 + 501600802081 + 501600802082 + 501600802083 + 501600802084 + 501600802085 + 501600802086 + 501600802087 + 501600802088 + 501600802089 + 501600802090 + 501600802091 + 501600802092 + 501600802093 + 501600802094 + 501600802095 + 501600802096 + 501600802097 + 501600802098 + 501600802099 + 501600802100 + 501600802101 + 501600802102 + 501600802103 + 501600802104 + 501600802105 + 501600802106 + 501600802107 + 501600802108 + 501600802109 + 501600802110 + 501600802111) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_240,

/*Recuperaciones*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501600802080')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501608003074','501608003075','501608003076','501608003077')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501600802080) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501608003074 + 501608003075 + 501608003076 + 501608003077) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_241,

/*Quebrantos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501600802088')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501608803078','501608803079','501608803080','501608803081','501608803082','501608803083','501608803084')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501600802088) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501608803078 + 501608803079 + 501608803080 + 501608803081 + 501608803082 + 501608803083 + 501608803084) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_242,

/*Fraudes*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501608803079')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501607904107','501607904108')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501608803079) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (501607904107 + 501607904108) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_243,

/*Gastos de administración y promoción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('602000301010')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('602001002114','602001002115','602001002116','602001002117','602001002118','602001002119','602001002120','602001002121','602001002122','602001002123','602001002124','602001002125','602001002126','602001002127','602001002128','602001002129','602001002130')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (602000301010) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (602001002114 + 602001002115 + 602001002116 + 602001002117 + 602001002118 + 602001002119 + 602001002120 + 602001002121 + 602001002122 + 602001002123 + 602001002124 + 602001002125 + 602001002126 + 602001002127 + 602001002128 + 602001002129 + 602001002130) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_245,

/*Beneficios directos a corto plazo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('602001002114')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('602011403085','602011403086')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (602001002114) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (602011403085 + 602011403086) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_246,

/*Participación de los trabajadores en las utilidades*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('602011403085')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('602008504109')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (602011403085) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (602008504109) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_247,

/*Costo neto del periodo derivado de beneficios a los empleados a largo plazo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('602001002115')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('602011503087','602011503088','602011503089')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (602001002115) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (602011503087 + 602011503088 + 602011503089) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_248,

/*Beneficios directos a largo plazo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('602011503087')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('602008704110','602008704111')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (602011503087) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (602008704110 + 602008704111) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_249,

/*Beneficios post-empleo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('602011503088')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('602008804112','602008804113','602008804114')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (602011503088) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (602008804112 + 602008804113 + 602008804114) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_250,

/*Beneficios por terminación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('602011503089')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('602008904115','602008904116')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (602011503089) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (602008904115 + 602008904116) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_251,

/*Depreciaciones*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('602001002123')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('602012303090','602012303091')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (602001002123) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (602012303090 + 602012303091) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_252,

/*Amortizaciones*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('602001002124')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('602012403092','602012403093')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (602001002124) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (602012403092 + 602012403093) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_253,

/*RESULTADO DE LA OPERACIÓN*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('330000000003')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('502200401011')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (330000000003) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (502200401011) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_254,

/*Participación en el resultado neto de otras entidades*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('502200401011')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('502201102131','502201102132','502201102133','502201102134','502201102135','502201102136')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502200401011) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (502201102131 + 502201102132 + 502201102133 + 502201102134 + 502201102135 + 502201102136) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_255,

/*Resultado del ejercicio de subsidiarias no consolidadas, asociadas y negocios conjuntos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('502201102131')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('502213103094','502213103095','502213103096')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502201102131) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (502213103094 + 502213103095 + 502213103096) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_256,

/*En subsidiarias no consolidadas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('502213103094')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('502209404117','502209404118')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502213103094) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (502209404117 + 502209404118) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_257,

/*En asociadas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('502213103095')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('502209504119','502209504120')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502213103095) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (502209504119 + 502209504120) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_258,

/*En negocios conjuntos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('502213103096')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('502209604121','502209604122')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502213103096) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (502209604121 + 502209604122) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_259,

/*RESULTADO ANTES DE IMPUESTOS A LA UTILIDAD*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('330000000004')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('602400501012')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (330000000004) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (602400501012) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_260,

/*Impuestos a la utilidad*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('602400501012')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('602401202137','602401202138','602401202139','602401202140')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (602400501012) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (602401202137 + 602401202138 + 602401202139 + 602401202140) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_261,

/*Impuestos a la utilidad causados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('602401202137')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('602413703097','602413703098')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (602401202137) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (602413703097 + 602413703098) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_262,

/*Impuestos a la utilidad diferidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('602401202138')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('602413803099','602413803100','602413803101')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (602401202138) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (602413803099 + 602413803100 + 602413803101) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_263,

/*Estimación por impuestos a la utilidad no recuperables*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('602401202139')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('602413903102','602413903103','602413903104')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (602401202139) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (602413903102 + 602413903103 + 602413903104) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_264,

/*RESULTADO DE OPERACIONES CONTINUAS*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('330000000005')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('502600601013')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (330000000005) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (502600601013) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_265,

/*Operaciones discontinuadas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('502600601013')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('502601302141','502601302142')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502600601013) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (502601302141 + 502601302142) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_266,

/*RESULTADO NETO*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('330000000006')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('502800701014','503000701015')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (330000000006) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (502800701014 + 503000701015) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_267,

/*Otros resultados integrales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('502800701014')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('502801402143','502801402144','502801402145','502801402146','502801402147','502801402148')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502800701014) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (502801402143 + 502801402144 + 502801402145 + 502801402146 + 502801402147 + 502801402148) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_268,

/*Valuación de instrumentos financieros para cobrar o vender*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('502801402143')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('502814303105','502814303106')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502801402143) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (502814303105 + 502814303106) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_269,

/*Efecto del periodo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('502814303105')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('502810504123','502810504124','502810504125')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502814303105) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (502810504123 + 502810504124 + 502810504125) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_270,

/*Valuación de instrumentos financieros derivados de cobertura de flujos de efectivo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('502801402144')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('502814403107','502814403108')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502801402144) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (502814403107 + 502814403108) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_271,

/*Efecto del periodo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('502814403107')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('502810704126','502810704127','502810704128')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502814403107) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (502810704126 + 502810704127 + 502810704128) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_272,

/*Ingresos y gastos relacionados con activos mantenidos para su disposición*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('502801402145')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('502814503109','502814503110')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502801402145) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (502814503109 + 502814503110) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_273,

/*Efecto del periodo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('502814503109')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('502810904129','502810904130','502810904131')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502814503109) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (502810904129 + 502810904130 + 502810904131) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_274,

/*Remedición de beneficios definidos a los empleados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('502801402146')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('502814603111','502814603112')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502801402146) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (502814603111 + 502814603112) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_275,

/*Efecto del periodo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('502814603111')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('502811104132','502811104133','502811104134')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502814603111) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (502811104132 + 502811104133 + 502811104134) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_276,

/*Efecto acumulado por conversión*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('502801402147')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('502814703113','502814703114')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502801402147) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (502814703113 + 502814703114) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_277,

/*Efecto del periodo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('502814703113')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('502811304135','502811304136','502811304137')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502814703113) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (502811304135 + 502811304136 + 502811304137) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_278,

/*Resultado por tenencia de activos no monetarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('502801402148')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('502814803115','502814803116')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502801402148) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (502814803115 + 502814803116) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_279,

/*Efecto del periodo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('502814803115')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('502811504138','502811504139','502811504140')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502814803115) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (502811504138 + 502811504139 + 502811504140) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_280,

/*Participación en ORI de otras entidades*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('503000701015')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('503001502149','503001502150')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (503000701015) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (503001502149 + 503001502150) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_281,

/*Efecto del periodo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('503001502149')   
AND c05_tipo_saldo IN ('141')    
AND c06_tipo_movimiento IN ('6')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('503014903117','503014903118','503014903119')
AND c05_tipo_saldo IN ('141')     
AND c06_tipo_movimiento IN ('6')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (503001502149) con Tipo de Saldo 141, Tipo de Movimiento 6, debe ser igual a la sumatoria de las cuentas (503014903117 + 503014903118 + 503014903119) con Tipo de Saldo 141, Tipo de Movimiento 6.')    
AS VALIDACION_282
	
INTO IFRS9_R10A_1012_TS141TM6_RESULT_3
FROM IFRS9_R10A_1012

END

BEGIN
	INSERT INTO IFRS9_R10A_1012_TS141TM6_RESULT_3 
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_201])),
            SUM(CHARINDEX('ERR',[VALIDACION_202])),
            SUM(CHARINDEX('ERR',[VALIDACION_203])),
            SUM(CHARINDEX('ERR',[VALIDACION_204])),
            SUM(CHARINDEX('ERR',[VALIDACION_205])),
            SUM(CHARINDEX('ERR',[VALIDACION_206])),
            SUM(CHARINDEX('ERR',[VALIDACION_207])),
            SUM(CHARINDEX('ERR',[VALIDACION_208])),
            SUM(CHARINDEX('ERR',[VALIDACION_209])),
            SUM(CHARINDEX('ERR',[VALIDACION_210])),
            SUM(CHARINDEX('ERR',[VALIDACION_211])),
            SUM(CHARINDEX('ERR',[VALIDACION_212])),
            SUM(CHARINDEX('ERR',[VALIDACION_213])),
            SUM(CHARINDEX('ERR',[VALIDACION_214])),
            SUM(CHARINDEX('ERR',[VALIDACION_215])),
            SUM(CHARINDEX('ERR',[VALIDACION_216])),
            SUM(CHARINDEX('ERR',[VALIDACION_217])),
            SUM(CHARINDEX('ERR',[VALIDACION_218])),
            SUM(CHARINDEX('ERR',[VALIDACION_219])),
            SUM(CHARINDEX('ERR',[VALIDACION_220])),
            SUM(CHARINDEX('ERR',[VALIDACION_221])),
            SUM(CHARINDEX('ERR',[VALIDACION_222])),
            SUM(CHARINDEX('ERR',[VALIDACION_223])),
            SUM(CHARINDEX('ERR',[VALIDACION_224])),
            SUM(CHARINDEX('ERR',[VALIDACION_225])),
            SUM(CHARINDEX('ERR',[VALIDACION_226])),
            SUM(CHARINDEX('ERR',[VALIDACION_227])),
            SUM(CHARINDEX('ERR',[VALIDACION_228])),
            SUM(CHARINDEX('ERR',[VALIDACION_229])),
            SUM(CHARINDEX('ERR',[VALIDACION_230])),
            SUM(CHARINDEX('ERR',[VALIDACION_231])),
            SUM(CHARINDEX('ERR',[VALIDACION_232])),
            SUM(CHARINDEX('ERR',[VALIDACION_233])),
            SUM(CHARINDEX('ERR',[VALIDACION_234])),
            SUM(CHARINDEX('ERR',[VALIDACION_235])),
            SUM(CHARINDEX('ERR',[VALIDACION_236])),
            SUM(CHARINDEX('ERR',[VALIDACION_237])),
            SUM(CHARINDEX('ERR',[VALIDACION_238])),
            SUM(CHARINDEX('ERR',[VALIDACION_239])),
            SUM(CHARINDEX('ERR',[VALIDACION_240])),
            SUM(CHARINDEX('ERR',[VALIDACION_241])),
            SUM(CHARINDEX('ERR',[VALIDACION_242])),
            SUM(CHARINDEX('ERR',[VALIDACION_243])),
            SUM(CHARINDEX('ERR',[VALIDACION_244])),
            SUM(CHARINDEX('ERR',[VALIDACION_245])),
            SUM(CHARINDEX('ERR',[VALIDACION_246])),
            SUM(CHARINDEX('ERR',[VALIDACION_247])),
            SUM(CHARINDEX('ERR',[VALIDACION_248])),
            SUM(CHARINDEX('ERR',[VALIDACION_249])),
            SUM(CHARINDEX('ERR',[VALIDACION_250])),
            SUM(CHARINDEX('ERR',[VALIDACION_251])),
            SUM(CHARINDEX('ERR',[VALIDACION_252])),
            SUM(CHARINDEX('ERR',[VALIDACION_253])),
            SUM(CHARINDEX('ERR',[VALIDACION_254])),
            SUM(CHARINDEX('ERR',[VALIDACION_255])),
            SUM(CHARINDEX('ERR',[VALIDACION_256])),
            SUM(CHARINDEX('ERR',[VALIDACION_257])),
            SUM(CHARINDEX('ERR',[VALIDACION_258])),
            SUM(CHARINDEX('ERR',[VALIDACION_259])),
            SUM(CHARINDEX('ERR',[VALIDACION_260])),
            SUM(CHARINDEX('ERR',[VALIDACION_261])),
            SUM(CHARINDEX('ERR',[VALIDACION_262])),
            SUM(CHARINDEX('ERR',[VALIDACION_263])),
            SUM(CHARINDEX('ERR',[VALIDACION_264])),
            SUM(CHARINDEX('ERR',[VALIDACION_265])),
            SUM(CHARINDEX('ERR',[VALIDACION_266])),
            SUM(CHARINDEX('ERR',[VALIDACION_267])),
            SUM(CHARINDEX('ERR',[VALIDACION_268])),
            SUM(CHARINDEX('ERR',[VALIDACION_269])),
            SUM(CHARINDEX('ERR',[VALIDACION_270])),
            SUM(CHARINDEX('ERR',[VALIDACION_271])),
            SUM(CHARINDEX('ERR',[VALIDACION_272])),
            SUM(CHARINDEX('ERR',[VALIDACION_273])),
            SUM(CHARINDEX('ERR',[VALIDACION_274])),
            SUM(CHARINDEX('ERR',[VALIDACION_275])),
            SUM(CHARINDEX('ERR',[VALIDACION_276])),
            SUM(CHARINDEX('ERR',[VALIDACION_277])),
            SUM(CHARINDEX('ERR',[VALIDACION_278])),
            SUM(CHARINDEX('ERR',[VALIDACION_279])),
            SUM(CHARINDEX('ERR',[VALIDACION_280])),
            SUM(CHARINDEX('ERR',[VALIDACION_281])),
            SUM(CHARINDEX('ERR',[VALIDACION_282])),
            SUM(CHARINDEX('ERR',[VALIDACION_283])),
            SUM(CHARINDEX('ERR',[VALIDACION_284])),
            SUM(CHARINDEX('ERR',[VALIDACION_285])),
            SUM(CHARINDEX('ERR',[VALIDACION_286])),
            SUM(CHARINDEX('ERR',[VALIDACION_287])),
            SUM(CHARINDEX('ERR',[VALIDACION_288])),
            SUM(CHARINDEX('ERR',[VALIDACION_289])),
            SUM(CHARINDEX('ERR',[VALIDACION_290])),
            SUM(CHARINDEX('ERR',[VALIDACION_291])),
            SUM(CHARINDEX('ERR',[VALIDACION_292])),
            SUM(CHARINDEX('ERR',[VALIDACION_293])),
            SUM(CHARINDEX('ERR',[VALIDACION_294])),
            SUM(CHARINDEX('ERR',[VALIDACION_295])),
            SUM(CHARINDEX('ERR',[VALIDACION_296])),
            SUM(CHARINDEX('ERR',[VALIDACION_297])),
            SUM(CHARINDEX('ERR',[VALIDACION_298])),
            SUM(CHARINDEX('ERR',[VALIDACION_299])),
            SUM(CHARINDEX('ERR',[VALIDACION_300]))
            


		FROM IFRS9_R10A_1012_TS141TM6_RESULT_3 
END

BEGIN
	EXEC SP_IFRS9_R10A_1012_TS141TM6_VIEW_3
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


