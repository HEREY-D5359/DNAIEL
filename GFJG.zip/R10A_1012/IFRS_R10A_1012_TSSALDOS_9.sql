﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Reclasificaciones. Reclasificaciones en el estado de resultado integral */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: JULIO 2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: NA*/
/*TIPO SALDO: SALDOS*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R10A_1012_TSSALDOS_COMP_9]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R10A_1012_TSSALDOS_RESULT_9')
BEGIN
DROP TABLE IFRS9_R10A_1012_TSSALDOS_RESULT_9
END 

BEGIN
SELECT DISTINCT
         /*id*/
CONVERT(VARCHAR,ID) AS ID, 
	/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501024107160')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501024107160')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501024107160) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501024107160) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_801,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501015106242')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501015106242')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501015106242) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501015106242) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_802,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501024207161')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501024207161')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501024207161) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501024207161) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_803,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501024207162')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501024207162')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501024207162) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501024207162) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_804,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501024207163')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501024207163')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501024207163) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501024207163) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_805,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501024207164')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501024207164')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501024207164) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501024207164) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_806,

/*Créditos comerciales restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501005304102')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501005304102')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501005304102) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501005304102) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_807,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010205152')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010205152')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501010205152) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501010205152) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_808,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501015206243')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501015206243')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501015206243) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501015206243) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_809,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501024307165')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501024307165')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501024307165) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501024307165) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_810,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501024307166')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501024307166')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501024307166) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501024307166) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_811,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501015206244')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501015206244')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501015206244) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501015206244) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_812,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501024407167')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501024407167')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501024407167) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501024407167) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_813,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501024407168')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501024407168')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501024407168) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501024407168) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_814,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501024407169')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501024407169')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501024407169) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501024407169) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_815,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501015206245')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501015206245')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501015206245) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501015206245) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_816,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501024507170')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501024507170')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501024507170) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501024507170) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_817,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501024507171')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501024507171')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501024507171) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501024507171) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_818,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501015206246')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501015206246')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501015206246) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501015206246) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_819,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501015206247')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501015206247')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501015206247) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501015206247) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_820,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501015206248')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501015206248')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501015206248) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501015206248) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_821,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501015206249')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501015206249')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501015206249) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501015206249) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_822,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501015206250')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501015206250')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501015206250) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501015206250) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_823,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010205153')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010205153')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501010205153) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501010205153) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_824,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501015306251')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501015306251')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501015306251) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501015306251) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_825,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501025107172')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501025107172')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501025107172) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501025107172) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_826,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501025107173')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501025107173')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501025107173) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501025107173) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_827,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501025107174')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501025107174')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501025107174) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501025107174) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_828,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501015306252')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501015306252')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501015306252) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501015306252) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_829,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501025207175')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501025207175')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501025207175) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501025207175) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_830,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501025207176')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501025207176')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501025207176) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501025207176) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_831,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501025207177')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501025207177')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501025207177) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501025207177) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_832,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010205154')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010205154')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501010205154) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501010205154) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_833,

/*Créditos al gobierno federal*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501015406253')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501015406253')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501015406253) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501015406253) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_834,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501015406254')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501015406254')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501015406254) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501015406254) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_835,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501025407178')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501025407178')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501025407178) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501025407178) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_836,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501025407179')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501025407179')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501025407179) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501025407179) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_837,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501025407180')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501025407180')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501025407180) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501025407180) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_838,

/*Fideicomisos públicos de contratación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501025407181')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501025407181')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501025407181) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501025407181) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_839,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501025407182')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501025407182')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501025407182) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501025407182) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_840,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501015406255')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501015406255')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501015406255) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501015406255) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_841,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501025507183')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501025507183')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501025507183) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501025507183) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_842,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501025507184')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501025507184')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501025507184) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501025507184) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_843,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501025507185')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501025507185')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501025507185) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501025507185) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_844,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501025507186')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501025507186')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501025507186) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501025507186) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_845,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501015406256')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501015406256')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501015406256) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501015406256) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_846,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501025607187')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501025607187')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501025607187) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501025607187) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_847,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501025607188')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501025607188')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501025607188) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501025607188) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_848,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501025607189')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501025607189')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501025607189) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501025607189) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_849,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501025607190')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501025607190')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501025607190) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501025607190) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_850,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501003803054')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501003803054')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501003803054) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501003803054) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_851,

/*Créditos de consumo sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501005404103')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501005404103')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501005404103) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501005404103) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_852,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010305155')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010305155')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501010305155) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501010305155) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_853,

/*Primera anualidad y subsecuentes de tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501015506257')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501015506257')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501015506257) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501015506257) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_854,

/*Negocios afiliados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501015506258')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501015506258')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501015506258) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501015506258) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_855,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010305156')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010305156')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501010305156) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501010305156) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_856,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010305157')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010305157')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501010305157) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501010305157) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_857,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010305158')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010305158')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501010305158) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501010305158) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_858,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010305159')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010305159')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501010305159) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501010305159) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_859,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010305160')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010305160')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501010305160) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501010305160) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_860,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010305161')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010305161')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501010305161) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501010305161) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_861,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010305162')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010305162')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501010305162) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501010305162) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_862,

/*Créditos de consumo restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501005404104')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501005404104')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501005404104) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501005404104) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_863,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010405163')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010405163')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501010405163) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501010405163) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_864,

/*Primera anualidad y subsecuentes de tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501016306259')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501016306259')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501016306259) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501016306259) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_865,

/*Negocios afiliados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501016306260')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501016306260')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501016306260) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501016306260) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_866,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010405164')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010405164')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501010405164) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501010405164) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_867,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010405165')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010405165')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501010405165) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501010405165) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_868,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010405166')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010405166')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501010405166) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501010405166) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_869,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010405167')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010405167')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501010405167) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501010405167) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_870,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010405168')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010405168')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501010405168) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501010405168) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_871,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010405169')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010405169')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501010405169) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501010405169) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_872,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010405170')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010405170')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501010405170) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501010405170) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_873,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501003803055')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501003803055')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501003803055) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501003803055) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_874,

/*Créditos a la vivienda sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501005504105')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501005504105')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501005504105) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501005504105) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_875,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010505171')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010505171')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501010505171) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501010505171) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_876,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010505172')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010505172')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501010505172) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501010505172) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_877,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010505173')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010505173')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501010505173) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501010505173) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_878,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501017306261')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501017306261')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501017306261) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501017306261) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_879,

/*Cartera en prórroga*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501017306262')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501017306262')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501017306262) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501017306262) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_880,

/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501017306263')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501017306263')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501017306263) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501017306263) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_881,

/*Remodelación o mejoramiento con garantía otorgada por la banca de desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010505174')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010505174')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501010505174) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501010505174) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_882,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010505175')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010505175')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501010505175) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501010505175) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_883,

/*Créditos a la vivienda restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501005504106')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501005504106')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501005504106) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501005504106) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_884,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010605176')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010605176')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501010605176) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501010605176) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_885,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010605177')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010605177')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501010605177) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501010605177) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_886,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010605178')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010605178')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501010605178) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501010605178) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_887,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501017806264')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501017806264')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501017806264) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501017806264) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_888,

/*Cartera en prórroga*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501017806265')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501017806265')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501017806265) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501017806265) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_889,

/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501017806266')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501017806266')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501017806266) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501017806266) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_890,

/*Remodelación o mejoramiento con garantía otorgada por la banca de desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010605179')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010605179')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501010605179) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501010605179) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_891,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501010605180')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010605180')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501010605180) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501010605180) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_892,

/*Compraventa de activos virtuales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501000502039')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501000502039')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501000502039) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501000502039) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_893,

/*Avales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501000502040')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501000502040')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501000502040) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501000502040) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_894,

/*Cartas de crédito sin refinanciamiento*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501000502041')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501000502041')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501000502041) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501000502041) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_895,

/*Aceptaciones por cuenta de terceros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501000502042')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501000502042')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501000502042) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501000502042) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_896,

/*Compraventa de instrumentos financieros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501000502043')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501000502043')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501000502043) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501000502043) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_897,

/*Apertura de cuenta*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501000502044')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501000502044')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501000502044) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501000502044) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_898,

/*Manejo de cuenta*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501000502045')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501000502045')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501000502045) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501000502045) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_899,

/*Actividades fiduciarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501000502046')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501000502046')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (501000502046) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (501000502046) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_900
	
INTO IFRS9_R10A_1012_TSSALDOS_RESULT_9
FROM IFRS9_R10A_1012

END

BEGIN
	INSERT INTO IFRS9_R10A_1012_TSSALDOS_RESULT_9 
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_801])),
            SUM(CHARINDEX('ERR',[VALIDACION_802])),
            SUM(CHARINDEX('ERR',[VALIDACION_803])),
            SUM(CHARINDEX('ERR',[VALIDACION_804])),
            SUM(CHARINDEX('ERR',[VALIDACION_805])),
            SUM(CHARINDEX('ERR',[VALIDACION_806])),
            SUM(CHARINDEX('ERR',[VALIDACION_807])),
            SUM(CHARINDEX('ERR',[VALIDACION_808])),
            SUM(CHARINDEX('ERR',[VALIDACION_809])),
            SUM(CHARINDEX('ERR',[VALIDACION_810])),
            SUM(CHARINDEX('ERR',[VALIDACION_811])),
            SUM(CHARINDEX('ERR',[VALIDACION_812])),
            SUM(CHARINDEX('ERR',[VALIDACION_813])),
            SUM(CHARINDEX('ERR',[VALIDACION_814])),
            SUM(CHARINDEX('ERR',[VALIDACION_815])),
            SUM(CHARINDEX('ERR',[VALIDACION_816])),
            SUM(CHARINDEX('ERR',[VALIDACION_817])),
            SUM(CHARINDEX('ERR',[VALIDACION_818])),
            SUM(CHARINDEX('ERR',[VALIDACION_819])),
            SUM(CHARINDEX('ERR',[VALIDACION_820])),
            SUM(CHARINDEX('ERR',[VALIDACION_821])),
            SUM(CHARINDEX('ERR',[VALIDACION_822])),
            SUM(CHARINDEX('ERR',[VALIDACION_823])),
            SUM(CHARINDEX('ERR',[VALIDACION_824])),
            SUM(CHARINDEX('ERR',[VALIDACION_825])),
            SUM(CHARINDEX('ERR',[VALIDACION_826])),
            SUM(CHARINDEX('ERR',[VALIDACION_827])),
            SUM(CHARINDEX('ERR',[VALIDACION_828])),
            SUM(CHARINDEX('ERR',[VALIDACION_829])),
            SUM(CHARINDEX('ERR',[VALIDACION_830])),
            SUM(CHARINDEX('ERR',[VALIDACION_831])),
            SUM(CHARINDEX('ERR',[VALIDACION_832])),
            SUM(CHARINDEX('ERR',[VALIDACION_833])),
            SUM(CHARINDEX('ERR',[VALIDACION_834])),
            SUM(CHARINDEX('ERR',[VALIDACION_835])),
            SUM(CHARINDEX('ERR',[VALIDACION_836])),
            SUM(CHARINDEX('ERR',[VALIDACION_837])),
            SUM(CHARINDEX('ERR',[VALIDACION_838])),
            SUM(CHARINDEX('ERR',[VALIDACION_839])),
            SUM(CHARINDEX('ERR',[VALIDACION_840])),
            SUM(CHARINDEX('ERR',[VALIDACION_841])),
            SUM(CHARINDEX('ERR',[VALIDACION_842])),
            SUM(CHARINDEX('ERR',[VALIDACION_843])),
            SUM(CHARINDEX('ERR',[VALIDACION_844])),
            SUM(CHARINDEX('ERR',[VALIDACION_845])),
            SUM(CHARINDEX('ERR',[VALIDACION_846])),
            SUM(CHARINDEX('ERR',[VALIDACION_847])),
            SUM(CHARINDEX('ERR',[VALIDACION_848])),
            SUM(CHARINDEX('ERR',[VALIDACION_849])),
            SUM(CHARINDEX('ERR',[VALIDACION_850])),
            SUM(CHARINDEX('ERR',[VALIDACION_851])),
            SUM(CHARINDEX('ERR',[VALIDACION_852])),
            SUM(CHARINDEX('ERR',[VALIDACION_853])),
            SUM(CHARINDEX('ERR',[VALIDACION_854])),
            SUM(CHARINDEX('ERR',[VALIDACION_855])),
            SUM(CHARINDEX('ERR',[VALIDACION_856])),
            SUM(CHARINDEX('ERR',[VALIDACION_857])),
            SUM(CHARINDEX('ERR',[VALIDACION_858])),
            SUM(CHARINDEX('ERR',[VALIDACION_859])),
            SUM(CHARINDEX('ERR',[VALIDACION_860])),
            SUM(CHARINDEX('ERR',[VALIDACION_861])),
            SUM(CHARINDEX('ERR',[VALIDACION_862])),
            SUM(CHARINDEX('ERR',[VALIDACION_863])),
            SUM(CHARINDEX('ERR',[VALIDACION_864])),
            SUM(CHARINDEX('ERR',[VALIDACION_865])),
            SUM(CHARINDEX('ERR',[VALIDACION_866])),
            SUM(CHARINDEX('ERR',[VALIDACION_867])),
            SUM(CHARINDEX('ERR',[VALIDACION_868])),
            SUM(CHARINDEX('ERR',[VALIDACION_869])),
            SUM(CHARINDEX('ERR',[VALIDACION_870])),
            SUM(CHARINDEX('ERR',[VALIDACION_871])),
            SUM(CHARINDEX('ERR',[VALIDACION_872])),
            SUM(CHARINDEX('ERR',[VALIDACION_873])),
            SUM(CHARINDEX('ERR',[VALIDACION_874])),
            SUM(CHARINDEX('ERR',[VALIDACION_875])),
            SUM(CHARINDEX('ERR',[VALIDACION_876])),
            SUM(CHARINDEX('ERR',[VALIDACION_877])),
            SUM(CHARINDEX('ERR',[VALIDACION_878])),
            SUM(CHARINDEX('ERR',[VALIDACION_879])),
            SUM(CHARINDEX('ERR',[VALIDACION_880])),
            SUM(CHARINDEX('ERR',[VALIDACION_881])),
            SUM(CHARINDEX('ERR',[VALIDACION_882])),
            SUM(CHARINDEX('ERR',[VALIDACION_883])),
            SUM(CHARINDEX('ERR',[VALIDACION_884])),
            SUM(CHARINDEX('ERR',[VALIDACION_885])),
            SUM(CHARINDEX('ERR',[VALIDACION_886])),
            SUM(CHARINDEX('ERR',[VALIDACION_887])),
            SUM(CHARINDEX('ERR',[VALIDACION_888])),
            SUM(CHARINDEX('ERR',[VALIDACION_889])),
            SUM(CHARINDEX('ERR',[VALIDACION_890])),
            SUM(CHARINDEX('ERR',[VALIDACION_891])),
            SUM(CHARINDEX('ERR',[VALIDACION_892])),
            SUM(CHARINDEX('ERR',[VALIDACION_893])),
            SUM(CHARINDEX('ERR',[VALIDACION_894])),
            SUM(CHARINDEX('ERR',[VALIDACION_895])),
            SUM(CHARINDEX('ERR',[VALIDACION_896])),
            SUM(CHARINDEX('ERR',[VALIDACION_897])),
            SUM(CHARINDEX('ERR',[VALIDACION_898])),
            SUM(CHARINDEX('ERR',[VALIDACION_899])),
            SUM(CHARINDEX('ERR',[VALIDACION_900]))
            


		FROM IFRS9_R10A_1012_TSSALDOS_RESULT_9 
END

BEGIN
	EXEC SP_IFRS9_R10A_1012_TSSALDOS_VIEW_9
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


