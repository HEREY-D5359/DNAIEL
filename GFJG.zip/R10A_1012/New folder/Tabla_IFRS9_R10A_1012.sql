SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Reclasificaciones. Reclasificaciones en el estado de resultado integral */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: JULIO 2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/



CREATE TABLE [dbo].[IFRS9_R10A_1012](
	[c04_concepto] [varchar](255) NULL,
	[c05_tipo_saldo] [varchar](255) NULL,
	[c06_tipo_movimiento] [varchar](255) NULL,
	[c07_dato] [varchar](255) NULL,
	[ID] [int] IDENTITY(1,1) NOT NULL
) ON [PRIMARY]
GO


