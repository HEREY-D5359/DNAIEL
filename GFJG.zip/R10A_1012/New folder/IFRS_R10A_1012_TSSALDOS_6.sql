﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Reclasificaciones. Reclasificaciones en el estado de resultado integral */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: JULIO 2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: NA*/
/*TIPO SALDO: SALDOS*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R10A_1012_TSSALDOS_COMP_6]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R10A_1012_TSSALDOS_RESULT_6')
BEGIN
DROP TABLE IFRS9_R10A_1012_TSSALDOS_RESULT_6
END 

BEGIN
SELECT DISTINCT

	/*ID*/

	CONVERT(VARCHAR,ID)  AS ID,   
	/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600807508035')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600807508035')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600807508035) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600807508035) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_501,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600807508036')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600807508036')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600807508036) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600807508036) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_502,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600814307076')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600814307076')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600814307076) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600814307076) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_503,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600807608037')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600807608037')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600807608037) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600807608037) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_504,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600807608038')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600807608038')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600807608038) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600807608038) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_505,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600807608039')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600807608039')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600807608039) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600807608039) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_506,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600809606144')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600809606144')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600809606144) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600809606144) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_507,

/*Créditos al gobierno federal*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600814407077')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600814407077')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600814407077) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600814407077) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_508,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600814407078')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600814407078')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600814407078) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600814407078) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_509,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600807808040')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600807808040')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600807808040) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600807808040) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_510,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600807808041')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600807808041')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600807808041) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600807808041) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_511,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600807808042')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600807808042')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600807808042) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600807808042) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_512,

/*Fideicomisos públicos de contratación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600807808043')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600807808043')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600807808043) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600807808043) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_513,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600807808044')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600807808044')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600807808044) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600807808044) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_514,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600814407079')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600814407079')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600814407079) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600814407079) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_515,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600807908045')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600807908045')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600807908045) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600807908045) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_516,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600807908046')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600807908046')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600807908046) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600807908046) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_517,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600807908047')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600807908047')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600807908047) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600807908047) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_518,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600807908048')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600807908048')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600807908048) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600807908048) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_519,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600814407080')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600814407080')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600814407080) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600814407080) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_520,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600808008049')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600808008049')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600808008049) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600808008049) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_521,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600808008050')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600808008050')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600808008050) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600808008050) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_522,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600808008051')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600808008051')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600808008051) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600808008051) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_523,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600808008052')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600808008052')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600808008052) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600808008052) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_524,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600804004076')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600804004076')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600804004076) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600804004076) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_525,

/*Créditos de consumo sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600807605097')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600807605097')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600807605097) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600807605097) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_526,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600809706145')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600809706145')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600809706145) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600809706145) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_527,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600809706146')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600809706146')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600809706146) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600809706146) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_528,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600809706147')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600809706147')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600809706147) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600809706147) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_529,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600809706148')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600809706148')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600809706148) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600809706148) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_530,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600809706149')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600809706149')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600809706149) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600809706149) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_531,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600809706150')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600809706150')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600809706150) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600809706150) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_532,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600809706151')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600809706151')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600809706151) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600809706151) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_533,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600809706152')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600809706152')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600809706152) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600809706152) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_534,

/*Créditos de consumo restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600807605098')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600807605098')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600807605098) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600807605098) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_535,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600809806153')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600809806153')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600809806153) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600809806153) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_536,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600809806154')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600809806154')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600809806154) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600809806154) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_537,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600809806155')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600809806155')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600809806155) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600809806155) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_538,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600809806156')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600809806156')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600809806156) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600809806156) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_539,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600809806157')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600809806157')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600809806157) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600809806157) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_540,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600809806158')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600809806158')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600809806158) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600809806158) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_541,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600809806159')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600809806159')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600809806159) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600809806159) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_542,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600809806160')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600809806160')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600809806160) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600809806160) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_543,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600804004077')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600804004077')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600804004077) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600804004077) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_544,

/*Créditos a la vivienda sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600807705099')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600807705099')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600807705099) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600807705099) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_545,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600809906161')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600809906161')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600809906161) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600809906161) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_546,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600809906162')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600809906162')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600809906162) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600809906162) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_547,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600809906163')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600809906163')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600809906163) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600809906163) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_548,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600816307081')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600816307081')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600816307081) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600816307081) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_549,

/*Cartera en prórroga*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600816307082')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600816307082')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600816307082) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600816307082) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_550,

/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600816307083')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600816307083')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600816307083) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600816307083) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_551,

/*Remodelación o mejoramiento con garantía otorgada por la banca de desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600809906164')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600809906164')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600809906164) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600809906164) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_552,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600809906165')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600809906165')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600809906165) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600809906165) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_553,

/*Créditos a la vivienda restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600807705100')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600807705100')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600807705100) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600807705100) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_554,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600810006166')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600810006166')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600810006166) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600810006166) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_555,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600810006167')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600810006167')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600810006167) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600810006167) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_556,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600810006168')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600810006168')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600810006168) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600810006168) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_557,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600816807084')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600816807084')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600816807084) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600816807084) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_558,

/*Cartera en prórroga*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600816807085')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600816807085')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600816807085) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600816807085) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_559,

/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600816807086')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600816807086')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600816807086) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600816807086) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_560,

/*Remodelación o mejoramiento con garantía otorgada por la banca de desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600810006169')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600810006169')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600810006169) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600810006169) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_561,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600810006170')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600810006170')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600810006170) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600810006170) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_562,

/*Cartera con riesgo de crédito etapa 2*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600803303041')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600803303041')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600803303041) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600803303041) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_563,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600804104079')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600804104079')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600804104079) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600804104079) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_564,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600807905101')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600807905101')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600807905101) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600807905101) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_565,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600810106171')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600810106171')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600810106171) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600810106171) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_566,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600817107087')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600817107087')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600817107087) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600817107087) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_567,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600817107088')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600817107088')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600817107088) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600817107088) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_568,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600810106172')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600810106172')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600810106172) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600810106172) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_569,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600817207089')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600817207089')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600817207089) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600817207089) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_570,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600817207090')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600817207090')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600817207090) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600817207090) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_571,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600817207091')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600817207091')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600817207091) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600817207091) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_572,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600810106173')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600810106173')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600810106173) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600810106173) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_573,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600817307092')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600817307092')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600817307092) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600817307092) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_574,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600817307093')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600817307093')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600817307093) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600817307093) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_575,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600810106174')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600810106174')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600810106174) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600810106174) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_576,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600810106175')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600810106175')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600810106175) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600810106175) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_577,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600810106176')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600810106176')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600810106176) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600810106176) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_578,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600810106177')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600810106177')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600810106177) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600810106177) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_579,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600810106178')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600810106178')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600810106178) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600810106178) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_580,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600807905102')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600807905102')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600807905102) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600807905102) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_581,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600810206179')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600810206179')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600810206179) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600810206179) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_582,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600817907094')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600817907094')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600817907094) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600817907094) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_583,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600817907095')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600817907095')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600817907095) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600817907095) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_584,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600817907096')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600817907096')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600817907096) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600817907096) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_585,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600810206180')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600810206180')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600810206180) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600810206180) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_586,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600818007097')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600818007097')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600818007097) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600818007097) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_587,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600818007098')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600818007098')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600818007098) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600818007098) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_588,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600818007099')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600818007099')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600818007099) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600818007099) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_589,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600807905103')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600807905103')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600807905103) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600807905103) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_590,

/*Créditos al gobierno federal*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600810306181')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600810306181')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600810306181) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600810306181) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_591,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600810306182')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600810306182')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600810306182) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600810306182) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_592,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600818207100')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600818207100')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600818207100) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600818207100) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_593,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600818207101')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600818207101')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600818207101) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600818207101) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_594,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600818207102')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600818207102')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600818207102) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600818207102) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_595,

/*Fideicomisos públicos de contratación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600818207103')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600818207103')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600818207103) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600818207103) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_596,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600818207104')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600818207104')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600818207104) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600818207104) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_597,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600810306183')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600810306183')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600810306183) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600810306183) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_598,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600818307105')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600818307105')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600818307105) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600818307105) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_599,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600818307106')   
AND c05_tipo_saldo IN ('130')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600818307106')
AND c05_tipo_saldo IN ('62','140','141')     
AND c06_tipo_movimiento IN ('0','5','6')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (600818307106) con Movimiento (0) y Tipo de Saldo (130) sea igual a la suma del Concepto (600818307106) con Movimiento (0, 5 y 6) y Tipo de Saldo (62, 140 y 141) ')    
AS VALIDACION_600
	
INTO IFRS9_R10A_1012_TSSALDOS_RESULT_6
FROM IFRS9_R10A_1012

END

BEGIN
	INSERT INTO 
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_X01])),
            SUM(CHARINDEX('ERR',[VALIDACION_X02])),
            SUM(CHARINDEX('ERR',[VALIDACION_X03])),
            SUM(CHARINDEX('ERR',[VALIDACION_X04])),
            SUM(CHARINDEX('ERR',[VALIDACION_X05])),
            SUM(CHARINDEX('ERR',[VALIDACION_X06])),
            SUM(CHARINDEX('ERR',[VALIDACION_X07])),
            SUM(CHARINDEX('ERR',[VALIDACION_X08])),
            SUM(CHARINDEX('ERR',[VALIDACION_X09])),
            SUM(CHARINDEX('ERR',[VALIDACION_X10])),
            SUM(CHARINDEX('ERR',[VALIDACION_X11])),
            SUM(CHARINDEX('ERR',[VALIDACION_X12])),
            SUM(CHARINDEX('ERR',[VALIDACION_X13])),
            SUM(CHARINDEX('ERR',[VALIDACION_X14])),
            SUM(CHARINDEX('ERR',[VALIDACION_X15])),
            SUM(CHARINDEX('ERR',[VALIDACION_X16])),
            SUM(CHARINDEX('ERR',[VALIDACION_X17])),
            SUM(CHARINDEX('ERR',[VALIDACION_X18])),
            SUM(CHARINDEX('ERR',[VALIDACION_X19])),
            SUM(CHARINDEX('ERR',[VALIDACION_X20])),
            SUM(CHARINDEX('ERR',[VALIDACION_X21])),
            SUM(CHARINDEX('ERR',[VALIDACION_X22])),
            SUM(CHARINDEX('ERR',[VALIDACION_X23])),
            SUM(CHARINDEX('ERR',[VALIDACION_X24])),
            SUM(CHARINDEX('ERR',[VALIDACION_X25])),
            SUM(CHARINDEX('ERR',[VALIDACION_X26])),
            SUM(CHARINDEX('ERR',[VALIDACION_X27])),
            SUM(CHARINDEX('ERR',[VALIDACION_X28])),
            SUM(CHARINDEX('ERR',[VALIDACION_X29])),
            SUM(CHARINDEX('ERR',[VALIDACION_X30])),
            SUM(CHARINDEX('ERR',[VALIDACION_X31])),
            SUM(CHARINDEX('ERR',[VALIDACION_X32])),
            SUM(CHARINDEX('ERR',[VALIDACION_X33])),
            SUM(CHARINDEX('ERR',[VALIDACION_X34])),
            SUM(CHARINDEX('ERR',[VALIDACION_X35])),
            SUM(CHARINDEX('ERR',[VALIDACION_X36])),
            SUM(CHARINDEX('ERR',[VALIDACION_X37])),
            SUM(CHARINDEX('ERR',[VALIDACION_X38])),
            SUM(CHARINDEX('ERR',[VALIDACION_X39])),
            SUM(CHARINDEX('ERR',[VALIDACION_X40])),
            SUM(CHARINDEX('ERR',[VALIDACION_X41])),
            SUM(CHARINDEX('ERR',[VALIDACION_X42])),
            SUM(CHARINDEX('ERR',[VALIDACION_X43])),
            SUM(CHARINDEX('ERR',[VALIDACION_X44])),
            SUM(CHARINDEX('ERR',[VALIDACION_X45])),
            SUM(CHARINDEX('ERR',[VALIDACION_X46])),
            SUM(CHARINDEX('ERR',[VALIDACION_X47])),
            SUM(CHARINDEX('ERR',[VALIDACION_X48])),
            SUM(CHARINDEX('ERR',[VALIDACION_X49])),
            SUM(CHARINDEX('ERR',[VALIDACION_X50])),
            SUM(CHARINDEX('ERR',[VALIDACION_X51])),
            SUM(CHARINDEX('ERR',[VALIDACION_X52])),
            SUM(CHARINDEX('ERR',[VALIDACION_X53])),
            SUM(CHARINDEX('ERR',[VALIDACION_X54])),
            SUM(CHARINDEX('ERR',[VALIDACION_X55])),
            SUM(CHARINDEX('ERR',[VALIDACION_X56])),
            SUM(CHARINDEX('ERR',[VALIDACION_X57])),
            SUM(CHARINDEX('ERR',[VALIDACION_X58])),
            SUM(CHARINDEX('ERR',[VALIDACION_X59])),
            SUM(CHARINDEX('ERR',[VALIDACION_X60])),
            SUM(CHARINDEX('ERR',[VALIDACION_X61])),
            SUM(CHARINDEX('ERR',[VALIDACION_X62])),
            SUM(CHARINDEX('ERR',[VALIDACION_X63])),
            SUM(CHARINDEX('ERR',[VALIDACION_X64])),
            SUM(CHARINDEX('ERR',[VALIDACION_X65])),
            SUM(CHARINDEX('ERR',[VALIDACION_X66])),
            SUM(CHARINDEX('ERR',[VALIDACION_X67])),
            SUM(CHARINDEX('ERR',[VALIDACION_X68])),
            SUM(CHARINDEX('ERR',[VALIDACION_X69])),
            SUM(CHARINDEX('ERR',[VALIDACION_X70])),
            SUM(CHARINDEX('ERR',[VALIDACION_X71])),
            SUM(CHARINDEX('ERR',[VALIDACION_X72])),
            SUM(CHARINDEX('ERR',[VALIDACION_X73])),
            SUM(CHARINDEX('ERR',[VALIDACION_X74])),
            SUM(CHARINDEX('ERR',[VALIDACION_X75])),
            SUM(CHARINDEX('ERR',[VALIDACION_X76])),
            SUM(CHARINDEX('ERR',[VALIDACION_X77])),
            SUM(CHARINDEX('ERR',[VALIDACION_X78])),
            SUM(CHARINDEX('ERR',[VALIDACION_X79])),
            SUM(CHARINDEX('ERR',[VALIDACION_X80])),
            SUM(CHARINDEX('ERR',[VALIDACION_X81])),
            SUM(CHARINDEX('ERR',[VALIDACION_X82])),
            SUM(CHARINDEX('ERR',[VALIDACION_X83])),
            SUM(CHARINDEX('ERR',[VALIDACION_X84])),
            SUM(CHARINDEX('ERR',[VALIDACION_X85])),
            SUM(CHARINDEX('ERR',[VALIDACION_X86])),
            SUM(CHARINDEX('ERR',[VALIDACION_X87])),
            SUM(CHARINDEX('ERR',[VALIDACION_X88])),
            SUM(CHARINDEX('ERR',[VALIDACION_X89])),
            SUM(CHARINDEX('ERR',[VALIDACION_X90])),
            SUM(CHARINDEX('ERR',[VALIDACION_X91])),
            SUM(CHARINDEX('ERR',[VALIDACION_X92])),
            SUM(CHARINDEX('ERR',[VALIDACION_X93])),
            SUM(CHARINDEX('ERR',[VALIDACION_X94])),
            SUM(CHARINDEX('ERR',[VALIDACION_X95])),
            SUM(CHARINDEX('ERR',[VALIDACION_X96])),
            SUM(CHARINDEX('ERR',[VALIDACION_X97])),
            SUM(CHARINDEX('ERR',[VALIDACION_X98])),
            SUM(CHARINDEX('ERR',[VALIDACION_X99])),
            SUM(CHARINDEX('ERR',[VALIDACION_X00]))
            


		fromx 
END

BEGIN
	EXEC SP_
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


