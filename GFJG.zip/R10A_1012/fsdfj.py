
import sys
from typing import NewType


CADENA = "IFRS_R10A_1012_TS124TM0_1.sql*IFRS_R10A_1012_TS124TM0_1.sql*IFRS_R10A_1012_TS124TM0_1_view.sql*IFRS_R10A_1012_TS124TM0_2.sql*IFRS_R10A_1012_TS124TM0_2_view.sql*IFRS_R10A_1012_TS124TM0_3.sql*IFRS_R10A_1012_TS124TM0_3_view.sql*IFRS_R10A_1012_TS125TM0_1.sql*IFRS_R10A_1012_TS125TM0_1_view.sql*IFRS_R10A_1012_TS125TM0_2.sql*IFRS_R10A_1012_TS125TM0_2_view.sql*IFRS_R10A_1012_TS125TM0_3.sql*IFRS_R10A_1012_TS125TM0_3_view.sql*IFRS_R10A_1012_TS130TM0_1.sql*IFRS_R10A_1012_TS130TM0_1_view.sql*IFRS_R10A_1012_TS130TM0_2.sql*IFRS_R10A_1012_TS130TM0_2_view.sql*IFRS_R10A_1012_TS130TM0_3.sql*IFRS_R10A_1012_TS130TM0_3_view.sql*IFRS_R10A_1012_TS140TM5_1.sql*IFRS_R10A_1012_TS140TM5_1_view.sql*IFRS_R10A_1012_TS140TM5_2.sql*IFRS_R10A_1012_TS140TM5_2_view.sql*IFRS_R10A_1012_TS140TM5_3.sql*IFRS_R10A_1012_TS140TM5_3_view.sql*IFRS_R10A_1012_TS140TM6_1.sql*IFRS_R10A_1012_TS140TM6_1_view.sql*IFRS_R10A_1012_TS140TM6_2.sql*IFRS_R10A_1012_TS140TM6_2_view.sql*IFRS_R10A_1012_TS140TM6_3.sql*IFRS_R10A_1012_TS140TM6_3_view.sql*IFRS_R10A_1012_TS141TM5_1.sql*IFRS_R10A_1012_TS141TM5_1_view.sql*IFRS_R10A_1012_TS141TM5_2.sql*IFRS_R10A_1012_TS141TM5_2_view.sql*IFRS_R10A_1012_TS141TM5_3.sql*IFRS_R10A_1012_TS141TM5_3_view.sql*IFRS_R10A_1012_TS141TM6_1.sql*IFRS_R10A_1012_TS141TM6_1_view.sql*IFRS_R10A_1012_TS141TM6_2.sql*IFRS_R10A_1012_TS141TM6_2_view.sql*IFRS_R10A_1012_TS141TM6_3.sql*IFRS_R10A_1012_TS141TM6_3_view.sql*IFRS_R10A_1012_TS62TM0_1.sql*IFRS_R10A_1012_TS62TM0_1_view.sql*IFRS_R10A_1012_TS62TM0_2.sql*IFRS_R10A_1012_TS62TM0_2_view.sql*IFRS_R10A_1012_TS62TM0_3.sql*IFRS_R10A_1012_TS62TM0_3_view.sql*IFRS_R10A_1012_TSSALDOS_1.sql*IFRS_R10A_1012_TSSALDOS_10.sql*IFRS_R10A_1012_TSSALDOS_10_view.sql*IFRS_R10A_1012_TSSALDOS_11.sql*IFRS_R10A_1012_TSSALDOS_11_view.sql*IFRS_R10A_1012_TSSALDOS_12_view.sql*IFRS_R10A_1012_TSSALDOS_1_view.sql*IFRS_R10A_1012_TSSALDOS_2.sql*IFRS_R10A_1012_TSSALDOS_2_view.sql*IFRS_R10A_1012_TSSALDOS_3.sql*IFRS_R10A_1012_TSSALDOS_3_view.sql*IFRS_R10A_1012_TSSALDOS_4.sql*IFRS_R10A_1012_TSSALDOS_4_view.sql*IFRS_R10A_1012_TSSALDOS_5.sql*IFRS_R10A_1012_TSSALDOS_5_view.sql*IFRS_R10A_1012_TSSALDOS_6.sql*IFRS_R10A_1012_TSSALDOS_6_view.sql*IFRS_R10A_1012_TSSALDOS_7.sql*IFRS_R10A_1012_TSSALDOS_7_view.sql*IFRS_R10A_1012_TSSALDOS_8.sql*IFRS_R10A_1012_TSSALDOS_8_view.sql*IFRS_R10A_1012_TSSALDOS_9.sql"


dato = CADENA.split("*")

for stringn in dato:
    f = open(stringn,'r')
    print(stringn, "  ", len(stringn))
    filedata = f.read()
    f.close()
    
    try:
            if stringn.find("view.sql") > -1:
                op = stringn.replace("_view","")
               
                name= op[len(op)-(op[::-1].index("_")):op.index(".")]
                print(name)
                newdata = filedata.replace("(VALIDACION_x00","(VALIDACION_"+name+"00")
                
                newdata = newdata.replace("(VALIDACION_X","(VALIDACION_"+str(int(name)-1))
                f = open(stringn,'w')
                f.write(newdata)
                f.close()
            else:
                print('false')
                
            if stringn.find("view.sql") == -1:
                print("WWW")
                name= stringn.index(".")
                name= stringn[len(stringn)-(stringn[::-1].index("_")):stringn.index(".")]
                
                newdata = filedata.replace("SUM(CHARINDEX('ERR',[VALIDACION_X00","SUM(CHARINDEX('ERR',[VALIDACION_"+name+"00")
                newdata = newdata.replace("SUM(CHARINDEX('ERR',[VALIDACION_X","SUM(CHARINDEX('ERR',[VALIDACION_"+str(int(name)-1))
                
                newInsert = stringn[stringn.index("I"):stringn.index(".")-1].rstrip()
                
                newInsert1 = newdata[newdata.find("INTO I"):newdata.find("INSERT INTO")]
                newInsert = newInsert1[5:newInsert1.find("FROM")-1].rstrip()
                newdata = newdata.replace("INSERT INTO","INSERT INTO "+newInsert)
                print(newdata.find("fromx"))
                newdata = newdata.replace("EXEC SP_","EXEC SP_"+newInsert.replace("RESULT","VIEW"))
                #print(newdata.replace("EXEC SP_ ","EXECSP_"+newInsert.replace("RESULT","VIEW")))
                newdata = newdata.replace("fromx","FROM "+ newInsert+ "")
                #print(newdata)
                f = open(stringn,'w')
                f.write(newdata)
                f.close()
    except:
            print("error "+stringn)
            f.close()    
        
        