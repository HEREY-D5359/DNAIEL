﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Reclasificaciones. Reclasificaciones en el estado de resultado integral */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: JULIO 2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: NA*/
/*TIPO SALDO: 62*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: 0*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R10A_1012_TS62TM0_COMP_2]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R10A_1012_TS62TM0_RESULT_2')
BEGIN
DROP TABLE IFRS9_R10A_1012_TS62TM0_RESULT_2
END 

BEGIN
SELECT DISTINCT

	/*ID*/

	CONVERT(VARCHAR,ID)  AS ID,   
	/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500201103024')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500202404058','500202404059','500202404060','500202404061','500202404062','500202404063','500202404064','500202404065')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201103024) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500202404058 + 500202404059 + 500202404060 + 500202404061 + 500202404062 + 500202404063 + 500202404064 + 500202404065) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_101,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500201103025')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500202504066','500202504067','500202504068','500202504069','500202504070')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201103025) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500202504066 + 500202504067 + 500202504068 + 500202504069 + 500202504070) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_102,

/*Primas por colocación de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200102013')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500201303026','500201303027')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200102013) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500201303026 + 500201303027) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_103,

/*Utilidad por valorización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200102015')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500201503028','500201503029','500201503030','500201503031','500201503032')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200102015) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500201503028 + 500201503029 + 500201503030 + 500201503031 + 500201503032) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_104,

/*Gastos por intereses*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600400101002')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600400202017','600400202018','600400202019','600400202020','600400202021','600400202022','600400202023','600400202024','600400202025','600400202026','600400202027','600400202028','600400202029')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600400101002) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600400202017 + 600400202018 + 600400202019 + 600400202020 + 600400202021 + 600400202022 + 600400202023 + 600400202024 + 600400202025 + 600400202026 + 600400202027 + 600400202028 + 600400202029) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_105,

/*Intereses, costos de transacción y descuentos a cargo por emisión de instrumentos financieros que califican como pasivo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600400202020')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600402003033','600402003034')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600400202020) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600402003033 + 600402003034) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_106,

/*Obligaciones subordinadas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600402003033')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600403304071','600403304072','600403304073','600403304074')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600402003033) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600403304071 + 600403304072 + 600403304073 + 600403304074) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_107,

/*Pérdida por valorización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600400202026')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600402603035','600402603036','600402603037','600402603038','600402603039')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600400202026) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600402603035 + 600402603036 + 600402603037 + 600402603038 + 600402603039) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_108,

/*Resultado por posición monetaria neto (margen financiero)(1)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500600101003')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500600302030','500600302031','500600302032')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500600101003) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500600302030 + 500600302031 + 500600302032) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_109,

/*MARGEN FINANCIERO*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('330000000001')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600800201004')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (330000000001) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600800201004) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_110,

/*Estimación preventiva para riesgos crediticios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600800201004')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600800402033','600800402034','600800402035','600800402036','600800402037')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600800201004) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600800402033 + 600800402034 + 600800402035 + 600800402036 + 600800402037) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_111,

/*Estimación preventiva para riesgos crediticios derivada de la calificación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600800402033')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600803303040','600803303041','600803303042','600803303043')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600800402033) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600803303040 + 600803303041 + 600803303042 + 600803303043) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_112,

/*Cartera con riesgo de crédito etapa 1*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600803303040')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600804004075','600804004076','600804004077')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600803303040) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600804004075 + 600804004076 + 600804004077) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_113,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600804004075')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600807505095','600807505096')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600804004075) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600807505095 + 600807505096) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_114,

/*Créditos comerciales sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600807505095')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600809506139','600809506140','600809506141')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600807505095) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600809506139 + 600809506140 + 600809506141) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_115,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600809506139')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600813907053','600813907054','600813907055','600813907056','600813907057','600813907058','600813907059','600813907060')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600809506139) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600813907053 + 600813907054 + 600813907055 + 600813907056 + 600813907057 + 600813907058 + 600813907059 + 600813907060) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_116,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600813907053')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600805308001','600805308002')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600813907053) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600805308001 + 600805308002) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_117,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600813907054')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600805408003','600805408004','600805408005')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600813907054) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600805408003 + 600805408004 + 600805408005) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_118,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600813907055')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600805508006','600805508007')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600813907055) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600805508006 + 600805508007) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_119,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600809506140')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600814007061','600814007062')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600809506140) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600814007061 + 600814007062) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_120,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600814007061')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600806108008','600806108009','600806108010')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600814007061) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600806108008 + 600806108009 + 600806108010) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_121,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600814007062')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600806208011','600806208012','600806208013')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600814007062) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600806208011 + 600806208012 + 600806208013) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_122,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600809506141')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600814107063','600814107064','600814107065','600814107066')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600809506141) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600814107063 + 600814107064 + 600814107065 + 600814107066) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_123,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600814107064')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600806408014','600806408015','600806408016','600806408017','600806408018')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600814107064) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600806408014 + 600806408015 + 600806408016 + 600806408017 + 600806408018) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_124,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600814107065')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600806508019','600806508020','600806508021','600806508022')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600814107065) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600806508019 + 600806508020 + 600806508021 + 600806508022) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_125,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600814107066')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600806608023','600806608024','600806608025','600806608026')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600814107066) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600806608023 + 600806608024 + 600806608025 + 600806608026) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_126,

/*Créditos comerciales restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600807505096')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600809606142','600809606143','600809606144')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600807505096) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600809606142 + 600809606143 + 600809606144) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_127,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600809606142')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600814207067','600814207068','600814207069','600814207070','600814207071','600814207072','600814207073','600814207074')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600809606142) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600814207067 + 600814207068 + 600814207069 + 600814207070 + 600814207071 + 600814207072 + 600814207073 + 600814207074) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_128,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600814207067')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600806708027','600806708028')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600814207067) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600806708027 + 600806708028) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_129,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600814207068')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600806808029','600806808030','600806808031')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600814207068) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600806808029 + 600806808030 + 600806808031) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_130,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600814207069')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600806908032','600806908033')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600814207069) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600806908032 + 600806908033) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_131,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600809606143')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600814307075','600814307076')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600809606143) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600814307075 + 600814307076) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_132,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600814307075')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600807508034','600807508035','600807508036')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600814307075) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600807508034 + 600807508035 + 600807508036) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_133,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600814307076')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600807608037','600807608038','600807608039')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600814307076) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600807608037 + 600807608038 + 600807608039) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_134,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600809606144')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600814407077','600814407078','600814407079','600814407080')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600809606144) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600814407077 + 600814407078 + 600814407079 + 600814407080) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_135,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600814407078')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600807808040','600807808041','600807808042','600807808043','600807808044')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600814407078) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600807808040 + 600807808041 + 600807808042 + 600807808043 + 600807808044) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_136,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600814407079')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600807908045','600807908046','600807908047','600807908048')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600814407079) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600807908045 + 600807908046 + 600807908047 + 600807908048) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_137,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600814407080')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600808008049','600808008050','600808008051','600808008052')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600814407080) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600808008049 + 600808008050 + 600808008051 + 600808008052) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_138,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600804004076')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600807605097','600807605098')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600804004076) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600807605097 + 600807605098) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_139,

/*Créditos de consumo sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600807605097')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600809706145','600809706146','600809706147','600809706148','600809706149','600809706150','600809706151','600809706152')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600807605097) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600809706145 + 600809706146 + 600809706147 + 600809706148 + 600809706149 + 600809706150 + 600809706151 + 600809706152) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_140,

/*Créditos de consumo restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600807605098')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600809806153','600809806154','600809806155','600809806156','600809806157','600809806158','600809806159','600809806160')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600807605098) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600809806153 + 600809806154 + 600809806155 + 600809806156 + 600809806157 + 600809806158 + 600809806159 + 600809806160) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_141,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600804004077')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600807705099','600807705100')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600804004077) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600807705099 + 600807705100) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_142,

/*Créditos a la vivienda sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600807705099')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600809906161','600809906162','600809906163','600809906164','600809906165')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600807705099) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600809906161 + 600809906162 + 600809906163 + 600809906164 + 600809906165) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_143,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600809906163')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600816307081','600816307082','600816307083')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600809906163) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600816307081 + 600816307082 + 600816307083) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_144,

/*Créditos a la vivienda restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600807705100')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600810006166','600810006167','600810006168','600810006169','600810006170')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600807705100) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600810006166 + 600810006167 + 600810006168 + 600810006169 + 600810006170) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_145,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600810006168')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600816807084','600816807085','600816807086')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600810006168) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600816807084 + 600816807085 + 600816807086) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_146,

/*Cartera con riesgo de crédito etapa 2*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600803303041')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600804104079','600804104080','600804104081')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600803303041) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600804104079 + 600804104080 + 600804104081) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_147,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600804104079')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600807905101','600807905102','600807905103')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600804104079) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600807905101 + 600807905102 + 600807905103) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_148,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600807905101')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600810106171','600810106172','600810106173','600810106174','600810106175','600810106176','600810106177','600810106178')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600807905101) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600810106171 + 600810106172 + 600810106173 + 600810106174 + 600810106175 + 600810106176 + 600810106177 + 600810106178) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_149,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600810106171')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600817107087','600817107088')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600810106171) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600817107087 + 600817107088) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_150,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600810106172')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600817207089','600817207090','600817207091')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600810106172) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600817207089 + 600817207090 + 600817207091) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_151,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600810106173')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600817307092','600817307093')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600810106173) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600817307092 + 600817307093) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_152,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600807905102')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600810206179','600810206180')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600807905102) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600810206179 + 600810206180) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_153,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600810206179')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600817907094','600817907095','600817907096')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600810206179) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600817907094 + 600817907095 + 600817907096) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_154,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600810206180')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600818007097','600818007098','600818007099')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600810206180) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600818007097 + 600818007098 + 600818007099) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_155,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600807905103')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600810306181','600810306182','600810306183','600810306184')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600807905103) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600810306181 + 600810306182 + 600810306183 + 600810306184) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_156,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600810306182')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600818207100','600818207101','600818207102','600818207103','600818207104')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600810306182) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600818207100 + 600818207101 + 600818207102 + 600818207103 + 600818207104) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_157,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600810306183')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600818307105','600818307106','600818307107','600818307108')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600810306183) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600818307105 + 600818307106 + 600818307107 + 600818307108) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_158,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600810306184')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600818407109','600818407110','600818407111','600818407112')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600810306184) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600818407109 + 600818407110 + 600818407111 + 600818407112) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_159,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600804104080')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600808005104','600808005105','600808005106','600808005107','600808005108','600808005109','600808005110','600808005111')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600804104080) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600808005104 + 600808005105 + 600808005106 + 600808005107 + 600808005108 + 600808005109 + 600808005110 + 600808005111) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_160,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600804104081')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600808105112','600808105113','600808105114','600808105115','600808105116')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600804104081) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600808105112 + 600808105113 + 600808105114 + 600808105115 + 600808105116) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_161,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600808105114')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600811406185','600811406186')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600808105114) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600811406185 + 600811406186) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_162,

/*Cartera con riesgo de crédito etapa 3*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600803303042')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600804204082','600804204083','600804204084')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600803303042) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600804204082 + 600804204083 + 600804204084) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_163,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600804204082')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600808205117','600808205118','600808205119')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600804204082) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600808205117 + 600808205118 + 600808205119) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_164,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600808205117')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600811706187','600811706188','600811706189','600811706190','600811706191','600811706192','600811706193','600811706194')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600808205117) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600811706187 + 600811706188 + 600811706189 + 600811706190 + 600811706191 + 600811706192 + 600811706193 + 600811706194) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_165,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600811706187')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600818707113','600818707114')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600811706187) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600818707113 + 600818707114) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_166,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600811706188')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600818807115','600818807116','600818807117')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600811706188) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600818807115 + 600818807116 + 600818807117) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_167,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600811706189')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600818907118','600818907119')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600811706189) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600818907118 + 600818907119) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_168,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600808205118')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600811806195','600811806196')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600808205118) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600811806195 + 600811806196) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_169,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600811806195')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600819507120','600819507121','600819507122')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600811806195) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600819507120 + 600819507121 + 600819507122) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_170,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600811806196')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600819607123','600819607124','600819607125')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600811806196) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600819607123 + 600819607124 + 600819607125) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_171,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600808205119')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600811906197','600811906198','600811906199','600811906200')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600808205119) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600811906197 + 600811906198 + 600811906199 + 600811906200) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_172,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600811906198')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600819807126','600819807127','600819807128','600819807129','600819807130')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600811906198) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600819807126 + 600819807127 + 600819807128 + 600819807129 + 600819807130) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_173,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600811906199')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600819907131','600819907132','600819907133','600819907134')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600811906199) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600819907131 + 600819907132 + 600819907133 + 600819907134) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_174,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600811906200')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600820007135','600820007136','600820007137','600820007138')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600811906200) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600820007135 + 600820007136 + 600820007137 + 600820007138) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_175,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600804204083')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600808305120','600808305121','600808305122','600808305123','600808305124','600808305125','600808305126','600808305127')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600804204083) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600808305120 + 600808305121 + 600808305122 + 600808305123 + 600808305124 + 600808305125 + 600808305126 + 600808305127) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_176,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600804204084')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600808405128','600808405129','600808405130','600808405131','600808405132')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600804204084) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600808405128 + 600808405129 + 600808405130 + 600808405131 + 600808405132) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_177,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600808405130')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600813006201','600813006202')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600808405130) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600813006201 + 600813006202) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_178,

/*Recuperación de cartera de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600800402034')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600803403044','600803403045','600803403046')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600800402034) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600803403044 + 600803403045 + 600803403046) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_179,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600803403044')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600804404085','600804404086','600804404087')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600803403044) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600804404085 + 600804404086 + 600804404087) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_180,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600804404085')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600808505133','600808505134','600808505135','600808505136','600808505137','600808505138','600808505139','600808505140')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600804404085) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600808505133 + 600808505134 + 600808505135 + 600808505136 + 600808505137 + 600808505138 + 600808505139 + 600808505140) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_181,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600808505133')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600813306203','600813306204')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600808505133) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600813306203 + 600813306204) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_182,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600808505134')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600813406205','600813406206','600813406207')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600808505134) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600813406205 + 600813406206 + 600813406207) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_183,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600808505135')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600813506208','600813506209')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600808505135) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600813506208 + 600813506209) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_184,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600804404086')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600808605141','600808605142')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600804404086) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600808605141 + 600808605142) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_185,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600808605141')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600814106210','600814106211','600814106212')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600808605141) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600814106210 + 600814106211 + 600814106212) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_186,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600808605142')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600814206213','600814206214','600814206215')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600808605142) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600814206213 + 600814206214 + 600814206215) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_187,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600804404087')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600808705143','600808705144','600808705145','600808705146')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600804404087) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600808705143 + 600808705144 + 600808705145 + 600808705146) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_188,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600808705144')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600814406216','600814406217','600814406218','600814406219','600814406220')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600808705144) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600814406216 + 600814406217 + 600814406218 + 600814406219 + 600814406220) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_189,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600808705145')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600814506221','600814506222','600814506223','600814506224')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600808705145) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600814506221 + 600814506222 + 600814506223 + 600814506224) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_190,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600808705146')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600814606225','600814606226','600814606227','600814606228')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600808705146) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600814606225 + 600814606226 + 600814606227 + 600814606228) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_191,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600803403045')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600804504088','600804504089','600804504090','600804504091','600804504092','600804504093','600804504094','600804504095')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600803403045) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600804504088 + 600804504089 + 600804504090 + 600804504091 + 600804504092 + 600804504093 + 600804504094 + 600804504095) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_192,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600803403046')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600804604096','600804604097','600804604098','600804604099','600804604100')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600803403046) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600804604096 + 600804604097 + 600804604098 + 600804604099 + 600804604100) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_193,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600804604098')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600809805147','600809805148')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600804604098) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600809805147 + 600809805148) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_194,

/*Estimación preventiva para riesgos crediticios adicional*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('600800402035')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('600803503047','600803503048','600803503049','600803503050','600803503051','600803503052')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600800402035) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (600803503047 + 600803503048 + 600803503049 + 600803503050 + 600803503051 + 600803503052) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_195,

/*MARGEN FINANCIERO AJUSTADO POR RIESGOS CREDITICIOS*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('330000000002')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501000301005','601200301006','501400301007','501600301008','602000301010')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (330000000002) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (501000301005 + 601200301006 + 501400301007 + 501600301008 + 602000301010) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_196,

/*Comisiones y tarifas cobradas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501000301005')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501000502038','501000502039','501000502040','501000502041','501000502042','501000502043','501000502044','501000502045','501000502046','501000502047','501000502048','501000502049','501000502050','501000502051','501000502052','501000502053','501000502054','501000502055','501000502056')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501000301005) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (501000502038 + 501000502039 + 501000502040 + 501000502041 + 501000502042 + 501000502043 + 501000502044 + 501000502045 + 501000502046 + 501000502047 + 501000502048 + 501000502049 + 501000502050 + 501000502051 + 501000502052 + 501000502053 + 501000502054 + 501000502055 + 501000502056) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_197,

/*Operaciones de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501000502038')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501003803053','501003803054','501003803055')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501000502038) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (501003803053 + 501003803054 + 501003803055) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_198,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501003803053')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501005304101','501005304102')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501003803053) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (501005304101 + 501005304102) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_199,

/*Créditos comerciales sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('501005304101')   
AND c05_tipo_saldo IN ('62')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('501010105149','501010105150','501010105151')
AND c05_tipo_saldo IN ('62')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501005304101) con Tipo de Saldo 62, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (501010105149 + 501010105150 + 501010105151) con Tipo de Saldo 62, Tipo de Movimiento 0.')    
AS VALIDACION_200
	
INTO IFRS9_R10A_1012_TS62TM0_RESULT_2
FROM IFRS9_R10A_1012

END

BEGIN
	INSERT INTO IFRS9_R10A_1012_TS62TM0_RESULT_2 
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_101])),
            SUM(CHARINDEX('ERR',[VALIDACION_102])),
            SUM(CHARINDEX('ERR',[VALIDACION_103])),
            SUM(CHARINDEX('ERR',[VALIDACION_104])),
            SUM(CHARINDEX('ERR',[VALIDACION_105])),
            SUM(CHARINDEX('ERR',[VALIDACION_106])),
            SUM(CHARINDEX('ERR',[VALIDACION_107])),
            SUM(CHARINDEX('ERR',[VALIDACION_108])),
            SUM(CHARINDEX('ERR',[VALIDACION_109])),
            SUM(CHARINDEX('ERR',[VALIDACION_110])),
            SUM(CHARINDEX('ERR',[VALIDACION_111])),
            SUM(CHARINDEX('ERR',[VALIDACION_112])),
            SUM(CHARINDEX('ERR',[VALIDACION_113])),
            SUM(CHARINDEX('ERR',[VALIDACION_114])),
            SUM(CHARINDEX('ERR',[VALIDACION_115])),
            SUM(CHARINDEX('ERR',[VALIDACION_116])),
            SUM(CHARINDEX('ERR',[VALIDACION_117])),
            SUM(CHARINDEX('ERR',[VALIDACION_118])),
            SUM(CHARINDEX('ERR',[VALIDACION_119])),
            SUM(CHARINDEX('ERR',[VALIDACION_120])),
            SUM(CHARINDEX('ERR',[VALIDACION_121])),
            SUM(CHARINDEX('ERR',[VALIDACION_122])),
            SUM(CHARINDEX('ERR',[VALIDACION_123])),
            SUM(CHARINDEX('ERR',[VALIDACION_124])),
            SUM(CHARINDEX('ERR',[VALIDACION_125])),
            SUM(CHARINDEX('ERR',[VALIDACION_126])),
            SUM(CHARINDEX('ERR',[VALIDACION_127])),
            SUM(CHARINDEX('ERR',[VALIDACION_128])),
            SUM(CHARINDEX('ERR',[VALIDACION_129])),
            SUM(CHARINDEX('ERR',[VALIDACION_130])),
            SUM(CHARINDEX('ERR',[VALIDACION_131])),
            SUM(CHARINDEX('ERR',[VALIDACION_132])),
            SUM(CHARINDEX('ERR',[VALIDACION_133])),
            SUM(CHARINDEX('ERR',[VALIDACION_134])),
            SUM(CHARINDEX('ERR',[VALIDACION_135])),
            SUM(CHARINDEX('ERR',[VALIDACION_136])),
            SUM(CHARINDEX('ERR',[VALIDACION_137])),
            SUM(CHARINDEX('ERR',[VALIDACION_138])),
            SUM(CHARINDEX('ERR',[VALIDACION_139])),
            SUM(CHARINDEX('ERR',[VALIDACION_140])),
            SUM(CHARINDEX('ERR',[VALIDACION_141])),
            SUM(CHARINDEX('ERR',[VALIDACION_142])),
            SUM(CHARINDEX('ERR',[VALIDACION_143])),
            SUM(CHARINDEX('ERR',[VALIDACION_144])),
            SUM(CHARINDEX('ERR',[VALIDACION_145])),
            SUM(CHARINDEX('ERR',[VALIDACION_146])),
            SUM(CHARINDEX('ERR',[VALIDACION_147])),
            SUM(CHARINDEX('ERR',[VALIDACION_148])),
            SUM(CHARINDEX('ERR',[VALIDACION_149])),
            SUM(CHARINDEX('ERR',[VALIDACION_150])),
            SUM(CHARINDEX('ERR',[VALIDACION_151])),
            SUM(CHARINDEX('ERR',[VALIDACION_152])),
            SUM(CHARINDEX('ERR',[VALIDACION_153])),
            SUM(CHARINDEX('ERR',[VALIDACION_154])),
            SUM(CHARINDEX('ERR',[VALIDACION_155])),
            SUM(CHARINDEX('ERR',[VALIDACION_156])),
            SUM(CHARINDEX('ERR',[VALIDACION_157])),
            SUM(CHARINDEX('ERR',[VALIDACION_158])),
            SUM(CHARINDEX('ERR',[VALIDACION_159])),
            SUM(CHARINDEX('ERR',[VALIDACION_160])),
            SUM(CHARINDEX('ERR',[VALIDACION_161])),
            SUM(CHARINDEX('ERR',[VALIDACION_162])),
            SUM(CHARINDEX('ERR',[VALIDACION_163])),
            SUM(CHARINDEX('ERR',[VALIDACION_164])),
            SUM(CHARINDEX('ERR',[VALIDACION_165])),
            SUM(CHARINDEX('ERR',[VALIDACION_166])),
            SUM(CHARINDEX('ERR',[VALIDACION_167])),
            SUM(CHARINDEX('ERR',[VALIDACION_168])),
            SUM(CHARINDEX('ERR',[VALIDACION_169])),
            SUM(CHARINDEX('ERR',[VALIDACION_170])),
            SUM(CHARINDEX('ERR',[VALIDACION_171])),
            SUM(CHARINDEX('ERR',[VALIDACION_172])),
            SUM(CHARINDEX('ERR',[VALIDACION_173])),
            SUM(CHARINDEX('ERR',[VALIDACION_174])),
            SUM(CHARINDEX('ERR',[VALIDACION_175])),
            SUM(CHARINDEX('ERR',[VALIDACION_176])),
            SUM(CHARINDEX('ERR',[VALIDACION_177])),
            SUM(CHARINDEX('ERR',[VALIDACION_178])),
            SUM(CHARINDEX('ERR',[VALIDACION_179])),
            SUM(CHARINDEX('ERR',[VALIDACION_180])),
            SUM(CHARINDEX('ERR',[VALIDACION_181])),
            SUM(CHARINDEX('ERR',[VALIDACION_182])),
            SUM(CHARINDEX('ERR',[VALIDACION_183])),
            SUM(CHARINDEX('ERR',[VALIDACION_184])),
            SUM(CHARINDEX('ERR',[VALIDACION_185])),
            SUM(CHARINDEX('ERR',[VALIDACION_186])),
            SUM(CHARINDEX('ERR',[VALIDACION_187])),
            SUM(CHARINDEX('ERR',[VALIDACION_188])),
            SUM(CHARINDEX('ERR',[VALIDACION_189])),
            SUM(CHARINDEX('ERR',[VALIDACION_190])),
            SUM(CHARINDEX('ERR',[VALIDACION_191])),
            SUM(CHARINDEX('ERR',[VALIDACION_192])),
            SUM(CHARINDEX('ERR',[VALIDACION_193])),
            SUM(CHARINDEX('ERR',[VALIDACION_194])),
            SUM(CHARINDEX('ERR',[VALIDACION_195])),
            SUM(CHARINDEX('ERR',[VALIDACION_196])),
            SUM(CHARINDEX('ERR',[VALIDACION_197])),
            SUM(CHARINDEX('ERR',[VALIDACION_198])),
            SUM(CHARINDEX('ERR',[VALIDACION_199])),
            SUM(CHARINDEX('ERR',[VALIDACION_200]))
            


		FROM IFRS9_R10A_1012_TS62TM0_RESULT_2 
END

BEGIN
	EXEC SP_IFRS9_R10A_1012_TS62TM0_VIEW_2
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


