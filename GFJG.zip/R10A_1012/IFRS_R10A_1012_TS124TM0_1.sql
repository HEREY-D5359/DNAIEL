﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Reclasificaciones. Reclasificaciones en el estado de resultado integral */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: JULIO 2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: NA*/
/*TIPO SALDO: 124*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: 0*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R10A_1012_TS124TM0_COMP_1]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R10A_1012_TS124TM0_RESULT_1')
BEGIN
DROP TABLE IFRS9_R10A_1012_TS124TM0_RESULT_1
END 

BEGIN
SELECT DISTINCT
      /*ID*/
      CONVERT(VARCHAR,ID) AS ID,
	/*Ingresos por intereses*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200101001')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500200102001','500200102002','500200102003','500200102004','500200102006','500200102007','500200102008','500200102009','500200102010','500200102011','500200102012','500200102013','500200102014','500200102015','500200102016')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200101001) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500200102001 + 500200102002 + 500200102003 + 500200102004 + 500200102006 + 500200102007 + 500200102008 + 500200102009 + 500200102010 + 500200102011 + 500200102012 + 500200102013 + 500200102014 + 500200102015 + 500200102016) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_1,

/*Intereses de efectivo y equivalentes de efectivo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200102001')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500200103001','500200103002','500200103003')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200102001) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500200103001 + 500200103002 + 500200103003) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_2,

/*Intereses y rendimientos a favor provenientes de cuentas de margen*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200102002')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500200203004','500200203005','500200203006')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200102002) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500200203004 + 500200203005 + 500200203006) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_3,

/*Intereses y rendimientos a favor provenientes de inversiones en instrumentos financieros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200102003')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500200303007','500200303008','500200303009')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200102003) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500200303007 + 500200303008 + 500200303009) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_4,

/*Intereses y rendimientos a favor en operaciones de reporto*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200102004')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500200102005')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200102004) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500200102005) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_5,

/*Intereses de cartera de crédito con riesgo de crédito etapa 1*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200102006')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500200603010','500200603011','500200603012')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200102006) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500200603010 + 500200603011 + 500200603012) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_6,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200603010')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500201004001','500201004002')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200603010) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500201004001 + 500201004002) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_7,

/*Créditos comerciales sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500201004001')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500200105001','500200105002','500200105003')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201004001) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500200105001 + 500200105002 + 500200105003) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_8,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200105001')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500200106001','500200106002','500200106003','500200106004','500200106005','500200106006','500200106007','500200106008')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200105001) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500200106001 + 500200106002 + 500200106003 + 500200106004 + 500200106005 + 500200106006 + 500200106007 + 500200106008) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_9,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200106001')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500200107001','500200107002')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200106001) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500200107001 + 500200107002) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_10,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200106002')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500200207003','500200207004','500200207005')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200106002) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500200207003 + 500200207004 + 500200207005) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_11,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200106003')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500200307006','500200307007')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200106003) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500200307006 + 500200307007) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_12,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200105002')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500200206009','500200206010')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200105002) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500200206009 + 500200206010) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_13,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200206009')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500200907008','500200907009','500200907010')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200206009) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500200907008 + 500200907009 + 500200907010) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_14,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200206010')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500201007011','500201007012','500201007013')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200206010) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500201007011 + 500201007012 + 500201007013) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_15,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200105003')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500200306011','500200306012','500200306013','500200306014')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200105003) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500200306011 + 500200306012 + 500200306013 + 500200306014) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_16,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200306012')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500201207014','500201207015','500201207016','500201207017','500201207018')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200306012) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500201207014 + 500201207015 + 500201207016 + 500201207017 + 500201207018) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_17,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200306013')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500201307019','500201307020','500201307021','500201307022')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200306013) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500201307019 + 500201307020 + 500201307021 + 500201307022) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_18,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200306014')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500201407023','500201407024','500201407025','500201407026')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200306014) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500201407023 + 500201407024 + 500201407025 + 500201407026) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_19,

/*Créditos comerciales restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500201004002')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500200205004','500200205005','500200205006')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201004002) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500200205004 + 500200205005 + 500200205006) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_20,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200205004')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500200406015','500200406016','500200406017','500200406018','500200406019','500200406020','500200406021','500200406022')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200205004) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500200406015 + 500200406016 + 500200406017 + 500200406018 + 500200406019 + 500200406020 + 500200406021 + 500200406022) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_21,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200406015')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500201507027','500201507028')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200406015) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500201507027 + 500201507028) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_22,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200406016')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500201607029','500201607030','500201607031')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200406016) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500201607029 + 500201607030 + 500201607031) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_23,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200406017')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500201707032','500201707033')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200406017) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500201707032 + 500201707033) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_24,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200205005')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500200506023','500200506024')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200205005) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500200506023 + 500200506024) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_25,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200506023')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500202307034','500202307035','500202307036')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200506023) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500202307034 + 500202307035 + 500202307036) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_26,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200506024')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500202407037','500202407038','500202407039')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200506024) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500202407037 + 500202407038 + 500202407039) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_27,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200205006')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500200606025','500200606026','500200606027','500200606028')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200205006) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500200606025 + 500200606026 + 500200606027 + 500200606028) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_28,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200606026')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500202607040','500202607041','500202607042','500202607043','500202607044')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200606026) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500202607040 + 500202607041 + 500202607042 + 500202607043 + 500202607044) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_29,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200606027')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500202707045','500202707046','500202707047','500202707048')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200606027) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500202707045 + 500202707046 + 500202707047 + 500202707048) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_30,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200606028')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500202807049','500202807050','500202807051','500202807052')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200606028) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500202807049 + 500202807050 + 500202807051 + 500202807052) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_31,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200603011')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500201104003','500201104004')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200603011) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500201104003 + 500201104004) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_32,

/*Créditos de consumo sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500201104003')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500200305007','500200305008','500200305009','500200305010','500200305011','500200305012','500200305013','500200305014')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201104003) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500200305007 + 500200305008 + 500200305009 + 500200305010 + 500200305011 + 500200305012 + 500200305013 + 500200305014) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_33,

/*Créditos de consumo restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500201104004')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500200405015','500200405016','500200405017','500200405018','500200405019','500200405020','500200405021','500200405022')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201104004) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500200405015 + 500200405016 + 500200405017 + 500200405018 + 500200405019 + 500200405020 + 500200405021 + 500200405022) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_34,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200603012')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500201204005','500201204006')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200603012) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500201204005 + 500201204006) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_35,

/*Créditos a la vivienda sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500201204005')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500200505023','500200505024','500200505025','500200505026','500200505027')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201204005) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500200505023 + 500200505024 + 500200505025 + 500200505026 + 500200505027) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_36,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200505025')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500202506029','500202506030','500202506031')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200505025) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500202506029 + 500202506030 + 500202506031) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_37,

/*Créditos a la vivienda restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500201204006')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500200605028','500200605029','500200605030','500200605031','500200605032')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201204006) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500200605028 + 500200605029 + 500200605030 + 500200605031 + 500200605032) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_38,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200605030')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500203006032','500203006033','500203006034')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200605030) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500203006032 + 500203006033 + 500203006034) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_39,

/*Intereses de cartera de crédito con riesgo de crédito etapa 2*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200102007')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500200703014','500200703015','500200703016')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200102007) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500200703014 + 500200703015 + 500200703016) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_40,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200703014')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500201404007','500201404008','500201404009')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200703014) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500201404007 + 500201404008 + 500201404009) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_41,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500201404007')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500200705033','500200705034','500200705035','500200705036','500200705037','500200705038','500200705039','500200705040')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201404007) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500200705033 + 500200705034 + 500200705035 + 500200705036 + 500200705037 + 500200705038 + 500200705039 + 500200705040) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_42,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200705033')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500203306035','500203306036')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200705033) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500203306035 + 500203306036) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_43,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200705034')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500203406037','500203406038','500203406039')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200705034) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500203406037 + 500203406038 + 500203406039) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_44,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200705035')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500203506040','500203506041')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200705035) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500203506040 + 500203506041) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_45,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500201404008')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500200805041','500200805042')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201404008) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500200805041 + 500200805042) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_46,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200805041')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500204106042','500204106043','500204106044')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200805041) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500204106042 + 500204106043 + 500204106044) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_47,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200805042')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500204206045','500204206046','500204206047')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200805042) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500204206045 + 500204206046 + 500204206047) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_48,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500201404009')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500200905043','500200905044','500200905045','500200905046')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201404009) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500200905043 + 500200905044 + 500200905045 + 500200905046) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_49,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200905044')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500204406048','500204406049','500204406050','500204406051','500204406052')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200905044) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500204406048 + 500204406049 + 500204406050 + 500204406051 + 500204406052) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_50,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200905045')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500204506053','500204506054','500204506055','500204506056')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200905045) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500204506053 + 500204506054 + 500204506055 + 500204506056) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_51,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200905046')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500204606057','500204606058','500204606059','500204606060')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200905046) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500204606057 + 500204606058 + 500204606059 + 500204606060) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_52,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200703015')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500201504010','500201504011','500201504012','500201504013','500201504014','500201504015','500201504016','500201504017')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200703015) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500201504010 + 500201504011 + 500201504012 + 500201504013 + 500201504014 + 500201504015 + 500201504016 + 500201504017) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_53,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200703016')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500201604018','500201604019','500201604020','500201604021','500201604022')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200703016) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500201604018 + 500201604019 + 500201604020 + 500201604021 + 500201604022) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_54,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500201604020')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500202005047','500202005048')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201604020) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500202005047 + 500202005048) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_55,

/*Intereses de cartera de crédito con riesgo de crédito etapa 3*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200102008')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500200803017','500200803018','500200803019')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200102008) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500200803017 + 500200803018 + 500200803019) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_56,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200803017')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500201704023','500201704024','500201704025')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200803017) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500201704023 + 500201704024 + 500201704025) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_57,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500201704023')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500202305049','500202305050','500202305051','500202305052','500202305053','500202305054','500202305055','500202305056')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201704023) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500202305049 + 500202305050 + 500202305051 + 500202305052 + 500202305053 + 500202305054 + 500202305055 + 500202305056) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_58,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500202305049')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500204906061','500204906062')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500202305049) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500204906061 + 500204906062) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_59,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500202305050')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500205006063','500205006064','500205006065')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500202305050) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500205006063 + 500205006064 + 500205006065) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_60,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500202305051')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500205106066','500205106067')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500202305051) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500205106066 + 500205106067) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_61,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500201704024')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500202405057','500202405058')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201704024) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500202405057 + 500202405058) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_62,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500202405057')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500205706068','500205706069','500205706070')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500202405057) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500205706068 + 500205706069 + 500205706070) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_63,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500202405058')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500205806071','500205806072','500205806073')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500202405058) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500205806071 + 500205806072 + 500205806073) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_64,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500201704025')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500202505059','500202505060','500202505061','500202505062')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201704025) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500202505059 + 500202505060 + 500202505061 + 500202505062) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_65,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500202505060')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500206006074','500206006075','500206006076','500206006077','500206006078')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500202505060) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500206006074 + 500206006075 + 500206006076 + 500206006077 + 500206006078) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_66,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500202505061')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500206106079','500206106080','500206106081','500206106082')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500202505061) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500206106079 + 500206106080 + 500206106081 + 500206106082) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_67,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500202505062')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500206206083','500206206084','500206206085','500206206086')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500202505062) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500206206083 + 500206206084 + 500206206085 + 500206206086) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_68,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200803018')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500201804026','500201804027','500201804028','500201804029','500201804030','500201804031','500201804032','500201804033')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200803018) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500201804026 + 500201804027 + 500201804028 + 500201804029 + 500201804030 + 500201804031 + 500201804032 + 500201804033) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_69,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200803019')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500201904034','500201904035','500201904036','500201904037','500201904038')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200803019) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500201904034 + 500201904035 + 500201904036 + 500201904037 + 500201904038) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_70,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500201904036')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500203605063','500203605064')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201904036) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500203605063 + 500203605064) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_71,

/*Ingresos por cartera de crédito valuada a valor razonable*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200102009')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500200903020','500200903021','500200903022')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200102009) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500200903020 + 500200903021 + 500200903022) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_72,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200903020')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500202004039','500202004040','500202004041')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200903020) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500202004039 + 500202004040 + 500202004041) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_73,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500202004039')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500203905065','500203905066','500203905067','500203905068','500203905069','500203905070','500203905071','500203905072')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500202004039) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500203905065 + 500203905066 + 500203905067 + 500203905068 + 500203905069 + 500203905070 + 500203905071 + 500203905072) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_74,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500203905065')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500206506087','500206506088')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500203905065) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500206506087 + 500206506088) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_75,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500203905066')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500206606089','500206606090','500206606091')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500203905066) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500206606089 + 500206606090 + 500206606091) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_76,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500203905067')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500206706092','500206706093')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500203905067) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500206706092 + 500206706093) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_77,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500202004040')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500204005073','500204005074')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500202004040) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500204005073 + 500204005074) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_78,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500204005073')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500207306094','500207306095','500207306096')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500204005073) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500207306094 + 500207306095 + 500207306096) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_79,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500204005074')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500207406097','500207406098','500207406099')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500204005074) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500207406097 + 500207406098 + 500207406099) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_80,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500202004041')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500204105075','500204105076','500204105077','500204105078')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500202004041) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500204105075 + 500204105076 + 500204105077 + 500204105078) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_81,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500204105076')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500207606100','500207606101','500207606102','500207606103','500207606104')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500204105076) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500207606100 + 500207606101 + 500207606102 + 500207606103 + 500207606104) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_82,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500204105077')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500207706105','500207706106','500207706107','500207706108')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500204105077) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500207706105 + 500207706106 + 500207706107 + 500207706108) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_83,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500204105078')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500207806109','500207806110','500207806111','500207806112')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500204105078) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500207806109 + 500207806110 + 500207806111 + 500207806112) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_84,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200903021')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500202104042','500202104043','500202104044','500202104045','500202104046','500202104047','500202104048','500202104049')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200903021) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500202104042 + 500202104043 + 500202104044 + 500202104045 + 500202104046 + 500202104047 + 500202104048 + 500202104049) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_85,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200903022')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500202204050','500202204051','500202204052','500202204053','500202204054')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200903022) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500202204050 + 500202204051 + 500202204052 + 500202204053 + 500202204054) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_86,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500202204052')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500205205079','500205205080')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500202204052) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500205205079 + 500205205080) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_87,

/*Comisiones por el otorgamiento del crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500200102011')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500201103023','500201103024','500201103025')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200102011) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500201103023 + 500201103024 + 500201103025) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_88,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500201103023')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500202304055','500202304056','500202304057')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201103023) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500202304055 + 500202304056 + 500202304057) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_89,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500202304055')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500205505081','500205505082','500205505083','500205505084','500205505085','500205505086','500205505087','500205505088')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500202304055) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500205505081 + 500205505082 + 500205505083 + 500205505084 + 500205505085 + 500205505086 + 500205505087 + 500205505088) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_90,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500205505081')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500208106113','500208106114')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500205505081) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500208106113 + 500208106114) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_91,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500205505082')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500208206115','500208206116','500208206117')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500205505082) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500208206115 + 500208206116 + 500208206117) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_92,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500205505083')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500208306118','500208306119')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500205505083) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500208306118 + 500208306119) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_93,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500202304056')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500205605089','500205605090')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500202304056) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500205605089 + 500205605090) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_94,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500205605089')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500208906120','500208906121','500208906122')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500205605089) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500208906120 + 500208906121 + 500208906122) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_95,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500205605090')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500209006123','500209006124','500209006125')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500205605090) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500209006123 + 500209006124 + 500209006125) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_96,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500202304057')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500205705091','500205705092','500205705093','500205705094')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500202304057) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500205705091 + 500205705092 + 500205705093 + 500205705094) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_97,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500205705092')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500209206126','500209206127','500209206128','500209206129','500209206130')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500205705092) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500209206126 + 500209206127 + 500209206128 + 500209206129 + 500209206130) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_98,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500205705093')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500209306131','500209306132','500209306133','500209306134')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500205705093) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500209306131 + 500209306132 + 500209306133 + 500209306134) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_99,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R10A_1012   
WHERE [c04_concepto] IN ('500205705094')   
AND c05_tipo_saldo IN ('124')    
AND c06_tipo_movimiento IN ('0')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R10A_1012     
WHERE [c04_concepto] IN ('500209406135','500209406136','500209406137','500209406138')
AND c05_tipo_saldo IN ('124')     
AND c06_tipo_movimiento IN ('0')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500205705094) con Tipo de Saldo 124, Tipo de Movimiento 0, debe ser igual a la sumatoria de las cuentas (500209406135 + 500209406136 + 500209406137 + 500209406138) con Tipo de Saldo 124, Tipo de Movimiento 0.')    
AS VALIDACION_100
	
INTO IFRS9_R10A_1012_TS124TM0_RESULT_1
FROM IFRS9_R10A_1012

END

BEGIN
	INSERT INTO IFRS9_R10A_1012_TS124TM0_RESULT_1 
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_1])),
            SUM(CHARINDEX('ERR',[VALIDACION_2])),
            SUM(CHARINDEX('ERR',[VALIDACION_3])),
            SUM(CHARINDEX('ERR',[VALIDACION_4])),
            SUM(CHARINDEX('ERR',[VALIDACION_5])),
            SUM(CHARINDEX('ERR',[VALIDACION_6])),
            SUM(CHARINDEX('ERR',[VALIDACION_7])),
            SUM(CHARINDEX('ERR',[VALIDACION_8])),
            SUM(CHARINDEX('ERR',[VALIDACION_9])),
            SUM(CHARINDEX('ERR',[VALIDACION_10])),
            SUM(CHARINDEX('ERR',[VALIDACION_11])),
            SUM(CHARINDEX('ERR',[VALIDACION_12])),
            SUM(CHARINDEX('ERR',[VALIDACION_13])),
            SUM(CHARINDEX('ERR',[VALIDACION_14])),
            SUM(CHARINDEX('ERR',[VALIDACION_15])),
            SUM(CHARINDEX('ERR',[VALIDACION_16])),
            SUM(CHARINDEX('ERR',[VALIDACION_17])),
            SUM(CHARINDEX('ERR',[VALIDACION_18])),
            SUM(CHARINDEX('ERR',[VALIDACION_19])),
            SUM(CHARINDEX('ERR',[VALIDACION_20])),
            SUM(CHARINDEX('ERR',[VALIDACION_21])),
            SUM(CHARINDEX('ERR',[VALIDACION_22])),
            SUM(CHARINDEX('ERR',[VALIDACION_23])),
            SUM(CHARINDEX('ERR',[VALIDACION_24])),
            SUM(CHARINDEX('ERR',[VALIDACION_25])),
            SUM(CHARINDEX('ERR',[VALIDACION_26])),
            SUM(CHARINDEX('ERR',[VALIDACION_27])),
            SUM(CHARINDEX('ERR',[VALIDACION_28])),
            SUM(CHARINDEX('ERR',[VALIDACION_29])),
            SUM(CHARINDEX('ERR',[VALIDACION_30])),
            SUM(CHARINDEX('ERR',[VALIDACION_31])),
            SUM(CHARINDEX('ERR',[VALIDACION_32])),
            SUM(CHARINDEX('ERR',[VALIDACION_33])),
            SUM(CHARINDEX('ERR',[VALIDACION_34])),
            SUM(CHARINDEX('ERR',[VALIDACION_35])),
            SUM(CHARINDEX('ERR',[VALIDACION_36])),
            SUM(CHARINDEX('ERR',[VALIDACION_37])),
            SUM(CHARINDEX('ERR',[VALIDACION_38])),
            SUM(CHARINDEX('ERR',[VALIDACION_39])),
            SUM(CHARINDEX('ERR',[VALIDACION_40])),
            SUM(CHARINDEX('ERR',[VALIDACION_41])),
            SUM(CHARINDEX('ERR',[VALIDACION_42])),
            SUM(CHARINDEX('ERR',[VALIDACION_43])),
            SUM(CHARINDEX('ERR',[VALIDACION_44])),
            SUM(CHARINDEX('ERR',[VALIDACION_45])),
            SUM(CHARINDEX('ERR',[VALIDACION_46])),
            SUM(CHARINDEX('ERR',[VALIDACION_47])),
            SUM(CHARINDEX('ERR',[VALIDACION_48])),
            SUM(CHARINDEX('ERR',[VALIDACION_49])),
            SUM(CHARINDEX('ERR',[VALIDACION_50])),
            SUM(CHARINDEX('ERR',[VALIDACION_51])),
            SUM(CHARINDEX('ERR',[VALIDACION_52])),
            SUM(CHARINDEX('ERR',[VALIDACION_53])),
            SUM(CHARINDEX('ERR',[VALIDACION_54])),
            SUM(CHARINDEX('ERR',[VALIDACION_55])),
            SUM(CHARINDEX('ERR',[VALIDACION_56])),
            SUM(CHARINDEX('ERR',[VALIDACION_57])),
            SUM(CHARINDEX('ERR',[VALIDACION_58])),
            SUM(CHARINDEX('ERR',[VALIDACION_59])),
            SUM(CHARINDEX('ERR',[VALIDACION_60])),
            SUM(CHARINDEX('ERR',[VALIDACION_61])),
            SUM(CHARINDEX('ERR',[VALIDACION_62])),
            SUM(CHARINDEX('ERR',[VALIDACION_63])),
            SUM(CHARINDEX('ERR',[VALIDACION_64])),
            SUM(CHARINDEX('ERR',[VALIDACION_65])),
            SUM(CHARINDEX('ERR',[VALIDACION_66])),
            SUM(CHARINDEX('ERR',[VALIDACION_67])),
            SUM(CHARINDEX('ERR',[VALIDACION_68])),
            SUM(CHARINDEX('ERR',[VALIDACION_69])),
            SUM(CHARINDEX('ERR',[VALIDACION_70])),
            SUM(CHARINDEX('ERR',[VALIDACION_71])),
            SUM(CHARINDEX('ERR',[VALIDACION_72])),
            SUM(CHARINDEX('ERR',[VALIDACION_73])),
            SUM(CHARINDEX('ERR',[VALIDACION_74])),
            SUM(CHARINDEX('ERR',[VALIDACION_75])),
            SUM(CHARINDEX('ERR',[VALIDACION_76])),
            SUM(CHARINDEX('ERR',[VALIDACION_77])),
            SUM(CHARINDEX('ERR',[VALIDACION_78])),
            SUM(CHARINDEX('ERR',[VALIDACION_79])),
            SUM(CHARINDEX('ERR',[VALIDACION_80])),
            SUM(CHARINDEX('ERR',[VALIDACION_81])),
            SUM(CHARINDEX('ERR',[VALIDACION_82])),
            SUM(CHARINDEX('ERR',[VALIDACION_83])),
            SUM(CHARINDEX('ERR',[VALIDACION_84])),
            SUM(CHARINDEX('ERR',[VALIDACION_85])),
            SUM(CHARINDEX('ERR',[VALIDACION_86])),
            SUM(CHARINDEX('ERR',[VALIDACION_87])),
            SUM(CHARINDEX('ERR',[VALIDACION_88])),
            SUM(CHARINDEX('ERR',[VALIDACION_89])),
            SUM(CHARINDEX('ERR',[VALIDACION_90])),
            SUM(CHARINDEX('ERR',[VALIDACION_91])),
            SUM(CHARINDEX('ERR',[VALIDACION_92])),
            SUM(CHARINDEX('ERR',[VALIDACION_93])),
            SUM(CHARINDEX('ERR',[VALIDACION_94])),
            SUM(CHARINDEX('ERR',[VALIDACION_95])),
            SUM(CHARINDEX('ERR',[VALIDACION_96])),
            SUM(CHARINDEX('ERR',[VALIDACION_97])),
            SUM(CHARINDEX('ERR',[VALIDACION_98])),
            SUM(CHARINDEX('ERR',[VALIDACION_99])),
            SUM(CHARINDEX('ERR',[VALIDACION_100]))
            


		FROM IFRS9_R10A_1012_TS124TM0_RESULT_1 
END

BEGIN
	EXEC SP_IFRS9_R10A_1012_TS124TM0_VIEW_1
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


