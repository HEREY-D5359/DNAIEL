﻿
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Reclasificaciones. Reclasificaciones en el estado de resultado integral */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: JULIO 2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: NA*/
/*TIPO SALDO: SALDOS*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/


CREATE OR ALTER PROC [dbo].[SP_IFRS9_R10A_1012_TSSALDOS_VIEW_9]
AS
BEGIN
	SELECT *
		
	FROM IFRS9_R10A_1012_TSSALDOS_RESULT_9
	WHERE

        (VALIDACION_801 <> '' ) OR
        (VALIDACION_802 <> '' ) OR
        (VALIDACION_803 <> '' ) OR
        (VALIDACION_804 <> '' ) OR
        (VALIDACION_805 <> '' ) OR
        (VALIDACION_806 <> '' ) OR
        (VALIDACION_807 <> '' ) OR
        (VALIDACION_808 <> '' ) OR
        (VALIDACION_809 <> '' ) OR
        (VALIDACION_810 <> '' ) OR
        (VALIDACION_811 <> '' ) OR
        (VALIDACION_812 <> '' ) OR
        (VALIDACION_813 <> '' ) OR
        (VALIDACION_814 <> '' ) OR
        (VALIDACION_815 <> '' ) OR
        (VALIDACION_816 <> '' ) OR
        (VALIDACION_817 <> '' ) OR
        (VALIDACION_818 <> '' ) OR
        (VALIDACION_819 <> '' ) OR
        (VALIDACION_820 <> '' ) OR
        (VALIDACION_821 <> '' ) OR
        (VALIDACION_822 <> '' ) OR
        (VALIDACION_823 <> '' ) OR
        (VALIDACION_824 <> '' ) OR
        (VALIDACION_825 <> '' ) OR
        (VALIDACION_826 <> '' ) OR
        (VALIDACION_827 <> '' ) OR
        (VALIDACION_828 <> '' ) OR
        (VALIDACION_829 <> '' ) OR
        (VALIDACION_830 <> '' ) OR
        (VALIDACION_831 <> '' ) OR
        (VALIDACION_832 <> '' ) OR
        (VALIDACION_833 <> '' ) OR
        (VALIDACION_834 <> '' ) OR
        (VALIDACION_835 <> '' ) OR
        (VALIDACION_836 <> '' ) OR
        (VALIDACION_837 <> '' ) OR
        (VALIDACION_838 <> '' ) OR
        (VALIDACION_839 <> '' ) OR
        (VALIDACION_840 <> '' ) OR
        (VALIDACION_841 <> '' ) OR
        (VALIDACION_842 <> '' ) OR
        (VALIDACION_843 <> '' ) OR
        (VALIDACION_844 <> '' ) OR
        (VALIDACION_845 <> '' ) OR
        (VALIDACION_846 <> '' ) OR
        (VALIDACION_847 <> '' ) OR
        (VALIDACION_848 <> '' ) OR
        (VALIDACION_849 <> '' ) OR
        (VALIDACION_850 <> '' ) OR
        (VALIDACION_851 <> '' ) OR
        (VALIDACION_852 <> '' ) OR
        (VALIDACION_853 <> '' ) OR
        (VALIDACION_854 <> '' ) OR
        (VALIDACION_855 <> '' ) OR
        (VALIDACION_856 <> '' ) OR
        (VALIDACION_857 <> '' ) OR
        (VALIDACION_858 <> '' ) OR
        (VALIDACION_859 <> '' ) OR
        (VALIDACION_860 <> '' ) OR
        (VALIDACION_861 <> '' ) OR
        (VALIDACION_862 <> '' ) OR
        (VALIDACION_863 <> '' ) OR
        (VALIDACION_864 <> '' ) OR
        (VALIDACION_865 <> '' ) OR
        (VALIDACION_866 <> '' ) OR
        (VALIDACION_867 <> '' ) OR
        (VALIDACION_868 <> '' ) OR
        (VALIDACION_869 <> '' ) OR
        (VALIDACION_870 <> '' ) OR
        (VALIDACION_871 <> '' ) OR
        (VALIDACION_872 <> '' ) OR
        (VALIDACION_873 <> '' ) OR
        (VALIDACION_874 <> '' ) OR
        (VALIDACION_875 <> '' ) OR
        (VALIDACION_876 <> '' ) OR
        (VALIDACION_877 <> '' ) OR
        (VALIDACION_878 <> '' ) OR
        (VALIDACION_879 <> '' ) OR
        (VALIDACION_880 <> '' ) OR
        (VALIDACION_881 <> '' ) OR
        (VALIDACION_882 <> '' ) OR
        (VALIDACION_883 <> '' ) OR
        (VALIDACION_884 <> '' ) OR
        (VALIDACION_885 <> '' ) OR
        (VALIDACION_886 <> '' ) OR
        (VALIDACION_887 <> '' ) OR
        (VALIDACION_888 <> '' ) OR
        (VALIDACION_889 <> '' ) OR
        (VALIDACION_890 <> '' ) OR
        (VALIDACION_891 <> '' ) OR
        (VALIDACION_892 <> '' ) OR
        (VALIDACION_893 <> '' ) OR
        (VALIDACION_894 <> '' ) OR
        (VALIDACION_895 <> '' ) OR
        (VALIDACION_896 <> '' ) OR
        (VALIDACION_897 <> '' ) OR
        (VALIDACION_898 <> '' ) OR
        (VALIDACION_899 <> '' ) OR
        (VALIDACION_900 <> '' ) 
ORDER BY 1
END


