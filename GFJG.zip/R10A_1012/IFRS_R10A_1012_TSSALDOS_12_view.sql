﻿
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Reclasificaciones. Reclasificaciones en el estado de resultado integral */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: JULIO 2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: NA*/
/*TIPO SALDO: SALDOS*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/


CREATE OR ALTER PROC [dbo].[SP_IFRS9_R10A_1012_TSSALDOS_VIEW_12]
AS
BEGIN
	SELECT *
		
	FROM IFRS9_R10A_1012_TSSALDOS_RESULT_12
	WHERE

        (VALIDACION_1101 <> '' ) OR
        (VALIDACION_1102 <> '' ) OR
        (VALIDACION_1103 <> '' ) OR
        (VALIDACION_1104 <> '' ) OR
        (VALIDACION_1105 <> '' ) OR
        (VALIDACION_1106 <> '' ) OR
        (VALIDACION_1107 <> '' ) OR
        (VALIDACION_1108 <> '' ) OR
        (VALIDACION_1109 <> '' ) OR
        (VALIDACION_1110 <> '' ) OR
        (VALIDACION_1111 <> '' ) OR
        (VALIDACION_1112 <> '' ) OR
        (VALIDACION_1113 <> '' ) OR
        (VALIDACION_1114 <> '' ) 
ORDER BY 1
END


