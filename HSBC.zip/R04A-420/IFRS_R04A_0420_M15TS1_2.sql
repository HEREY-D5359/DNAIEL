﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapa 3 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0420_M15TS1_COMP_2]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0420_M15TS1_RESULT_2')
BEGIN
DROP TABLE IFRS9_R04A_0420_M15TS1_RESULT_2
END 

BEGIN
SELECT DISTINCT

	/*ID*/

	CONVERT(VARCHAR,ID)  AS ID,   
	/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401006035')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403507100','112403507101','112403507102')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401006035) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112403507100 + 112403507101 + 112403507102) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_101,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403507100')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410008107','112410008108','112410008109','112410008110','112410008111','112410008112','112410008113','112410008114')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112403507100) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112410008107 + 112410008108 + 112410008109 + 112410008110 + 112410008111 + 112410008112 + 112410008113 + 112410008114) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_102,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410008107')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410709131','112410709132')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112410008107) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112410709131 + 112410709132) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_103,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410008108')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410809133','112410809134','112410809135')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112410008108) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112410809133 + 112410809134 + 112410809135) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_104,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410008109')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410909136','112410909137')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112410008109) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112410909136 + 112410909137) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_105,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403507101')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410108115','112410108116')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112403507101) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112410108115 + 112410108116) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_106,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410108115')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112411509138','112411509139','112411509140')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112410108115) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112411509138 + 112411509139 + 112411509140) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_107,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410108116')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112411609141','112411609142','112411609143')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112410108116) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112411609141 + 112411609142 + 112411609143) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_108,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403507102')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410208117','112410208118','112410208119','112410208120')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112403507102) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112410208117 + 112410208118 + 112410208119 + 112410208120) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_109,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410208118')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112411809144','112411809145','112411809146','112411809147','112411809148')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112410208118) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112411809144 + 112411809145 + 112411809146 + 112411809147 + 112411809148) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_110,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410208119')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112411909149','112411909150','112411909151','112411909152')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112410208119) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112411909149 + 112411909150 + 112411909151 + 112411909152) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_111,

/*Créditos a organismos descentralizados o desconcentrados  */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410208120')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112412009153','112412009154','112412009155','112412009156')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112410208120) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112412009153 + 112412009154 + 112412009155 + 112412009156) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_112,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401006036')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403607103','112403607104','112403607105','112403607106','112403607107','112403607108','112403607109','112403607110')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401006036) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112403607103 + 112403607104 + 112403607105 + 112403607106 + 112403607107 + 112403607108 + 112403607109 + 112403607110) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_113,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401006037')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403707111','112403707112','112403707113','112403707114','112403707115')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401006037) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112403707111 + 112403707112 + 112403707113 + 112403707114 + 112403707115) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_114,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403707113')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112411308121','112411308122')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112403707113) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112411308121 + 112411308122) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_115,

/*Por documentos de cobro inmediato no cobrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400205011')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401106038','112401106039','112401106040')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400205011) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112401106038 + 112401106039 + 112401106040) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_116,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401106038')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403807116','112403807117','112403807118')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401106038) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112403807116 + 112403807117 + 112403807118) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_117,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403807116')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112411608123','112411608124','112411608125','112411608126','112411608127','112411608128','112411608129','112411608130')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112403807116) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112411608123 + 112411608124 + 112411608125 + 112411608126 + 112411608127 + 112411608128 + 112411608129 + 112411608130) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_118,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112411608123')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112412309157','112412309158')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112411608123) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112412309157 + 112412309158) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_119,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112411608124')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112412409159','112412409160','112412409161')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112411608124) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112412409159 + 112412409160 + 112412409161) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_120,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112411608125')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112412509162','112412509163')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112411608125) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112412509162 + 112412509163) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_121,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403807117')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112411708131','112411708132')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112403807117) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112411708131 + 112411708132) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_122,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112411708131')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112413109164','112413109165','112413109166')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112411708131) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112413109164 + 112413109165 + 112413109166) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_123,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112411708132')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112413209167','112413209168','112413209169')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112411708132) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112413209167 + 112413209168 + 112413209169) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_124,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403807118')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112411808133','112411808134','112411808135','112411808136')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112403807118) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112411808133 + 112411808134 + 112411808135 + 112411808136) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_125,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112411808134')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112413409170','112413409171','112413409172','112413409173','112413409174')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112411808134) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112413409170 + 112413409171 + 112413409172 + 112413409173 + 112413409174) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_126,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112411808135')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112413509175','112413509176','112413509177','112413509178')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112411808135) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112413509175 + 112413509176 + 112413509177 + 112413509178) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_127,

/*Créditos a organismos descentralizados o desconcentrados  */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112411808136')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112413609179','112413609180','112413609181','112413609182')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112411808136) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112413609179 + 112413609180 + 112413609181 + 112413609182) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_128,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401106039')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403907119','112403907120','112403907121','112403907122','112403907123','112403907124','112403907125','112403907126')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401106039) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112403907119 + 112403907120 + 112403907121 + 112403907122 + 112403907123 + 112403907124 + 112403907125 + 112403907126) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_129,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401106040')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112404007127','112404007128','112404007129','112404007130','112404007131')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401106040) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112404007127 + 112404007128 + 112404007129 + 112404007130 + 112404007131) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_130,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112404007129')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112412908137','112412908138')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112404007129) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112412908137 + 112412908138) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_131,

/*Salidas de cartera con riesgo de crédito etapa 3*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400104003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400305012','112400305013','112400305014','112400305015','112400305016','112400305017')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400104003) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112400305012 + 112400305013 + 112400305014 + 112400305015 + 112400305016 + 112400305017) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_132,

/*Reestructuras y renovaciones (2)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400305012')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401206041','112401206042','112401206043')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400305012) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112401206041 + 112401206042 + 112401206043) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_133,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401206041')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112404107132','112404107133','112404107134')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401206041) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112404107132 + 112404107133 + 112404107134) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_134,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112404107132')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112413208139','112413208140','112413208141','112413208142','112413208143','112413208144','112413208145','112413208146')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112404107132) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112413208139 + 112413208140 + 112413208141 + 112413208142 + 112413208143 + 112413208144 + 112413208145 + 112413208146) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_135,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112413208139')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112413909183','112413909184')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112413208139) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112413909183 + 112413909184) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_136,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112413208140')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112414009185','112414009186','112414009187')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112413208140) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112414009185 + 112414009186 + 112414009187) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_137,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112413208141')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112414109188','112414109189')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112413208141) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112414109188 + 112414109189) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_138,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112404107133')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112413308147','112413308148')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112404107133) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112413308147 + 112413308148) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_139,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112413308147')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112414709190','112414709191','112414709192')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112413308147) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112414709190 + 112414709191 + 112414709192) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_140,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112413308148')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112414809193','112414809194','112414809195')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112413308148) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112414809193 + 112414809194 + 112414809195) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_141,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112404107134')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112413408149','112413408150','112413408151','112413408152')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112404107134) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112413408149 + 112413408150 + 112413408151 + 112413408152) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_142,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112413408150')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112415009196','112415009197','112415009198','112415009199','112415009200')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112413408150) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112415009196 + 112415009197 + 112415009198 + 112415009199 + 112415009200) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_143,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112413408151')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112415109201','112415109202','112415109203','112415109204')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112413408151) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112415109201 + 112415109202 + 112415109203 + 112415109204) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_144,

/*Créditos a organismos descentralizados o desconcentrados  */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112413408152')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112415209205','112415209206','112415209207','112415209208')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112413408152) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112415209205 + 112415209206 + 112415209207 + 112415209208) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_145,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401206042')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112404207135','112404207136','112404207137','112404207138','112404207139','112404207140','112404207141','112404207142')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401206042) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112404207135 + 112404207136 + 112404207137 + 112404207138 + 112404207139 + 112404207140 + 112404207141 + 112404207142) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_146,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401206043')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112404307143','112404307144','112404307145','112404307146','112404307147')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401206043) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112404307143 + 112404307144 + 112404307145 + 112404307146 + 112404307147) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_147,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112404307145')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112414508153','112414508154')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112404307145) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112414508153 + 112414508154) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_148,

/*Créditos liquidados (3)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400305013')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401306044','112401306045','112401306046','112401306047','112401306048')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400305013) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112401306044 + 112401306045 + 112401306046 + 112401306047 + 112401306048) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_149,

/*Cobranza en efectivo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401306044')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112404407148','112404407149','112404407150')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401306044) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112404407148 + 112404407149 + 112404407150) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_150,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112404407148')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112414808155','112414808156','112414808157')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112404407148) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112414808155 + 112414808156 + 112414808157) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_151,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112414808155')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112415509209','112415509210','112415509211','112415509212','112415509213','112415509214','112415509215','112415509216')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112414808155) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112415509209 + 112415509210 + 112415509211 + 112415509212 + 112415509213 + 112415509214 + 112415509215 + 112415509216) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_152,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112415509209')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112420910001','112420910002')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112415509209) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112420910001 + 112420910002) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_153,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112415509210')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112421010003','112421010004','112421010005')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112415509210) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112421010003 + 112421010004 + 112421010005) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_154,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112415509211')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112421110006','112421110007')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112415509211) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112421110006 + 112421110007) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_155,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112414808156')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112415609217','112415609218')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112414808156) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112415609217 + 112415609218) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_156,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112415609217')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112421710008','112421710009','112421710010')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112415609217) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112421710008 + 112421710009 + 112421710010) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_157,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112415609218')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112421810011','112421810012','112421810013')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112415609218) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112421810011 + 112421810012 + 112421810013) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_158,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112414808157')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112415709219','112415709220','112415709221','112415709222')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112414808157) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112415709219 + 112415709220 + 112415709221 + 112415709222) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_159,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112415709220')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112422010014','112422010015','112422010016','112422010017','112422010018')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112415709220) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112422010014 + 112422010015 + 112422010016 + 112422010017 + 112422010018) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_160,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112415709221')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112422110019','112422110020','112422110021','112422110022')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112415709221) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112422110019 + 112422110020 + 112422110021 + 112422110022) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_161,

/*Créditos a organismos descentralizados o desconcentrados  */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112415709222')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112422210023','112422210024','112422210025','112422210026')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112415709222) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112422210023 + 112422210024 + 112422210025 + 112422210026) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_162,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112404407149')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112414908158','112414908159','112414908160','112414908161','112414908162','112414908163','112414908164','112414908165')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112404407149) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112414908158 + 112414908159 + 112414908160 + 112414908161 + 112414908162 + 112414908163 + 112414908164 + 112414908165) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_163,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112404407150')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112415008166','112415008167','112415008168','112415008169','112415008170')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112404407150) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112415008166 + 112415008167 + 112415008168 + 112415008169 + 112415008170) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_164,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112415008168')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112416809223','112416809224')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112415008168) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112416809223 + 112416809224) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_165,

/*Cobranza en especie (4)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401306045')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112404507151','112404507152','112404507153')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401306045) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112404507151 + 112404507152 + 112404507153) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_166,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112404507151')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112415108171','112415108172','112415108173')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112404507151) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112415108171 + 112415108172 + 112415108173) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_167,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112415108171')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112417109225','112417109226','112417109227','112417109228','112417109229','112417109230','112417109231','112417109232')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112415108171) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112417109225 + 112417109226 + 112417109227 + 112417109228 + 112417109229 + 112417109230 + 112417109231 + 112417109232) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_168,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112417109225')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112422510027','112422510028')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112417109225) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112422510027 + 112422510028) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_169,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112417109226')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112422610029','112422610030','112422610031')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112417109226) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112422610029 + 112422610030 + 112422610031) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_170,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112417109227')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112422710032','112422710033')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112417109227) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112422710032 + 112422710033) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_171,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112415108172')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112417209233','112417209234')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112415108172) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112417209233 + 112417209234) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_172,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112417209233')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112423310034','112423310035','112423310036')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112417209233) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112423310034 + 112423310035 + 112423310036) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_173,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112417209234')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112423410037','112423410038','112423410039')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112417209234) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112423410037 + 112423410038 + 112423410039) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_174,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112415108173')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112417309235','112417309236','112417309237','112417309238')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112415108173) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112417309235 + 112417309236 + 112417309237 + 112417309238) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_175,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112417309236')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112423610040','112423610041','112423610042','112423610043','112423610044')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112417309236) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112423610040 + 112423610041 + 112423610042 + 112423610043 + 112423610044) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_176,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112417309237')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112423710045','112423710046','112423710047','112423710048')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112417309237) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112423710045 + 112423710046 + 112423710047 + 112423710048) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_177,

/*Créditos a organismos descentralizados o desconcentrados  */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112417309238')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112423810049','112423810050','112423810051','112423810052')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112417309238) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112423810049 + 112423810050 + 112423810051 + 112423810052) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_178,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112404507152')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112415208174','112415208175','112415208176','112415208177','112415208178','112415208179','112415208180','112415208181')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112404507152) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112415208174 + 112415208175 + 112415208176 + 112415208177 + 112415208178 + 112415208179 + 112415208180 + 112415208181) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_179,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112404507153')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112415308182','112415308183','112415308184','112415308185','112415308186')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112404507153) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112415308182 + 112415308183 + 112415308184 + 112415308185 + 112415308186) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_180,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112415308184')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112418409239','112418409240')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112415308184) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112418409239 + 112418409240) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_181,

/*Capitalización de adeudos a favor del banco*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401306046')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112404607154','112404607155','112404607156')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401306046) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112404607154 + 112404607155 + 112404607156) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_182,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112404607154')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112415408187','112415408188','112415408189')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112404607154) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112415408187 + 112415408188 + 112415408189) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_183,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112415408187')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112418709241','112418709242','112418709243','112418709244','112418709245','112418709246','112418709247','112418709248')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112415408187) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112418709241 + 112418709242 + 112418709243 + 112418709244 + 112418709245 + 112418709246 + 112418709247 + 112418709248) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_184,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112418709241')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112424110053','112424110054')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112418709241) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112424110053 + 112424110054) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_185,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112418709242')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112424210055','112424210056','112424210057')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112418709242) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112424210055 + 112424210056 + 112424210057) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_186,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112418709243')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112424310058','112424310059')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112418709243) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112424310058 + 112424310059) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_187,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112415408188')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112418809249','112418809250')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112415408188) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112418809249 + 112418809250) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_188,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112418809249')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112424910060','112424910061','112424910062')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112418809249) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112424910060 + 112424910061 + 112424910062) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_189,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112418809250')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112425010063','112425010064','112425010065')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112418809250) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112425010063 + 112425010064 + 112425010065) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_190,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112415408189')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112418909251','112418909252','112418909253','112418909254')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112415408189) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112418909251 + 112418909252 + 112418909253 + 112418909254) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_191,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112418909252')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112425210066','112425210067','112425210068','112425210069','112425210070')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112418909252) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112425210066 + 112425210067 + 112425210068 + 112425210069 + 112425210070) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_192,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112418909253')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112425310071','112425310072','112425310073','112425310074')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112418909253) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112425310071 + 112425310072 + 112425310073 + 112425310074) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_193,

/*Créditos a organismos descentralizados o desconcentrados  */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112418909254')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112425410075','112425410076','112425410077','112425410078')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112418909254) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112425410075 + 112425410076 + 112425410077 + 112425410078) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_194,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112404607155')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112415508190','112415508191','112415508192','112415508193','112415508194','112415508195','112415508196','112415508197')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112404607155) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112415508190 + 112415508191 + 112415508192 + 112415508193 + 112415508194 + 112415508195 + 112415508196 + 112415508197) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_195,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112404607156')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112415608198','112415608199','112415608200','112415608201','112415608202')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112404607156) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112415608198 + 112415608199 + 112415608200 + 112415608201 + 112415608202) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_196,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112415608200')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112420009255','112420009256')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112415608200) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112420009255 + 112420009256) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_197,

/*Castigos, quitas y condonaciones por (3)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401306047')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112404707157','112404707158','112404707159')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401306047) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112404707157 + 112404707158 + 112404707159) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_198,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112404707157')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112415708203','112415708204','112415708205')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112404707157) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112415708203 + 112415708204 + 112415708205) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_199,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112415708203')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112420309257','112420309258','112420309259','112420309260','112420309261','112420309262','112420309263','112420309264')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112415708203) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112420309257 + 112420309258 + 112420309259 + 112420309260 + 112420309261 + 112420309262 + 112420309263 + 112420309264) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_200
	
INTO IFRS9_R04A_0420_M15TS1_RESULT_2
FROM IFRS9_R04A_0420

END

BEGIN
	INSERT INTO IFRS9_R04A_0420_M15TS1_RESULT_2
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_101])),
            SUM(CHARINDEX('ERR',[VALIDACION_102])),
            SUM(CHARINDEX('ERR',[VALIDACION_103])),
            SUM(CHARINDEX('ERR',[VALIDACION_104])),
            SUM(CHARINDEX('ERR',[VALIDACION_105])),
            SUM(CHARINDEX('ERR',[VALIDACION_106])),
            SUM(CHARINDEX('ERR',[VALIDACION_107])),
            SUM(CHARINDEX('ERR',[VALIDACION_108])),
            SUM(CHARINDEX('ERR',[VALIDACION_109])),
            SUM(CHARINDEX('ERR',[VALIDACION_110])),
            SUM(CHARINDEX('ERR',[VALIDACION_111])),
            SUM(CHARINDEX('ERR',[VALIDACION_112])),
            SUM(CHARINDEX('ERR',[VALIDACION_113])),
            SUM(CHARINDEX('ERR',[VALIDACION_114])),
            SUM(CHARINDEX('ERR',[VALIDACION_115])),
            SUM(CHARINDEX('ERR',[VALIDACION_116])),
            SUM(CHARINDEX('ERR',[VALIDACION_117])),
            SUM(CHARINDEX('ERR',[VALIDACION_118])),
            SUM(CHARINDEX('ERR',[VALIDACION_119])),
            SUM(CHARINDEX('ERR',[VALIDACION_120])),
            SUM(CHARINDEX('ERR',[VALIDACION_121])),
            SUM(CHARINDEX('ERR',[VALIDACION_122])),
            SUM(CHARINDEX('ERR',[VALIDACION_123])),
            SUM(CHARINDEX('ERR',[VALIDACION_124])),
            SUM(CHARINDEX('ERR',[VALIDACION_125])),
            SUM(CHARINDEX('ERR',[VALIDACION_126])),
            SUM(CHARINDEX('ERR',[VALIDACION_127])),
            SUM(CHARINDEX('ERR',[VALIDACION_128])),
            SUM(CHARINDEX('ERR',[VALIDACION_129])),
            SUM(CHARINDEX('ERR',[VALIDACION_130])),
            SUM(CHARINDEX('ERR',[VALIDACION_131])),
            SUM(CHARINDEX('ERR',[VALIDACION_132])),
            SUM(CHARINDEX('ERR',[VALIDACION_133])),
            SUM(CHARINDEX('ERR',[VALIDACION_134])),
            SUM(CHARINDEX('ERR',[VALIDACION_135])),
            SUM(CHARINDEX('ERR',[VALIDACION_136])),
            SUM(CHARINDEX('ERR',[VALIDACION_137])),
            SUM(CHARINDEX('ERR',[VALIDACION_138])),
            SUM(CHARINDEX('ERR',[VALIDACION_139])),
            SUM(CHARINDEX('ERR',[VALIDACION_140])),
            SUM(CHARINDEX('ERR',[VALIDACION_141])),
            SUM(CHARINDEX('ERR',[VALIDACION_142])),
            SUM(CHARINDEX('ERR',[VALIDACION_143])),
            SUM(CHARINDEX('ERR',[VALIDACION_144])),
            SUM(CHARINDEX('ERR',[VALIDACION_145])),
            SUM(CHARINDEX('ERR',[VALIDACION_146])),
            SUM(CHARINDEX('ERR',[VALIDACION_147])),
            SUM(CHARINDEX('ERR',[VALIDACION_148])),
            SUM(CHARINDEX('ERR',[VALIDACION_149])),
            SUM(CHARINDEX('ERR',[VALIDACION_150])),
            SUM(CHARINDEX('ERR',[VALIDACION_151])),
            SUM(CHARINDEX('ERR',[VALIDACION_152])),
            SUM(CHARINDEX('ERR',[VALIDACION_153])),
            SUM(CHARINDEX('ERR',[VALIDACION_154])),
            SUM(CHARINDEX('ERR',[VALIDACION_155])),
            SUM(CHARINDEX('ERR',[VALIDACION_156])),
            SUM(CHARINDEX('ERR',[VALIDACION_157])),
            SUM(CHARINDEX('ERR',[VALIDACION_158])),
            SUM(CHARINDEX('ERR',[VALIDACION_159])),
            SUM(CHARINDEX('ERR',[VALIDACION_160])),
            SUM(CHARINDEX('ERR',[VALIDACION_161])),
            SUM(CHARINDEX('ERR',[VALIDACION_162])),
            SUM(CHARINDEX('ERR',[VALIDACION_163])),
            SUM(CHARINDEX('ERR',[VALIDACION_164])),
            SUM(CHARINDEX('ERR',[VALIDACION_165])),
            SUM(CHARINDEX('ERR',[VALIDACION_166])),
            SUM(CHARINDEX('ERR',[VALIDACION_167])),
            SUM(CHARINDEX('ERR',[VALIDACION_168])),
            SUM(CHARINDEX('ERR',[VALIDACION_169])),
            SUM(CHARINDEX('ERR',[VALIDACION_170])),
            SUM(CHARINDEX('ERR',[VALIDACION_171])),
            SUM(CHARINDEX('ERR',[VALIDACION_172])),
            SUM(CHARINDEX('ERR',[VALIDACION_173])),
            SUM(CHARINDEX('ERR',[VALIDACION_174])),
            SUM(CHARINDEX('ERR',[VALIDACION_175])),
            SUM(CHARINDEX('ERR',[VALIDACION_176])),
            SUM(CHARINDEX('ERR',[VALIDACION_177])),
            SUM(CHARINDEX('ERR',[VALIDACION_178])),
            SUM(CHARINDEX('ERR',[VALIDACION_179])),
            SUM(CHARINDEX('ERR',[VALIDACION_180])),
            SUM(CHARINDEX('ERR',[VALIDACION_181])),
            SUM(CHARINDEX('ERR',[VALIDACION_182])),
            SUM(CHARINDEX('ERR',[VALIDACION_183])),
            SUM(CHARINDEX('ERR',[VALIDACION_184])),
            SUM(CHARINDEX('ERR',[VALIDACION_185])),
            SUM(CHARINDEX('ERR',[VALIDACION_186])),
            SUM(CHARINDEX('ERR',[VALIDACION_187])),
            SUM(CHARINDEX('ERR',[VALIDACION_188])),
            SUM(CHARINDEX('ERR',[VALIDACION_189])),
            SUM(CHARINDEX('ERR',[VALIDACION_190])),
            SUM(CHARINDEX('ERR',[VALIDACION_191])),
            SUM(CHARINDEX('ERR',[VALIDACION_192])),
            SUM(CHARINDEX('ERR',[VALIDACION_193])),
            SUM(CHARINDEX('ERR',[VALIDACION_194])),
            SUM(CHARINDEX('ERR',[VALIDACION_195])),
            SUM(CHARINDEX('ERR',[VALIDACION_196])),
            SUM(CHARINDEX('ERR',[VALIDACION_197])),
            SUM(CHARINDEX('ERR',[VALIDACION_198])),
            SUM(CHARINDEX('ERR',[VALIDACION_199])),
            SUM(CHARINDEX('ERR',[VALIDACION_200]))
            


		from IFRS9_R04A_0420_M15TS1_RESULT_2
END

BEGIN
	EXEC SP_IFRS9_R04A_0420_M15TS1_VIEW_2
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


