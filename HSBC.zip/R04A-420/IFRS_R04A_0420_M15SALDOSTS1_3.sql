﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapa 3 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15SALDOS*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0420_M15SALDOSTS1_COMP_3]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0420_M15SALDOSTS1_RESULT_3')
BEGIN
DROP TABLE IFRS9_R04A_0420_M15SALDOSTS1_RESULT_3
END 

BEGIN
SELECT DISTINCT
         /*id*/
CONVERT(VARCHAR,ID) AS ID, 
	/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112404908062')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112404908062')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112404908062) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112404908062) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_201,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112404908063')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112404908063')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112404908063) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112404908063) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_202,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112404908064')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112404908064')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112404908064) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112404908064) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_203,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112404908065')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112404908065')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112404908065) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112404908065) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_204,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112404908066')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112404908066')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112404908066) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112404908066) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_205,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402307050')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402307050')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112402307050) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112402307050) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_206,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112405008067')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112405008067')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112405008067) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112405008067) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_207,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112406709060')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112406709060')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112406709060) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112406709060) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_208,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112406709061')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112406709061')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112406709061) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112406709061) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_209,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112406709062')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112406709062')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112406709062) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112406709062) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_210,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112405008068')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112405008068')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112405008068) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112405008068) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_211,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112406809063')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112406809063')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112406809063) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112406809063) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_212,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112406809064')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112406809064')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112406809064) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112406809064) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_213,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112406809065')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112406809065')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112406809065) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112406809065) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_214,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402307051')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402307051')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112402307051) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112402307051) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_215,

/*Créditos al gobierno federal */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112405108069')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112405108069')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112405108069) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112405108069) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_216,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112405108070')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112405108070')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112405108070) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112405108070) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_217,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407009066')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407009066')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112407009066) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112407009066) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_218,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407009067')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407009067')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112407009067) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112407009067) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_219,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407009068')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407009068')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112407009068) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112407009068) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_220,

/*Fideicomisos públicos de contratación */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407009069')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407009069')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112407009069) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112407009069) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_221,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407009070')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407009070')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112407009070) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112407009070) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_222,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112405108071')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112405108071')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112405108071) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112405108071) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_223,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407109071')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407109071')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112407109071) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112407109071) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_224,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407109072')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407109072')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112407109072) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112407109072) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_225,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407109073')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407109073')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112407109073) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112407109073) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_226,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407109074')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407109074')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112407109074) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112407109074) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_227,

/*Créditos a organismos descentralizados o desconcentrados  */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112405108072')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112405108072')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112405108072) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112405108072) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_228,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407209075')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407209075')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112407209075) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112407209075) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_229,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407209076')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407209076')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112407209076) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112407209076) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_230,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407209077')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407209077')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112407209077) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112407209077) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_231,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407209078')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407209078')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112407209078) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112407209078) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_232,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400606024')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400606024')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400606024) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400606024) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_233,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402407052')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402407052')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112402407052) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112402407052) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_234,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402407053')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402407053')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112402407053) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112402407053) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_235,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402407054')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402407054')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112402407054) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112402407054) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_236,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402407055')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402407055')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112402407055) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112402407055) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_237,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402407056')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402407056')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112402407056) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112402407056) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_238,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402407057')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402407057')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112402407057) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112402407057) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_239,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402407058')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402407058')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112402407058) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112402407058) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_240,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402407059')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402407059')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112402407059) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112402407059) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_241,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400606025')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400606025')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400606025) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400606025) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_242,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402507060')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402507060')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112402507060) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112402507060) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_243,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402507061')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402507061')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112402507061) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112402507061) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_244,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402507062')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402507062')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112402507062) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112402507062) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_245,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112406208073')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112406208073')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112406208073) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112406208073) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_246,

/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112406208074')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112406208074')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112406208074) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112406208074) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_247,

/*Remodelación o mejoramiento con garantía otorgada por la Banca de Desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402507063')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402507063')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112402507063) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112402507063) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_248,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402507064')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402507064')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112402507064) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112402507064) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_249,

/*Traspaso de cartera de crédito valuada a valor razonable*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400205007')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400205007')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400205007) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400205007) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_250,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400706026')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400706026')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400706026) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400706026) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_251,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402607065')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402607065')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112402607065) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112402607065) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_252,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402607066')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402607066')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112402607066) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112402607066) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_253,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402607067')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402607067')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112402607067) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112402607067) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_254,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400706027')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400706027')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400706027) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400706027) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_255,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400706028')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400706028')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400706028) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400706028) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_256,

/*Compras de cartera*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400205008')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400205008')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400205008) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400205008) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_257,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400806029')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400806029')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400806029) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400806029) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_258,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402907068')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402907068')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112402907068) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112402907068) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_259,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112406808075')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112406808075')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112406808075) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112406808075) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_260,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407509079')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407509079')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112407509079) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112407509079) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_261,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407509080')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407509080')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112407509080) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112407509080) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_262,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112406808076')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112406808076')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112406808076) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112406808076) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_263,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407609081')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407609081')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112407609081) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112407609081) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_264,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407609082')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407609082')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112407609082) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112407609082) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_265,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407609083')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407609083')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112407609083) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112407609083) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_266,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112406808077')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112406808077')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112406808077) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112406808077) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_267,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407709084')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407709084')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112407709084) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112407709084) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_268,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407709085')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407709085')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112407709085) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112407709085) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_269,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112406808078')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112406808078')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112406808078) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112406808078) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_270,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112406808079')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112406808079')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112406808079) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112406808079) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_271,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112406808080')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112406808080')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112406808080) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112406808080) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_272,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112406808081')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112406808081')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112406808081) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112406808081) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_273,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112406808082')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112406808082')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112406808082) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112406808082) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_274,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402907069')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402907069')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112402907069) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112402907069) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_275,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112406908083')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112406908083')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112406908083) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112406908083) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_276,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408309086')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408309086')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408309086) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408309086) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_277,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408309087')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408309087')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408309087) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408309087) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_278,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408309088')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408309088')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408309088) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408309088) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_279,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112406908084')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112406908084')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112406908084) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112406908084) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_280,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408409089')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408409089')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408409089) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408409089) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_281,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408409090')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408409090')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408409090) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408409090) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_282,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408409091')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408409091')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408409091) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408409091) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_283,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402907070')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402907070')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112402907070) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112402907070) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_284,

/*Créditos al gobierno federal */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407008085')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407008085')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112407008085) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112407008085) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_285,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407008086')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407008086')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112407008086) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112407008086) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_286,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408609092')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408609092')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408609092) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408609092) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_287,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408609093')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408609093')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408609093) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408609093) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_288,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408609094')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408609094')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408609094) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408609094) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_289,

/*Fideicomisos públicos de contratación */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408609095')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408609095')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408609095) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408609095) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_290,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408609096')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408609096')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408609096) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408609096) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_291,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407008087')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407008087')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112407008087) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112407008087) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_292,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408709097')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408709097')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408709097) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408709097) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_293,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408709098')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408709098')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408709098) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408709098) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_294,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408709099')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408709099')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408709099) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408709099) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_295,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408709100')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408709100')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408709100) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408709100) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_296,

/*Créditos a organismos descentralizados o desconcentrados  */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407008088')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407008088')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112407008088) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112407008088) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_297,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408809101')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408809101')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408809101) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408809101) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_298,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408809102')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408809102')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408809102) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408809102) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_299,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408809103')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408809103')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408809103) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408809103) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_300
	
INTO IFRS9_R04A_0420_M15SALDOSTS1_RESULT_3
FROM IFRS9_R04A_0420

END

BEGIN
	INSERT INTO IFRS9_R04A_0420_M15SALDOSTS1_RESULT_3
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_201])),
            SUM(CHARINDEX('ERR',[VALIDACION_202])),
            SUM(CHARINDEX('ERR',[VALIDACION_203])),
            SUM(CHARINDEX('ERR',[VALIDACION_204])),
            SUM(CHARINDEX('ERR',[VALIDACION_205])),
            SUM(CHARINDEX('ERR',[VALIDACION_206])),
            SUM(CHARINDEX('ERR',[VALIDACION_207])),
            SUM(CHARINDEX('ERR',[VALIDACION_208])),
            SUM(CHARINDEX('ERR',[VALIDACION_209])),
            SUM(CHARINDEX('ERR',[VALIDACION_210])),
            SUM(CHARINDEX('ERR',[VALIDACION_211])),
            SUM(CHARINDEX('ERR',[VALIDACION_212])),
            SUM(CHARINDEX('ERR',[VALIDACION_213])),
            SUM(CHARINDEX('ERR',[VALIDACION_214])),
            SUM(CHARINDEX('ERR',[VALIDACION_215])),
            SUM(CHARINDEX('ERR',[VALIDACION_216])),
            SUM(CHARINDEX('ERR',[VALIDACION_217])),
            SUM(CHARINDEX('ERR',[VALIDACION_218])),
            SUM(CHARINDEX('ERR',[VALIDACION_219])),
            SUM(CHARINDEX('ERR',[VALIDACION_220])),
            SUM(CHARINDEX('ERR',[VALIDACION_221])),
            SUM(CHARINDEX('ERR',[VALIDACION_222])),
            SUM(CHARINDEX('ERR',[VALIDACION_223])),
            SUM(CHARINDEX('ERR',[VALIDACION_224])),
            SUM(CHARINDEX('ERR',[VALIDACION_225])),
            SUM(CHARINDEX('ERR',[VALIDACION_226])),
            SUM(CHARINDEX('ERR',[VALIDACION_227])),
            SUM(CHARINDEX('ERR',[VALIDACION_228])),
            SUM(CHARINDEX('ERR',[VALIDACION_229])),
            SUM(CHARINDEX('ERR',[VALIDACION_230])),
            SUM(CHARINDEX('ERR',[VALIDACION_231])),
            SUM(CHARINDEX('ERR',[VALIDACION_232])),
            SUM(CHARINDEX('ERR',[VALIDACION_233])),
            SUM(CHARINDEX('ERR',[VALIDACION_234])),
            SUM(CHARINDEX('ERR',[VALIDACION_235])),
            SUM(CHARINDEX('ERR',[VALIDACION_236])),
            SUM(CHARINDEX('ERR',[VALIDACION_237])),
            SUM(CHARINDEX('ERR',[VALIDACION_238])),
            SUM(CHARINDEX('ERR',[VALIDACION_239])),
            SUM(CHARINDEX('ERR',[VALIDACION_240])),
            SUM(CHARINDEX('ERR',[VALIDACION_241])),
            SUM(CHARINDEX('ERR',[VALIDACION_242])),
            SUM(CHARINDEX('ERR',[VALIDACION_243])),
            SUM(CHARINDEX('ERR',[VALIDACION_244])),
            SUM(CHARINDEX('ERR',[VALIDACION_245])),
            SUM(CHARINDEX('ERR',[VALIDACION_246])),
            SUM(CHARINDEX('ERR',[VALIDACION_247])),
            SUM(CHARINDEX('ERR',[VALIDACION_248])),
            SUM(CHARINDEX('ERR',[VALIDACION_249])),
            SUM(CHARINDEX('ERR',[VALIDACION_250])),
            SUM(CHARINDEX('ERR',[VALIDACION_251])),
            SUM(CHARINDEX('ERR',[VALIDACION_252])),
            SUM(CHARINDEX('ERR',[VALIDACION_253])),
            SUM(CHARINDEX('ERR',[VALIDACION_254])),
            SUM(CHARINDEX('ERR',[VALIDACION_255])),
            SUM(CHARINDEX('ERR',[VALIDACION_256])),
            SUM(CHARINDEX('ERR',[VALIDACION_257])),
            SUM(CHARINDEX('ERR',[VALIDACION_258])),
            SUM(CHARINDEX('ERR',[VALIDACION_259])),
            SUM(CHARINDEX('ERR',[VALIDACION_260])),
            SUM(CHARINDEX('ERR',[VALIDACION_261])),
            SUM(CHARINDEX('ERR',[VALIDACION_262])),
            SUM(CHARINDEX('ERR',[VALIDACION_263])),
            SUM(CHARINDEX('ERR',[VALIDACION_264])),
            SUM(CHARINDEX('ERR',[VALIDACION_265])),
            SUM(CHARINDEX('ERR',[VALIDACION_266])),
            SUM(CHARINDEX('ERR',[VALIDACION_267])),
            SUM(CHARINDEX('ERR',[VALIDACION_268])),
            SUM(CHARINDEX('ERR',[VALIDACION_269])),
            SUM(CHARINDEX('ERR',[VALIDACION_270])),
            SUM(CHARINDEX('ERR',[VALIDACION_271])),
            SUM(CHARINDEX('ERR',[VALIDACION_272])),
            SUM(CHARINDEX('ERR',[VALIDACION_273])),
            SUM(CHARINDEX('ERR',[VALIDACION_274])),
            SUM(CHARINDEX('ERR',[VALIDACION_275])),
            SUM(CHARINDEX('ERR',[VALIDACION_276])),
            SUM(CHARINDEX('ERR',[VALIDACION_277])),
            SUM(CHARINDEX('ERR',[VALIDACION_278])),
            SUM(CHARINDEX('ERR',[VALIDACION_279])),
            SUM(CHARINDEX('ERR',[VALIDACION_280])),
            SUM(CHARINDEX('ERR',[VALIDACION_281])),
            SUM(CHARINDEX('ERR',[VALIDACION_282])),
            SUM(CHARINDEX('ERR',[VALIDACION_283])),
            SUM(CHARINDEX('ERR',[VALIDACION_284])),
            SUM(CHARINDEX('ERR',[VALIDACION_285])),
            SUM(CHARINDEX('ERR',[VALIDACION_286])),
            SUM(CHARINDEX('ERR',[VALIDACION_287])),
            SUM(CHARINDEX('ERR',[VALIDACION_288])),
            SUM(CHARINDEX('ERR',[VALIDACION_289])),
            SUM(CHARINDEX('ERR',[VALIDACION_290])),
            SUM(CHARINDEX('ERR',[VALIDACION_291])),
            SUM(CHARINDEX('ERR',[VALIDACION_292])),
            SUM(CHARINDEX('ERR',[VALIDACION_293])),
            SUM(CHARINDEX('ERR',[VALIDACION_294])),
            SUM(CHARINDEX('ERR',[VALIDACION_295])),
            SUM(CHARINDEX('ERR',[VALIDACION_296])),
            SUM(CHARINDEX('ERR',[VALIDACION_297])),
            SUM(CHARINDEX('ERR',[VALIDACION_298])),
            SUM(CHARINDEX('ERR',[VALIDACION_299])),
            SUM(CHARINDEX('ERR',[VALIDACION_300]))
            


		from IFRS9_R04A_0420_M15SALDOSTS1_RESULT_3
END

BEGIN
	EXEC SP_IFRS9_R04A_0420_M15SALDOSTS1_VIEW_3
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


