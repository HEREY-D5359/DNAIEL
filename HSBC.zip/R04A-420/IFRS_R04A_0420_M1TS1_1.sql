﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapa 3 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 1*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0420_M1TS1_COMP_1]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0420_M1TS1_RESULT_1')
BEGIN
DROP TABLE IFRS9_R04A_0420_M1TS1_RESULT_1
END 

BEGIN
SELECT DISTINCT
         /*id*/
CONVERT(VARCHAR,ID) AS ID, 
	/*Saldo inicial de cartera con riesgo de crédito etapa 3*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400104001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400105001','112400105002','112400105003')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400104001) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112400105001 + 112400105002 + 112400105003) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_1,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400105001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400106001','112400106002','112400106003')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400105001) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112400106001 + 112400106002 + 112400106003) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_2,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400106001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400107001','112400107002','112400107003','112400107004','112400107005','112400107006','112400107007','112400107008')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400106001) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112400107001 + 112400107002 + 112400107003 + 112400107004 + 112400107005 + 112400107006 + 112400107007 + 112400107008) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_3,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400107001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400108001','112400108002')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400107001) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112400108001 + 112400108002) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_4,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400107002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400208003','112400208004','112400208005')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400107002) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112400208003 + 112400208004 + 112400208005) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_5,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400107003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400308006','112400308007')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400107003) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112400308006 + 112400308007) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_6,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400106002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400207009','112400207010')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400106002) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112400207009 + 112400207010) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_7,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400207009')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400908008','112400908009','112400908010')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400207009) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112400908008 + 112400908009 + 112400908010) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_8,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400207010')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401008011','112401008012','112401008013')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400207010) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112401008011 + 112401008012 + 112401008013) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_9,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400106003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400307011','112400307012','112400307013','112400307014')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400106003) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112400307011 + 112400307012 + 112400307013 + 112400307014) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_10,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400307012')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401208014','112401208015','112401208016','112401208017','112401208018')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400307012) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112401208014 + 112401208015 + 112401208016 + 112401208017 + 112401208018) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_11,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400307013')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401308019','112401308020','112401308021','112401308022')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400307013) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112401308019 + 112401308020 + 112401308021 + 112401308022) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_12,

/*Créditos a organismos descentralizados o desconcentrados  */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400307014')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401408023','112401408024','112401408025','112401408026')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400307014) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112401408023 + 112401408024 + 112401408025 + 112401408026) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_13,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400105002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400206004','112400206005','112400206006','112400206007','112400206008','112400206009','112400206010','112400206011')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400105002) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112400206004 + 112400206005 + 112400206006 + 112400206007 + 112400206008 + 112400206009 + 112400206010 + 112400206011) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_14,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400105003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400306012','112400306013','112400306014','112400306015','112400306016')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400105003) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112400306012 + 112400306013 + 112400306014 + 112400306015 + 112400306016) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_15,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400306014')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401407015','112401407016')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400306014) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112401407015 + 112401407016) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_16,

/*Entradas a cartera con riesgo de crédito etapa 3*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400104002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400205004','112400205005','112400205006','112400205007','112400205008','112400205009','112400205010','112400205011')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400104002) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112400205004 + 112400205005 + 112400205006 + 112400205007 + 112400205008 + 112400205009 + 112400205010 + 112400205011) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_17,

/*Reestructuras y renovaciones  (1)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400205004')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400406017','112400406018','112400406019')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400205004) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112400406017 + 112400406018 + 112400406019) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_18,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400406017')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401707017','112401707018','112401707019')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400406017) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112401707017 + 112401707018 + 112401707019) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_19,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401707017')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401708027','112401708028','112401708029','112401708030','112401708031','112401708032','112401708033','112401708034')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401707017) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112401708027 + 112401708028 + 112401708029 + 112401708030 + 112401708031 + 112401708032 + 112401708033 + 112401708034) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_20,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401708027')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402709001','112402709002')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401708027) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112402709001 + 112402709002) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_21,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401708028')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402809003','112402809004','112402809005')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401708028) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112402809003 + 112402809004 + 112402809005) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_22,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401708029')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402909006','112402909007')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401708029) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112402909006 + 112402909007) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_23,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401707018')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401808035','112401808036')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401707018) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112401808035 + 112401808036) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_24,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401808035')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403509008','112403509009','112403509010')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401808035) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112403509008 + 112403509009 + 112403509010) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_25,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401808036')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403609011','112403609012','112403609013')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401808036) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112403609011 + 112403609012 + 112403609013) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_26,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401707019')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401908037','112401908038','112401908039','112401908040')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401707019) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112401908037 + 112401908038 + 112401908039 + 112401908040) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_27,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401908038')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403809014','112403809015','112403809016','112403809017','112403809018')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401908038) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112403809014 + 112403809015 + 112403809016 + 112403809017 + 112403809018) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_28,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401908039')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403909019','112403909020','112403909021','112403909022')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401908039) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112403909019 + 112403909020 + 112403909021 + 112403909022) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_29,

/*Créditos a organismos descentralizados o desconcentrados  */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401908040')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112404009023','112404009024','112404009025','112404009026')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401908040) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112404009023 + 112404009024 + 112404009025 + 112404009026) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_30,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400406018')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401807020','112401807021','112401807022','112401807023','112401807024','112401807025','112401807026','112401807027')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400406018) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112401807020 + 112401807021 + 112401807022 + 112401807023 + 112401807024 + 112401807025 + 112401807026 + 112401807027) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_31,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400406019')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401907028','112401907029','112401907030','112401907031','112401907032')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400406019) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112401907028 + 112401907029 + 112401907030 + 112401907031 + 112401907032) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_32,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401907030')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403008041','112403008042')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401907030) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112403008041 + 112403008042) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_33,

/*Traspaso de cartera con riesgo de crédito etapa 1*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400205005')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400506020','112400506021','112400506022')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400205005) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112400506020 + 112400506021 + 112400506022) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_34,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400506020')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402007033','112402007034','112402007035')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400506020) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112402007033 + 112402007034 + 112402007035) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_35,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402007033')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403308043','112403308044','112403308045','112403308046','112403308047','112403308048','112403308049','112403308050')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112402007033) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112403308043 + 112403308044 + 112403308045 + 112403308046 + 112403308047 + 112403308048 + 112403308049 + 112403308050) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_36,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403308043')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112404309027','112404309028')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112403308043) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112404309027 + 112404309028) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_37,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403308044')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112404409029','112404409030','112404409031')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112403308044) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112404409029 + 112404409030 + 112404409031) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_38,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403308045')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112404509032','112404509033')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112403308045) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112404509032 + 112404509033) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_39,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402007034')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403408051','112403408052')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112402007034) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112403408051 + 112403408052) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_40,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403408051')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112405109034','112405109035','112405109036')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112403408051) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112405109034 + 112405109035 + 112405109036) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_41,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403408052')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112405209037','112405209038','112405209039')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112403408052) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112405209037 + 112405209038 + 112405209039) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_42,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402007035')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403508053','112403508054','112403508055','112403508056')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112402007035) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112403508053 + 112403508054 + 112403508055 + 112403508056) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_43,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403508054')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112405409040','112405409041','112405409042','112405409043','112405409044')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112403508054) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112405409040 + 112405409041 + 112405409042 + 112405409043 + 112405409044) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_44,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403508055')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112405509045','112405509046','112405509047','112405509048')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112403508055) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112405509045 + 112405509046 + 112405509047 + 112405509048) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_45,

/*Créditos a organismos descentralizados o desconcentrados  */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403508056')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112405609049','112405609050','112405609051','112405609052')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112403508056) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112405609049 + 112405609050 + 112405609051 + 112405609052) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_46,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400506021')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402107036','112402107037','112402107038','112402107039','112402107040','112402107041','112402107042','112402107043')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400506021) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112402107036 + 112402107037 + 112402107038 + 112402107039 + 112402107040 + 112402107041 + 112402107042 + 112402107043) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_47,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400506022')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402207044','112402207045','112402207046','112402207047','112402207048')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400506022) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112402207044 + 112402207045 + 112402207046 + 112402207047 + 112402207048) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_48,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402207046')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112404608057','112404608058')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112402207046) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112404608057 + 112404608058) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_49,

/*Traspaso de cartera con riesgo de crédito etapa 2*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400205006')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400606023','112400606024','112400606025')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400205006) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112400606023 + 112400606024 + 112400606025) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_50,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400606023')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402307049','112402307050','112402307051')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400606023) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112402307049 + 112402307050 + 112402307051) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_51,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402307049')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112404908059','112404908060','112404908061','112404908062','112404908063','112404908064','112404908065','112404908066')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112402307049) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112404908059 + 112404908060 + 112404908061 + 112404908062 + 112404908063 + 112404908064 + 112404908065 + 112404908066) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_52,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112404908059')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112405909053','112405909054')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112404908059) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112405909053 + 112405909054) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_53,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112404908060')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112406009055','112406009056','112406009057')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112404908060) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112406009055 + 112406009056 + 112406009057) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_54,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112404908061')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112406109058','112406109059')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112404908061) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112406109058 + 112406109059) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_55,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402307050')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112405008067','112405008068')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112402307050) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112405008067 + 112405008068) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_56,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112405008067')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112406709060','112406709061','112406709062')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112405008067) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112406709060 + 112406709061 + 112406709062) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_57,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112405008068')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112406809063','112406809064','112406809065')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112405008068) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112406809063 + 112406809064 + 112406809065) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_58,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402307051')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112405108069','112405108070','112405108071','112405108072')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112402307051) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112405108069 + 112405108070 + 112405108071 + 112405108072) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_59,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112405108070')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407009066','112407009067','112407009068','112407009069','112407009070')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112405108070) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112407009066 + 112407009067 + 112407009068 + 112407009069 + 112407009070) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_60,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112405108071')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407109071','112407109072','112407109073','112407109074')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112405108071) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112407109071 + 112407109072 + 112407109073 + 112407109074) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_61,

/*Créditos a organismos descentralizados o desconcentrados  */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112405108072')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407209075','112407209076','112407209077','112407209078')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112405108072) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112407209075 + 112407209076 + 112407209077 + 112407209078) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_62,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400606024')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402407052','112402407053','112402407054','112402407055','112402407056','112402407057','112402407058','112402407059')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400606024) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112402407052 + 112402407053 + 112402407054 + 112402407055 + 112402407056 + 112402407057 + 112402407058 + 112402407059) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_63,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400606025')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402507060','112402507061','112402507062','112402507063','112402507064')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400606025) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112402507060 + 112402507061 + 112402507062 + 112402507063 + 112402507064) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_64,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402507062')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112406208073','112406208074')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112402507062) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112406208073 + 112406208074) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_65,

/*Traspaso de cartera de crédito valuada a valor razonable*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400205007')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400706026','112400706027','112400706028')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400205007) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112400706026 + 112400706027 + 112400706028) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_66,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400706026')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402607065','112402607066','112402607067')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400706026) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112402607065 + 112402607066 + 112402607067) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_67,

/*Compras de cartera*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400205008')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400806029','112400806030','112400806031')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400205008) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112400806029 + 112400806030 + 112400806031) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_68,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400806029')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402907068','112402907069','112402907070')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400806029) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112402907068 + 112402907069 + 112402907070) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_69,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402907068')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112406808075','112406808076','112406808077','112406808078','112406808079','112406808080','112406808081','112406808082')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112402907068) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112406808075 + 112406808076 + 112406808077 + 112406808078 + 112406808079 + 112406808080 + 112406808081 + 112406808082) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_70,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112406808075')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407509079','112407509080')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112406808075) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112407509079 + 112407509080) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_71,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112406808076')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407609081','112407609082','112407609083')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112406808076) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112407609081 + 112407609082 + 112407609083) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_72,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112406808077')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407709084','112407709085')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112406808077) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112407709084 + 112407709085) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_73,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402907069')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112406908083','112406908084')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112402907069) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112406908083 + 112406908084) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_74,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112406908083')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408309086','112408309087','112408309088')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112406908083) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112408309086 + 112408309087 + 112408309088) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_75,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112406908084')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408409089','112408409090','112408409091')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112406908084) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112408409089 + 112408409090 + 112408409091) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_76,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402907070')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407008085','112407008086','112407008087','112407008088')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112402907070) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112407008085 + 112407008086 + 112407008087 + 112407008088) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_77,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407008086')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408609092','112408609093','112408609094','112408609095','112408609096')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112407008086) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112408609092 + 112408609093 + 112408609094 + 112408609095 + 112408609096) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_78,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407008087')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408709097','112408709098','112408709099','112408709100')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112407008087) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112408709097 + 112408709098 + 112408709099 + 112408709100) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_79,

/*Créditos a organismos descentralizados o desconcentrados  */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407008088')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408809101','112408809102','112408809103','112408809104')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112407008088) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112408809101 + 112408809102 + 112408809103 + 112408809104) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_80,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400806030')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403007071','112403007072','112403007073','112403007074','112403007075','112403007076','112403007077','112403007078')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400806030) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112403007071 + 112403007072 + 112403007073 + 112403007074 + 112403007075 + 112403007076 + 112403007077 + 112403007078) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_81,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400806031')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403107079','112403107080','112403107081','112403107082','112403107083')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400806031) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112403107079 + 112403107080 + 112403107081 + 112403107082 + 112403107083) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_82,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403107081')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408108089','112408108090')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112403107081) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112408108089 + 112408108090) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_83,

/*Intereses devengados no cobrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400205009')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400906032','112400906033','112400906034')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400205009) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112400906032 + 112400906033 + 112400906034) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_84,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400906032')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403207084','112403207085','112403207086')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400906032) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112403207084 + 112403207085 + 112403207086) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_85,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403207084')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408408091','112408408092','112408408093','112408408094','112408408095','112408408096','112408408097','112408408098')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112403207084) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112408408091 + 112408408092 + 112408408093 + 112408408094 + 112408408095 + 112408408096 + 112408408097 + 112408408098) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_86,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408408091')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112409109105','112409109106')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112408408091) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112409109105 + 112409109106) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_87,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408408092')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112409209107','112409209108','112409209109')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112408408092) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112409209107 + 112409209108 + 112409209109) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_88,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408408093')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112409309110','112409309111')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112408408093) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112409309110 + 112409309111) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_89,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403207085')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408508099','112408508100')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112403207085) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112408508099 + 112408508100) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_90,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408508099')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112409909112','112409909113','112409909114')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112408508099) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112409909112 + 112409909113 + 112409909114) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_91,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408508100')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410009115','112410009116','112410009117')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112408508100) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112410009115 + 112410009116 + 112410009117) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_92,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403207086')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408608101','112408608102','112408608103','112408608104')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112403207086) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112408608101 + 112408608102 + 112408608103 + 112408608104) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_93,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408608102')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410209118','112410209119','112410209120','112410209121','112410209122')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112408608102) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112410209118 + 112410209119 + 112410209120 + 112410209121 + 112410209122) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_94,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408608103')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410309123','112410309124','112410309125','112410309126')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112408608103) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112410309123 + 112410309124 + 112410309125 + 112410309126) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_95,

/*Créditos a organismos descentralizados o desconcentrados  */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408608104')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410409127','112410409128','112410409129','112410409130')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112408608104) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112410409127 + 112410409128 + 112410409129 + 112410409130) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_96,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400906033')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403307087','112403307088','112403307089','112403307090','112403307091','112403307092','112403307093','112403307094')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400906033) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112403307087 + 112403307088 + 112403307089 + 112403307090 + 112403307091 + 112403307092 + 112403307093 + 112403307094) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_97,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400906034')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403407095','112403407096','112403407097','112403407098','112403407099')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400906034) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112403407095 + 112403407096 + 112403407097 + 112403407098 + 112403407099) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_98,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403407097')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112409708105','112409708106')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112403407097) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112409708105 + 112409708106) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_99,

/*Por sobregiros en cuentas de cheques que no cuenten con línea de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400205010')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401006035','112401006036','112401006037')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400205010) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112401006035 + 112401006036 + 112401006037) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_100
	
INTO IFRS9_R04A_0420_M1TS1_RESULT_1
FROM IFRS9_R04A_0420

END

BEGIN
	INSERT INTO IFRS9_R04A_0420_M1TS1_RESULT_1
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_1])),
            SUM(CHARINDEX('ERR',[VALIDACION_2])),
            SUM(CHARINDEX('ERR',[VALIDACION_3])),
            SUM(CHARINDEX('ERR',[VALIDACION_4])),
            SUM(CHARINDEX('ERR',[VALIDACION_5])),
            SUM(CHARINDEX('ERR',[VALIDACION_6])),
            SUM(CHARINDEX('ERR',[VALIDACION_7])),
            SUM(CHARINDEX('ERR',[VALIDACION_8])),
            SUM(CHARINDEX('ERR',[VALIDACION_9])),
            SUM(CHARINDEX('ERR',[VALIDACION_10])),
            SUM(CHARINDEX('ERR',[VALIDACION_11])),
            SUM(CHARINDEX('ERR',[VALIDACION_12])),
            SUM(CHARINDEX('ERR',[VALIDACION_13])),
            SUM(CHARINDEX('ERR',[VALIDACION_14])),
            SUM(CHARINDEX('ERR',[VALIDACION_15])),
            SUM(CHARINDEX('ERR',[VALIDACION_16])),
            SUM(CHARINDEX('ERR',[VALIDACION_17])),
            SUM(CHARINDEX('ERR',[VALIDACION_18])),
            SUM(CHARINDEX('ERR',[VALIDACION_19])),
            SUM(CHARINDEX('ERR',[VALIDACION_20])),
            SUM(CHARINDEX('ERR',[VALIDACION_21])),
            SUM(CHARINDEX('ERR',[VALIDACION_22])),
            SUM(CHARINDEX('ERR',[VALIDACION_23])),
            SUM(CHARINDEX('ERR',[VALIDACION_24])),
            SUM(CHARINDEX('ERR',[VALIDACION_25])),
            SUM(CHARINDEX('ERR',[VALIDACION_26])),
            SUM(CHARINDEX('ERR',[VALIDACION_27])),
            SUM(CHARINDEX('ERR',[VALIDACION_28])),
            SUM(CHARINDEX('ERR',[VALIDACION_29])),
            SUM(CHARINDEX('ERR',[VALIDACION_30])),
            SUM(CHARINDEX('ERR',[VALIDACION_31])),
            SUM(CHARINDEX('ERR',[VALIDACION_32])),
            SUM(CHARINDEX('ERR',[VALIDACION_33])),
            SUM(CHARINDEX('ERR',[VALIDACION_34])),
            SUM(CHARINDEX('ERR',[VALIDACION_35])),
            SUM(CHARINDEX('ERR',[VALIDACION_36])),
            SUM(CHARINDEX('ERR',[VALIDACION_37])),
            SUM(CHARINDEX('ERR',[VALIDACION_38])),
            SUM(CHARINDEX('ERR',[VALIDACION_39])),
            SUM(CHARINDEX('ERR',[VALIDACION_40])),
            SUM(CHARINDEX('ERR',[VALIDACION_41])),
            SUM(CHARINDEX('ERR',[VALIDACION_42])),
            SUM(CHARINDEX('ERR',[VALIDACION_43])),
            SUM(CHARINDEX('ERR',[VALIDACION_44])),
            SUM(CHARINDEX('ERR',[VALIDACION_45])),
            SUM(CHARINDEX('ERR',[VALIDACION_46])),
            SUM(CHARINDEX('ERR',[VALIDACION_47])),
            SUM(CHARINDEX('ERR',[VALIDACION_48])),
            SUM(CHARINDEX('ERR',[VALIDACION_49])),
            SUM(CHARINDEX('ERR',[VALIDACION_50])),
            SUM(CHARINDEX('ERR',[VALIDACION_51])),
            SUM(CHARINDEX('ERR',[VALIDACION_52])),
            SUM(CHARINDEX('ERR',[VALIDACION_53])),
            SUM(CHARINDEX('ERR',[VALIDACION_54])),
            SUM(CHARINDEX('ERR',[VALIDACION_55])),
            SUM(CHARINDEX('ERR',[VALIDACION_56])),
            SUM(CHARINDEX('ERR',[VALIDACION_57])),
            SUM(CHARINDEX('ERR',[VALIDACION_58])),
            SUM(CHARINDEX('ERR',[VALIDACION_59])),
            SUM(CHARINDEX('ERR',[VALIDACION_60])),
            SUM(CHARINDEX('ERR',[VALIDACION_61])),
            SUM(CHARINDEX('ERR',[VALIDACION_62])),
            SUM(CHARINDEX('ERR',[VALIDACION_63])),
            SUM(CHARINDEX('ERR',[VALIDACION_64])),
            SUM(CHARINDEX('ERR',[VALIDACION_65])),
            SUM(CHARINDEX('ERR',[VALIDACION_66])),
            SUM(CHARINDEX('ERR',[VALIDACION_67])),
            SUM(CHARINDEX('ERR',[VALIDACION_68])),
            SUM(CHARINDEX('ERR',[VALIDACION_69])),
            SUM(CHARINDEX('ERR',[VALIDACION_70])),
            SUM(CHARINDEX('ERR',[VALIDACION_71])),
            SUM(CHARINDEX('ERR',[VALIDACION_72])),
            SUM(CHARINDEX('ERR',[VALIDACION_73])),
            SUM(CHARINDEX('ERR',[VALIDACION_74])),
            SUM(CHARINDEX('ERR',[VALIDACION_75])),
            SUM(CHARINDEX('ERR',[VALIDACION_76])),
            SUM(CHARINDEX('ERR',[VALIDACION_77])),
            SUM(CHARINDEX('ERR',[VALIDACION_78])),
            SUM(CHARINDEX('ERR',[VALIDACION_79])),
            SUM(CHARINDEX('ERR',[VALIDACION_80])),
            SUM(CHARINDEX('ERR',[VALIDACION_81])),
            SUM(CHARINDEX('ERR',[VALIDACION_82])),
            SUM(CHARINDEX('ERR',[VALIDACION_83])),
            SUM(CHARINDEX('ERR',[VALIDACION_84])),
            SUM(CHARINDEX('ERR',[VALIDACION_85])),
            SUM(CHARINDEX('ERR',[VALIDACION_86])),
            SUM(CHARINDEX('ERR',[VALIDACION_87])),
            SUM(CHARINDEX('ERR',[VALIDACION_88])),
            SUM(CHARINDEX('ERR',[VALIDACION_89])),
            SUM(CHARINDEX('ERR',[VALIDACION_90])),
            SUM(CHARINDEX('ERR',[VALIDACION_91])),
            SUM(CHARINDEX('ERR',[VALIDACION_92])),
            SUM(CHARINDEX('ERR',[VALIDACION_93])),
            SUM(CHARINDEX('ERR',[VALIDACION_94])),
            SUM(CHARINDEX('ERR',[VALIDACION_95])),
            SUM(CHARINDEX('ERR',[VALIDACION_96])),
            SUM(CHARINDEX('ERR',[VALIDACION_97])),
            SUM(CHARINDEX('ERR',[VALIDACION_98])),
            SUM(CHARINDEX('ERR',[VALIDACION_99])),
            SUM(CHARINDEX('ERR',[VALIDACION_100]))
            


		from IFRS9_R04A_0420_M1TS1_RESULT_1
END

BEGIN
	EXEC SP_IFRS9_R04A_0420_M1TS1_VIEW_1
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


