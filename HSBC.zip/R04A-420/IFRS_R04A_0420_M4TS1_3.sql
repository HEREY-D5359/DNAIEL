﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapa 3 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 4*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0420_M4TS1_COMP_3]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0420_M4TS1_RESULT_3')
BEGIN
DROP TABLE IFRS9_R04A_0420_M4TS1_RESULT_3
END 

BEGIN
SELECT DISTINCT
         /*id*/
CONVERT(VARCHAR,ID) AS ID, 
	/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112420309257')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112425710079','112425710080')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112420309257) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112425710079 + 112425710080) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_201,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112420309258')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112425810081','112425810082','112425810083')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112420309258) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112425810081 + 112425810082 + 112425810083) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_202,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112420309259')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112425910084','112425910085')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112420309259) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112425910084 + 112425910085) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_203,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112415708204')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112420409265','112420409266')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112415708204) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112420409265 + 112420409266) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_204,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112420409265')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112426510086','112426510087','112426510088')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112420409265) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112426510086 + 112426510087 + 112426510088) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_205,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112420409266')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112426610089','112426610090','112426610091')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112420409266) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112426610089 + 112426610090 + 112426610091) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_206,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112415708205')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112420509267','112420509268','112420509269','112420509270')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112415708205) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112420509267 + 112420509268 + 112420509269 + 112420509270) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_207,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112420509268')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112426810092','112426810093','112426810094','112426810095','112426810096')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112420509268) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112426810092 + 112426810093 + 112426810094 + 112426810095 + 112426810096) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_208,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112420509269')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112426910097','112426910098','112426910099','112426910100')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112420509269) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112426910097 + 112426910098 + 112426910099 + 112426910100) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_209,

/*Créditos a organismos descentralizados o desconcentrados  */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112420509270')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112427010101','112427010102','112427010103','112427010104')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112420509270) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112427010101 + 112427010102 + 112427010103 + 112427010104) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_210,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112404707158')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112415808206','112415808207','112415808208','112415808209','112415808210','112415808211','112415808212','112415808213')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112404707158) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112415808206 + 112415808207 + 112415808208 + 112415808209 + 112415808210 + 112415808211 + 112415808212 + 112415808213) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_211,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112404707159')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112415908214','112415908215','112415908216','112415908217','112415908218')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112404707159) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112415908214 + 112415908215 + 112415908216 + 112415908217 + 112415908218) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_212,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112415908216')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112421609271','112421609272')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112415908216) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112421609271 + 112421609272) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_213,

/*Bonificaciones y descuentos sobre (3)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401306048')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112404807160','112404807161','112404807162')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401306048) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112404807160 + 112404807161 + 112404807162) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_214,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112404807160')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112416008219','112416008220','112416008221')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112404807160) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112416008219 + 112416008220 + 112416008221) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_215,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112416008219')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112421909273','112421909274','112421909275','112421909276','112421909277','112421909278','112421909279','112421909280')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112416008219) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112421909273 + 112421909274 + 112421909275 + 112421909276 + 112421909277 + 112421909278 + 112421909279 + 112421909280) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_216,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112421909273')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112427310105','112427310106')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112421909273) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112427310105 + 112427310106) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_217,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112421909274')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112427410107','112427410108','112427410109')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112421909274) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112427410107 + 112427410108 + 112427410109) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_218,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112421909275')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112427510110','112427510111')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112421909275) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112427510110 + 112427510111) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_219,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112416008220')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112422009281','112422009282')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112416008220) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112422009281 + 112422009282) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_220,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112422009281')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112428110112','112428110113','112428110114')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112422009281) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112428110112 + 112428110113 + 112428110114) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_221,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112422009282')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112428210115','112428210116','112428210117')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112422009282) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112428210115 + 112428210116 + 112428210117) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_222,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112416008221')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112422109283','112422109284','112422109285','112422109286')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112416008221) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112422109283 + 112422109284 + 112422109285 + 112422109286) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_223,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112422109284')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112428410118','112428410119','112428410120','112428410121','112428410122')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112422109284) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112428410118 + 112428410119 + 112428410120 + 112428410121 + 112428410122) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_224,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112422109285')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112428510123','112428510124','112428510125','112428510126')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112422109285) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112428510123 + 112428510124 + 112428510125 + 112428510126) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_225,

/*Créditos a organismos descentralizados o desconcentrados  */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112422109286')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112428610127','112428610128','112428610129','112428610130')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112422109286) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112428610127 + 112428610128 + 112428610129 + 112428610130) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_226,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112404807161')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112416108222','112416108223','112416108224','112416108225','112416108226','112416108227','112416108228','112416108229')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112404807161) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112416108222 + 112416108223 + 112416108224 + 112416108225 + 112416108226 + 112416108227 + 112416108228 + 112416108229) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_227,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112404807162')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112416208230','112416208231','112416208232','112416208233','112416208234')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112404807162) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112416208230 + 112416208231 + 112416208232 + 112416208233 + 112416208234) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_228,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112416208232')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112423209287','112423209288')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112416208232) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112423209287 + 112423209288) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_229,

/*Ventas de cartera (5)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400305014')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401406049','112401406050','112401406051')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400305014) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112401406049 + 112401406050 + 112401406051) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_230,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401406049')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112404907163','112404907164','112404907165')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401406049) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112404907163 + 112404907164 + 112404907165) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_231,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112404907163')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112416308235','112416308236','112416308237','112416308238','112416308239','112416308240','112416308241','112416308242')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112404907163) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112416308235 + 112416308236 + 112416308237 + 112416308238 + 112416308239 + 112416308240 + 112416308241 + 112416308242) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_232,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112416308235')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112423509289','112423509290')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112416308235) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112423509289 + 112423509290) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_233,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112416308236')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112423609291','112423609292','112423609293')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112416308236) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112423609291 + 112423609292 + 112423609293) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_234,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112416308237')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112423709294','112423709295')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112416308237) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112423709294 + 112423709295) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_235,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112404907164')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112416408243','112416408244')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112404907164) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112416408243 + 112416408244) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_236,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112416408243')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112424309296','112424309297','112424309298')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112416408243) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112424309296 + 112424309297 + 112424309298) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_237,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112416408244')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112424409299','112424409300','112424409301')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112416408244) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112424409299 + 112424409300 + 112424409301) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_238,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112404907165')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112416508245','112416508246','112416508247','112416508248')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112404907165) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112416508245 + 112416508246 + 112416508247 + 112416508248) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_239,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112416508246')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112424609302','112424609303','112424609304','112424609305','112424609306')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112416508246) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112424609302 + 112424609303 + 112424609304 + 112424609305 + 112424609306) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_240,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112416508247')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112424709307','112424709308','112424709309','112424709310')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112416508247) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112424709307 + 112424709308 + 112424709309 + 112424709310) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_241,

/*Créditos a organismos descentralizados o desconcentrados  */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112416508248')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112424809311','112424809312','112424809313','112424809314')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112416508248) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112424809311 + 112424809312 + 112424809313 + 112424809314) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_242,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401406050')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112405007166','112405007167','112405007168','112405007169','112405007170','112405007171','112405007172','112405007173')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401406050) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112405007166 + 112405007167 + 112405007168 + 112405007169 + 112405007170 + 112405007171 + 112405007172 + 112405007173) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_243,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401406051')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112405107174','112405107175','112405107176','112405107177','112405107178')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401406051) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112405107174 + 112405107175 + 112405107176 + 112405107177 + 112405107178) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_244,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112405107176')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112417608249','112417608250')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112405107176) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112417608249 + 112417608250) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_245,

/*Traspaso a cartera con riesgo de crédito etapa 1*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400305015')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401506052','112401506053','112401506054')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400305015) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112401506052 + 112401506053 + 112401506054) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_246,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401506052')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112405207179','112405207180','112405207181')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401506052) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112405207179 + 112405207180 + 112405207181) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_247,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112405207179')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112417908251','112417908252','112417908253','112417908254','112417908255','112417908256','112417908257','112417908258')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112405207179) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112417908251 + 112417908252 + 112417908253 + 112417908254 + 112417908255 + 112417908256 + 112417908257 + 112417908258) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_248,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112417908251')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112425109315','112425109316')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112417908251) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112425109315 + 112425109316) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_249,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112417908252')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112425209317','112425209318','112425209319')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112417908252) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112425209317 + 112425209318 + 112425209319) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_250,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112417908253')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112425309320','112425309321')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112417908253) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112425309320 + 112425309321) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_251,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112405207180')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112418008259','112418008260')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112405207180) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112418008259 + 112418008260) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_252,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112418008259')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112425909322','112425909323','112425909324')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112418008259) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112425909322 + 112425909323 + 112425909324) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_253,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112418008260')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112426009325','112426009326','112426009327')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112418008260) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112426009325 + 112426009326 + 112426009327) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_254,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112405207181')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112418108261','112418108262','112418108263','112418108264')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112405207181) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112418108261 + 112418108262 + 112418108263 + 112418108264) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_255,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112418108262')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112426209328','112426209329','112426209330','112426209331','112426209332')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112418108262) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112426209328 + 112426209329 + 112426209330 + 112426209331 + 112426209332) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_256,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112418108263')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112426309333','112426309334','112426309335','112426309336')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112418108263) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112426309333 + 112426309334 + 112426309335 + 112426309336) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_257,

/*Créditos a organismos descentralizados o desconcentrados  */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112418108264')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112426409337','112426409338','112426409339','112426409340')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112418108264) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112426409337 + 112426409338 + 112426409339 + 112426409340) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_258,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401506053')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112405307182','112405307183','112405307184','112405307185','112405307186','112405307187','112405307188','112405307189')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401506053) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112405307182 + 112405307183 + 112405307184 + 112405307185 + 112405307186 + 112405307187 + 112405307188 + 112405307189) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_259,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401506054')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112405407190','112405407191','112405407192','112405407193','112405407194')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401506054) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112405407190 + 112405407191 + 112405407192 + 112405407193 + 112405407194) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_260,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112405407192')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112419208265','112419208266')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112405407192) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112419208265 + 112419208266) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_261,

/*Traspaso a cartera con riesgo de crédito etapa 2*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400305016')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401606055','112401606056','112401606057')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400305016) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112401606055 + 112401606056 + 112401606057) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_262,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401606055')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112405507195','112405507196','112405507197')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401606055) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112405507195 + 112405507196 + 112405507197) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_263,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112405507195')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112419508267','112419508268','112419508269','112419508270','112419508271','112419508272','112419508273','112419508274')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112405507195) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112419508267 + 112419508268 + 112419508269 + 112419508270 + 112419508271 + 112419508272 + 112419508273 + 112419508274) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_264,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112419508267')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112426709341','112426709342')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112419508267) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112426709341 + 112426709342) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_265,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112419508268')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112426809343','112426809344','112426809345')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112419508268) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112426809343 + 112426809344 + 112426809345) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_266,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112419508269')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112426909346','112426909347')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112419508269) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112426909346 + 112426909347) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_267,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112405507196')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112419608275','112419608276')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112405507196) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112419608275 + 112419608276) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_268,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112419608275')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112427509348','112427509349','112427509350')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112419608275) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112427509348 + 112427509349 + 112427509350) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_269,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112419608276')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112427609351','112427609352','112427609353')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112419608276) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112427609351 + 112427609352 + 112427609353) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_270,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112405507197')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112419708277','112419708278','112419708279','112419708280')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112405507197) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112419708277 + 112419708278 + 112419708279 + 112419708280) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_271,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112419708278')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112427809354','112427809355','112427809356','112427809357','112427809358')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112419708278) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112427809354 + 112427809355 + 112427809356 + 112427809357 + 112427809358) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_272,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112419708279')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112427909359','112427909360','112427909361','112427909362')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112419708279) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112427909359 + 112427909360 + 112427909361 + 112427909362) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_273,

/*Créditos a organismos descentralizados o desconcentrados  */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112419708280')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112428009363','112428009364','112428009365','112428009366')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112419708280) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112428009363 + 112428009364 + 112428009365 + 112428009366) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_274,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401606056')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112405607198','112405607199','112405607200','112405607201','112405607202','112405607203','112405607204','112405607205')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401606056) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112405607198 + 112405607199 + 112405607200 + 112405607201 + 112405607202 + 112405607203 + 112405607204 + 112405607205) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_275,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401606057')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112405707206','112405707207','112405707208','112405707209','112405707210')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401606057) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112405707206 + 112405707207 + 112405707208 + 112405707209 + 112405707210) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_276,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112405707208')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112420808281','112420808282')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112405707208) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112420808281 + 112420808282) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_277,

/*Traspaso a cartera de crédito valuada a valor razonable*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400305017')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401706058','112401706059','112401706060')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400305017) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112401706058 + 112401706059 + 112401706060) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_278,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401706058')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112405807211','112405807212','112405807213')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401706058) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112405807211 + 112405807212 + 112405807213) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_279,

/*Ajuste cambiario etapa 3*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400104004')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400405018','112400405019','112400405020')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400104004) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112400405018 + 112400405019 + 112400405020) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_280,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400405018')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401806061','112401806062','112401806063')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400405018) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112401806061 + 112401806062 + 112401806063) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_281,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401806061')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112406107214','112406107215','112406107216','112406107217','112406107218','112406107219','112406107220','112406107221')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401806061) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112406107214 + 112406107215 + 112406107216 + 112406107217 + 112406107218 + 112406107219 + 112406107220 + 112406107221) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_282,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112406107214')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112421408283','112421408284')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112406107214) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112421408283 + 112421408284) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_283,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112406107215')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112421508285','112421508286','112421508287')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112406107215) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112421508285 + 112421508286 + 112421508287) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_284,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112406107216')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112421608288','112421608289')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112406107216) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112421608288 + 112421608289) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_285,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401806062')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112406207222','112406207223')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401806062) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112406207222 + 112406207223) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_286,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112406207222')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112422208290','112422208291','112422208292')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112406207222) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112422208290 + 112422208291 + 112422208292) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_287,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112406207223')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112422308293','112422308294','112422308295')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112406207223) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112422308293 + 112422308294 + 112422308295) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_288,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401806063')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112406307224','112406307225','112406307226','112406307227')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112401806063) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112406307224 + 112406307225 + 112406307226 + 112406307227) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_289,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112406307225')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112422508296','112422508297','112422508298','112422508299','112422508300')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112406307225) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112422508296 + 112422508297 + 112422508298 + 112422508299 + 112422508300) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_290,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112406307226')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112422608301','112422608302','112422608303','112422608304')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112406307226) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112422608301 + 112422608302 + 112422608303 + 112422608304) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_291,

/*Créditos a organismos descentralizados o desconcentrados  */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112406307227')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112422708305','112422708306','112422708307','112422708308')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112406307227) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112422708305 + 112422708306 + 112422708307 + 112422708308) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_292,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400405019')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401906064','112401906065','112401906066','112401906067','112401906068','112401906069','112401906070','112401906071')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400405019) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112401906064 + 112401906065 + 112401906066 + 112401906067 + 112401906068 + 112401906069 + 112401906070 + 112401906071) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_293,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400405020')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402006072','112402006073','112402006074','112402006075','112402006076')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400405020) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112402006072 + 112402006073 + 112402006074 + 112402006075 + 112402006076) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_294,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402006074')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407407228','112407407229')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112402006074) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112407407228 + 112407407229) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_295,

/*Capitalización de Intereses etapa 3*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400104005')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400505021','112400505022','112400505023')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400104005) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112400505021 + 112400505022 + 112400505023) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_296,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400505021')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402106077','112402106078','112402106079')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400505021) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112402106077 + 112402106078 + 112402106079) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_297,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402106077')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407707230','112407707231','112407707232','112407707233','112407707234','112407707235','112407707236','112407707237')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112402106077) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112407707230 + 112407707231 + 112407707232 + 112407707233 + 112407707234 + 112407707235 + 112407707236 + 112407707237) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_298,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407707230')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112423008309','112423008310')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112407707230) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112423008309 + 112423008310) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_299,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407707231')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112423108311','112423108312','112423108313')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112407707231) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112423108311 + 112423108312 + 112423108313) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_300
	
INTO IFRS9_R04A_0420_M4TS1_RESULT_3
FROM IFRS9_R04A_0420

END

BEGIN
	INSERT INTO IFRS9_R04A_0420_M4TS1_RESULT_3
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_201])),
            SUM(CHARINDEX('ERR',[VALIDACION_202])),
            SUM(CHARINDEX('ERR',[VALIDACION_203])),
            SUM(CHARINDEX('ERR',[VALIDACION_204])),
            SUM(CHARINDEX('ERR',[VALIDACION_205])),
            SUM(CHARINDEX('ERR',[VALIDACION_206])),
            SUM(CHARINDEX('ERR',[VALIDACION_207])),
            SUM(CHARINDEX('ERR',[VALIDACION_208])),
            SUM(CHARINDEX('ERR',[VALIDACION_209])),
            SUM(CHARINDEX('ERR',[VALIDACION_210])),
            SUM(CHARINDEX('ERR',[VALIDACION_211])),
            SUM(CHARINDEX('ERR',[VALIDACION_212])),
            SUM(CHARINDEX('ERR',[VALIDACION_213])),
            SUM(CHARINDEX('ERR',[VALIDACION_214])),
            SUM(CHARINDEX('ERR',[VALIDACION_215])),
            SUM(CHARINDEX('ERR',[VALIDACION_216])),
            SUM(CHARINDEX('ERR',[VALIDACION_217])),
            SUM(CHARINDEX('ERR',[VALIDACION_218])),
            SUM(CHARINDEX('ERR',[VALIDACION_219])),
            SUM(CHARINDEX('ERR',[VALIDACION_220])),
            SUM(CHARINDEX('ERR',[VALIDACION_221])),
            SUM(CHARINDEX('ERR',[VALIDACION_222])),
            SUM(CHARINDEX('ERR',[VALIDACION_223])),
            SUM(CHARINDEX('ERR',[VALIDACION_224])),
            SUM(CHARINDEX('ERR',[VALIDACION_225])),
            SUM(CHARINDEX('ERR',[VALIDACION_226])),
            SUM(CHARINDEX('ERR',[VALIDACION_227])),
            SUM(CHARINDEX('ERR',[VALIDACION_228])),
            SUM(CHARINDEX('ERR',[VALIDACION_229])),
            SUM(CHARINDEX('ERR',[VALIDACION_230])),
            SUM(CHARINDEX('ERR',[VALIDACION_231])),
            SUM(CHARINDEX('ERR',[VALIDACION_232])),
            SUM(CHARINDEX('ERR',[VALIDACION_233])),
            SUM(CHARINDEX('ERR',[VALIDACION_234])),
            SUM(CHARINDEX('ERR',[VALIDACION_235])),
            SUM(CHARINDEX('ERR',[VALIDACION_236])),
            SUM(CHARINDEX('ERR',[VALIDACION_237])),
            SUM(CHARINDEX('ERR',[VALIDACION_238])),
            SUM(CHARINDEX('ERR',[VALIDACION_239])),
            SUM(CHARINDEX('ERR',[VALIDACION_240])),
            SUM(CHARINDEX('ERR',[VALIDACION_241])),
            SUM(CHARINDEX('ERR',[VALIDACION_242])),
            SUM(CHARINDEX('ERR',[VALIDACION_243])),
            SUM(CHARINDEX('ERR',[VALIDACION_244])),
            SUM(CHARINDEX('ERR',[VALIDACION_245])),
            SUM(CHARINDEX('ERR',[VALIDACION_246])),
            SUM(CHARINDEX('ERR',[VALIDACION_247])),
            SUM(CHARINDEX('ERR',[VALIDACION_248])),
            SUM(CHARINDEX('ERR',[VALIDACION_249])),
            SUM(CHARINDEX('ERR',[VALIDACION_250])),
            SUM(CHARINDEX('ERR',[VALIDACION_251])),
            SUM(CHARINDEX('ERR',[VALIDACION_252])),
            SUM(CHARINDEX('ERR',[VALIDACION_253])),
            SUM(CHARINDEX('ERR',[VALIDACION_254])),
            SUM(CHARINDEX('ERR',[VALIDACION_255])),
            SUM(CHARINDEX('ERR',[VALIDACION_256])),
            SUM(CHARINDEX('ERR',[VALIDACION_257])),
            SUM(CHARINDEX('ERR',[VALIDACION_258])),
            SUM(CHARINDEX('ERR',[VALIDACION_259])),
            SUM(CHARINDEX('ERR',[VALIDACION_260])),
            SUM(CHARINDEX('ERR',[VALIDACION_261])),
            SUM(CHARINDEX('ERR',[VALIDACION_262])),
            SUM(CHARINDEX('ERR',[VALIDACION_263])),
            SUM(CHARINDEX('ERR',[VALIDACION_264])),
            SUM(CHARINDEX('ERR',[VALIDACION_265])),
            SUM(CHARINDEX('ERR',[VALIDACION_266])),
            SUM(CHARINDEX('ERR',[VALIDACION_267])),
            SUM(CHARINDEX('ERR',[VALIDACION_268])),
            SUM(CHARINDEX('ERR',[VALIDACION_269])),
            SUM(CHARINDEX('ERR',[VALIDACION_270])),
            SUM(CHARINDEX('ERR',[VALIDACION_271])),
            SUM(CHARINDEX('ERR',[VALIDACION_272])),
            SUM(CHARINDEX('ERR',[VALIDACION_273])),
            SUM(CHARINDEX('ERR',[VALIDACION_274])),
            SUM(CHARINDEX('ERR',[VALIDACION_275])),
            SUM(CHARINDEX('ERR',[VALIDACION_276])),
            SUM(CHARINDEX('ERR',[VALIDACION_277])),
            SUM(CHARINDEX('ERR',[VALIDACION_278])),
            SUM(CHARINDEX('ERR',[VALIDACION_279])),
            SUM(CHARINDEX('ERR',[VALIDACION_280])),
            SUM(CHARINDEX('ERR',[VALIDACION_281])),
            SUM(CHARINDEX('ERR',[VALIDACION_282])),
            SUM(CHARINDEX('ERR',[VALIDACION_283])),
            SUM(CHARINDEX('ERR',[VALIDACION_284])),
            SUM(CHARINDEX('ERR',[VALIDACION_285])),
            SUM(CHARINDEX('ERR',[VALIDACION_286])),
            SUM(CHARINDEX('ERR',[VALIDACION_287])),
            SUM(CHARINDEX('ERR',[VALIDACION_288])),
            SUM(CHARINDEX('ERR',[VALIDACION_289])),
            SUM(CHARINDEX('ERR',[VALIDACION_290])),
            SUM(CHARINDEX('ERR',[VALIDACION_291])),
            SUM(CHARINDEX('ERR',[VALIDACION_292])),
            SUM(CHARINDEX('ERR',[VALIDACION_293])),
            SUM(CHARINDEX('ERR',[VALIDACION_294])),
            SUM(CHARINDEX('ERR',[VALIDACION_295])),
            SUM(CHARINDEX('ERR',[VALIDACION_296])),
            SUM(CHARINDEX('ERR',[VALIDACION_297])),
            SUM(CHARINDEX('ERR',[VALIDACION_298])),
            SUM(CHARINDEX('ERR',[VALIDACION_299])),
            SUM(CHARINDEX('ERR',[VALIDACION_300]))
            


		from IFRS9_R04A_0420_M4TS1_RESULT_3
END

BEGIN
	EXEC SP_IFRS9_R04A_0420_M4TS1_VIEW_3
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


