﻿
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapa 3 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15SALDOS*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/


CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0420_M15SALDOSTS1_VIEW_13]
AS
BEGIN
	SELECT *
		
	FROM IFRS9_R04A_0420_M15SALDOSTS1_RESULT_13
	    WHERE

        (VALIDACION_1201 <> '' ) OR
        (VALIDACION_1202 <> '' ) OR
        (VALIDACION_1203 <> '' ) OR
        (VALIDACION_1204 <> '' ) OR
        (VALIDACION_1205 <> '' ) OR
        (VALIDACION_1206 <> '' ) OR
        (VALIDACION_1207 <> '' ) OR
        (VALIDACION_1208 <> '' ) OR
        (VALIDACION_1209 <> '' ) OR
        (VALIDACION_1210 <> '' ) OR
        (VALIDACION_1211 <> '' ) OR
        (VALIDACION_1212 <> '' ) OR
        (VALIDACION_1213 <> '' ) OR
        (VALIDACION_1214 <> '' ) OR
        (VALIDACION_1215 <> '' ) OR
        (VALIDACION_1216 <> '' ) OR
        (VALIDACION_1217 <> '' ) OR
        (VALIDACION_1218 <> '' ) OR
        (VALIDACION_1219 <> '' ) OR
        (VALIDACION_1220 <> '' ) OR
        (VALIDACION_1221 <> '' ) OR
        (VALIDACION_1222 <> '' ) OR
        (VALIDACION_1223 <> '' ) OR
        (VALIDACION_1224 <> '' ) OR
        (VALIDACION_1225 <> '' ) OR
        (VALIDACION_1226 <> '' ) OR
        (VALIDACION_1227 <> '' ) OR
        (VALIDACION_1228 <> '' ) OR
        (VALIDACION_1229 <> '' ) OR
        (VALIDACION_1230 <> '' ) OR
        (VALIDACION_1231 <> '' ) OR
        (VALIDACION_1232 <> '' ) OR
        (VALIDACION_1233 <> '' ) OR
        (VALIDACION_1234 <> '' ) OR
        (VALIDACION_1235 <> '' ) OR
        (VALIDACION_1236 <> '' ) OR
        (VALIDACION_1237 <> '' ) OR
        (VALIDACION_1238 <> '' ) OR
        (VALIDACION_1239 <> '' ) OR
        (VALIDACION_1240 <> '' ) OR
        (VALIDACION_1241 <> '' ) OR
        (VALIDACION_1242 <> '' ) OR
        (VALIDACION_1243 <> '' ) OR
        (VALIDACION_1244 <> '' ) OR
        (VALIDACION_1245 <> '' ) OR
        (VALIDACION_1246 <> '' ) OR
        (VALIDACION_1247 <> '' ) OR
        (VALIDACION_1248 <> '' ) OR
        (VALIDACION_1249 <> '' ) OR
        (VALIDACION_1250 <> '' ) OR
        (VALIDACION_1251 <> '' ) OR
        (VALIDACION_1252 <> '' ) OR
        (VALIDACION_1253 <> '' ) OR
        (VALIDACION_1254 <> '' ) OR
        (VALIDACION_1255 <> '' ) OR
        (VALIDACION_1256 <> '' ) OR
        (VALIDACION_1257 <> '' ) OR
        (VALIDACION_1258 <> '' ) OR
        (VALIDACION_1259 <> '' ) OR
        (VALIDACION_1260 <> '' ) OR
        (VALIDACION_1261 <> '' ) OR
        (VALIDACION_1262 <> '' ) OR
        (VALIDACION_1263 <> '' ) OR
        (VALIDACION_1264 <> '' ) OR
        (VALIDACION_1265 <> '' ) OR
        (VALIDACION_1266 <> '' ) OR
        (VALIDACION_1267 <> '' ) OR
        (VALIDACION_1268 <> '' ) OR
        (VALIDACION_1269 <> '' ) OR
        (VALIDACION_1270 <> '' ) OR
        (VALIDACION_1271 <> '' ) OR
        (VALIDACION_1272 <> '' ) OR
        (VALIDACION_1273 <> '' ) OR
        (VALIDACION_1274 <> '' ) OR
        (VALIDACION_1275 <> '' ) OR
        (VALIDACION_1276 <> '' ) OR
        (VALIDACION_1277 <> '' ) OR
        (VALIDACION_1278 <> '' ) OR
        (VALIDACION_1279 <> '' ) OR
        (VALIDACION_1280 <> '' ) OR
        (VALIDACION_1281 <> '' ) OR
        (VALIDACION_1282 <> '' ) OR
        (VALIDACION_1283 <> '' ) OR
        (VALIDACION_1284 <> '' ) OR
        (VALIDACION_1285 <> '' ) 
ORDER BY 1
END


