SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE:  Validaciones Estructura Contables*/
/*CREADO POR: Héctor Daniel García Sánchez*/
/*FECHA CREACION: 01/08/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


CREATE OR ALTER PROCEDURE  [dbo].[SP_IFRS9_R04A_0420_COMP_1]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0420_COMP_RESULT_1')
BEGIN
DROP TABLE IFRS9_R04A_0420_COMP_RESULT_1
END 

BEGIN
SELECT DISTINCT

    /*ID*/

    CONVERT(VARCHAR,ID) AS ID,
    

/* VALIDACION Tipo de Dato */

 IIF(ISNUMERIC(c04_concepto)=0,   CONCAT('ERROR: EN LA FILA: ',ID,', El campo CONCEPTO (',[c04_concepto],') no es numerico.'),'') as VALIDACION_1,	

/* VALIDACION Longitud */

IIF(LEN([c04_concepto])>12, CONCAT('ERROR: EN LA FILA: ',ID,', El campo CONCEPTO (',[c04_concepto],') tiene una longitud mayor a 12 caracteres.'), '')  AS VALIDACION_2,	

/* VALIDACION Decimales */

IIF(CHARINDEX('.',[c04_concepto])>0, CONCAT('ERROR: EN LA FILA: ',ID,', El campo CONCEPTO (',[c04_concepto],') no puede tener mas de 0 decimales.'),'')  AS VALIDACION_3,

/* VALIDACION Obligatorio */

IIF([c04_concepto] IS NULL or [c04_concepto] = '' ,   CONCAT('ERROR: EN LA FILA: ',ID,', El campo CONCEPTO (',[c04_concepto],') es obligatorio, no puede estar vacío.'),'')  AS VALIDACION_4,	

/* VALIDACION Caracteres especiales */

IIF(PATINDEX('%[^0-9].%', [c04_concepto]) <> 0 ,   CONCAT('ERROR: EN LA FILA: ',ID,',  El campo CONCEPTO (',[c04_concepto],') no puede tener caracteres especiales ni espacios en blanco.'),'')  AS VALIDACION_5,


/* VALIDACION Tipo de Dato */

 IIF(ISNUMERIC([c04_concepto])=0,   CONCAT('ERROR: EN LA FILA: ',ID,', El campo MONEDA (',[c05_moneda],') no es numerico.'),'') as VALIDACION_6,	

/* VALIDACION Longitud */

IIF(LEN([c05_moneda])>4, CONCAT('ERROR: EN LA FILA: ',ID,', El campo MONEDA (',[c05_moneda],') tiene una longitud mayor a 4 caracteres.'), '')  AS VALIDACION_7,	

/* VALIDACION Decimales */

IIF(CHARINDEX('.',[c05_moneda])>0, CONCAT('ERROR: EN LA FILA: ',ID,', El campo MONEDA (',[c05_moneda],') no puede tener mas de 0 decimales.'),'')  AS VALIDACION_8,	

/* VALIDACION Obligatorio */

IIF([c05_moneda] IS NULL or [c05_moneda] = '' ,   CONCAT('ERROR: EN LA FILA: ',ID,', El campo MONEDA (',[c05_moneda],') es obligatorio, no puede estar vacío.'),'')  AS VALIDACION_9,	

/* VALIDACION Caracteres especiales */

IIF(PATINDEX('%[^0-9].%', [c05_moneda]) <> 0 ,   CONCAT('ERROR: EN LA FILA: ',ID,',  El campo MONEDA (',[c05_moneda],') no puede tener caracteres especiales ni espacios en blanco.'),'')  AS VALIDACION_10,	

/* VALIDACION Catalogo */

 IIF(CONVERT(decimal,[c05_moneda]) not in (1,4,9,15),   CONCAT('ERROR: EN LA FILA: ',ID,', El campo MONEDA (',[c05_moneda],') no está dentro de los valores permitidos (1,4,9,15).'),'') as VALIDACION_11,


/* VALIDACION Tipo de Dato */

 IIF(ISNUMERIC([c05_moneda])=0,   CONCAT('ERROR: EN LA FILA: ',ID,', El campo TIPO_SALDO (',[c06_tipo_saldo],') no es numerico.'),'') as VALIDACION_12,	

/* VALIDACION Longitud */

IIF(LEN([c06_tipo_saldo])>4, CONCAT('ERROR: EN LA FILA: ',ID,', El campo TIPO_SALDO (',[c06_tipo_saldo],') tiene una longitud mayor a 4 caracteres.'), '')  AS VALIDACION_13,	

/* VALIDACION Decimales */

IIF(CHARINDEX('.',[c06_tipo_saldo])>0, CONCAT('ERROR: EN LA FILA: ',ID,', El campo TIPO_SALDO (',[c06_tipo_saldo],') no puede tener mas de 0 decimales.'),'')  AS VALIDACION_14,	

/* VALIDACION Obligatorio */

IIF([c06_tipo_saldo] IS NULL or [c06_tipo_saldo] = '' ,   CONCAT('ERROR: EN LA FILA: ',ID,', El campo TIPO_SALDO (',[c06_tipo_saldo],') es obligatorio, no puede estar vacío.'),'')  AS VALIDACION_15,	

/* VALIDACION Caracteres especiales */

IIF(PATINDEX('%[^0-9].%', [c06_tipo_saldo]) <> 0 ,   CONCAT('ERROR: EN LA FILA: ',ID,',  El campo TIPO_SALDO (',[c06_tipo_saldo],') no puede tener caracteres especiales ni espacios en blanco.'),'')  AS VALIDACION_16,	

/* VALIDACION Catalogo */

 IIF(CONVERT(decimal,[c06_tipo_saldo]) not in (1),   CONCAT('ERROR: EN LA FILA: ',ID,', El campo TIPO_SALDO (',[c06_tipo_saldo],') no está dentro de los valores permitidos (1).'),'') as VALIDACION_17,


/* VALIDACION Tipo de Dato */

 IIF(ISNUMERIC([c06_tipo_saldo])=0,   CONCAT('ERROR: EN LA FILA: ',ID,', El campo DATO (',[c07_dato],') no es numerico.'),'') as VALIDACION_18,	

/* VALIDACION Longitud */

IIF(LEN([c07_dato])>21, CONCAT('ERROR: EN LA FILA: ',ID,', El campo DATO (',[c07_dato],') tiene una longitud mayor a 21 caracteres.'), '')  AS VALIDACION_19,	

/* VALIDACION Decimales */

IIF(CHARINDEX('.',[c07_dato])>2, CONCAT('ERROR: EN LA FILA: ',ID,', El campo DATO (',[c07_dato],') no puede tener mas de 2 decimales.'),'')  AS VALIDACION_20,	

/* VALIDACION Obligatorio */

IIF([c07_dato] IS NULL or [c07_dato] = '' ,   CONCAT('ERROR: EN LA FILA: ',ID,', El campo DATO (',[c07_dato],') es obligatorio, no puede estar vacío.'),'')  AS VALIDACION_21,

/* VALIDACION Caracteres especiales */

IIF(PATINDEX('%[^0-9].%', [c07_dato]) <> 0 ,   CONCAT('ERROR: EN LA FILA: ',ID,',  El campo DATO (',[c07_dato],') no puede tener caracteres especiales ni espacios en blanco.'),'')  AS VALIDACION_22	



INTO IFRS9_R04A_0420_COMP_RESULT_1
FROM IFRS9_R04A_0420

END

BEGIN
	INSERT INTO IFRS9_R04A_0420_COMP_RESULT_1
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_1])),
            SUM(CHARINDEX('ERR',[VALIDACION_2])),
            SUM(CHARINDEX('ERR',[VALIDACION_3])),
            SUM(CHARINDEX('ERR',[VALIDACION_4])),
            SUM(CHARINDEX('ERR',[VALIDACION_5])),
            SUM(CHARINDEX('ERR',[VALIDACION_6])),
            SUM(CHARINDEX('ERR',[VALIDACION_7])),
            SUM(CHARINDEX('ERR',[VALIDACION_8])),
            SUM(CHARINDEX('ERR',[VALIDACION_9])),
            SUM(CHARINDEX('ERR',[VALIDACION_10])),
            SUM(CHARINDEX('ERR',[VALIDACION_11])),
            SUM(CHARINDEX('ERR',[VALIDACION_12])),
            SUM(CHARINDEX('ERR',[VALIDACION_13])),
            SUM(CHARINDEX('ERR',[VALIDACION_14])),
            SUM(CHARINDEX('ERR',[VALIDACION_15])),
            SUM(CHARINDEX('ERR',[VALIDACION_16])),
            SUM(CHARINDEX('ERR',[VALIDACION_17])),
            SUM(CHARINDEX('ERR',[VALIDACION_18])),
            SUM(CHARINDEX('ERR',[VALIDACION_19])),
            SUM(CHARINDEX('ERR',[VALIDACION_20])),
            SUM(CHARINDEX('ERR',[VALIDACION_21])),
            SUM(CHARINDEX('ERR',[VALIDACION_22]))
        

		from IFRS9_R04A_0420_COMP_RESULT_1
END

BEGIN
	EXEC SP_IFRS9_R04A_0420_COMP_VIEW_1
END

COMMIT
END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH