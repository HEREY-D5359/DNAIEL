﻿
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapa 3 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15SALDOS*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/


CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0420_M15SALDOSTS1_VIEW_5]
AS
BEGIN
	SELECT *
		
	FROM IFRS9_R04A_0420_M15SALDOSTS1_RESULT_5
	    WHERE

        (VALIDACION_401 <> '' ) OR
        (VALIDACION_402 <> '' ) OR
        (VALIDACION_403 <> '' ) OR
        (VALIDACION_404 <> '' ) OR
        (VALIDACION_405 <> '' ) OR
        (VALIDACION_406 <> '' ) OR
        (VALIDACION_407 <> '' ) OR
        (VALIDACION_408 <> '' ) OR
        (VALIDACION_409 <> '' ) OR
        (VALIDACION_410 <> '' ) OR
        (VALIDACION_411 <> '' ) OR
        (VALIDACION_412 <> '' ) OR
        (VALIDACION_413 <> '' ) OR
        (VALIDACION_414 <> '' ) OR
        (VALIDACION_415 <> '' ) OR
        (VALIDACION_416 <> '' ) OR
        (VALIDACION_417 <> '' ) OR
        (VALIDACION_418 <> '' ) OR
        (VALIDACION_419 <> '' ) OR
        (VALIDACION_420 <> '' ) OR
        (VALIDACION_421 <> '' ) OR
        (VALIDACION_422 <> '' ) OR
        (VALIDACION_423 <> '' ) OR
        (VALIDACION_424 <> '' ) OR
        (VALIDACION_425 <> '' ) OR
        (VALIDACION_426 <> '' ) OR
        (VALIDACION_427 <> '' ) OR
        (VALIDACION_428 <> '' ) OR
        (VALIDACION_429 <> '' ) OR
        (VALIDACION_430 <> '' ) OR
        (VALIDACION_431 <> '' ) OR
        (VALIDACION_432 <> '' ) OR
        (VALIDACION_433 <> '' ) OR
        (VALIDACION_434 <> '' ) OR
        (VALIDACION_435 <> '' ) OR
        (VALIDACION_436 <> '' ) OR
        (VALIDACION_437 <> '' ) OR
        (VALIDACION_438 <> '' ) OR
        (VALIDACION_439 <> '' ) OR
        (VALIDACION_440 <> '' ) OR
        (VALIDACION_441 <> '' ) OR
        (VALIDACION_442 <> '' ) OR
        (VALIDACION_443 <> '' ) OR
        (VALIDACION_444 <> '' ) OR
        (VALIDACION_445 <> '' ) OR
        (VALIDACION_446 <> '' ) OR
        (VALIDACION_447 <> '' ) OR
        (VALIDACION_448 <> '' ) OR
        (VALIDACION_449 <> '' ) OR
        (VALIDACION_450 <> '' ) OR
        (VALIDACION_451 <> '' ) OR
        (VALIDACION_452 <> '' ) OR
        (VALIDACION_453 <> '' ) OR
        (VALIDACION_454 <> '' ) OR
        (VALIDACION_455 <> '' ) OR
        (VALIDACION_456 <> '' ) OR
        (VALIDACION_457 <> '' ) OR
        (VALIDACION_458 <> '' ) OR
        (VALIDACION_459 <> '' ) OR
        (VALIDACION_460 <> '' ) OR
        (VALIDACION_461 <> '' ) OR
        (VALIDACION_462 <> '' ) OR
        (VALIDACION_463 <> '' ) OR
        (VALIDACION_464 <> '' ) OR
        (VALIDACION_465 <> '' ) OR
        (VALIDACION_466 <> '' ) OR
        (VALIDACION_467 <> '' ) OR
        (VALIDACION_468 <> '' ) OR
        (VALIDACION_469 <> '' ) OR
        (VALIDACION_470 <> '' ) OR
        (VALIDACION_471 <> '' ) OR
        (VALIDACION_472 <> '' ) OR
        (VALIDACION_473 <> '' ) OR
        (VALIDACION_474 <> '' ) OR
        (VALIDACION_475 <> '' ) OR
        (VALIDACION_476 <> '' ) OR
        (VALIDACION_477 <> '' ) OR
        (VALIDACION_478 <> '' ) OR
        (VALIDACION_479 <> '' ) OR
        (VALIDACION_480 <> '' ) OR
        (VALIDACION_481 <> '' ) OR
        (VALIDACION_482 <> '' ) OR
        (VALIDACION_483 <> '' ) OR
        (VALIDACION_484 <> '' ) OR
        (VALIDACION_485 <> '' ) OR
        (VALIDACION_486 <> '' ) OR
        (VALIDACION_487 <> '' ) OR
        (VALIDACION_488 <> '' ) OR
        (VALIDACION_489 <> '' ) OR
        (VALIDACION_490 <> '' ) OR
        (VALIDACION_491 <> '' ) OR
        (VALIDACION_492 <> '' ) OR
        (VALIDACION_493 <> '' ) OR
        (VALIDACION_494 <> '' ) OR
        (VALIDACION_495 <> '' ) OR
        (VALIDACION_496 <> '' ) OR
        (VALIDACION_497 <> '' ) OR
        (VALIDACION_498 <> '' ) OR
        (VALIDACION_499 <> '' ) OR
        (VALIDACION_500 <> '' ) 
ORDER BY 1
END


