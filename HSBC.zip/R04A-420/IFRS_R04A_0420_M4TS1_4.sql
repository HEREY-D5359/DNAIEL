﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapa 3 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 4*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0420_M4TS1_COMP_4]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0420_M4TS1_RESULT_4')
BEGIN
DROP TABLE IFRS9_R04A_0420_M4TS1_RESULT_4
END 

BEGIN
SELECT DISTINCT

	/*ID*/

	CONVERT(VARCHAR,ID)  AS ID,   
	/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407707232')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112423208314','112423208315')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112407707232) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112423208314 + 112423208315) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_301,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402106078')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407807238','112407807239')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112402106078) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112407807238 + 112407807239) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_302,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407807238')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112423808316','112423808317','112423808318')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112407807238) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112423808316 + 112423808317 + 112423808318) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_303,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407807239')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112423908319','112423908320','112423908321')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112407807239) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112423908319 + 112423908320 + 112423908321) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_304,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402106079')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112407907240','112407907241','112407907242','112407907243')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112402106079) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112407907240 + 112407907241 + 112407907242 + 112407907243) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_305,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407907241')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112424108322','112424108323','112424108324','112424108325','112424108326')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112407907241) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112424108322 + 112424108323 + 112424108324 + 112424108325 + 112424108326) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_306,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407907242')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112424208327','112424208328','112424208329','112424208330')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112407907242) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112424208327 + 112424208328 + 112424208329 + 112424208330) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_307,

/*Créditos a organismos descentralizados o desconcentrados  */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112407907243')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112424308331','112424308332','112424308333','112424308334')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112407907243) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112424308331 + 112424308332 + 112424308333 + 112424308334) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_308,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400505022')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402206080','112402206081','112402206082','112402206083','112402206084','112402206085','112402206086','112402206087')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400505022) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112402206080 + 112402206081 + 112402206082 + 112402206083 + 112402206084 + 112402206085 + 112402206086 + 112402206087) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_309,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400505023')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402306088','112402306089','112402306090','112402306091','112402306092')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112400505023) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112402306088 + 112402306089 + 112402306090 + 112402306091 + 112402306092) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_310,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402306090')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112409007244','112409007245')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112402306090) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112409007244 + 112409007245) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_311,

/*Saldo final de cartera con riesgo de crédito etapa 3*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('101800104003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111800305008','111800305009','111800305010')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800104003) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111800305008 + 111800305009 + 111800305010) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_312,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111800305008')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111800806033','111800806034','111800806035')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111800305008) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111800806033 + 111800806034 + 111800806035) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_313,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111800806033')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111803307034','111803307035','111803307036','111803307037','111803307038','111803307039','111803307040','111803307041')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111800806033) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111803307034 + 111803307035 + 111803307036 + 111803307037 + 111803307038 + 111803307039 + 111803307040 + 111803307041) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_314,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111803307034')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111803408053','111803408054')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111803307034) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111803408053 + 111803408054) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_315,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111803307035')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111803508055','111803508056','111803508057')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111803307035) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111803508055 + 111803508056 + 111803508057) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_316,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111803307036')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111803608058','111803608059')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111803307036) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111803608058 + 111803608059) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_317,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111800806034')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111803407042','111803407043')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111800806034) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111803407042 + 111803407043) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_318,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111803407042')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111804208060','111804208061','111804208062')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111803407042) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111804208060 + 111804208061 + 111804208062) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_319,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111803407043')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111804308063','111804308064','111804308065')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111803407043) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111804308063 + 111804308064 + 111804308065) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_320,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111800806035')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111803507044','111803507045','111803507046','111803507047')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111800806035) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111803507044 + 111803507045 + 111803507046 + 111803507047) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_321,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111803507045')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111804508066','111804508067','111804508068','111804508069','111804508070')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111803507045) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111804508066 + 111804508067 + 111804508068 + 111804508069 + 111804508070) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_322,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111803507046')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111804608071','111804608072','111804608073','111804608074')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111803507046) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111804608071 + 111804608072 + 111804608073 + 111804608074) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_323,

/*Créditos a organismos descentralizados o desconcentrados  */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111803507047')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111804708075','111804708076','111804708077','111804708078')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111803507047) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111804708075 + 111804708076 + 111804708077 + 111804708078) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_324,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111800305009')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111800906036','111800906037','111800906038','111800906039','111800906040','111800906041','111800906042','111800906043')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111800305009) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111800906036 + 111800906037 + 111800906038 + 111800906039 + 111800906040 + 111800906041 + 111800906042 + 111800906043) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_325,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111800305010')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111801006044','111801006045','111801006046','111801006047','111801006048')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111800305010) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111801006044 + 111801006045 + 111801006046 + 111801006047 + 111801006048) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_326,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111801006046')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111804607048','111804607049')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111801006046) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111804607048 + 111804607049) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_327,

/*Saldo inicial de cartera de crédito valuada a valor razonable*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112600104001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112600105001','112600105002','112600105003')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112600104001) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112600105001 + 112600105002 + 112600105003) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_328,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112600105001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112600106001','112600106002','112600106003')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112600105001) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112600106001 + 112600106002 + 112600106003) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_329,

/*Entradas a cartera de crédito valuada a valor razonable*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112600104002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112600205004','112600205005','112600205006')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112600104002) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112600205004 + 112600205005 + 112600205006) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_330,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112600205004')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112600406004','112600406005','112600406006')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112600205004) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112600406004 + 112600406005 + 112600406006) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_331,

/*Salidas de cartera de crédito valuada a valor razonable*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112600104003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112600305007','112600305008','112600305009')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112600104003) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112600305007 + 112600305008 + 112600305009) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_332,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112600305007')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112600706007','112600706008','112600706009')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112600305007) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112600706007 + 112600706008 + 112600706009) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_333,

/*Saldo final de cartera de crédito valuada a valor razonable*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('101800104004')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111800405011','111800405012')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800104004) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111800405011 + 111800405012) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_334,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111800405011')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111801106049','111801106050','111801106051')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111800405011) con Moneda 4, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111801106049 + 111801106050 + 111801106051) con Moneda 4, Tipo de Saldo 1.')    
AS VALIDACION_335
	
INTO IFRS9_R04A_0420_M4TS1_RESULT_4
FROM IFRS9_R04A_0420

END

BEGIN
	INSERT INTO IFRS9_R04A_0420_M4TS1_RESULT_4
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_301])),
            SUM(CHARINDEX('ERR',[VALIDACION_302])),
            SUM(CHARINDEX('ERR',[VALIDACION_303])),
            SUM(CHARINDEX('ERR',[VALIDACION_304])),
            SUM(CHARINDEX('ERR',[VALIDACION_305])),
            SUM(CHARINDEX('ERR',[VALIDACION_306])),
            SUM(CHARINDEX('ERR',[VALIDACION_307])),
            SUM(CHARINDEX('ERR',[VALIDACION_308])),
            SUM(CHARINDEX('ERR',[VALIDACION_309])),
            SUM(CHARINDEX('ERR',[VALIDACION_310])),
            SUM(CHARINDEX('ERR',[VALIDACION_311])),
            SUM(CHARINDEX('ERR',[VALIDACION_312])),
            SUM(CHARINDEX('ERR',[VALIDACION_313])),
            SUM(CHARINDEX('ERR',[VALIDACION_314])),
            SUM(CHARINDEX('ERR',[VALIDACION_315])),
            SUM(CHARINDEX('ERR',[VALIDACION_316])),
            SUM(CHARINDEX('ERR',[VALIDACION_317])),
            SUM(CHARINDEX('ERR',[VALIDACION_318])),
            SUM(CHARINDEX('ERR',[VALIDACION_319])),
            SUM(CHARINDEX('ERR',[VALIDACION_320])),
            SUM(CHARINDEX('ERR',[VALIDACION_321])),
            SUM(CHARINDEX('ERR',[VALIDACION_322])),
            SUM(CHARINDEX('ERR',[VALIDACION_323])),
            SUM(CHARINDEX('ERR',[VALIDACION_324])),
            SUM(CHARINDEX('ERR',[VALIDACION_325])),
            SUM(CHARINDEX('ERR',[VALIDACION_326])),
            SUM(CHARINDEX('ERR',[VALIDACION_327])),
            SUM(CHARINDEX('ERR',[VALIDACION_328])),
            SUM(CHARINDEX('ERR',[VALIDACION_329])),
            SUM(CHARINDEX('ERR',[VALIDACION_330])),
            SUM(CHARINDEX('ERR',[VALIDACION_331])),
            SUM(CHARINDEX('ERR',[VALIDACION_332])),
            SUM(CHARINDEX('ERR',[VALIDACION_333])),
            SUM(CHARINDEX('ERR',[VALIDACION_334])),
            SUM(CHARINDEX('ERR',[VALIDACION_335])),
            SUM(CHARINDEX('ERR',[VALIDACION_336])),
            SUM(CHARINDEX('ERR',[VALIDACION_337])),
            SUM(CHARINDEX('ERR',[VALIDACION_338])),
            SUM(CHARINDEX('ERR',[VALIDACION_339])),
            SUM(CHARINDEX('ERR',[VALIDACION_340])),
            SUM(CHARINDEX('ERR',[VALIDACION_341])),
            SUM(CHARINDEX('ERR',[VALIDACION_342])),
            SUM(CHARINDEX('ERR',[VALIDACION_343])),
            SUM(CHARINDEX('ERR',[VALIDACION_344])),
            SUM(CHARINDEX('ERR',[VALIDACION_345])),
            SUM(CHARINDEX('ERR',[VALIDACION_346])),
            SUM(CHARINDEX('ERR',[VALIDACION_347])),
            SUM(CHARINDEX('ERR',[VALIDACION_348])),
            SUM(CHARINDEX('ERR',[VALIDACION_349])),
            SUM(CHARINDEX('ERR',[VALIDACION_350])),
            SUM(CHARINDEX('ERR',[VALIDACION_351])),
            SUM(CHARINDEX('ERR',[VALIDACION_352])),
            SUM(CHARINDEX('ERR',[VALIDACION_353])),
            SUM(CHARINDEX('ERR',[VALIDACION_354])),
            SUM(CHARINDEX('ERR',[VALIDACION_355])),
            SUM(CHARINDEX('ERR',[VALIDACION_356])),
            SUM(CHARINDEX('ERR',[VALIDACION_357])),
            SUM(CHARINDEX('ERR',[VALIDACION_358])),
            SUM(CHARINDEX('ERR',[VALIDACION_359])),
            SUM(CHARINDEX('ERR',[VALIDACION_360])),
            SUM(CHARINDEX('ERR',[VALIDACION_361])),
            SUM(CHARINDEX('ERR',[VALIDACION_362])),
            SUM(CHARINDEX('ERR',[VALIDACION_363])),
            SUM(CHARINDEX('ERR',[VALIDACION_364])),
            SUM(CHARINDEX('ERR',[VALIDACION_365])),
            SUM(CHARINDEX('ERR',[VALIDACION_366])),
            SUM(CHARINDEX('ERR',[VALIDACION_367])),
            SUM(CHARINDEX('ERR',[VALIDACION_368])),
            SUM(CHARINDEX('ERR',[VALIDACION_369])),
            SUM(CHARINDEX('ERR',[VALIDACION_370])),
            SUM(CHARINDEX('ERR',[VALIDACION_371])),
            SUM(CHARINDEX('ERR',[VALIDACION_372])),
            SUM(CHARINDEX('ERR',[VALIDACION_373])),
            SUM(CHARINDEX('ERR',[VALIDACION_374])),
            SUM(CHARINDEX('ERR',[VALIDACION_375])),
            SUM(CHARINDEX('ERR',[VALIDACION_376])),
            SUM(CHARINDEX('ERR',[VALIDACION_377])),
            SUM(CHARINDEX('ERR',[VALIDACION_378])),
            SUM(CHARINDEX('ERR',[VALIDACION_379])),
            SUM(CHARINDEX('ERR',[VALIDACION_380])),
            SUM(CHARINDEX('ERR',[VALIDACION_381])),
            SUM(CHARINDEX('ERR',[VALIDACION_382])),
            SUM(CHARINDEX('ERR',[VALIDACION_383])),
            SUM(CHARINDEX('ERR',[VALIDACION_384])),
            SUM(CHARINDEX('ERR',[VALIDACION_385])),
            SUM(CHARINDEX('ERR',[VALIDACION_386])),
            SUM(CHARINDEX('ERR',[VALIDACION_387])),
            SUM(CHARINDEX('ERR',[VALIDACION_388])),
            SUM(CHARINDEX('ERR',[VALIDACION_389])),
            SUM(CHARINDEX('ERR',[VALIDACION_390])),
            SUM(CHARINDEX('ERR',[VALIDACION_391])),
            SUM(CHARINDEX('ERR',[VALIDACION_392])),
            SUM(CHARINDEX('ERR',[VALIDACION_393])),
            SUM(CHARINDEX('ERR',[VALIDACION_394])),
            SUM(CHARINDEX('ERR',[VALIDACION_395])),
            SUM(CHARINDEX('ERR',[VALIDACION_396])),
            SUM(CHARINDEX('ERR',[VALIDACION_397])),
            SUM(CHARINDEX('ERR',[VALIDACION_398])),
            SUM(CHARINDEX('ERR',[VALIDACION_399])),
            SUM(CHARINDEX('ERR',[VALIDACION_400]))
            


		from IFRS9_R04A_0420_M4TS1_RESULT_4
END

BEGIN
	EXEC SP_IFRS9_R04A_0420_M4TS1_VIEW_4
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


