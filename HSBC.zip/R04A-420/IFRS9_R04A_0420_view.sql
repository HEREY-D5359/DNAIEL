
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapa 3 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0420_COMP_VIEW_1]
AS
BEGIN
	SELECT *
		
	FROM IFRS9_R04A_0420_COMP_RESULT_1
	WHERE

        (VALIDACION_1 <> '' ) OR
        (VALIDACION_2 <> '' ) OR
        (VALIDACION_3 <> '' ) OR
        (VALIDACION_4 <> '' ) OR
        (VALIDACION_5 <> '' ) OR
        (VALIDACION_6 <> '' ) OR
        (VALIDACION_7 <> '' ) OR
        (VALIDACION_8 <> '' ) OR
        (VALIDACION_9 <> '' ) OR
        (VALIDACION_10 <> '' ) OR
        (VALIDACION_11 <> '' ) OR
        (VALIDACION_12 <> '' ) OR
        (VALIDACION_13 <> '' ) OR
        (VALIDACION_14 <> '' ) OR
        (VALIDACION_15 <> '' ) OR
        (VALIDACION_16 <> '' ) OR
        (VALIDACION_17 <> '' ) OR
        (VALIDACION_18 <> '' ) OR
        (VALIDACION_19 <> '' ) OR
        (VALIDACION_20 <> '' ) OR
        (VALIDACION_21 <> '' ) OR
        (VALIDACION_22 <> '' ) 
	ORDER BY 1
END


