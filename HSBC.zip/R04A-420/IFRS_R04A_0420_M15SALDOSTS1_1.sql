﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapa 3 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15SALDOS*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0420_M15SALDOSTS1_COMP_1]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0420_M15SALDOSTS1_RESULT_1')
BEGIN
DROP TABLE IFRS9_R04A_0420_M15SALDOSTS1_RESULT_1
END 

BEGIN
SELECT DISTINCT
         /*id*/
CONVERT(VARCHAR,ID) AS ID, 
	/*Saldo inicial de cartera con riesgo de crédito etapa 3*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400104001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400104001')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400104001) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400104001) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400105001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400105001')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400105001) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400105001) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400106001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400106001')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400106001) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400106001) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_3,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400107001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400107001')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400107001) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400107001) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_4,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400108001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400108001')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400108001) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400108001) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_5,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400108002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400108002')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400108002) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400108002) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_6,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400107002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400107002')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400107002) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400107002) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_7,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400208003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400208003')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400208003) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400208003) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_8,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400208004')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400208004')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400208004) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400208004) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_9,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400208005')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400208005')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400208005) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400208005) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_10,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400107003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400107003')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400107003) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400107003) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_11,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400308006')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400308006')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400308006) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400308006) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_12,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400308007')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400308007')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400308007) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400308007) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_13,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400107004')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400107004')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400107004) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400107004) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_14,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400107005')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400107005')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400107005) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400107005) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_15,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400107006')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400107006')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400107006) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400107006) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_16,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400107007')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400107007')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400107007) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400107007) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_17,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400107008')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400107008')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400107008) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400107008) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_18,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400106002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400106002')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400106002) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400106002) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_19,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400207009')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400207009')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400207009) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400207009) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_20,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400908008')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400908008')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400908008) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400908008) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_21,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400908009')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400908009')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400908009) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400908009) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_22,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400908010')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400908010')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400908010) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400908010) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_23,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400207010')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400207010')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400207010) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400207010) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_24,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401008011')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401008011')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401008011) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401008011) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_25,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401008012')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401008012')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401008012) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401008012) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_26,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401008013')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401008013')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401008013) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401008013) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_27,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400106003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400106003')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400106003) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400106003) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_28,

/*Créditos al gobierno federal */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400307011')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400307011')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400307011) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400307011) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_29,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400307012')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400307012')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400307012) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400307012) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_30,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401208014')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401208014')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401208014) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401208014) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_31,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401208015')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401208015')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401208015) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401208015) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_32,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401208016')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401208016')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401208016) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401208016) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_33,

/*Fideicomisos públicos de contratación */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401208017')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401208017')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401208017) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401208017) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_34,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401208018')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401208018')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401208018) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401208018) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_35,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400307013')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400307013')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400307013) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400307013) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_36,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401308019')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401308019')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401308019) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401308019) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_37,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401308020')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401308020')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401308020) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401308020) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_38,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401308021')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401308021')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401308021) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401308021) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_39,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401308022')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401308022')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401308022) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401308022) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_40,

/*Créditos a organismos descentralizados o desconcentrados  */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400307014')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400307014')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400307014) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400307014) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_41,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401408023')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401408023')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401408023) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401408023) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_42,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401408024')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401408024')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401408024) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401408024) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_43,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401408025')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401408025')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401408025) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401408025) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_44,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401408026')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401408026')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401408026) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401408026) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_45,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400105002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400105002')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400105002) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400105002) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_46,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400206004')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400206004')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400206004) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400206004) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_47,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400206005')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400206005')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400206005) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400206005) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_48,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400206006')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400206006')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400206006) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400206006) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_49,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400206007')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400206007')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400206007) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400206007) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_50,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400206008')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400206008')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400206008) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400206008) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_51,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400206009')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400206009')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400206009) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400206009) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_52,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400206010')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400206010')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400206010) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400206010) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_53,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400206011')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400206011')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400206011) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400206011) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_54,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400105003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400105003')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400105003) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400105003) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_55,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400306012')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400306012')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400306012) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400306012) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_56,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400306013')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400306013')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400306013) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400306013) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_57,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400306014')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400306014')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400306014) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400306014) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_58,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401407015')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401407015')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401407015) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401407015) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_59,

/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401407016')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401407016')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401407016) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401407016) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_60,

/*Remodelación o mejoramiento con garantía otorgada por la Banca de Desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400306015')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400306015')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400306015) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400306015) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_61,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400306016')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400306016')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400306016) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400306016) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_62,

/*Entradas a cartera con riesgo de crédito etapa 3*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400104002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400104002')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400104002) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400104002) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_63,

/*Reestructuras y renovaciones  (1)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400205004')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400205004')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400205004) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400205004) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_64,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400406017')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400406017')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400406017) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400406017) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_65,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401707017')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401707017')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401707017) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401707017) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_66,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401708027')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401708027')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401708027) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401708027) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_67,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402709001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402709001')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112402709001) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112402709001) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_68,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402709002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402709002')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112402709002) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112402709002) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_69,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401708028')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401708028')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401708028) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401708028) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_70,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402809003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402809003')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112402809003) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112402809003) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_71,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402809004')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402809004')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112402809004) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112402809004) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_72,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402809005')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402809005')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112402809005) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112402809005) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_73,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401708029')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401708029')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401708029) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401708029) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_74,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402909006')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402909006')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112402909006) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112402909006) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_75,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112402909007')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112402909007')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112402909007) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112402909007) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_76,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401708030')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401708030')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401708030) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401708030) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_77,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401708031')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401708031')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401708031) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401708031) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_78,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401708032')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401708032')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401708032) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401708032) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_79,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401708033')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401708033')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401708033) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401708033) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_80,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401708034')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401708034')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401708034) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401708034) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_81,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401707018')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401707018')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401707018) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401707018) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_82,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401808035')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401808035')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401808035) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401808035) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_83,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403509008')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403509008')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403509008) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403509008) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_84,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403509009')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403509009')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403509009) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403509009) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_85,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403509010')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403509010')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403509010) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403509010) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_86,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401808036')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401808036')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401808036) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401808036) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_87,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403609011')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403609011')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403609011) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403609011) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_88,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403609012')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403609012')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403609012) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403609012) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_89,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403609013')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403609013')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403609013) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403609013) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_90,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401707019')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401707019')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401707019) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401707019) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_91,

/*Créditos al gobierno federal */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401908037')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401908037')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401908037) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401908037) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_92,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401908038')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401908038')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401908038) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401908038) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_93,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403809014')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403809014')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403809014) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403809014) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_94,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403809015')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403809015')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403809015) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403809015) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_95,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403809016')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403809016')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403809016) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403809016) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_96,

/*Fideicomisos públicos de contratación */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403809017')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403809017')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403809017) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403809017) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_97,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403809018')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403809018')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403809018) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403809018) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_98,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401908039')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401908039')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401908039) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401908039) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_99,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403909019')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403909019')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403909019) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403909019) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_100
	
INTO IFRS9_R04A_0420_M15SALDOSTS1_RESULT_1
FROM IFRS9_R04A_0420

END

BEGIN
	INSERT INTO IFRS9_R04A_0420_M15SALDOSTS1_RESULT_1
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_1])),
            SUM(CHARINDEX('ERR',[VALIDACION_2])),
            SUM(CHARINDEX('ERR',[VALIDACION_3])),
            SUM(CHARINDEX('ERR',[VALIDACION_4])),
            SUM(CHARINDEX('ERR',[VALIDACION_5])),
            SUM(CHARINDEX('ERR',[VALIDACION_6])),
            SUM(CHARINDEX('ERR',[VALIDACION_7])),
            SUM(CHARINDEX('ERR',[VALIDACION_8])),
            SUM(CHARINDEX('ERR',[VALIDACION_9])),
            SUM(CHARINDEX('ERR',[VALIDACION_10])),
            SUM(CHARINDEX('ERR',[VALIDACION_11])),
            SUM(CHARINDEX('ERR',[VALIDACION_12])),
            SUM(CHARINDEX('ERR',[VALIDACION_13])),
            SUM(CHARINDEX('ERR',[VALIDACION_14])),
            SUM(CHARINDEX('ERR',[VALIDACION_15])),
            SUM(CHARINDEX('ERR',[VALIDACION_16])),
            SUM(CHARINDEX('ERR',[VALIDACION_17])),
            SUM(CHARINDEX('ERR',[VALIDACION_18])),
            SUM(CHARINDEX('ERR',[VALIDACION_19])),
            SUM(CHARINDEX('ERR',[VALIDACION_20])),
            SUM(CHARINDEX('ERR',[VALIDACION_21])),
            SUM(CHARINDEX('ERR',[VALIDACION_22])),
            SUM(CHARINDEX('ERR',[VALIDACION_23])),
            SUM(CHARINDEX('ERR',[VALIDACION_24])),
            SUM(CHARINDEX('ERR',[VALIDACION_25])),
            SUM(CHARINDEX('ERR',[VALIDACION_26])),
            SUM(CHARINDEX('ERR',[VALIDACION_27])),
            SUM(CHARINDEX('ERR',[VALIDACION_28])),
            SUM(CHARINDEX('ERR',[VALIDACION_29])),
            SUM(CHARINDEX('ERR',[VALIDACION_30])),
            SUM(CHARINDEX('ERR',[VALIDACION_31])),
            SUM(CHARINDEX('ERR',[VALIDACION_32])),
            SUM(CHARINDEX('ERR',[VALIDACION_33])),
            SUM(CHARINDEX('ERR',[VALIDACION_34])),
            SUM(CHARINDEX('ERR',[VALIDACION_35])),
            SUM(CHARINDEX('ERR',[VALIDACION_36])),
            SUM(CHARINDEX('ERR',[VALIDACION_37])),
            SUM(CHARINDEX('ERR',[VALIDACION_38])),
            SUM(CHARINDEX('ERR',[VALIDACION_39])),
            SUM(CHARINDEX('ERR',[VALIDACION_40])),
            SUM(CHARINDEX('ERR',[VALIDACION_41])),
            SUM(CHARINDEX('ERR',[VALIDACION_42])),
            SUM(CHARINDEX('ERR',[VALIDACION_43])),
            SUM(CHARINDEX('ERR',[VALIDACION_44])),
            SUM(CHARINDEX('ERR',[VALIDACION_45])),
            SUM(CHARINDEX('ERR',[VALIDACION_46])),
            SUM(CHARINDEX('ERR',[VALIDACION_47])),
            SUM(CHARINDEX('ERR',[VALIDACION_48])),
            SUM(CHARINDEX('ERR',[VALIDACION_49])),
            SUM(CHARINDEX('ERR',[VALIDACION_50])),
            SUM(CHARINDEX('ERR',[VALIDACION_51])),
            SUM(CHARINDEX('ERR',[VALIDACION_52])),
            SUM(CHARINDEX('ERR',[VALIDACION_53])),
            SUM(CHARINDEX('ERR',[VALIDACION_54])),
            SUM(CHARINDEX('ERR',[VALIDACION_55])),
            SUM(CHARINDEX('ERR',[VALIDACION_56])),
            SUM(CHARINDEX('ERR',[VALIDACION_57])),
            SUM(CHARINDEX('ERR',[VALIDACION_58])),
            SUM(CHARINDEX('ERR',[VALIDACION_59])),
            SUM(CHARINDEX('ERR',[VALIDACION_60])),
            SUM(CHARINDEX('ERR',[VALIDACION_61])),
            SUM(CHARINDEX('ERR',[VALIDACION_62])),
            SUM(CHARINDEX('ERR',[VALIDACION_63])),
            SUM(CHARINDEX('ERR',[VALIDACION_64])),
            SUM(CHARINDEX('ERR',[VALIDACION_65])),
            SUM(CHARINDEX('ERR',[VALIDACION_66])),
            SUM(CHARINDEX('ERR',[VALIDACION_67])),
            SUM(CHARINDEX('ERR',[VALIDACION_68])),
            SUM(CHARINDEX('ERR',[VALIDACION_69])),
            SUM(CHARINDEX('ERR',[VALIDACION_70])),
            SUM(CHARINDEX('ERR',[VALIDACION_71])),
            SUM(CHARINDEX('ERR',[VALIDACION_72])),
            SUM(CHARINDEX('ERR',[VALIDACION_73])),
            SUM(CHARINDEX('ERR',[VALIDACION_74])),
            SUM(CHARINDEX('ERR',[VALIDACION_75])),
            SUM(CHARINDEX('ERR',[VALIDACION_76])),
            SUM(CHARINDEX('ERR',[VALIDACION_77])),
            SUM(CHARINDEX('ERR',[VALIDACION_78])),
            SUM(CHARINDEX('ERR',[VALIDACION_79])),
            SUM(CHARINDEX('ERR',[VALIDACION_80])),
            SUM(CHARINDEX('ERR',[VALIDACION_81])),
            SUM(CHARINDEX('ERR',[VALIDACION_82])),
            SUM(CHARINDEX('ERR',[VALIDACION_83])),
            SUM(CHARINDEX('ERR',[VALIDACION_84])),
            SUM(CHARINDEX('ERR',[VALIDACION_85])),
            SUM(CHARINDEX('ERR',[VALIDACION_86])),
            SUM(CHARINDEX('ERR',[VALIDACION_87])),
            SUM(CHARINDEX('ERR',[VALIDACION_88])),
            SUM(CHARINDEX('ERR',[VALIDACION_89])),
            SUM(CHARINDEX('ERR',[VALIDACION_90])),
            SUM(CHARINDEX('ERR',[VALIDACION_91])),
            SUM(CHARINDEX('ERR',[VALIDACION_92])),
            SUM(CHARINDEX('ERR',[VALIDACION_93])),
            SUM(CHARINDEX('ERR',[VALIDACION_94])),
            SUM(CHARINDEX('ERR',[VALIDACION_95])),
            SUM(CHARINDEX('ERR',[VALIDACION_96])),
            SUM(CHARINDEX('ERR',[VALIDACION_97])),
            SUM(CHARINDEX('ERR',[VALIDACION_98])),
            SUM(CHARINDEX('ERR',[VALIDACION_99])),
            SUM(CHARINDEX('ERR',[VALIDACION_100]))
            


		from IFRS9_R04A_0420_M15SALDOSTS1_RESULT_1
END

BEGIN
	EXEC SP_IFRS9_R04A_0420_M15SALDOSTS1_VIEW_1
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


