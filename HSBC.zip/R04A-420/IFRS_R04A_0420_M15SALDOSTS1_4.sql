﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapa 3 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15SALDOS*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0420_M15SALDOSTS1_COMP_4]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0420_M15SALDOSTS1_RESULT_4')
BEGIN
DROP TABLE IFRS9_R04A_0420_M15SALDOSTS1_RESULT_4
END 

BEGIN
SELECT DISTINCT
         /*id*/
CONVERT(VARCHAR,ID) AS ID, 
	/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408809104')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408809104')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408809104) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408809104) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_301,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400806030')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400806030')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400806030) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400806030) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_302,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403007071')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403007071')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403007071) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403007071) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_303,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403007072')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403007072')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403007072) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403007072) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_304,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403007073')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403007073')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403007073) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403007073) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_305,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403007074')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403007074')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403007074) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403007074) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_306,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403007075')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403007075')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403007075) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403007075) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_307,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403007076')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403007076')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403007076) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403007076) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_308,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403007077')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403007077')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403007077) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403007077) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_309,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403007078')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403007078')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403007078) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403007078) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_310,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400806031')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400806031')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400806031) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400806031) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_311,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403107079')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403107079')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403107079) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403107079) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_312,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403107080')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403107080')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403107080) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403107080) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_313,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403107081')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403107081')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403107081) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403107081) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_314,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408108089')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408108089')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408108089) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408108089) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_315,

/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408108090')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408108090')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408108090) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408108090) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_316,

/*Remodelación o mejoramiento con garantía otorgada por la Banca de Desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403107082')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403107082')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403107082) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403107082) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_317,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403107083')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403107083')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403107083) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403107083) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_318,

/*Intereses devengados no cobrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400205009')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400205009')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400205009) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400205009) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_319,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400906032')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400906032')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400906032) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400906032) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_320,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403207084')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403207084')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403207084) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403207084) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_321,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408408091')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408408091')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408408091) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408408091) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_322,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112409109105')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112409109105')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112409109105) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112409109105) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_323,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112409109106')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112409109106')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112409109106) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112409109106) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_324,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408408092')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408408092')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408408092) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408408092) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_325,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112409209107')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112409209107')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112409209107) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112409209107) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_326,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112409209108')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112409209108')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112409209108) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112409209108) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_327,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112409209109')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112409209109')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112409209109) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112409209109) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_328,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408408093')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408408093')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408408093) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408408093) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_329,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112409309110')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112409309110')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112409309110) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112409309110) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_330,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112409309111')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112409309111')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112409309111) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112409309111) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_331,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408408094')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408408094')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408408094) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408408094) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_332,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408408095')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408408095')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408408095) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408408095) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_333,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408408096')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408408096')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408408096) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408408096) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_334,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408408097')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408408097')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408408097) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408408097) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_335,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408408098')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408408098')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408408098) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408408098) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_336,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403207085')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403207085')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403207085) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403207085) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_337,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408508099')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408508099')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408508099) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408508099) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_338,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112409909112')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112409909112')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112409909112) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112409909112) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_339,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112409909113')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112409909113')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112409909113) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112409909113) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_340,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112409909114')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112409909114')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112409909114) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112409909114) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_341,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408508100')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408508100')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408508100) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408508100) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_342,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410009115')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410009115')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112410009115) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112410009115) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_343,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410009116')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410009116')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112410009116) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112410009116) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_344,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410009117')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410009117')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112410009117) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112410009117) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_345,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403207086')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403207086')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403207086) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403207086) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_346,

/*Créditos al gobierno federal */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408608101')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408608101')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408608101) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408608101) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_347,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408608102')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408608102')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408608102) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408608102) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_348,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410209118')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410209118')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112410209118) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112410209118) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_349,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410209119')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410209119')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112410209119) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112410209119) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_350,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410209120')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410209120')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112410209120) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112410209120) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_351,

/*Fideicomisos públicos de contratación */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410209121')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410209121')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112410209121) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112410209121) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_352,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410209122')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410209122')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112410209122) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112410209122) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_353,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408608103')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408608103')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408608103) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408608103) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_354,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410309123')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410309123')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112410309123) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112410309123) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_355,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410309124')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410309124')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112410309124) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112410309124) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_356,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410309125')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410309125')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112410309125) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112410309125) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_357,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410309126')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410309126')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112410309126) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112410309126) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_358,

/*Créditos a organismos descentralizados o desconcentrados  */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112408608104')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112408608104')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112408608104) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112408608104) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_359,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410409127')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410409127')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112410409127) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112410409127) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_360,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410409128')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410409128')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112410409128) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112410409128) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_361,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410409129')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410409129')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112410409129) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112410409129) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_362,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410409130')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410409130')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112410409130) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112410409130) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_363,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400906033')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400906033')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400906033) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400906033) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_364,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403307087')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403307087')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403307087) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403307087) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_365,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403307088')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403307088')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403307088) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403307088) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_366,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403307089')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403307089')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403307089) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403307089) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_367,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403307090')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403307090')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403307090) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403307090) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_368,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403307091')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403307091')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403307091) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403307091) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_369,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403307092')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403307092')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403307092) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403307092) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_370,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403307093')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403307093')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403307093) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403307093) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_371,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403307094')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403307094')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403307094) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403307094) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_372,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400906034')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400906034')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400906034) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400906034) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_373,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403407095')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403407095')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403407095) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403407095) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_374,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403407096')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403407096')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403407096) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403407096) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_375,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403407097')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403407097')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403407097) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403407097) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_376,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112409708105')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112409708105')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112409708105) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112409708105) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_377,

/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112409708106')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112409708106')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112409708106) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112409708106) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_378,

/*Remodelación o mejoramiento con garantía otorgada por la Banca de Desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403407098')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403407098')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403407098) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403407098) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_379,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403407099')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403407099')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403407099) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403407099) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_380,

/*Por sobregiros en cuentas de cheques que no cuenten con línea de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112400205010')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112400205010')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112400205010) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112400205010) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_381,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112401006035')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112401006035')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112401006035) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112401006035) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_382,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403507100')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403507100')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403507100) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403507100) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_383,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410008107')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410008107')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112410008107) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112410008107) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_384,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410709131')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410709131')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112410709131) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112410709131) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_385,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410709132')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410709132')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112410709132) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112410709132) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_386,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410008108')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410008108')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112410008108) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112410008108) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_387,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410809133')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410809133')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112410809133) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112410809133) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_388,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410809134')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410809134')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112410809134) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112410809134) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_389,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410809135')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410809135')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112410809135) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112410809135) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_390,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410008109')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410008109')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112410008109) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112410008109) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_391,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410909136')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410909136')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112410909136) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112410909136) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_392,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410909137')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410909137')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112410909137) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112410909137) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_393,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410008110')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410008110')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112410008110) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112410008110) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_394,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410008111')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410008111')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112410008111) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112410008111) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_395,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410008112')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410008112')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112410008112) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112410008112) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_396,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410008113')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410008113')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112410008113) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112410008113) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_397,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410008114')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410008114')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112410008114) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112410008114) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_398,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112403507101')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112403507101')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112403507101) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112403507101) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_399,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112410108115')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112410108115')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112410108115) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112410108115) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_400
	
INTO IFRS9_R04A_0420_M15SALDOSTS1_RESULT_4
FROM IFRS9_R04A_0420

END

BEGIN
	INSERT INTO IFRS9_R04A_0420_M15SALDOSTS1_RESULT_4
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_301])),
            SUM(CHARINDEX('ERR',[VALIDACION_302])),
            SUM(CHARINDEX('ERR',[VALIDACION_303])),
            SUM(CHARINDEX('ERR',[VALIDACION_304])),
            SUM(CHARINDEX('ERR',[VALIDACION_305])),
            SUM(CHARINDEX('ERR',[VALIDACION_306])),
            SUM(CHARINDEX('ERR',[VALIDACION_307])),
            SUM(CHARINDEX('ERR',[VALIDACION_308])),
            SUM(CHARINDEX('ERR',[VALIDACION_309])),
            SUM(CHARINDEX('ERR',[VALIDACION_310])),
            SUM(CHARINDEX('ERR',[VALIDACION_311])),
            SUM(CHARINDEX('ERR',[VALIDACION_312])),
            SUM(CHARINDEX('ERR',[VALIDACION_313])),
            SUM(CHARINDEX('ERR',[VALIDACION_314])),
            SUM(CHARINDEX('ERR',[VALIDACION_315])),
            SUM(CHARINDEX('ERR',[VALIDACION_316])),
            SUM(CHARINDEX('ERR',[VALIDACION_317])),
            SUM(CHARINDEX('ERR',[VALIDACION_318])),
            SUM(CHARINDEX('ERR',[VALIDACION_319])),
            SUM(CHARINDEX('ERR',[VALIDACION_320])),
            SUM(CHARINDEX('ERR',[VALIDACION_321])),
            SUM(CHARINDEX('ERR',[VALIDACION_322])),
            SUM(CHARINDEX('ERR',[VALIDACION_323])),
            SUM(CHARINDEX('ERR',[VALIDACION_324])),
            SUM(CHARINDEX('ERR',[VALIDACION_325])),
            SUM(CHARINDEX('ERR',[VALIDACION_326])),
            SUM(CHARINDEX('ERR',[VALIDACION_327])),
            SUM(CHARINDEX('ERR',[VALIDACION_328])),
            SUM(CHARINDEX('ERR',[VALIDACION_329])),
            SUM(CHARINDEX('ERR',[VALIDACION_330])),
            SUM(CHARINDEX('ERR',[VALIDACION_331])),
            SUM(CHARINDEX('ERR',[VALIDACION_332])),
            SUM(CHARINDEX('ERR',[VALIDACION_333])),
            SUM(CHARINDEX('ERR',[VALIDACION_334])),
            SUM(CHARINDEX('ERR',[VALIDACION_335])),
            SUM(CHARINDEX('ERR',[VALIDACION_336])),
            SUM(CHARINDEX('ERR',[VALIDACION_337])),
            SUM(CHARINDEX('ERR',[VALIDACION_338])),
            SUM(CHARINDEX('ERR',[VALIDACION_339])),
            SUM(CHARINDEX('ERR',[VALIDACION_340])),
            SUM(CHARINDEX('ERR',[VALIDACION_341])),
            SUM(CHARINDEX('ERR',[VALIDACION_342])),
            SUM(CHARINDEX('ERR',[VALIDACION_343])),
            SUM(CHARINDEX('ERR',[VALIDACION_344])),
            SUM(CHARINDEX('ERR',[VALIDACION_345])),
            SUM(CHARINDEX('ERR',[VALIDACION_346])),
            SUM(CHARINDEX('ERR',[VALIDACION_347])),
            SUM(CHARINDEX('ERR',[VALIDACION_348])),
            SUM(CHARINDEX('ERR',[VALIDACION_349])),
            SUM(CHARINDEX('ERR',[VALIDACION_350])),
            SUM(CHARINDEX('ERR',[VALIDACION_351])),
            SUM(CHARINDEX('ERR',[VALIDACION_352])),
            SUM(CHARINDEX('ERR',[VALIDACION_353])),
            SUM(CHARINDEX('ERR',[VALIDACION_354])),
            SUM(CHARINDEX('ERR',[VALIDACION_355])),
            SUM(CHARINDEX('ERR',[VALIDACION_356])),
            SUM(CHARINDEX('ERR',[VALIDACION_357])),
            SUM(CHARINDEX('ERR',[VALIDACION_358])),
            SUM(CHARINDEX('ERR',[VALIDACION_359])),
            SUM(CHARINDEX('ERR',[VALIDACION_360])),
            SUM(CHARINDEX('ERR',[VALIDACION_361])),
            SUM(CHARINDEX('ERR',[VALIDACION_362])),
            SUM(CHARINDEX('ERR',[VALIDACION_363])),
            SUM(CHARINDEX('ERR',[VALIDACION_364])),
            SUM(CHARINDEX('ERR',[VALIDACION_365])),
            SUM(CHARINDEX('ERR',[VALIDACION_366])),
            SUM(CHARINDEX('ERR',[VALIDACION_367])),
            SUM(CHARINDEX('ERR',[VALIDACION_368])),
            SUM(CHARINDEX('ERR',[VALIDACION_369])),
            SUM(CHARINDEX('ERR',[VALIDACION_370])),
            SUM(CHARINDEX('ERR',[VALIDACION_371])),
            SUM(CHARINDEX('ERR',[VALIDACION_372])),
            SUM(CHARINDEX('ERR',[VALIDACION_373])),
            SUM(CHARINDEX('ERR',[VALIDACION_374])),
            SUM(CHARINDEX('ERR',[VALIDACION_375])),
            SUM(CHARINDEX('ERR',[VALIDACION_376])),
            SUM(CHARINDEX('ERR',[VALIDACION_377])),
            SUM(CHARINDEX('ERR',[VALIDACION_378])),
            SUM(CHARINDEX('ERR',[VALIDACION_379])),
            SUM(CHARINDEX('ERR',[VALIDACION_380])),
            SUM(CHARINDEX('ERR',[VALIDACION_381])),
            SUM(CHARINDEX('ERR',[VALIDACION_382])),
            SUM(CHARINDEX('ERR',[VALIDACION_383])),
            SUM(CHARINDEX('ERR',[VALIDACION_384])),
            SUM(CHARINDEX('ERR',[VALIDACION_385])),
            SUM(CHARINDEX('ERR',[VALIDACION_386])),
            SUM(CHARINDEX('ERR',[VALIDACION_387])),
            SUM(CHARINDEX('ERR',[VALIDACION_388])),
            SUM(CHARINDEX('ERR',[VALIDACION_389])),
            SUM(CHARINDEX('ERR',[VALIDACION_390])),
            SUM(CHARINDEX('ERR',[VALIDACION_391])),
            SUM(CHARINDEX('ERR',[VALIDACION_392])),
            SUM(CHARINDEX('ERR',[VALIDACION_393])),
            SUM(CHARINDEX('ERR',[VALIDACION_394])),
            SUM(CHARINDEX('ERR',[VALIDACION_395])),
            SUM(CHARINDEX('ERR',[VALIDACION_396])),
            SUM(CHARINDEX('ERR',[VALIDACION_397])),
            SUM(CHARINDEX('ERR',[VALIDACION_398])),
            SUM(CHARINDEX('ERR',[VALIDACION_399])),
            SUM(CHARINDEX('ERR',[VALIDACION_400]))
            


		from IFRS9_R04A_0420_M15SALDOSTS1_RESULT_4
END

BEGIN
	EXEC SP_IFRS9_R04A_0420_M15SALDOSTS1_VIEW_4
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


