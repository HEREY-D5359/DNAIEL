﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapa 3 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15SALDOS*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0420_M15SALDOSTS1_COMP_13]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0420_M15SALDOSTS1_RESULT_13')
BEGIN
DROP TABLE IFRS9_R04A_0420_M15SALDOSTS1_RESULT_13
END 

BEGIN
SELECT DISTINCT
         /*id*/
CONVERT(VARCHAR,ID) AS ID, 
	/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111803408054')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111803408054')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111803408054) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111803408054) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1201,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111803307035')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111803307035')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111803307035) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111803307035) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1202,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111803508055')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111803508055')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111803508055) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111803508055) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1203,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111803508056')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111803508056')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111803508056) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111803508056) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1204,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111803508057')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111803508057')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111803508057) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111803508057) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1205,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111803307036')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111803307036')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111803307036) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111803307036) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1206,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111803608058')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111803608058')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111803608058) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111803608058) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1207,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111803608059')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111803608059')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111803608059) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111803608059) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1208,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111803307037')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111803307037')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111803307037) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111803307037) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1209,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111803307038')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111803307038')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111803307038) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111803307038) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1210,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111803307039')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111803307039')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111803307039) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111803307039) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1211,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111803307040')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111803307040')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111803307040) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111803307040) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1212,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111803307041')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111803307041')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111803307041) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111803307041) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1213,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111800806034')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111800806034')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111800806034) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111800806034) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1214,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111803407042')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111803407042')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111803407042) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111803407042) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1215,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111804208060')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111804208060')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111804208060) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111804208060) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1216,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111804208061')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111804208061')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111804208061) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111804208061) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1217,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111804208062')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111804208062')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111804208062) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111804208062) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1218,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111803407043')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111803407043')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111803407043) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111803407043) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1219,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111804308063')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111804308063')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111804308063) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111804308063) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1220,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111804308064')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111804308064')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111804308064) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111804308064) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1221,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111804308065')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111804308065')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111804308065) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111804308065) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1222,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111800806035')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111800806035')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111800806035) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111800806035) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1223,

/*Créditos al gobierno federal */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111803507044')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111803507044')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111803507044) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111803507044) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1224,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111803507045')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111803507045')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111803507045) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111803507045) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1225,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111804508066')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111804508066')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111804508066) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111804508066) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1226,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111804508067')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111804508067')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111804508067) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111804508067) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1227,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111804508068')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111804508068')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111804508068) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111804508068) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1228,

/*Fideicomisos públicos de contratación */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111804508069')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111804508069')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111804508069) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111804508069) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1229,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111804508070')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111804508070')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111804508070) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111804508070) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1230,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111803507046')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111803507046')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111803507046) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111803507046) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1231,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111804608071')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111804608071')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111804608071) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111804608071) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1232,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111804608072')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111804608072')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111804608072) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111804608072) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1233,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111804608073')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111804608073')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111804608073) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111804608073) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1234,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111804608074')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111804608074')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111804608074) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111804608074) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1235,

/*Créditos a organismos descentralizados o desconcentrados  */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111803507047')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111803507047')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111803507047) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111803507047) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1236,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111804708075')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111804708075')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111804708075) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111804708075) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1237,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111804708076')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111804708076')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111804708076) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111804708076) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1238,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111804708077')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111804708077')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111804708077) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111804708077) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1239,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111804708078')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111804708078')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111804708078) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111804708078) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1240,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111800305009')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111800305009')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111800305009) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111800305009) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1241,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111800906036')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111800906036')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111800906036) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111800906036) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1242,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111800906037')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111800906037')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111800906037) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111800906037) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1243,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111800906038')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111800906038')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111800906038) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111800906038) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1244,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111800906039')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111800906039')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111800906039) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111800906039) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1245,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111800906040')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111800906040')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111800906040) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111800906040) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1246,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111800906041')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111800906041')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111800906041) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111800906041) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1247,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111800906042')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111800906042')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111800906042) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111800906042) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1248,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111800906043')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111800906043')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111800906043) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111800906043) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1249,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111800305010')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111800305010')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111800305010) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111800305010) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1250,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111801006044')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111801006044')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801006044) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801006044) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1251,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111801006045')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111801006045')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801006045) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801006045) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1252,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111801006046')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111801006046')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801006046) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801006046) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1253,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111804607048')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111804607048')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111804607048) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111804607048) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1254,

/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111804607049')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111804607049')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111804607049) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111804607049) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1255,

/*Remodelación o mejoramiento con garantía otorgada por la Banca de Desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111801006047')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111801006047')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801006047) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801006047) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1256,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111801006048')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111801006048')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801006048) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801006048) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1257,

/*Saldo inicial de cartera de crédito valuada a valor razonable*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112600104001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112600104001')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112600104001) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112600104001) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1258,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112600105001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112600105001')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112600105001) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112600105001) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1259,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112600106001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112600106001')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112600106001) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112600106001) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1260,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112600106002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112600106002')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112600106002) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112600106002) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1261,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112600106003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112600106003')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112600106003) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112600106003) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1262,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112600105002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112600105002')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112600105002) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112600105002) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1263,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112600105003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112600105003')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112600105003) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112600105003) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1264,

/*Entradas a cartera de crédito valuada a valor razonable*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112600104002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112600104002')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112600104002) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112600104002) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1265,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112600205004')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112600205004')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112600205004) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112600205004) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1266,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112600406004')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112600406004')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112600406004) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112600406004) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1267,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112600406005')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112600406005')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112600406005) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112600406005) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1268,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112600406006')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112600406006')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112600406006) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112600406006) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1269,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112600205005')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112600205005')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112600205005) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112600205005) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1270,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112600205006')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112600205006')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112600205006) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112600205006) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1271,

/*Salidas de cartera de crédito valuada a valor razonable*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112600104003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112600104003')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112600104003) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112600104003) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1272,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112600305007')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112600305007')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112600305007) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112600305007) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1273,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112600706007')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112600706007')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112600706007) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112600706007) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1274,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112600706008')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112600706008')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112600706008) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112600706008) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1275,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112600706009')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112600706009')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112600706009) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112600706009) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1276,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112600305008')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112600305008')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112600305008) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112600305008) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1277,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('112600305009')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('112600305009')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112600305009) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112600305009) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1278,

/*Saldo final de cartera de crédito valuada a valor razonable*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('101800104004')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('101800104004')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800104004) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800104004) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1279,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111800405011')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111800405011')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111800405011) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111800405011) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1280,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111801106049')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111801106049')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801106049) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801106049) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1281,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111801106050')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111801106050')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801106050) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801106050) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1282,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111801106051')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111801106051')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801106051) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801106051) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1283,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111800405012')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111800405012')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111800405012) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111800405012) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1284,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0420   
WHERE [c04_CONCEPTO] IN ('111800405013')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0420     
WHERE [c04_CONCEPTO] IN ('111800405013')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111800405013) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111800405013) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1285
	
INTO IFRS9_R04A_0420_M15SALDOSTS1_RESULT_13
FROM IFRS9_R04A_0420

END

BEGIN
	INSERT INTO IFRS9_R04A_0420_M15SALDOSTS1_RESULT_13
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_1201])),
            SUM(CHARINDEX('ERR',[VALIDACION_1202])),
            SUM(CHARINDEX('ERR',[VALIDACION_1203])),
            SUM(CHARINDEX('ERR',[VALIDACION_1204])),
            SUM(CHARINDEX('ERR',[VALIDACION_1205])),
            SUM(CHARINDEX('ERR',[VALIDACION_1206])),
            SUM(CHARINDEX('ERR',[VALIDACION_1207])),
            SUM(CHARINDEX('ERR',[VALIDACION_1208])),
            SUM(CHARINDEX('ERR',[VALIDACION_1209])),
            SUM(CHARINDEX('ERR',[VALIDACION_1210])),
            SUM(CHARINDEX('ERR',[VALIDACION_1211])),
            SUM(CHARINDEX('ERR',[VALIDACION_1212])),
            SUM(CHARINDEX('ERR',[VALIDACION_1213])),
            SUM(CHARINDEX('ERR',[VALIDACION_1214])),
            SUM(CHARINDEX('ERR',[VALIDACION_1215])),
            SUM(CHARINDEX('ERR',[VALIDACION_1216])),
            SUM(CHARINDEX('ERR',[VALIDACION_1217])),
            SUM(CHARINDEX('ERR',[VALIDACION_1218])),
            SUM(CHARINDEX('ERR',[VALIDACION_1219])),
            SUM(CHARINDEX('ERR',[VALIDACION_1220])),
            SUM(CHARINDEX('ERR',[VALIDACION_1221])),
            SUM(CHARINDEX('ERR',[VALIDACION_1222])),
            SUM(CHARINDEX('ERR',[VALIDACION_1223])),
            SUM(CHARINDEX('ERR',[VALIDACION_1224])),
            SUM(CHARINDEX('ERR',[VALIDACION_1225])),
            SUM(CHARINDEX('ERR',[VALIDACION_1226])),
            SUM(CHARINDEX('ERR',[VALIDACION_1227])),
            SUM(CHARINDEX('ERR',[VALIDACION_1228])),
            SUM(CHARINDEX('ERR',[VALIDACION_1229])),
            SUM(CHARINDEX('ERR',[VALIDACION_1230])),
            SUM(CHARINDEX('ERR',[VALIDACION_1231])),
            SUM(CHARINDEX('ERR',[VALIDACION_1232])),
            SUM(CHARINDEX('ERR',[VALIDACION_1233])),
            SUM(CHARINDEX('ERR',[VALIDACION_1234])),
            SUM(CHARINDEX('ERR',[VALIDACION_1235])),
            SUM(CHARINDEX('ERR',[VALIDACION_1236])),
            SUM(CHARINDEX('ERR',[VALIDACION_1237])),
            SUM(CHARINDEX('ERR',[VALIDACION_1238])),
            SUM(CHARINDEX('ERR',[VALIDACION_1239])),
            SUM(CHARINDEX('ERR',[VALIDACION_1240])),
            SUM(CHARINDEX('ERR',[VALIDACION_1241])),
            SUM(CHARINDEX('ERR',[VALIDACION_1242])),
            SUM(CHARINDEX('ERR',[VALIDACION_1243])),
            SUM(CHARINDEX('ERR',[VALIDACION_1244])),
            SUM(CHARINDEX('ERR',[VALIDACION_1245])),
            SUM(CHARINDEX('ERR',[VALIDACION_1246])),
            SUM(CHARINDEX('ERR',[VALIDACION_1247])),
            SUM(CHARINDEX('ERR',[VALIDACION_1248])),
            SUM(CHARINDEX('ERR',[VALIDACION_1249])),
            SUM(CHARINDEX('ERR',[VALIDACION_1250])),
            SUM(CHARINDEX('ERR',[VALIDACION_1251])),
            SUM(CHARINDEX('ERR',[VALIDACION_1252])),
            SUM(CHARINDEX('ERR',[VALIDACION_1253])),
            SUM(CHARINDEX('ERR',[VALIDACION_1254])),
            SUM(CHARINDEX('ERR',[VALIDACION_1255])),
            SUM(CHARINDEX('ERR',[VALIDACION_1256])),
            SUM(CHARINDEX('ERR',[VALIDACION_1257])),
            SUM(CHARINDEX('ERR',[VALIDACION_1258])),
            SUM(CHARINDEX('ERR',[VALIDACION_1259])),
            SUM(CHARINDEX('ERR',[VALIDACION_1260])),
            SUM(CHARINDEX('ERR',[VALIDACION_1261])),
            SUM(CHARINDEX('ERR',[VALIDACION_1262])),
            SUM(CHARINDEX('ERR',[VALIDACION_1263])),
            SUM(CHARINDEX('ERR',[VALIDACION_1264])),
            SUM(CHARINDEX('ERR',[VALIDACION_1265])),
            SUM(CHARINDEX('ERR',[VALIDACION_1266])),
            SUM(CHARINDEX('ERR',[VALIDACION_1267])),
            SUM(CHARINDEX('ERR',[VALIDACION_1268])),
            SUM(CHARINDEX('ERR',[VALIDACION_1269])),
            SUM(CHARINDEX('ERR',[VALIDACION_1270])),
            SUM(CHARINDEX('ERR',[VALIDACION_1271])),
            SUM(CHARINDEX('ERR',[VALIDACION_1272])),
            SUM(CHARINDEX('ERR',[VALIDACION_1273])),
            SUM(CHARINDEX('ERR',[VALIDACION_1274])),
            SUM(CHARINDEX('ERR',[VALIDACION_1275])),
            SUM(CHARINDEX('ERR',[VALIDACION_1276])),
            SUM(CHARINDEX('ERR',[VALIDACION_1277])),
            SUM(CHARINDEX('ERR',[VALIDACION_1278])),
            SUM(CHARINDEX('ERR',[VALIDACION_1279])),
            SUM(CHARINDEX('ERR',[VALIDACION_1280])),
            SUM(CHARINDEX('ERR',[VALIDACION_1281])),
            SUM(CHARINDEX('ERR',[VALIDACION_1282])),
            SUM(CHARINDEX('ERR',[VALIDACION_1283])),
            SUM(CHARINDEX('ERR',[VALIDACION_1284])),
            SUM(CHARINDEX('ERR',[VALIDACION_1285]))
            


		from IFRS9_R04A_0420_M15SALDOSTS1_RESULT_13
END

BEGIN
	EXEC SP_IFRS9_R04A_0420_M15SALDOSTS1_VIEW_13
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


