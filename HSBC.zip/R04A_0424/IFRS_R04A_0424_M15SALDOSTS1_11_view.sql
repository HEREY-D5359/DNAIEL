﻿
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapas 1 y 2 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15SALDOS*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/


CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0424_M15SALDOSTS1_VIEW_11]
AS
BEGIN
	SELECT *
		
	FROM IFRS9_R04A_0424_M15SALDOSTS1_RESULT_11
	WHERE

        (VALIDACION_1001 <> '' ) OR
        (VALIDACION_1002 <> '' ) OR
        (VALIDACION_1003 <> '' ) OR
        (VALIDACION_1004 <> '' ) OR
        (VALIDACION_1005 <> '' ) OR
        (VALIDACION_1006 <> '' ) OR
        (VALIDACION_1007 <> '' ) OR
        (VALIDACION_1008 <> '' ) OR
        (VALIDACION_1009 <> '' ) OR
        (VALIDACION_1010 <> '' ) OR
        (VALIDACION_1011 <> '' ) OR
        (VALIDACION_1012 <> '' ) OR
        (VALIDACION_1013 <> '' ) OR
        (VALIDACION_1014 <> '' ) OR
        (VALIDACION_1015 <> '' ) OR
        (VALIDACION_1016 <> '' ) OR
        (VALIDACION_1017 <> '' ) OR
        (VALIDACION_1018 <> '' ) OR
        (VALIDACION_1019 <> '' ) OR
        (VALIDACION_1020 <> '' ) OR
        (VALIDACION_1021 <> '' ) OR
        (VALIDACION_1022 <> '' ) OR
        (VALIDACION_1023 <> '' ) OR
        (VALIDACION_1024 <> '' ) OR
        (VALIDACION_1025 <> '' ) OR
        (VALIDACION_1026 <> '' ) OR
        (VALIDACION_1027 <> '' ) OR
        (VALIDACION_1028 <> '' ) OR
        (VALIDACION_1029 <> '' ) OR
        (VALIDACION_1030 <> '' ) OR
        (VALIDACION_1031 <> '' ) OR
        (VALIDACION_1032 <> '' ) OR
        (VALIDACION_1033 <> '' ) OR
        (VALIDACION_1034 <> '' ) OR
        (VALIDACION_1035 <> '' ) OR
        (VALIDACION_1036 <> '' ) OR
        (VALIDACION_1037 <> '' ) OR
        (VALIDACION_1038 <> '' ) OR
        (VALIDACION_1039 <> '' ) OR
        (VALIDACION_1040 <> '' ) OR
        (VALIDACION_1041 <> '' ) OR
        (VALIDACION_1042 <> '' ) OR
        (VALIDACION_1043 <> '' ) OR
        (VALIDACION_1044 <> '' ) OR
        (VALIDACION_1045 <> '' ) OR
        (VALIDACION_1046 <> '' ) OR
        (VALIDACION_1047 <> '' ) OR
        (VALIDACION_1048 <> '' ) OR
        (VALIDACION_1049 <> '' ) OR
        (VALIDACION_1050 <> '' ) OR
        (VALIDACION_1051 <> '' ) OR
        (VALIDACION_1052 <> '' ) OR
        (VALIDACION_1053 <> '' ) OR
        (VALIDACION_1054 <> '' ) OR
        (VALIDACION_1055 <> '' ) OR
        (VALIDACION_1056 <> '' ) OR
        (VALIDACION_1057 <> '' ) OR
        (VALIDACION_1058 <> '' ) OR
        (VALIDACION_1059 <> '' ) OR
        (VALIDACION_1060 <> '' ) OR
        (VALIDACION_1061 <> '' ) OR
        (VALIDACION_1062 <> '' ) OR
        (VALIDACION_1063 <> '' ) OR
        (VALIDACION_1064 <> '' ) OR
        (VALIDACION_1065 <> '' ) OR
        (VALIDACION_1066 <> '' ) OR
        (VALIDACION_1067 <> '' ) OR
        (VALIDACION_1068 <> '' ) OR
        (VALIDACION_1069 <> '' ) OR
        (VALIDACION_1070 <> '' ) OR
        (VALIDACION_1071 <> '' ) OR
        (VALIDACION_1072 <> '' ) OR
        (VALIDACION_1073 <> '' ) OR
        (VALIDACION_1074 <> '' ) OR
        (VALIDACION_1075 <> '' ) OR
        (VALIDACION_1076 <> '' ) OR
        (VALIDACION_1077 <> '' ) OR
        (VALIDACION_1078 <> '' ) OR
        (VALIDACION_1079 <> '' ) OR
        (VALIDACION_1080 <> '' ) OR
        (VALIDACION_1081 <> '' ) OR
        (VALIDACION_1082 <> '' ) OR
        (VALIDACION_1083 <> '' ) OR
        (VALIDACION_1084 <> '' ) OR
        (VALIDACION_1085 <> '' ) OR
        (VALIDACION_1086 <> '' ) OR
        (VALIDACION_1087 <> '' ) OR
        (VALIDACION_1088 <> '' ) OR
        (VALIDACION_1089 <> '' ) OR
        (VALIDACION_1090 <> '' ) OR
        (VALIDACION_1091 <> '' ) OR
        (VALIDACION_1092 <> '' ) OR
        (VALIDACION_1093 <> '' ) OR
        (VALIDACION_1094 <> '' ) OR
        (VALIDACION_1095 <> '' ) OR
        (VALIDACION_1096 <> '' ) OR
        (VALIDACION_1097 <> '' ) OR
        (VALIDACION_1098 <> '' ) OR
        (VALIDACION_1099 <> '' ) OR
        (VALIDACION_1100 <> '' ) 
ORDER BY 1
END

