﻿
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapas 1 y 2 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15SALDOS*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/


CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0424_M15SALDOSTS1_VIEW_20]
AS
BEGIN
	SELECT *
		
	FROM IFRS9_R04A_0424_M15SALDOSTS1_RESULT_20
	WHERE

        (VALIDACION_1901 <> '' ) OR
        (VALIDACION_1902 <> '' ) OR
        (VALIDACION_1903 <> '' ) OR
        (VALIDACION_1904 <> '' ) OR
        (VALIDACION_1905 <> '' ) OR
        (VALIDACION_1906 <> '' ) OR
        (VALIDACION_1907 <> '' ) OR
        (VALIDACION_1908 <> '' ) OR
        (VALIDACION_1909 <> '' ) OR
        (VALIDACION_1910 <> '' ) OR
        (VALIDACION_1911 <> '' ) OR
        (VALIDACION_1912 <> '' ) OR
        (VALIDACION_1913 <> '' ) OR
        (VALIDACION_1914 <> '' ) OR
        (VALIDACION_1915 <> '' ) OR
        (VALIDACION_1916 <> '' ) OR
        (VALIDACION_1917 <> '' ) OR
        (VALIDACION_1918 <> '' ) OR
        (VALIDACION_1919 <> '' ) OR
        (VALIDACION_1920 <> '' ) OR
        (VALIDACION_1921 <> '' ) OR
        (VALIDACION_1922 <> '' ) OR
        (VALIDACION_1923 <> '' ) OR
        (VALIDACION_1924 <> '' ) OR
        (VALIDACION_1925 <> '' ) OR
        (VALIDACION_1926 <> '' ) OR
        (VALIDACION_1927 <> '' ) OR
        (VALIDACION_1928 <> '' ) OR
        (VALIDACION_1929 <> '' ) OR
        (VALIDACION_1930 <> '' ) OR
        (VALIDACION_1931 <> '' ) OR
        (VALIDACION_1932 <> '' ) OR
        (VALIDACION_1933 <> '' ) OR
        (VALIDACION_1934 <> '' ) OR
        (VALIDACION_1935 <> '' ) OR
        (VALIDACION_1936 <> '' ) OR
        (VALIDACION_1937 <> '' ) OR
        (VALIDACION_1938 <> '' ) OR
        (VALIDACION_1939 <> '' ) OR
        (VALIDACION_1940 <> '' ) OR
        (VALIDACION_1941 <> '' ) OR
        (VALIDACION_1942 <> '' ) OR
        (VALIDACION_1943 <> '' ) OR
        (VALIDACION_1944 <> '' ) OR
        (VALIDACION_1945 <> '' ) OR
        (VALIDACION_1946 <> '' ) OR
        (VALIDACION_1947 <> '' ) OR
        (VALIDACION_1948 <> '' ) OR
        (VALIDACION_1949 <> '' ) OR
        (VALIDACION_1950 <> '' ) OR
        (VALIDACION_1951 <> '' ) OR
        (VALIDACION_1952 <> '' ) OR
        (VALIDACION_1953 <> '' ) OR
        (VALIDACION_1954 <> '' ) OR
        (VALIDACION_1955 <> '' ) OR
        (VALIDACION_1956 <> '' ) OR
        (VALIDACION_1957 <> '' ) OR
        (VALIDACION_1958 <> '' ) OR
        (VALIDACION_1959 <> '' ) OR
        (VALIDACION_1960 <> '' ) OR
        (VALIDACION_1961 <> '' ) OR
        (VALIDACION_1962 <> '' ) OR
        (VALIDACION_1963 <> '' ) OR
        (VALIDACION_1964 <> '' ) OR
        (VALIDACION_1965 <> '' ) OR
        (VALIDACION_1966 <> '' ) OR
        (VALIDACION_1967 <> '' ) OR
        (VALIDACION_1968 <> '' ) OR
        (VALIDACION_1969 <> '' ) OR
        (VALIDACION_1970 <> '' ) OR
        (VALIDACION_1971 <> '' ) OR
        (VALIDACION_1972 <> '' ) OR
        (VALIDACION_1973 <> '' ) OR
        (VALIDACION_1974 <> '' ) OR
        (VALIDACION_1975 <> '' ) OR
        (VALIDACION_1976 <> '' ) OR
        (VALIDACION_1977 <> '' ) OR
        (VALIDACION_1978 <> '' ) OR
        (VALIDACION_1979 <> '' ) OR
        (VALIDACION_1980 <> '' ) OR
        (VALIDACION_1981 <> '' ) OR
        (VALIDACION_1982 <> '' ) OR
        (VALIDACION_1983 <> '' ) OR
        (VALIDACION_1984 <> '' ) OR
        (VALIDACION_1985 <> '' ) OR
        (VALIDACION_1986 <> '' ) OR
        (VALIDACION_1987 <> '' ) OR
        (VALIDACION_1988 <> '' ) OR
        (VALIDACION_1989 <> '' ) OR
        (VALIDACION_1990 <> '' ) OR
        (VALIDACION_1991 <> '' ) OR
        (VALIDACION_1992 <> '' ) OR
        (VALIDACION_1993 <> '' ) OR
        (VALIDACION_1994 <> '' ) OR
        (VALIDACION_1995 <> '' ) OR
        (VALIDACION_1996 <> '' ) OR
        (VALIDACION_1997 <> '' ) OR
        (VALIDACION_1998 <> '' ) OR
        (VALIDACION_1999 <> '' ) OR
        (VALIDACION_2000 <> '' ) 
ORDER BY 1
END

