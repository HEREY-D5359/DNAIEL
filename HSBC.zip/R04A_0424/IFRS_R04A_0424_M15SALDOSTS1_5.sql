﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapas 1 y 2 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15SALDOS*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0424_M15SALDOSTS1_COMP_5]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0424_M15SALDOSTS1_RESULT_5')
BEGIN
DROP TABLE IFRS9_R04A_0424_M15SALDOSTS1_RESULT_5
END 

BEGIN
SELECT DISTINCT

	/*ID*/

	CONVERT(VARCHAR,ID)  AS ID,   
	/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112009908119')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112009908119')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112009908119) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112009908119) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_401,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112011909141')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112011909141')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112011909141) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112011909141) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_402,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112011909142')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112011909142')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112011909142) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112011909142) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_403,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112011909143')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112011909143')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112011909143) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112011909143) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_404,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112003507100')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112003507100')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112003507100) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112003507100) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_405,

/*Créditos al gobierno federal */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112010008120')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112010008120')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112010008120) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112010008120) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_406,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112010008121')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112010008121')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112010008121) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112010008121) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_407,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112012109144')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112012109144')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112012109144) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112012109144) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_408,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112012109145')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112012109145')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112012109145) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112012109145) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_409,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112012109146')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112012109146')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112012109146) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112012109146) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_410,

/*Fideicomisos públicos de contratación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112012109147')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112012109147')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112012109147) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112012109147) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_411,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112012109148')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112012109148')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112012109148) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112012109148) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_412,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112010008122')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112010008122')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112010008122) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112010008122) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_413,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112012209149')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112012209149')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112012209149) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112012209149) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_414,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112012209150')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112012209150')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112012209150) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112012209150) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_415,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112012209151')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112012209151')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112012209151) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112012209151) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_416,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112012209152')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112012209152')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112012209152) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112012209152) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_417,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112010008123')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112010008123')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112010008123) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112010008123) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_418,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112012309153')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112012309153')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112012309153) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112012309153) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_419,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112012309154')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112012309154')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112012309154) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112012309154) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_420,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112012309155')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112012309155')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112012309155) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112012309155) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_421,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112012309156')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112012309156')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112012309156) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112012309156) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_422,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112001006036')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112001006036')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112001006036) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112001006036) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_423,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112003607101')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112003607101')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112003607101) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112003607101) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_424,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112003607102')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112003607102')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112003607102) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112003607102) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_425,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112003607103')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112003607103')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112003607103) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112003607103) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_426,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112003607104')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112003607104')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112003607104) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112003607104) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_427,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112003607105')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112003607105')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112003607105) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112003607105) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_428,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112003607106')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112003607106')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112003607106) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112003607106) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_429,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112003607107')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112003607107')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112003607107) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112003607107) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_430,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112003607108')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112003607108')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112003607108) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112003607108) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_431,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112001006037')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112001006037')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112001006037) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112001006037) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_432,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112003707109')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112003707109')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112003707109) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112003707109) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_433,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112003707110')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112003707110')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112003707110) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112003707110) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_434,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112003707111')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112003707111')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112003707111) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112003707111) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_435,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112011108124')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112011108124')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112011108124) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112011108124) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_436,

/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112011108125')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112011108125')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112011108125) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112011108125) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_437,

/*Remodelación o mejoramiento con garantía otorgada por la Banca de Desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112003707112')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112003707112')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112003707112) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112003707112) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_438,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112003707113')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112003707113')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112003707113) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112003707113) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_439,

/*Traspaso de cartera de crédito valuada a valor razonable*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112000205011')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112000205011')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112000205011) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112000205011) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_440,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112001106038')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112001106038')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112001106038) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112001106038) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_441,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112003807114')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112003807114')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112003807114) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112003807114) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_442,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112003807115')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112003807115')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112003807115) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112003807115) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_443,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112003807116')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112003807116')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112003807116) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112003807116) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_444,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112001106039')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112001106039')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112001106039) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112001106039) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_445,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112001106040')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112001106040')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112001106040) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112001106040) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_446,

/*Salidas de cartera con riesgo de crédito etapa 1*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112000104003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112000104003')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112000104003) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112000104003) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_447,

/*Reestructuras y renovaciones (2)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112000305012')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112000305012')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112000305012) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112000305012) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_448,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112001206041')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112001206041')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112001206041) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112001206041) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_449,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112004107117')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112004107117')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112004107117) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112004107117) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_450,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112011708126')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112011708126')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112011708126) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112011708126) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_451,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112012609157')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112012609157')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112012609157) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112012609157) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_452,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112012609158')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112012609158')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112012609158) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112012609158) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_453,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112011708127')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112011708127')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112011708127) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112011708127) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_454,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112012709159')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112012709159')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112012709159) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112012709159) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_455,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112012709160')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112012709160')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112012709160) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112012709160) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_456,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112012709161')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112012709161')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112012709161) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112012709161) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_457,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112011708128')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112011708128')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112011708128) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112011708128) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_458,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112012809162')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112012809162')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112012809162) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112012809162) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_459,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112012809163')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112012809163')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112012809163) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112012809163) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_460,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112011708129')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112011708129')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112011708129) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112011708129) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_461,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112011708130')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112011708130')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112011708130) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112011708130) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_462,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112011708131')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112011708131')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112011708131) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112011708131) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_463,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112011708132')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112011708132')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112011708132) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112011708132) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_464,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112011708133')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112011708133')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112011708133) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112011708133) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_465,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112004107118')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112004107118')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112004107118) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112004107118) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_466,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112011808134')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112011808134')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112011808134) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112011808134) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_467,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112013409164')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112013409164')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112013409164) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112013409164) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_468,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112013409165')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112013409165')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112013409165) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112013409165) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_469,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112013409166')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112013409166')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112013409166) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112013409166) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_470,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112011808135')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112011808135')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112011808135) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112011808135) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_471,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112013509167')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112013509167')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112013509167) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112013509167) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_472,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112013509168')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112013509168')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112013509168) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112013509168) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_473,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112013509169')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112013509169')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112013509169) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112013509169) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_474,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112004107119')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112004107119')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112004107119) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112004107119) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_475,

/*Créditos al gobierno federal */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112011908136')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112011908136')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112011908136) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112011908136) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_476,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112011908137')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112011908137')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112011908137) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112011908137) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_477,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112013709170')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112013709170')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112013709170) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112013709170) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_478,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112013709171')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112013709171')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112013709171) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112013709171) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_479,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112013709172')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112013709172')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112013709172) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112013709172) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_480,

/*Fideicomisos públicos de contratación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112013709173')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112013709173')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112013709173) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112013709173) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_481,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112013709174')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112013709174')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112013709174) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112013709174) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_482,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112011908138')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112011908138')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112011908138) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112011908138) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_483,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112013809175')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112013809175')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112013809175) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112013809175) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_484,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112013809176')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112013809176')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112013809176) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112013809176) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_485,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112013809177')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112013809177')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112013809177) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112013809177) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_486,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112013809178')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112013809178')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112013809178) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112013809178) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_487,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112011908139')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112011908139')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112011908139) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112011908139) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_488,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112013909179')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112013909179')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112013909179) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112013909179) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_489,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112013909180')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112013909180')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112013909180) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112013909180) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_490,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112013909181')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112013909181')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112013909181) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112013909181) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_491,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112013909182')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112013909182')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112013909182) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112013909182) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_492,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112001206042')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112001206042')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112001206042) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112001206042) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_493,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112004207120')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112004207120')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112004207120) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112004207120) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_494,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112004207121')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112004207121')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112004207121) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112004207121) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_495,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112004207122')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112004207122')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112004207122) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112004207122) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_496,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112004207123')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112004207123')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112004207123) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112004207123) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_497,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112004207124')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112004207124')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112004207124) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112004207124) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_498,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112004207125')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112004207125')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112004207125) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112004207125) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_499,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112004207126')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112004207126')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112004207126) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112004207126) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_500
	
INTO IFRS9_R04A_0424_M15SALDOSTS1_RESULT_5
FROM IFRS9_R04A_0424

END

BEGIN
	INSERT INTO IFRS9_R04A_0424_M15SALDOSTS1_RESULT_5 
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_401])),
            SUM(CHARINDEX('ERR',[VALIDACION_402])),
            SUM(CHARINDEX('ERR',[VALIDACION_403])),
            SUM(CHARINDEX('ERR',[VALIDACION_404])),
            SUM(CHARINDEX('ERR',[VALIDACION_405])),
            SUM(CHARINDEX('ERR',[VALIDACION_406])),
            SUM(CHARINDEX('ERR',[VALIDACION_407])),
            SUM(CHARINDEX('ERR',[VALIDACION_408])),
            SUM(CHARINDEX('ERR',[VALIDACION_409])),
            SUM(CHARINDEX('ERR',[VALIDACION_410])),
            SUM(CHARINDEX('ERR',[VALIDACION_411])),
            SUM(CHARINDEX('ERR',[VALIDACION_412])),
            SUM(CHARINDEX('ERR',[VALIDACION_413])),
            SUM(CHARINDEX('ERR',[VALIDACION_414])),
            SUM(CHARINDEX('ERR',[VALIDACION_415])),
            SUM(CHARINDEX('ERR',[VALIDACION_416])),
            SUM(CHARINDEX('ERR',[VALIDACION_417])),
            SUM(CHARINDEX('ERR',[VALIDACION_418])),
            SUM(CHARINDEX('ERR',[VALIDACION_419])),
            SUM(CHARINDEX('ERR',[VALIDACION_420])),
            SUM(CHARINDEX('ERR',[VALIDACION_421])),
            SUM(CHARINDEX('ERR',[VALIDACION_422])),
            SUM(CHARINDEX('ERR',[VALIDACION_423])),
            SUM(CHARINDEX('ERR',[VALIDACION_424])),
            SUM(CHARINDEX('ERR',[VALIDACION_425])),
            SUM(CHARINDEX('ERR',[VALIDACION_426])),
            SUM(CHARINDEX('ERR',[VALIDACION_427])),
            SUM(CHARINDEX('ERR',[VALIDACION_428])),
            SUM(CHARINDEX('ERR',[VALIDACION_429])),
            SUM(CHARINDEX('ERR',[VALIDACION_430])),
            SUM(CHARINDEX('ERR',[VALIDACION_431])),
            SUM(CHARINDEX('ERR',[VALIDACION_432])),
            SUM(CHARINDEX('ERR',[VALIDACION_433])),
            SUM(CHARINDEX('ERR',[VALIDACION_434])),
            SUM(CHARINDEX('ERR',[VALIDACION_435])),
            SUM(CHARINDEX('ERR',[VALIDACION_436])),
            SUM(CHARINDEX('ERR',[VALIDACION_437])),
            SUM(CHARINDEX('ERR',[VALIDACION_438])),
            SUM(CHARINDEX('ERR',[VALIDACION_439])),
            SUM(CHARINDEX('ERR',[VALIDACION_440])),
            SUM(CHARINDEX('ERR',[VALIDACION_441])),
            SUM(CHARINDEX('ERR',[VALIDACION_442])),
            SUM(CHARINDEX('ERR',[VALIDACION_443])),
            SUM(CHARINDEX('ERR',[VALIDACION_444])),
            SUM(CHARINDEX('ERR',[VALIDACION_445])),
            SUM(CHARINDEX('ERR',[VALIDACION_446])),
            SUM(CHARINDEX('ERR',[VALIDACION_447])),
            SUM(CHARINDEX('ERR',[VALIDACION_448])),
            SUM(CHARINDEX('ERR',[VALIDACION_449])),
            SUM(CHARINDEX('ERR',[VALIDACION_450])),
            SUM(CHARINDEX('ERR',[VALIDACION_451])),
            SUM(CHARINDEX('ERR',[VALIDACION_452])),
            SUM(CHARINDEX('ERR',[VALIDACION_453])),
            SUM(CHARINDEX('ERR',[VALIDACION_454])),
            SUM(CHARINDEX('ERR',[VALIDACION_455])),
            SUM(CHARINDEX('ERR',[VALIDACION_456])),
            SUM(CHARINDEX('ERR',[VALIDACION_457])),
            SUM(CHARINDEX('ERR',[VALIDACION_458])),
            SUM(CHARINDEX('ERR',[VALIDACION_459])),
            SUM(CHARINDEX('ERR',[VALIDACION_460])),
            SUM(CHARINDEX('ERR',[VALIDACION_461])),
            SUM(CHARINDEX('ERR',[VALIDACION_462])),
            SUM(CHARINDEX('ERR',[VALIDACION_463])),
            SUM(CHARINDEX('ERR',[VALIDACION_464])),
            SUM(CHARINDEX('ERR',[VALIDACION_465])),
            SUM(CHARINDEX('ERR',[VALIDACION_466])),
            SUM(CHARINDEX('ERR',[VALIDACION_467])),
            SUM(CHARINDEX('ERR',[VALIDACION_468])),
            SUM(CHARINDEX('ERR',[VALIDACION_469])),
            SUM(CHARINDEX('ERR',[VALIDACION_470])),
            SUM(CHARINDEX('ERR',[VALIDACION_471])),
            SUM(CHARINDEX('ERR',[VALIDACION_472])),
            SUM(CHARINDEX('ERR',[VALIDACION_473])),
            SUM(CHARINDEX('ERR',[VALIDACION_474])),
            SUM(CHARINDEX('ERR',[VALIDACION_475])),
            SUM(CHARINDEX('ERR',[VALIDACION_476])),
            SUM(CHARINDEX('ERR',[VALIDACION_477])),
            SUM(CHARINDEX('ERR',[VALIDACION_478])),
            SUM(CHARINDEX('ERR',[VALIDACION_479])),
            SUM(CHARINDEX('ERR',[VALIDACION_480])),
            SUM(CHARINDEX('ERR',[VALIDACION_481])),
            SUM(CHARINDEX('ERR',[VALIDACION_482])),
            SUM(CHARINDEX('ERR',[VALIDACION_483])),
            SUM(CHARINDEX('ERR',[VALIDACION_484])),
            SUM(CHARINDEX('ERR',[VALIDACION_485])),
            SUM(CHARINDEX('ERR',[VALIDACION_486])),
            SUM(CHARINDEX('ERR',[VALIDACION_487])),
            SUM(CHARINDEX('ERR',[VALIDACION_488])),
            SUM(CHARINDEX('ERR',[VALIDACION_489])),
            SUM(CHARINDEX('ERR',[VALIDACION_490])),
            SUM(CHARINDEX('ERR',[VALIDACION_491])),
            SUM(CHARINDEX('ERR',[VALIDACION_492])),
            SUM(CHARINDEX('ERR',[VALIDACION_493])),
            SUM(CHARINDEX('ERR',[VALIDACION_494])),
            SUM(CHARINDEX('ERR',[VALIDACION_495])),
            SUM(CHARINDEX('ERR',[VALIDACION_496])),
            SUM(CHARINDEX('ERR',[VALIDACION_497])),
            SUM(CHARINDEX('ERR',[VALIDACION_498])),
            SUM(CHARINDEX('ERR',[VALIDACION_499])),
            SUM(CHARINDEX('ERR',[VALIDACION_500]))
            


		FROM IFRS9_R04A_0424_M15SALDOSTS1_RESULT_5 
END

BEGIN
	EXEC SP_IFRS9_R04A_0424_M15SALDOSTS1_VIEW_5
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


