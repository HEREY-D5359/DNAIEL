SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapas 1 y 2 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*[IFRS9_R04A_0424]*/

CREATE TABLE [dbo].[IFRS9_R04A_0424](
	[c04_concepto] [varchar](255) NULL,
	[c05_moneda] [varchar](255) NULL,
	[c06_tipo_saldo] [varchar](255) NULL,
	[c07_dato] [varchar](255) NULL
) ON [PRIMARY]
GO


