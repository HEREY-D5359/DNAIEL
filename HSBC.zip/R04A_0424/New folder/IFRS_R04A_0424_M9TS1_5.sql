﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapas 1 y 2 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 9*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0424_M9TS1_COMP_5]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0424_M9TS1_RESULT_5')
BEGIN
DROP TABLE IFRS9_R04A_0424_M9TS1_RESULT_5
END 

BEGIN
SELECT DISTINCT

	/*ID*/

	CONVERT(VARCHAR,ID)  AS ID,   
	/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112208208100')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112210009115','112210009116','112210009117')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112208208100) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112210009115 + 112210009116 + 112210009117) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_401,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202907083')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112208308101','112208308102','112208308103','112208308104')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112202907083) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112208308101 + 112208308102 + 112208308103 + 112208308104) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_402,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112208308102')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112210209118','112210209119','112210209120','112210209121','112210209122')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112208308102) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112210209118 + 112210209119 + 112210209120 + 112210209121 + 112210209122) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_403,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112208308103')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112210309123','112210309124','112210309125','112210309126')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112208308103) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112210309123 + 112210309124 + 112210309125 + 112210309126) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_404,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112208308104')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112210409127','112210409128','112210409129','112210409130')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112208308104) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112210409127 + 112210409128 + 112210409129 + 112210409130) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_405,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200806030')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112203007084','112203007085','112203007086','112203007087','112203007088','112203007089','112203007090','112203007091')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200806030) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112203007084 + 112203007085 + 112203007086 + 112203007087 + 112203007088 + 112203007089 + 112203007090 + 112203007091) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_406,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200806031')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112203107092','112203107093','112203107094','112203107095','112203107096')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200806031) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112203107092 + 112203107093 + 112203107094 + 112203107095 + 112203107096) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_407,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112203107094')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112209408105','112209408106')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112203107094) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112209408105 + 112209408106) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_408,

/*Traspaso de cartera de crédito valuada a valor razonable*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200205009')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200906032','112200906033','112200906034')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200205009) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112200906032 + 112200906033 + 112200906034) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_409,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200906032')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112203207097','112203207098','112203207099')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200906032) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112203207097 + 112203207098 + 112203207099) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_410,

/*Salidas de cartera con riesgo de crédito etapa 2*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200104003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200305010','112200305011','112200305012','112200305013','112200305014','112200305015')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200104003) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112200305010 + 112200305011 + 112200305012 + 112200305013 + 112200305014 + 112200305015) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_411,

/*Reestructuras y renovaciones (2)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200305010')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201006035','112201006036','112201006037')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200305010) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112201006035 + 112201006036 + 112201006037) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_412,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201006035')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112203507100','112203507101','112203507102')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201006035) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112203507100 + 112203507101 + 112203507102) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_413,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112203507100')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112210008107','112210008108','112210008109','112210008110','112210008111','112210008112','112210008113','112210008114')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112203507100) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112210008107 + 112210008108 + 112210008109 + 112210008110 + 112210008111 + 112210008112 + 112210008113 + 112210008114) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_414,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112210008107')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112210709131','112210709132')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112210008107) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112210709131 + 112210709132) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_415,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112210008108')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112210809133','112210809134','112210809135')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112210008108) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112210809133 + 112210809134 + 112210809135) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_416,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112210008109')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112210909136','112210909137')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112210008109) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112210909136 + 112210909137) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_417,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112203507101')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112210108115','112210108116')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112203507101) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112210108115 + 112210108116) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_418,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112210108115')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112211509138','112211509139','112211509140')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112210108115) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112211509138 + 112211509139 + 112211509140) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_419,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112210108116')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112211609141','112211609142','112211609143')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112210108116) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112211609141 + 112211609142 + 112211609143) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_420,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112203507102')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112210208117','112210208118','112210208119','112210208120')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112203507102) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112210208117 + 112210208118 + 112210208119 + 112210208120) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_421,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112210208118')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112211809144','112211809145','112211809146','112211809147','112211809148')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112210208118) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112211809144 + 112211809145 + 112211809146 + 112211809147 + 112211809148) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_422,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112210208119')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112211909149','112211909150','112211909151','112211909152')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112210208119) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112211909149 + 112211909150 + 112211909151 + 112211909152) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_423,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112210208120')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112212009153','112212009154','112212009155','112212009156')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112210208120) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112212009153 + 112212009154 + 112212009155 + 112212009156) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_424,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201006036')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112203607103','112203607104','112203607105','112203607106','112203607107','112203607108','112203607109','112203607110')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201006036) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112203607103 + 112203607104 + 112203607105 + 112203607106 + 112203607107 + 112203607108 + 112203607109 + 112203607110) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_425,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201006037')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112203707111','112203707112','112203707113','112203707114','112203707115')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201006037) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112203707111 + 112203707112 + 112203707113 + 112203707114 + 112203707115) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_426,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112203707113')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112211308121','112211308122')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112203707113) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112211308121 + 112211308122) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_427,

/*Créditos liquidados (3)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200305011')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201106038','112201106039','112201106040','112201106041','112201106042')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200305011) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112201106038 + 112201106039 + 112201106040 + 112201106041 + 112201106042) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_428,

/*Cobranza en efectivo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201106038')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112203807116','112203807117','112203807118')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201106038) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112203807116 + 112203807117 + 112203807118) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_429,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112203807116')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112211608123','112211608124','112211608125')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112203807116) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112211608123 + 112211608124 + 112211608125) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_430,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112211608123')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112212309157','112212309158','112212309159','112212309160','112212309161','112212309162','112212309163','112212309164')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112211608123) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112212309157 + 112212309158 + 112212309159 + 112212309160 + 112212309161 + 112212309162 + 112212309163 + 112212309164) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_431,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112212309157')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112215710001','112215710002')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112212309157) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112215710001 + 112215710002) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_432,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112212309158')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112215810003','112215810004','112215810005')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112212309158) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112215810003 + 112215810004 + 112215810005) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_433,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112212309159')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112215910006','112215910007')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112212309159) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112215910006 + 112215910007) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_434,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112211608124')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112212409165','112212409166')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112211608124) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112212409165 + 112212409166) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_435,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112212409165')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112216510008','112216510009','112216510010')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112212409165) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112216510008 + 112216510009 + 112216510010) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_436,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112212409166')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112216610011','112216610012','112216610013')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112212409166) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112216610011 + 112216610012 + 112216610013) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_437,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112211608125')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112212509167','112212509168','112212509169','112212509170')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112211608125) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112212509167 + 112212509168 + 112212509169 + 112212509170) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_438,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112212509168')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112216810014','112216810015','112216810016','112216810017','112216810018')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112212509168) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112216810014 + 112216810015 + 112216810016 + 112216810017 + 112216810018) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_439,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112212509169')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112216910019','112216910020','112216910021','112216910022')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112212509169) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112216910019 + 112216910020 + 112216910021 + 112216910022) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_440,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112212509170')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112217010023','112217010024','112217010025','112217010026')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112212509170) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112217010023 + 112217010024 + 112217010025 + 112217010026) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_441,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112203807117')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112211708126','112211708127','112211708128','112211708129','112211708130','112211708131','112211708132','112211708133')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112203807117) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112211708126 + 112211708127 + 112211708128 + 112211708129 + 112211708130 + 112211708131 + 112211708132 + 112211708133) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_442,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112203807118')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112211808134','112211808135','112211808136','112211808137','112211808138')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112203807118) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112211808134 + 112211808135 + 112211808136 + 112211808137 + 112211808138) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_443,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112211808136')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213609171','112213609172')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112211808136) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112213609171 + 112213609172) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_444,

/*Cobranza en especie (4)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201106039')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112203907119','112203907120','112203907121')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201106039) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112203907119 + 112203907120 + 112203907121) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_445,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112203907119')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112211908139','112211908140','112211908141')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112203907119) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112211908139 + 112211908140 + 112211908141) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_446,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112211908139')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213909173','112213909174','112213909175','112213909176','112213909177','112213909178','112213909179','112213909180')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112211908139) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112213909173 + 112213909174 + 112213909175 + 112213909176 + 112213909177 + 112213909178 + 112213909179 + 112213909180) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_447,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213909173')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112217310027','112217310028')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112213909173) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112217310027 + 112217310028) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_448,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213909174')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112217410029','112217410030','112217410031')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112213909174) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112217410029 + 112217410030 + 112217410031) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_449,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213909175')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112217510032','112217510033')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112213909175) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112217510032 + 112217510033) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_450,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112211908140')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112214009181','112214009182')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112211908140) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112214009181 + 112214009182) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_451,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112214009181')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112218110034','112218110035','112218110036')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112214009181) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112218110034 + 112218110035 + 112218110036) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_452,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112214009182')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112218210037','112218210038','112218210039')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112214009182) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112218210037 + 112218210038 + 112218210039) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_453,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112211908141')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112214109183','112214109184','112214109185','112214109186')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112211908141) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112214109183 + 112214109184 + 112214109185 + 112214109186) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_454,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112214109184')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112218410040','112218410041','112218410042','112218410043','112218410044')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112214109184) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112218410040 + 112218410041 + 112218410042 + 112218410043 + 112218410044) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_455,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112214109185')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112218510045','112218510046','112218510047','112218510048')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112214109185) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112218510045 + 112218510046 + 112218510047 + 112218510048) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_456,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112214109186')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112218610049','112218610050','112218610051','112218610052')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112214109186) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112218610049 + 112218610050 + 112218610051 + 112218610052) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_457,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112203907120')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112212008142','112212008143','112212008144','112212008145','112212008146','112212008147','112212008148','112212008149')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112203907120) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112212008142 + 112212008143 + 112212008144 + 112212008145 + 112212008146 + 112212008147 + 112212008148 + 112212008149) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_458,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112203907121')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112212108150','112212108151','112212108152','112212108153','112212108154')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112203907121) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112212108150 + 112212108151 + 112212108152 + 112212108153 + 112212108154) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_459,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112212108152')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112215209187','112215209188')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112212108152) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112215209187 + 112215209188) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_460,

/*Capitalización de adeudos a favor del banco */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201106040')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112204007122','112204007123','112204007124')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201106040) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112204007122 + 112204007123 + 112204007124) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_461,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112204007122')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112212208155','112212208156','112212208157')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112204007122) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112212208155 + 112212208156 + 112212208157) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_462,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112212208155')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112215509189','112215509190','112215509191','112215509192','112215509193','112215509194','112215509195','112215509196')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112212208155) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112215509189 + 112215509190 + 112215509191 + 112215509192 + 112215509193 + 112215509194 + 112215509195 + 112215509196) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_463,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112215509189')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112218910053','112218910054')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112215509189) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112218910053 + 112218910054) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_464,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112215509190')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112219010055','112219010056','112219010057')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112215509190) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112219010055 + 112219010056 + 112219010057) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_465,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112215509191')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112219110058','112219110059')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112215509191) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112219110058 + 112219110059) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_466,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112212208156')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112215609197','112215609198')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112212208156) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112215609197 + 112215609198) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_467,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112215609197')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112219710060','112219710061','112219710062')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112215609197) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112219710060 + 112219710061 + 112219710062) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_468,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112215609198')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112219810063','112219810064','112219810065')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112215609198) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112219810063 + 112219810064 + 112219810065) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_469,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112212208157')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112215709199','112215709200','112215709201','112215709202')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112212208157) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112215709199 + 112215709200 + 112215709201 + 112215709202) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_470,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112215709200')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220010066','112220010067','112220010068','112220010069','112220010070')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112215709200) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112220010066 + 112220010067 + 112220010068 + 112220010069 + 112220010070) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_471,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112215709201')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220110071','112220110072','112220110073','112220110074')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112215709201) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112220110071 + 112220110072 + 112220110073 + 112220110074) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_472,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112215709202')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220210075','112220210076','112220210077','112220210078')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112215709202) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112220210075 + 112220210076 + 112220210077 + 112220210078) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_473,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112204007123')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112212308158','112212308159','112212308160','112212308161','112212308162','112212308163','112212308164','112212308165')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112204007123) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112212308158 + 112212308159 + 112212308160 + 112212308161 + 112212308162 + 112212308163 + 112212308164 + 112212308165) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_474,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112204007124')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112212408166','112212408167','112212408168','112212408169','112212408170')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112204007124) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112212408166 + 112212408167 + 112212408168 + 112212408169 + 112212408170) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_475,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112212408168')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112216809203','112216809204','112216809205')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112212408168) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112216809203 + 112216809204 + 112216809205) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_476,

/*Castigos, quitas y condonaciones por (3)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201106041')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112204107126','112204107127','112204107128')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201106041) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112204107126 + 112204107127 + 112204107128) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_477,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112204107126')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112212608171','112212608172','112212608173')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112204107126) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112212608171 + 112212608172 + 112212608173) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_478,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112212608171')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112217109206','112217109207','112217109208','112217109209','112217109210','112217109211','112217109212','112217109213')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112212608171) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112217109206 + 112217109207 + 112217109208 + 112217109209 + 112217109210 + 112217109211 + 112217109212 + 112217109213) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_479,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112217109206')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220610079','112220610080')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112217109206) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112220610079 + 112220610080) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_480,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112217109207')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220710081','112220710082','112220710083')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112217109207) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112220710081 + 112220710082 + 112220710083) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_481,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112217109208')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220810084','112220810085')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112217109208) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112220810084 + 112220810085) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_482,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112212608172')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112217209214','112217209215')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112212608172) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112217209214 + 112217209215) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_483,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112217209214')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221410086','112221410087','112221410088')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112217209214) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112221410086 + 112221410087 + 112221410088) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_484,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112217209215')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221510089','112221510090','112221510091')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112217209215) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112221510089 + 112221510090 + 112221510091) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_485,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112212608173')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112217309216','112217309217','112217309218','112217309219')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112212608173) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112217309216 + 112217309217 + 112217309218 + 112217309219) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_486,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112217309217')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221710092','112221710093','112221710094','112221710095','112221710096')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112217309217) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112221710092 + 112221710093 + 112221710094 + 112221710095 + 112221710096) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_487,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112217309218')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221810097','112221810098','112221810099','112221810100')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112217309218) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112221810097 + 112221810098 + 112221810099 + 112221810100) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_488,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112217309219')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221910101','112221910102','112221910103','112221910104')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112217309219) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112221910101 + 112221910102 + 112221910103 + 112221910104) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_489,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112204107127')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112212708174','112212708175','112212708176','112212708177','112212708178','112212708179','112212708180','112212708181')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112204107127) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112212708174 + 112212708175 + 112212708176 + 112212708177 + 112212708178 + 112212708179 + 112212708180 + 112212708181) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_490,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112204107128')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112212808182','112212808183','112212808184','112212808185','112212808186')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112204107128) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112212808182 + 112212808183 + 112212808184 + 112212808185 + 112212808186) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_491,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112212808184')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112218409220','112218409221','112218409222')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112212808184) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112218409220 + 112218409221 + 112218409222) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_492,

/*Bonificaciones y descuentos sobre (3)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201106042')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112204207130','112204207131','112204207132')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201106042) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112204207130 + 112204207131 + 112204207132) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_493,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112204207130')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213008187','112213008188','112213008189')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112204207130) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112213008187 + 112213008188 + 112213008189) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_494,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213008187')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112218709223','112218709224','112218709225','112218709226','112218709227','112218709228','112218709229','112218709230')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112213008187) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112218709223 + 112218709224 + 112218709225 + 112218709226 + 112218709227 + 112218709228 + 112218709229 + 112218709230) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_495,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112218709223')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112222310105','112222310106')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112218709223) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112222310105 + 112222310106) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_496,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112218709224')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112222410107','112222410108','112222410109')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112218709224) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112222410107 + 112222410108 + 112222410109) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_497,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112218709225')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112222510110','112222510111')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112218709225) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112222510110 + 112222510111) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_498,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213008188')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112218809231','112218809232')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112213008188) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112218809231 + 112218809232) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_499,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112218809231')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112223110112','112223110113','112223110114')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112218809231) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112223110112 + 112223110113 + 112223110114) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_500
	
INTO IFRS9_R04A_0424_M9TS1_RESULT_5
FROM IFRS9_R04A_0424

END

BEGIN
	INSERT INTO 
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_X01])),
            SUM(CHARINDEX('ERR',[VALIDACION_X02])),
            SUM(CHARINDEX('ERR',[VALIDACION_X03])),
            SUM(CHARINDEX('ERR',[VALIDACION_X04])),
            SUM(CHARINDEX('ERR',[VALIDACION_X05])),
            SUM(CHARINDEX('ERR',[VALIDACION_X06])),
            SUM(CHARINDEX('ERR',[VALIDACION_X07])),
            SUM(CHARINDEX('ERR',[VALIDACION_X08])),
            SUM(CHARINDEX('ERR',[VALIDACION_X09])),
            SUM(CHARINDEX('ERR',[VALIDACION_X10])),
            SUM(CHARINDEX('ERR',[VALIDACION_X11])),
            SUM(CHARINDEX('ERR',[VALIDACION_X12])),
            SUM(CHARINDEX('ERR',[VALIDACION_X13])),
            SUM(CHARINDEX('ERR',[VALIDACION_X14])),
            SUM(CHARINDEX('ERR',[VALIDACION_X15])),
            SUM(CHARINDEX('ERR',[VALIDACION_X16])),
            SUM(CHARINDEX('ERR',[VALIDACION_X17])),
            SUM(CHARINDEX('ERR',[VALIDACION_X18])),
            SUM(CHARINDEX('ERR',[VALIDACION_X19])),
            SUM(CHARINDEX('ERR',[VALIDACION_X20])),
            SUM(CHARINDEX('ERR',[VALIDACION_X21])),
            SUM(CHARINDEX('ERR',[VALIDACION_X22])),
            SUM(CHARINDEX('ERR',[VALIDACION_X23])),
            SUM(CHARINDEX('ERR',[VALIDACION_X24])),
            SUM(CHARINDEX('ERR',[VALIDACION_X25])),
            SUM(CHARINDEX('ERR',[VALIDACION_X26])),
            SUM(CHARINDEX('ERR',[VALIDACION_X27])),
            SUM(CHARINDEX('ERR',[VALIDACION_X28])),
            SUM(CHARINDEX('ERR',[VALIDACION_X29])),
            SUM(CHARINDEX('ERR',[VALIDACION_X30])),
            SUM(CHARINDEX('ERR',[VALIDACION_X31])),
            SUM(CHARINDEX('ERR',[VALIDACION_X32])),
            SUM(CHARINDEX('ERR',[VALIDACION_X33])),
            SUM(CHARINDEX('ERR',[VALIDACION_X34])),
            SUM(CHARINDEX('ERR',[VALIDACION_X35])),
            SUM(CHARINDEX('ERR',[VALIDACION_X36])),
            SUM(CHARINDEX('ERR',[VALIDACION_X37])),
            SUM(CHARINDEX('ERR',[VALIDACION_X38])),
            SUM(CHARINDEX('ERR',[VALIDACION_X39])),
            SUM(CHARINDEX('ERR',[VALIDACION_X40])),
            SUM(CHARINDEX('ERR',[VALIDACION_X41])),
            SUM(CHARINDEX('ERR',[VALIDACION_X42])),
            SUM(CHARINDEX('ERR',[VALIDACION_X43])),
            SUM(CHARINDEX('ERR',[VALIDACION_X44])),
            SUM(CHARINDEX('ERR',[VALIDACION_X45])),
            SUM(CHARINDEX('ERR',[VALIDACION_X46])),
            SUM(CHARINDEX('ERR',[VALIDACION_X47])),
            SUM(CHARINDEX('ERR',[VALIDACION_X48])),
            SUM(CHARINDEX('ERR',[VALIDACION_X49])),
            SUM(CHARINDEX('ERR',[VALIDACION_X50])),
            SUM(CHARINDEX('ERR',[VALIDACION_X51])),
            SUM(CHARINDEX('ERR',[VALIDACION_X52])),
            SUM(CHARINDEX('ERR',[VALIDACION_X53])),
            SUM(CHARINDEX('ERR',[VALIDACION_X54])),
            SUM(CHARINDEX('ERR',[VALIDACION_X55])),
            SUM(CHARINDEX('ERR',[VALIDACION_X56])),
            SUM(CHARINDEX('ERR',[VALIDACION_X57])),
            SUM(CHARINDEX('ERR',[VALIDACION_X58])),
            SUM(CHARINDEX('ERR',[VALIDACION_X59])),
            SUM(CHARINDEX('ERR',[VALIDACION_X60])),
            SUM(CHARINDEX('ERR',[VALIDACION_X61])),
            SUM(CHARINDEX('ERR',[VALIDACION_X62])),
            SUM(CHARINDEX('ERR',[VALIDACION_X63])),
            SUM(CHARINDEX('ERR',[VALIDACION_X64])),
            SUM(CHARINDEX('ERR',[VALIDACION_X65])),
            SUM(CHARINDEX('ERR',[VALIDACION_X66])),
            SUM(CHARINDEX('ERR',[VALIDACION_X67])),
            SUM(CHARINDEX('ERR',[VALIDACION_X68])),
            SUM(CHARINDEX('ERR',[VALIDACION_X69])),
            SUM(CHARINDEX('ERR',[VALIDACION_X70])),
            SUM(CHARINDEX('ERR',[VALIDACION_X71])),
            SUM(CHARINDEX('ERR',[VALIDACION_X72])),
            SUM(CHARINDEX('ERR',[VALIDACION_X73])),
            SUM(CHARINDEX('ERR',[VALIDACION_X74])),
            SUM(CHARINDEX('ERR',[VALIDACION_X75])),
            SUM(CHARINDEX('ERR',[VALIDACION_X76])),
            SUM(CHARINDEX('ERR',[VALIDACION_X77])),
            SUM(CHARINDEX('ERR',[VALIDACION_X78])),
            SUM(CHARINDEX('ERR',[VALIDACION_X79])),
            SUM(CHARINDEX('ERR',[VALIDACION_X80])),
            SUM(CHARINDEX('ERR',[VALIDACION_X81])),
            SUM(CHARINDEX('ERR',[VALIDACION_X82])),
            SUM(CHARINDEX('ERR',[VALIDACION_X83])),
            SUM(CHARINDEX('ERR',[VALIDACION_X84])),
            SUM(CHARINDEX('ERR',[VALIDACION_X85])),
            SUM(CHARINDEX('ERR',[VALIDACION_X86])),
            SUM(CHARINDEX('ERR',[VALIDACION_X87])),
            SUM(CHARINDEX('ERR',[VALIDACION_X88])),
            SUM(CHARINDEX('ERR',[VALIDACION_X89])),
            SUM(CHARINDEX('ERR',[VALIDACION_X90])),
            SUM(CHARINDEX('ERR',[VALIDACION_X91])),
            SUM(CHARINDEX('ERR',[VALIDACION_X92])),
            SUM(CHARINDEX('ERR',[VALIDACION_X93])),
            SUM(CHARINDEX('ERR',[VALIDACION_X94])),
            SUM(CHARINDEX('ERR',[VALIDACION_X95])),
            SUM(CHARINDEX('ERR',[VALIDACION_X96])),
            SUM(CHARINDEX('ERR',[VALIDACION_X97])),
            SUM(CHARINDEX('ERR',[VALIDACION_X98])),
            SUM(CHARINDEX('ERR',[VALIDACION_X99])),
            SUM(CHARINDEX('ERR',[VALIDACION_X00]))
            


		FROMx 
END

BEGIN
	EXEC SP_
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


