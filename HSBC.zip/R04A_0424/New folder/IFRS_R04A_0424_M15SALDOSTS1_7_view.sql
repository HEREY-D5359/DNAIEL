﻿
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapas 1 y 2 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15SALDOS*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/


CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0424_M15SALDOSTS1_VIEW_7]
AS
BEGIN
	SELECT *
		
	FROM IFRS9_R04A_0424_M15SALDOSTS1_RESULT_7
	WHERE

        (VALIDACION_601 <> '' ) OR
        (VALIDACION_602 <> '' ) OR
        (VALIDACION_603 <> '' ) OR
        (VALIDACION_604 <> '' ) OR
        (VALIDACION_605 <> '' ) OR
        (VALIDACION_606 <> '' ) OR
        (VALIDACION_607 <> '' ) OR
        (VALIDACION_608 <> '' ) OR
        (VALIDACION_609 <> '' ) OR
        (VALIDACION_610 <> '' ) OR
        (VALIDACION_611 <> '' ) OR
        (VALIDACION_612 <> '' ) OR
        (VALIDACION_613 <> '' ) OR
        (VALIDACION_614 <> '' ) OR
        (VALIDACION_615 <> '' ) OR
        (VALIDACION_616 <> '' ) OR
        (VALIDACION_617 <> '' ) OR
        (VALIDACION_618 <> '' ) OR
        (VALIDACION_619 <> '' ) OR
        (VALIDACION_620 <> '' ) OR
        (VALIDACION_621 <> '' ) OR
        (VALIDACION_622 <> '' ) OR
        (VALIDACION_623 <> '' ) OR
        (VALIDACION_624 <> '' ) OR
        (VALIDACION_625 <> '' ) OR
        (VALIDACION_626 <> '' ) OR
        (VALIDACION_627 <> '' ) OR
        (VALIDACION_628 <> '' ) OR
        (VALIDACION_629 <> '' ) OR
        (VALIDACION_630 <> '' ) OR
        (VALIDACION_631 <> '' ) OR
        (VALIDACION_632 <> '' ) OR
        (VALIDACION_633 <> '' ) OR
        (VALIDACION_634 <> '' ) OR
        (VALIDACION_635 <> '' ) OR
        (VALIDACION_636 <> '' ) OR
        (VALIDACION_637 <> '' ) OR
        (VALIDACION_638 <> '' ) OR
        (VALIDACION_639 <> '' ) OR
        (VALIDACION_640 <> '' ) OR
        (VALIDACION_641 <> '' ) OR
        (VALIDACION_642 <> '' ) OR
        (VALIDACION_643 <> '' ) OR
        (VALIDACION_644 <> '' ) OR
        (VALIDACION_645 <> '' ) OR
        (VALIDACION_646 <> '' ) OR
        (VALIDACION_647 <> '' ) OR
        (VALIDACION_648 <> '' ) OR
        (VALIDACION_649 <> '' ) OR
        (VALIDACION_650 <> '' ) OR
        (VALIDACION_651 <> '' ) OR
        (VALIDACION_652 <> '' ) OR
        (VALIDACION_653 <> '' ) OR
        (VALIDACION_654 <> '' ) OR
        (VALIDACION_655 <> '' ) OR
        (VALIDACION_656 <> '' ) OR
        (VALIDACION_657 <> '' ) OR
        (VALIDACION_658 <> '' ) OR
        (VALIDACION_659 <> '' ) OR
        (VALIDACION_660 <> '' ) OR
        (VALIDACION_661 <> '' ) OR
        (VALIDACION_662 <> '' ) OR
        (VALIDACION_663 <> '' ) OR
        (VALIDACION_664 <> '' ) OR
        (VALIDACION_665 <> '' ) OR
        (VALIDACION_666 <> '' ) OR
        (VALIDACION_667 <> '' ) OR
        (VALIDACION_668 <> '' ) OR
        (VALIDACION_669 <> '' ) OR
        (VALIDACION_670 <> '' ) OR
        (VALIDACION_671 <> '' ) OR
        (VALIDACION_672 <> '' ) OR
        (VALIDACION_673 <> '' ) OR
        (VALIDACION_674 <> '' ) OR
        (VALIDACION_675 <> '' ) OR
        (VALIDACION_676 <> '' ) OR
        (VALIDACION_677 <> '' ) OR
        (VALIDACION_678 <> '' ) OR
        (VALIDACION_679 <> '' ) OR
        (VALIDACION_680 <> '' ) OR
        (VALIDACION_681 <> '' ) OR
        (VALIDACION_682 <> '' ) OR
        (VALIDACION_683 <> '' ) OR
        (VALIDACION_684 <> '' ) OR
        (VALIDACION_685 <> '' ) OR
        (VALIDACION_686 <> '' ) OR
        (VALIDACION_687 <> '' ) OR
        (VALIDACION_688 <> '' ) OR
        (VALIDACION_689 <> '' ) OR
        (VALIDACION_690 <> '' ) OR
        (VALIDACION_691 <> '' ) OR
        (VALIDACION_692 <> '' ) OR
        (VALIDACION_693 <> '' ) OR
        (VALIDACION_694 <> '' ) OR
        (VALIDACION_695 <> '' ) OR
        (VALIDACION_696 <> '' ) OR
        (VALIDACION_697 <> '' ) OR
        (VALIDACION_698 <> '' ) OR
        (VALIDACION_699 <> '' ) OR
        (VALIDACION_700 <> '' ) 
ORDER BY 1
END

