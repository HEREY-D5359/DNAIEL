﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapas 1 y 2 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0424_M15TS1_COMP_4]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0424_M15TS1_RESULT_4')
BEGIN
DROP TABLE IFRS9_R04A_0424_M15TS1_RESULT_4
END 

BEGIN
SELECT DISTINCT

	/*ID*/

	CONVERT(VARCHAR,ID)  AS ID,   
	/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111800107003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111800308006','111800308007')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111800107003) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111800308006 + 111800308007) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_301,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111800106002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111800207009','111800207010')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111800106002) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111800207009 + 111800207010) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_302,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111800207009')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111800908008','111800908009','111800908010')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111800207009) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111800908008 + 111800908009 + 111800908010) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_303,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111800207010')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801008011','111801008012','111801008013')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111800207010) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111801008011 + 111801008012 + 111801008013) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_304,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111800106003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111800307011','111800307012','111800307013','111800307014')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111800106003) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111800307011 + 111800307012 + 111800307013 + 111800307014) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_305,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111800307012')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801208014','111801208015','111801208016','111801208017','111801208018')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111800307012) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111801208014 + 111801208015 + 111801208016 + 111801208017 + 111801208018) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_306,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111800307013')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801308019','111801308020','111801308021','111801308022')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111800307013) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111801308019 + 111801308020 + 111801308021 + 111801308022) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_307,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111800307014')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801408023','111801408024','111801408025','111801408026')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111800307014) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111801408023 + 111801408024 + 111801408025 + 111801408026) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_308,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111800105002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111800206004','111800206005','111800206006','111800206007','111800206008','111800206009','111800206010','111800206011')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111800105002) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111800206004 + 111800206005 + 111800206006 + 111800206007 + 111800206008 + 111800206009 + 111800206010 + 111800206011) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_309,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111800105003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111800306012','111800306013','111800306014','111800306015','111800306016')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111800105003) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111800306012 + 111800306013 + 111800306014 + 111800306015 + 111800306016) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_310,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111800306014')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801407015','111801407016','111801407017')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111800306014) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111801407015 + 111801407016 + 111801407017) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_311,

/*Saldo inicial de cartera con riesgo de crédito etapa 2*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200104001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200105001','112200105002','112200105003')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200104001) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112200105001 + 112200105002 + 112200105003) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_312,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200105001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200106001','112200106002','112200106003')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200105001) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112200106001 + 112200106002 + 112200106003) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_313,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200106001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200107001','112200107002','112200107003','112200107004','112200107005','112200107006','112200107007','112200107008')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200106001) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112200107001 + 112200107002 + 112200107003 + 112200107004 + 112200107005 + 112200107006 + 112200107007 + 112200107008) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_314,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200107001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200108001','112200108002')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200107001) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112200108001 + 112200108002) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_315,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200107002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200208003','112200208004','112200208005')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200107002) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112200208003 + 112200208004 + 112200208005) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_316,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200107003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200308006','112200308007')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200107003) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112200308006 + 112200308007) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_317,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200106002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200207009','112200207010')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200106002) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112200207009 + 112200207010) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_318,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200207009')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200908008','112200908009','112200908010')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200207009) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112200908008 + 112200908009 + 112200908010) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_319,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200207010')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201008011','112201008012','112201008013')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200207010) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112201008011 + 112201008012 + 112201008013) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_320,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200106003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200307011','112200307012','112200307013','112200307014')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200106003) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112200307011 + 112200307012 + 112200307013 + 112200307014) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_321,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200307012')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201208014','112201208015','112201208016','112201208017','112201208018')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200307012) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112201208014 + 112201208015 + 112201208016 + 112201208017 + 112201208018) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_322,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200307013')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201308019','112201308020','112201308021','112201308022')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200307013) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112201308019 + 112201308020 + 112201308021 + 112201308022) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_323,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200307014')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201408023','112201408024','112201408025','112201408026')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200307014) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112201408023 + 112201408024 + 112201408025 + 112201408026) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_324,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200105002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200206004','112200206005','112200206006','112200206007','112200206008','112200206009','112200206010','112200206011')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200105002) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112200206004 + 112200206005 + 112200206006 + 112200206007 + 112200206008 + 112200206009 + 112200206010 + 112200206011) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_325,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200105003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200306012','112200306013','112200306014','112200306015','112200306016')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200105003) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112200306012 + 112200306013 + 112200306014 + 112200306015 + 112200306016) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_326,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200306014')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201407015','112201407016')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200306014) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112201407015 + 112201407016) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_327,

/*Entradas a cartera con riesgo de crédito etapa 2*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200104002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200205004','112200205005','112200205006','112200205007','112200205008','112200205009')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200104002) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112200205004 + 112200205005 + 112200205006 + 112200205007 + 112200205008 + 112200205009) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_328,

/*Compras de cartera*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200205004')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200406017','112200406018','112200406019')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200205004) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112200406017 + 112200406018 + 112200406019) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_329,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200406017')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201707017','112201707018','112201707019')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200406017) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112201707017 + 112201707018 + 112201707019) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_330,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201707017')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201708027','112201708028','112201708029','112201708030','112201708031','112201708032','112201708033','112201708034')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201707017) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112201708027 + 112201708028 + 112201708029 + 112201708030 + 112201708031 + 112201708032 + 112201708033 + 112201708034) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_331,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201708027')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202709001','112202709002')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201708027) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112202709001 + 112202709002) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_332,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201708028')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202809003','112202809004','112202809005')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201708028) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112202809003 + 112202809004 + 112202809005) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_333,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201708029')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202909006','112202909007')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201708029) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112202909006 + 112202909007) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_334,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201707018')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201808035','112201808036')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201707018) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112201808035 + 112201808036) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_335,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201808035')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112203509008','112203509009','112203509010')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201808035) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112203509008 + 112203509009 + 112203509010) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_336,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201808036')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112203609011','112203609012','112203609013')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201808036) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112203609011 + 112203609012 + 112203609013) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_337,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201707019')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201908037','112201908038','112201908039','112201908040')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201707019) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112201908037 + 112201908038 + 112201908039 + 112201908040) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_338,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201908038')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112203809014','112203809015','112203809016','112203809017','112203809018')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201908038) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112203809014 + 112203809015 + 112203809016 + 112203809017 + 112203809018) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_339,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201908039')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112203909019','112203909020','112203909021','112203909022')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201908039) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112203909019 + 112203909020 + 112203909021 + 112203909022) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_340,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201908040')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112204009023','112204009024','112204009025','112204009026')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201908040) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112204009023 + 112204009024 + 112204009025 + 112204009026) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_341,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200406018')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201807020','112201807021','112201807022','112201807023','112201807024','112201807025','112201807026','112201807027')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200406018) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112201807020 + 112201807021 + 112201807022 + 112201807023 + 112201807024 + 112201807025 + 112201807026 + 112201807027) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_342,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200406019')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201907028','112201907029','112201907030','112201907031','112201907032')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200406019) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112201907028 + 112201907029 + 112201907030 + 112201907031 + 112201907032) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_343,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201907030')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112203008041','112203008042')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201907030) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112203008041 + 112203008042) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_344,

/*Intereses devengados no cobrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200205005')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200506020','112200506021','112200506022')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200205005) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112200506020 + 112200506021 + 112200506022) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_345,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200506020')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202007033','112202007034','112202007035')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200506020) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112202007033 + 112202007034 + 112202007035) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_346,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202007033')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112203308043','112203308044','112203308045','112203308046','112203308047','112203308048','112203308049','112203308050')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112202007033) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112203308043 + 112203308044 + 112203308045 + 112203308046 + 112203308047 + 112203308048 + 112203308049 + 112203308050) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_347,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112203308043')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112204309027','112204309028')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112203308043) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112204309027 + 112204309028) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_348,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112203308044')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112204409029','112204409030','112204409031')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112203308044) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112204409029 + 112204409030 + 112204409031) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_349,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112203308045')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112204509032','112204509033')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112203308045) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112204509032 + 112204509033) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_350,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202007034')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112203408051','112203408052')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112202007034) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112203408051 + 112203408052) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_351,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112203408051')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112205109034','112205109035','112205109036')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112203408051) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112205109034 + 112205109035 + 112205109036) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_352,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112203408052')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112205209037','112205209038','112205209039')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112203408052) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112205209037 + 112205209038 + 112205209039) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_353,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202007035')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112203508053','112203508054','112203508055','112203508056')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112202007035) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112203508053 + 112203508054 + 112203508055 + 112203508056) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_354,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112203508054')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112205409040','112205409041','112205409042','112205409043','112205409044')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112203508054) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112205409040 + 112205409041 + 112205409042 + 112205409043 + 112205409044) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_355,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112203508055')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112205509045','112205509046','112205509047','112205509048')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112203508055) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112205509045 + 112205509046 + 112205509047 + 112205509048) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_356,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112203508056')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112205609049','112205609050','112205609051','112205609052')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112203508056) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112205609049 + 112205609050 + 112205609051 + 112205609052) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_357,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200506021')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202107036','112202107037','112202107038','112202107039','112202107040','112202107041','112202107042','112202107043')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200506021) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112202107036 + 112202107037 + 112202107038 + 112202107039 + 112202107040 + 112202107041 + 112202107042 + 112202107043) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_358,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200506022')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202207044','112202207045','112202207046','112202207047','112202207048')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200506022) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112202207044 + 112202207045 + 112202207046 + 112202207047 + 112202207048) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_359,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202207046')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112204608057','112204608058')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112202207046) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112204608057 + 112204608058) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_360,

/*Reestructuras y renovaciones (1)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200205006')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200606023','112200606024','112200606025')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200205006) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112200606023 + 112200606024 + 112200606025) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_361,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200606023')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202307049','112202307050','112202307051')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200606023) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112202307049 + 112202307050 + 112202307051) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_362,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202307049')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112204908059','112204908060','112204908061','112204908062','112204908063','112204908064','112204908065','112204908066')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112202307049) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112204908059 + 112204908060 + 112204908061 + 112204908062 + 112204908063 + 112204908064 + 112204908065 + 112204908066) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_363,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112204908059')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112205909053','112205909054')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112204908059) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112205909053 + 112205909054) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_364,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112204908060')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112206009055','112206009056','112206009057')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112204908060) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112206009055 + 112206009056 + 112206009057) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_365,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112204908061')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112206109058','112206109059')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112204908061) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112206109058 + 112206109059) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_366,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202307050')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112205008067','112205008068')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112202307050) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112205008067 + 112205008068) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_367,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112205008067')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112206709060','112206709061','112206709062')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112205008067) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112206709060 + 112206709061 + 112206709062) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_368,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112205008068')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112206809063','112206809064','112206809065')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112205008068) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112206809063 + 112206809064 + 112206809065) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_369,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202307051')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112205108069','112205108070','112205108071','112205108072')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112202307051) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112205108069 + 112205108070 + 112205108071 + 112205108072) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_370,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112205108070')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207009066','112207009067','112207009068','112207009069','112207009070')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112205108070) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112207009066 + 112207009067 + 112207009068 + 112207009069 + 112207009070) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_371,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112205108071')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207109071','112207109072','112207109073','112207109074')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112205108071) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112207109071 + 112207109072 + 112207109073 + 112207109074) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_372,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112205108072')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207209075','112207209076','112207209077','112207209078')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112205108072) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112207209075 + 112207209076 + 112207209077 + 112207209078) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_373,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200606024')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202407052','112202407053','112202407054','112202407055','112202407056','112202407057','112202407058','112202407059')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200606024) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112202407052 + 112202407053 + 112202407054 + 112202407055 + 112202407056 + 112202407057 + 112202407058 + 112202407059) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_374,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200606025')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202507060','112202507061','112202507062','112202507063','112202507064')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200606025) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112202507060 + 112202507061 + 112202507062 + 112202507063 + 112202507064) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_375,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202507062')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112206208073','112206208074')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112202507062) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112206208073 + 112206208074) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_376,

/*Traspaso de cartera con riesgo de crédito etapa 1*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200205007')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200706026','112200706027','112200706028')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200205007) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112200706026 + 112200706027 + 112200706028) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_377,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200706026')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202607065','112202607066','112202607067')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200706026) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112202607065 + 112202607066 + 112202607067) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_378,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202607065')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112206508075','112206508076','112206508077','112206508078','112206508079','112206508080','112206508081','112206508082')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112202607065) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112206508075 + 112206508076 + 112206508077 + 112206508078 + 112206508079 + 112206508080 + 112206508081 + 112206508082) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_379,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112206508075')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207509079','112207509080')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112206508075) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112207509079 + 112207509080) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_380,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112206508076')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207609081','112207609082','112207609083')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112206508076) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112207609081 + 112207609082 + 112207609083) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_381,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112206508077')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207709084','112207709085')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112206508077) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112207709084 + 112207709085) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_382,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202607066')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112206608083','112206608084')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112202607066) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112206608083 + 112206608084) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_383,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112206608083')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112208309086','112208309087','112208309088')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112206608083) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112208309086 + 112208309087 + 112208309088) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_384,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112206608084')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112208409089','112208409090','112208409091')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112206608084) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112208409089 + 112208409090 + 112208409091) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_385,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202607067')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112206708085','112206708086','112206708087','112206708088')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112202607067) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112206708085 + 112206708086 + 112206708087 + 112206708088) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_386,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112206708086')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112208609092','112208609093','112208609094','112208609095','112208609096')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112206708086) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112208609092 + 112208609093 + 112208609094 + 112208609095 + 112208609096) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_387,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112206708087')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112208709097','112208709098','112208709099','112208709100')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112206708087) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112208709097 + 112208709098 + 112208709099 + 112208709100) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_388,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112206708088')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112208809101','112208809102','112208809103','112208809104')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112206708088) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112208809101 + 112208809102 + 112208809103 + 112208809104) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_389,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200706027')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202707068','112202707069','112202707070','112202707071','112202707072','112202707073','112202707074','112202707075')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200706027) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112202707068 + 112202707069 + 112202707070 + 112202707071 + 112202707072 + 112202707073 + 112202707074 + 112202707075) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_390,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200706028')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202807076','112202807077','112202807078','112202807079','112202807080')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200706028) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112202807076 + 112202807077 + 112202807078 + 112202807079 + 112202807080) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_391,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202807078')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207808089','112207808090')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112202807078) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112207808089 + 112207808090) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_392,

/*Traspaso de cartera con riesgo de crédito etapa 3*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200205008')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200806029','112200806030','112200806031')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200205008) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112200806029 + 112200806030 + 112200806031) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_393,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200806029')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202907081','112202907082','112202907083')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200806029) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112202907081 + 112202907082 + 112202907083) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_394,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202907081')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112208108091','112208108092','112208108093','112208108094','112208108095','112208108096','112208108097','112208108098')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112202907081) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112208108091 + 112208108092 + 112208108093 + 112208108094 + 112208108095 + 112208108096 + 112208108097 + 112208108098) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_395,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112208108091')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112209109105','112209109106')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112208108091) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112209109105 + 112209109106) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_396,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112208108092')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112209209107','112209209108','112209209109')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112208108092) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112209209107 + 112209209108 + 112209209109) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_397,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112208108093')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112209309110','112209309111')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112208108093) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112209309110 + 112209309111) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_398,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202907082')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112208208099','112208208100')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112202907082) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112208208099 + 112208208100) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_399,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112208208099')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112209909112','112209909113','112209909114')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112208208099) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112209909112 + 112209909113 + 112209909114) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_400
	
INTO IFRS9_R04A_0424_M15TS1_RESULT_4
FROM IFRS9_R04A_0424

END

BEGIN
	INSERT INTO 
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_X01])),
            SUM(CHARINDEX('ERR',[VALIDACION_X02])),
            SUM(CHARINDEX('ERR',[VALIDACION_X03])),
            SUM(CHARINDEX('ERR',[VALIDACION_X04])),
            SUM(CHARINDEX('ERR',[VALIDACION_X05])),
            SUM(CHARINDEX('ERR',[VALIDACION_X06])),
            SUM(CHARINDEX('ERR',[VALIDACION_X07])),
            SUM(CHARINDEX('ERR',[VALIDACION_X08])),
            SUM(CHARINDEX('ERR',[VALIDACION_X09])),
            SUM(CHARINDEX('ERR',[VALIDACION_X10])),
            SUM(CHARINDEX('ERR',[VALIDACION_X11])),
            SUM(CHARINDEX('ERR',[VALIDACION_X12])),
            SUM(CHARINDEX('ERR',[VALIDACION_X13])),
            SUM(CHARINDEX('ERR',[VALIDACION_X14])),
            SUM(CHARINDEX('ERR',[VALIDACION_X15])),
            SUM(CHARINDEX('ERR',[VALIDACION_X16])),
            SUM(CHARINDEX('ERR',[VALIDACION_X17])),
            SUM(CHARINDEX('ERR',[VALIDACION_X18])),
            SUM(CHARINDEX('ERR',[VALIDACION_X19])),
            SUM(CHARINDEX('ERR',[VALIDACION_X20])),
            SUM(CHARINDEX('ERR',[VALIDACION_X21])),
            SUM(CHARINDEX('ERR',[VALIDACION_X22])),
            SUM(CHARINDEX('ERR',[VALIDACION_X23])),
            SUM(CHARINDEX('ERR',[VALIDACION_X24])),
            SUM(CHARINDEX('ERR',[VALIDACION_X25])),
            SUM(CHARINDEX('ERR',[VALIDACION_X26])),
            SUM(CHARINDEX('ERR',[VALIDACION_X27])),
            SUM(CHARINDEX('ERR',[VALIDACION_X28])),
            SUM(CHARINDEX('ERR',[VALIDACION_X29])),
            SUM(CHARINDEX('ERR',[VALIDACION_X30])),
            SUM(CHARINDEX('ERR',[VALIDACION_X31])),
            SUM(CHARINDEX('ERR',[VALIDACION_X32])),
            SUM(CHARINDEX('ERR',[VALIDACION_X33])),
            SUM(CHARINDEX('ERR',[VALIDACION_X34])),
            SUM(CHARINDEX('ERR',[VALIDACION_X35])),
            SUM(CHARINDEX('ERR',[VALIDACION_X36])),
            SUM(CHARINDEX('ERR',[VALIDACION_X37])),
            SUM(CHARINDEX('ERR',[VALIDACION_X38])),
            SUM(CHARINDEX('ERR',[VALIDACION_X39])),
            SUM(CHARINDEX('ERR',[VALIDACION_X40])),
            SUM(CHARINDEX('ERR',[VALIDACION_X41])),
            SUM(CHARINDEX('ERR',[VALIDACION_X42])),
            SUM(CHARINDEX('ERR',[VALIDACION_X43])),
            SUM(CHARINDEX('ERR',[VALIDACION_X44])),
            SUM(CHARINDEX('ERR',[VALIDACION_X45])),
            SUM(CHARINDEX('ERR',[VALIDACION_X46])),
            SUM(CHARINDEX('ERR',[VALIDACION_X47])),
            SUM(CHARINDEX('ERR',[VALIDACION_X48])),
            SUM(CHARINDEX('ERR',[VALIDACION_X49])),
            SUM(CHARINDEX('ERR',[VALIDACION_X50])),
            SUM(CHARINDEX('ERR',[VALIDACION_X51])),
            SUM(CHARINDEX('ERR',[VALIDACION_X52])),
            SUM(CHARINDEX('ERR',[VALIDACION_X53])),
            SUM(CHARINDEX('ERR',[VALIDACION_X54])),
            SUM(CHARINDEX('ERR',[VALIDACION_X55])),
            SUM(CHARINDEX('ERR',[VALIDACION_X56])),
            SUM(CHARINDEX('ERR',[VALIDACION_X57])),
            SUM(CHARINDEX('ERR',[VALIDACION_X58])),
            SUM(CHARINDEX('ERR',[VALIDACION_X59])),
            SUM(CHARINDEX('ERR',[VALIDACION_X60])),
            SUM(CHARINDEX('ERR',[VALIDACION_X61])),
            SUM(CHARINDEX('ERR',[VALIDACION_X62])),
            SUM(CHARINDEX('ERR',[VALIDACION_X63])),
            SUM(CHARINDEX('ERR',[VALIDACION_X64])),
            SUM(CHARINDEX('ERR',[VALIDACION_X65])),
            SUM(CHARINDEX('ERR',[VALIDACION_X66])),
            SUM(CHARINDEX('ERR',[VALIDACION_X67])),
            SUM(CHARINDEX('ERR',[VALIDACION_X68])),
            SUM(CHARINDEX('ERR',[VALIDACION_X69])),
            SUM(CHARINDEX('ERR',[VALIDACION_X70])),
            SUM(CHARINDEX('ERR',[VALIDACION_X71])),
            SUM(CHARINDEX('ERR',[VALIDACION_X72])),
            SUM(CHARINDEX('ERR',[VALIDACION_X73])),
            SUM(CHARINDEX('ERR',[VALIDACION_X74])),
            SUM(CHARINDEX('ERR',[VALIDACION_X75])),
            SUM(CHARINDEX('ERR',[VALIDACION_X76])),
            SUM(CHARINDEX('ERR',[VALIDACION_X77])),
            SUM(CHARINDEX('ERR',[VALIDACION_X78])),
            SUM(CHARINDEX('ERR',[VALIDACION_X79])),
            SUM(CHARINDEX('ERR',[VALIDACION_X80])),
            SUM(CHARINDEX('ERR',[VALIDACION_X81])),
            SUM(CHARINDEX('ERR',[VALIDACION_X82])),
            SUM(CHARINDEX('ERR',[VALIDACION_X83])),
            SUM(CHARINDEX('ERR',[VALIDACION_X84])),
            SUM(CHARINDEX('ERR',[VALIDACION_X85])),
            SUM(CHARINDEX('ERR',[VALIDACION_X86])),
            SUM(CHARINDEX('ERR',[VALIDACION_X87])),
            SUM(CHARINDEX('ERR',[VALIDACION_X88])),
            SUM(CHARINDEX('ERR',[VALIDACION_X89])),
            SUM(CHARINDEX('ERR',[VALIDACION_X90])),
            SUM(CHARINDEX('ERR',[VALIDACION_X91])),
            SUM(CHARINDEX('ERR',[VALIDACION_X92])),
            SUM(CHARINDEX('ERR',[VALIDACION_X93])),
            SUM(CHARINDEX('ERR',[VALIDACION_X94])),
            SUM(CHARINDEX('ERR',[VALIDACION_X95])),
            SUM(CHARINDEX('ERR',[VALIDACION_X96])),
            SUM(CHARINDEX('ERR',[VALIDACION_X97])),
            SUM(CHARINDEX('ERR',[VALIDACION_X98])),
            SUM(CHARINDEX('ERR',[VALIDACION_X99])),
            SUM(CHARINDEX('ERR',[VALIDACION_X00]))
            


		FROMx 
END

BEGIN
	EXEC SP_
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


