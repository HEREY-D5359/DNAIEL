﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapas 1 y 2 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15SALDOS*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0424_M15SALDOSTS1_COMP_23]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0424_M15SALDOSTS1_RESULT_23')
BEGIN
DROP TABLE IFRS9_R04A_0424_M15SALDOSTS1_RESULT_23
END 

BEGIN
SELECT DISTINCT
         /*id*/
CONVERT(VARCHAR,ID) AS ID, 
	/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112219708274')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112219708274')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112219708274) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112219708274) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2201,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112219708275')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112219708275')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112219708275) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112219708275) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2202,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112219708276')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112219708276')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112219708276) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112219708276) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2203,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200405017')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200405017')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112200405017) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112200405017) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2204,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201706058')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201706058')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201706058) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201706058) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2205,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201706059')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201706059')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201706059) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201706059) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2206,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201706060')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201706060')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201706060) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201706060) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2207,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201706061')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201706061')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201706061) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201706061) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2208,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201706062')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201706062')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201706062) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201706062) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2209,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201706063')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201706063')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201706063) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201706063) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2210,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201706064')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201706064')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201706064) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201706064) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2211,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201706065')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201706065')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201706065) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201706065) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2212,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200405018')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200405018')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112200405018) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112200405018) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2213,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201806066')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201806066')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201806066) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201806066) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2214,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201806067')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201806067')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201806067) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201806067) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2215,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201806068')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201806068')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201806068) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201806068) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2216,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112206807198')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112206807198')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112206807198) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112206807198) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2217,

/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112206807199')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112206807199')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112206807199) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112206807199) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2218,

/*Remodelación o mejoramiento con garantía otorgada por la Banca de Desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201806069')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201806069')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201806069) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201806069) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2219,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201806070')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201806070')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201806070) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201806070) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2220,

/*Capitalización de Intereses etapa 2*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200104005')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200104005')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112200104005) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112200104005) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2221,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200505019')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200505019')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112200505019) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112200505019) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2222,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201906071')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201906071')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201906071) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201906071) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2223,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207107200')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207107200')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112207107200) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112207107200) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2224,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220008277')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220008277')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220008277) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220008277) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2225,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220008278')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220008278')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220008278) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220008278) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2226,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207107201')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207107201')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112207107201) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112207107201) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2227,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220108279')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220108279')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220108279) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220108279) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2228,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220108280')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220108280')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220108280) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220108280) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2229,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220108281')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220108281')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220108281) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220108281) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2230,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207107202')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207107202')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112207107202) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112207107202) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2231,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220208282')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220208282')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220208282) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220208282) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2232,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220208283')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220208283')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220208283) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220208283) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2233,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207107203')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207107203')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112207107203) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112207107203) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2234,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207107204')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207107204')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112207107204) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112207107204) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2235,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207107205')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207107205')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112207107205) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112207107205) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2236,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207107206')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207107206')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112207107206) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112207107206) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2237,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207107207')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207107207')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112207107207) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112207107207) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2238,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201906072')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201906072')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201906072) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201906072) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2239,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207207208')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207207208')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112207207208) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112207207208) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2240,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220808284')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220808284')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220808284) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220808284) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2241,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220808285')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220808285')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220808285) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220808285) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2242,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220808286')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220808286')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220808286) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220808286) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2243,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207207209')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207207209')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112207207209) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112207207209) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2244,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220908287')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220908287')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220908287) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220908287) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2245,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220908288')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220908288')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220908288) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220908288) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2246,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220908289')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220908289')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220908289) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220908289) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2247,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201906073')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201906073')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201906073) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201906073) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2248,

/*Créditos al gobierno federal */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207307210')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207307210')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112207307210) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112207307210) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2249,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207307211')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207307211')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112207307211) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112207307211) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2250,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221108290')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221108290')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221108290) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221108290) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2251,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221108291')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221108291')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221108291) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221108291) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2252,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221108292')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221108292')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221108292) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221108292) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2253,

/*Fideicomisos públicos de contratación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221108293')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221108293')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221108293) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221108293) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2254,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221108294')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221108294')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221108294) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221108294) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2255,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207307212')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207307212')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112207307212) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112207307212) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2256,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221208295')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221208295')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221208295) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221208295) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2257,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221208296')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221208296')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221208296) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221208296) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2258,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221208297')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221208297')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221208297) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221208297) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2259,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221208298')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221208298')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221208298) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221208298) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2260,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207307213')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207307213')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112207307213) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112207307213) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2261,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221308299')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221308299')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221308299) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221308299) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2262,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221308300')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221308300')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221308300) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221308300) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2263,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221308301')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221308301')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221308301) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221308301) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2264,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221308302')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221308302')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221308302) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221308302) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2265,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200505020')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200505020')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112200505020) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112200505020) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2266,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202006074')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202006074')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112202006074) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112202006074) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2267,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202006075')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202006075')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112202006075) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112202006075) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2268,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202006076')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202006076')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112202006076) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112202006076) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2269,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202006077')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202006077')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112202006077) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112202006077) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2270,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202006078')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202006078')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112202006078) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112202006078) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2271,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202006079')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202006079')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112202006079) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112202006079) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2272,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202006080')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202006080')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112202006080) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112202006080) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2273,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202006081')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202006081')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112202006081) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112202006081) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2274,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200505021')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200505021')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112200505021) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112200505021) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2275,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202106082')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202106082')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112202106082) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112202106082) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2276,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202106083')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202106083')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112202106083) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112202106083) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2277,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202106084')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202106084')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112202106084) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112202106084) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2278,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112208407214')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112208407214')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112208407214) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112208407214) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2279,

/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112208407215')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112208407215')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112208407215) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112208407215) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2280,

/*Remodelación o mejoramiento con garantía otorgada por la Banca de Desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202106085')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202106085')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112202106085) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112202106085) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2281,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202106086')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202106086')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112202106086) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112202106086) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2282,

/*Saldo final de cartera con riesgo de crédito etapa 2*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('101800104002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('101800104002')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800104002) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800104002) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2283,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111800205005')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111800205005')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111800205005) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111800205005) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2284,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111800506017')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111800506017')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111800506017) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111800506017) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2285,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801707018')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801707018')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801707018) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801707018) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2286,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801808027')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801808027')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801808027) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801808027) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2287,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801808028')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801808028')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801808028) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801808028) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2288,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801707019')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801707019')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801707019) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801707019) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2289,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801908029')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801908029')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801908029) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801908029) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2290,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801908030')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801908030')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801908030) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801908030) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2291,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801908031')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801908031')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801908031) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801908031) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2292,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801707020')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801707020')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801707020) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801707020) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2293,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111802008032')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111802008032')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111802008032) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111802008032) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2294,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111802008033')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111802008033')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111802008033) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111802008033) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2295,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801707021')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801707021')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801707021) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801707021) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2296,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801707022')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801707022')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801707022) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801707022) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2297,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801707023')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801707023')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801707023) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801707023) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2298,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801707024')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801707024')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801707024) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801707024) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2299,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801707025')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801707025')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801707025) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801707025) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2300
	
INTO IFRS9_R04A_0424_M15SALDOSTS1_RESULT_23
FROM IFRS9_R04A_0424

END

BEGIN
	INSERT INTO 
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_X01])),
            SUM(CHARINDEX('ERR',[VALIDACION_X02])),
            SUM(CHARINDEX('ERR',[VALIDACION_X03])),
            SUM(CHARINDEX('ERR',[VALIDACION_X04])),
            SUM(CHARINDEX('ERR',[VALIDACION_X05])),
            SUM(CHARINDEX('ERR',[VALIDACION_X06])),
            SUM(CHARINDEX('ERR',[VALIDACION_X07])),
            SUM(CHARINDEX('ERR',[VALIDACION_X08])),
            SUM(CHARINDEX('ERR',[VALIDACION_X09])),
            SUM(CHARINDEX('ERR',[VALIDACION_X10])),
            SUM(CHARINDEX('ERR',[VALIDACION_X11])),
            SUM(CHARINDEX('ERR',[VALIDACION_X12])),
            SUM(CHARINDEX('ERR',[VALIDACION_X13])),
            SUM(CHARINDEX('ERR',[VALIDACION_X14])),
            SUM(CHARINDEX('ERR',[VALIDACION_X15])),
            SUM(CHARINDEX('ERR',[VALIDACION_X16])),
            SUM(CHARINDEX('ERR',[VALIDACION_X17])),
            SUM(CHARINDEX('ERR',[VALIDACION_X18])),
            SUM(CHARINDEX('ERR',[VALIDACION_X19])),
            SUM(CHARINDEX('ERR',[VALIDACION_X20])),
            SUM(CHARINDEX('ERR',[VALIDACION_X21])),
            SUM(CHARINDEX('ERR',[VALIDACION_X22])),
            SUM(CHARINDEX('ERR',[VALIDACION_X23])),
            SUM(CHARINDEX('ERR',[VALIDACION_X24])),
            SUM(CHARINDEX('ERR',[VALIDACION_X25])),
            SUM(CHARINDEX('ERR',[VALIDACION_X26])),
            SUM(CHARINDEX('ERR',[VALIDACION_X27])),
            SUM(CHARINDEX('ERR',[VALIDACION_X28])),
            SUM(CHARINDEX('ERR',[VALIDACION_X29])),
            SUM(CHARINDEX('ERR',[VALIDACION_X30])),
            SUM(CHARINDEX('ERR',[VALIDACION_X31])),
            SUM(CHARINDEX('ERR',[VALIDACION_X32])),
            SUM(CHARINDEX('ERR',[VALIDACION_X33])),
            SUM(CHARINDEX('ERR',[VALIDACION_X34])),
            SUM(CHARINDEX('ERR',[VALIDACION_X35])),
            SUM(CHARINDEX('ERR',[VALIDACION_X36])),
            SUM(CHARINDEX('ERR',[VALIDACION_X37])),
            SUM(CHARINDEX('ERR',[VALIDACION_X38])),
            SUM(CHARINDEX('ERR',[VALIDACION_X39])),
            SUM(CHARINDEX('ERR',[VALIDACION_X40])),
            SUM(CHARINDEX('ERR',[VALIDACION_X41])),
            SUM(CHARINDEX('ERR',[VALIDACION_X42])),
            SUM(CHARINDEX('ERR',[VALIDACION_X43])),
            SUM(CHARINDEX('ERR',[VALIDACION_X44])),
            SUM(CHARINDEX('ERR',[VALIDACION_X45])),
            SUM(CHARINDEX('ERR',[VALIDACION_X46])),
            SUM(CHARINDEX('ERR',[VALIDACION_X47])),
            SUM(CHARINDEX('ERR',[VALIDACION_X48])),
            SUM(CHARINDEX('ERR',[VALIDACION_X49])),
            SUM(CHARINDEX('ERR',[VALIDACION_X50])),
            SUM(CHARINDEX('ERR',[VALIDACION_X51])),
            SUM(CHARINDEX('ERR',[VALIDACION_X52])),
            SUM(CHARINDEX('ERR',[VALIDACION_X53])),
            SUM(CHARINDEX('ERR',[VALIDACION_X54])),
            SUM(CHARINDEX('ERR',[VALIDACION_X55])),
            SUM(CHARINDEX('ERR',[VALIDACION_X56])),
            SUM(CHARINDEX('ERR',[VALIDACION_X57])),
            SUM(CHARINDEX('ERR',[VALIDACION_X58])),
            SUM(CHARINDEX('ERR',[VALIDACION_X59])),
            SUM(CHARINDEX('ERR',[VALIDACION_X60])),
            SUM(CHARINDEX('ERR',[VALIDACION_X61])),
            SUM(CHARINDEX('ERR',[VALIDACION_X62])),
            SUM(CHARINDEX('ERR',[VALIDACION_X63])),
            SUM(CHARINDEX('ERR',[VALIDACION_X64])),
            SUM(CHARINDEX('ERR',[VALIDACION_X65])),
            SUM(CHARINDEX('ERR',[VALIDACION_X66])),
            SUM(CHARINDEX('ERR',[VALIDACION_X67])),
            SUM(CHARINDEX('ERR',[VALIDACION_X68])),
            SUM(CHARINDEX('ERR',[VALIDACION_X69])),
            SUM(CHARINDEX('ERR',[VALIDACION_X70])),
            SUM(CHARINDEX('ERR',[VALIDACION_X71])),
            SUM(CHARINDEX('ERR',[VALIDACION_X72])),
            SUM(CHARINDEX('ERR',[VALIDACION_X73])),
            SUM(CHARINDEX('ERR',[VALIDACION_X74])),
            SUM(CHARINDEX('ERR',[VALIDACION_X75])),
            SUM(CHARINDEX('ERR',[VALIDACION_X76])),
            SUM(CHARINDEX('ERR',[VALIDACION_X77])),
            SUM(CHARINDEX('ERR',[VALIDACION_X78])),
            SUM(CHARINDEX('ERR',[VALIDACION_X79])),
            SUM(CHARINDEX('ERR',[VALIDACION_X80])),
            SUM(CHARINDEX('ERR',[VALIDACION_X81])),
            SUM(CHARINDEX('ERR',[VALIDACION_X82])),
            SUM(CHARINDEX('ERR',[VALIDACION_X83])),
            SUM(CHARINDEX('ERR',[VALIDACION_X84])),
            SUM(CHARINDEX('ERR',[VALIDACION_X85])),
            SUM(CHARINDEX('ERR',[VALIDACION_X86])),
            SUM(CHARINDEX('ERR',[VALIDACION_X87])),
            SUM(CHARINDEX('ERR',[VALIDACION_X88])),
            SUM(CHARINDEX('ERR',[VALIDACION_X89])),
            SUM(CHARINDEX('ERR',[VALIDACION_X90])),
            SUM(CHARINDEX('ERR',[VALIDACION_X91])),
            SUM(CHARINDEX('ERR',[VALIDACION_X92])),
            SUM(CHARINDEX('ERR',[VALIDACION_X93])),
            SUM(CHARINDEX('ERR',[VALIDACION_X94])),
            SUM(CHARINDEX('ERR',[VALIDACION_X95])),
            SUM(CHARINDEX('ERR',[VALIDACION_X96])),
            SUM(CHARINDEX('ERR',[VALIDACION_X97])),
            SUM(CHARINDEX('ERR',[VALIDACION_X98])),
            SUM(CHARINDEX('ERR',[VALIDACION_X99])),
            SUM(CHARINDEX('ERR',[VALIDACION_X00]))
            


		FROMx 
END

BEGIN
	EXEC SP_
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


