﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapas 1 y 2 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 9*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0424_M9TS1_COMP_6]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0424_M9TS1_RESULT_6')
BEGIN
DROP TABLE IFRS9_R04A_0424_M9TS1_RESULT_6
END 

BEGIN
SELECT DISTINCT

	/*ID*/

	CONVERT(VARCHAR,ID)  AS ID,   
	/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112218809232')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112223210115','112223210116','112223210117')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112218809232) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112223210115 + 112223210116 + 112223210117) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_501,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213008189')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112218909233','112218909234','112218909235','112218909236')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112213008189) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112218909233 + 112218909234 + 112218909235 + 112218909236) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_502,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112218909234')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112223410118','112223410119','112223410120','112223410121','112223410122')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112218909234) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112223410118 + 112223410119 + 112223410120 + 112223410121 + 112223410122) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_503,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112218909235')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112223510123','112223510124','112223510125','112223510126')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112218909235) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112223510123 + 112223510124 + 112223510125 + 112223510126) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_504,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112218909236')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112223610127','112223610128','112223610129','112223610130')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112218909236) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112223610127 + 112223610128 + 112223610129 + 112223610130) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_505,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112204207131')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213108190','112213108191','112213108192','112213108193','112213108194','112213108195','112213108196','112213108197')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112204207131) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112213108190 + 112213108191 + 112213108192 + 112213108193 + 112213108194 + 112213108195 + 112213108196 + 112213108197) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_506,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112204207132')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213208198','112213208199','112213208200','112213208201','112213208202')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112204207132) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112213208198 + 112213208199 + 112213208200 + 112213208201 + 112213208202) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_507,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213208200')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220009237','112220009238')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112213208200) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112220009237 + 112220009238) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_508,

/*Ventas de cartera (5)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200305012')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201206043','112201206044','112201206045')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200305012) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112201206043 + 112201206044 + 112201206045) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_509,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201206043')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112204307133','112204307134','112204307135')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201206043) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112204307133 + 112204307134 + 112204307135) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_510,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112204307133')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213308203','112213308204','112213308205','112213308206','112213308207','112213308208','112213308209','112213308210')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112204307133) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112213308203 + 112213308204 + 112213308205 + 112213308206 + 112213308207 + 112213308208 + 112213308209 + 112213308210) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_511,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213308203')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220309239','112220309240')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112213308203) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112220309239 + 112220309240) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_512,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213308204')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220409241','112220409242','112220409243')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112213308204) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112220409241 + 112220409242 + 112220409243) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_513,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213308205')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220509244','112220509245')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112213308205) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112220509244 + 112220509245) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_514,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112204307134')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213408211','112213408212')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112204307134) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112213408211 + 112213408212) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_515,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213408211')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221109246','112221109247','112221109248')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112213408211) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112221109246 + 112221109247 + 112221109248) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_516,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213408212')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221209249','112221209250','112221209251')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112213408212) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112221209249 + 112221209250 + 112221209251) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_517,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112204307135')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213508213','112213508214','112213508215','112213508216')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112204307135) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112213508213 + 112213508214 + 112213508215 + 112213508216) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_518,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213508214')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221409252','112221409253','112221409254','112221409255','112221409256')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112213508214) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112221409252 + 112221409253 + 112221409254 + 112221409255 + 112221409256) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_519,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213508215')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221509257','112221509258','112221509259','112221509260')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112213508215) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112221509257 + 112221509258 + 112221509259 + 112221509260) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_520,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213508216')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221609261','112221609262','112221609263','112221609264')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112213508216) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112221609261 + 112221609262 + 112221609263 + 112221609264) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_521,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201206044')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112204407136','112204407137','112204407138','112204407139','112204407140','112204407141','112204407142','112204407143')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201206044) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112204407136 + 112204407137 + 112204407138 + 112204407139 + 112204407140 + 112204407141 + 112204407142 + 112204407143) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_522,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201206045')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112204507144','112204507145','112204507146','112204507147','112204507148')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201206045) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112204507144 + 112204507145 + 112204507146 + 112204507147 + 112204507148) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_523,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112204507146')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112214608217','112214608218')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112204507146) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112214608217 + 112214608218) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_524,

/*Traspaso a cartera con riesgo de crédito etapa 1*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200305013')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201306046','112201306047','112201306048')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200305013) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112201306046 + 112201306047 + 112201306048) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_525,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201306046')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112204607149','112204607150','112204607151')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201306046) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112204607149 + 112204607150 + 112204607151) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_526,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112204607149')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112214908219','112214908220','112214908221','112214908222','112214908223','112214908224','112214908225','112214908226')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112204607149) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112214908219 + 112214908220 + 112214908221 + 112214908222 + 112214908223 + 112214908224 + 112214908225 + 112214908226) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_527,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112214908219')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221909265','112221909266')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112214908219) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112221909265 + 112221909266) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_528,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112214908220')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112222009267','112222009268','112222009269')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112214908220) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112222009267 + 112222009268 + 112222009269) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_529,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112214908221')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112222109270','112222109271')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112214908221) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112222109270 + 112222109271) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_530,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112204607150')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112215008227','112215008228')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112204607150) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112215008227 + 112215008228) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_531,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112215008227')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112222709272','112222709273','112222709274')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112215008227) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112222709272 + 112222709273 + 112222709274) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_532,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112215008228')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112222809275','112222809276','112222809277')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112215008228) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112222809275 + 112222809276 + 112222809277) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_533,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112204607151')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112215108229','112215108230','112215108231','112215108232')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112204607151) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112215108229 + 112215108230 + 112215108231 + 112215108232) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_534,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112215108230')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112223009278','112223009279','112223009280','112223009281','112223009282')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112215108230) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112223009278 + 112223009279 + 112223009280 + 112223009281 + 112223009282) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_535,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112215108231')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112223109283','112223109284','112223109285','112223109286')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112215108231) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112223109283 + 112223109284 + 112223109285 + 112223109286) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_536,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112215108232')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112223209287','112223209288','112223209289','112223209290')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112215108232) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112223209287 + 112223209288 + 112223209289 + 112223209290) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_537,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201306047')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112204707152','112204707153','112204707154','112204707155','112204707156','112204707157','112204707158','112204707159')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201306047) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112204707152 + 112204707153 + 112204707154 + 112204707155 + 112204707156 + 112204707157 + 112204707158 + 112204707159) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_538,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201306048')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112204807160','112204807161','112204807162','112204807163','112204807164')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201306048) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112204807160 + 112204807161 + 112204807162 + 112204807163 + 112204807164) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_539,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112204807162')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112216208233','112216208234')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112204807162) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112216208233 + 112216208234) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_540,

/*Traspaso a cartera con riesgo de crédito etapa 3*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200305014')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201406049','112201406050','112201406051')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200305014) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112201406049 + 112201406050 + 112201406051) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_541,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201406049')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112204907165','112204907166','112204907167')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201406049) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112204907165 + 112204907166 + 112204907167) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_542,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112204907165')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112216508235','112216508236','112216508237','112216508238','112216508239','112216508240','112216508241','112216508242')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112204907165) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112216508235 + 112216508236 + 112216508237 + 112216508238 + 112216508239 + 112216508240 + 112216508241 + 112216508242) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_543,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112216508235')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112223509291','112223509292')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112216508235) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112223509291 + 112223509292) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_544,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112216508236')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112223609293','112223609294','112223609295')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112216508236) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112223609293 + 112223609294 + 112223609295) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_545,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112216508237')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112223709296','112223709297')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112216508237) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112223709296 + 112223709297) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_546,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112204907166')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112216608243','112216608244')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112204907166) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112216608243 + 112216608244) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_547,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112216608243')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112224309298','112224309299','112224309300')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112216608243) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112224309298 + 112224309299 + 112224309300) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_548,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112216608244')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112224409301','112224409302','112224409303')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112216608244) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112224409301 + 112224409302 + 112224409303) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_549,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112204907167')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112216708245','112216708246','112216708247','112216708248')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112204907167) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112216708245 + 112216708246 + 112216708247 + 112216708248) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_550,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112216708246')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112224609304','112224609305','112224609306','112224609307','112224609308')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112216708246) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112224609304 + 112224609305 + 112224609306 + 112224609307 + 112224609308) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_551,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112216708247')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112224709309','112224709310','112224709311','112224709312')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112216708247) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112224709309 + 112224709310 + 112224709311 + 112224709312) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_552,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112216708248')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112224809313','112224809314','112224809315','112224809316')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112216708248) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112224809313 + 112224809314 + 112224809315 + 112224809316) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_553,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201406050')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112205007168','112205007169','112205007170','112205007171','112205007172','112205007173','112205007174','112205007175')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201406050) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112205007168 + 112205007169 + 112205007170 + 112205007171 + 112205007172 + 112205007173 + 112205007174 + 112205007175) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_554,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201406051')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112205107176','112205107177','112205107178','112205107179','112205107180')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201406051) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112205107176 + 112205107177 + 112205107178 + 112205107179 + 112205107180) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_555,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112205107178')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112217808249','112217808250')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112205107178) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112217808249 + 112217808250) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_556,

/*Traspaso a cartera de crédito valuada a valor razonable*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200305015')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201506052','112201506053','112201506054')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200305015) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112201506052 + 112201506053 + 112201506054) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_557,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201506052')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112205207181','112205207182','112205207183')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201506052) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112205207181 + 112205207182 + 112205207183) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_558,

/*Ajuste cambiario etapa 2*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200104004')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200405016','112200405017','112200405018')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200104004) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112200405016 + 112200405017 + 112200405018) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_559,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200405016')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201606055','112201606056','112201606057')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200405016) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112201606055 + 112201606056 + 112201606057) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_560,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201606055')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112205507184','112205507185','112205507186','112205507187','112205507188','112205507189','112205507190','112205507191')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201606055) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112205507184 + 112205507185 + 112205507186 + 112205507187 + 112205507188 + 112205507189 + 112205507190 + 112205507191) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_561,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112205507184')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112218408251','112218408252')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112205507184) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112218408251 + 112218408252) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_562,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112205507185')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112218508253','112218508254','112218508255')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112205507185) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112218508253 + 112218508254 + 112218508255) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_563,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112205507186')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112218608256','112218608257')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112205507186) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112218608256 + 112218608257) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_564,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201606056')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112205607192','112205607193')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201606056) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112205607192 + 112205607193) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_565,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112205607192')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112219208258','112219208259','112219208260')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112205607192) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112219208258 + 112219208259 + 112219208260) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_566,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112205607193')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112219308261','112219308262','112219308263')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112205607193) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112219308261 + 112219308262 + 112219308263) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_567,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201606057')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112205707194','112205707195','112205707196','112205707197')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201606057) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112205707194 + 112205707195 + 112205707196 + 112205707197) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_568,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112205707195')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112219508264','112219508265','112219508266','112219508267','112219508268')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112205707195) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112219508264 + 112219508265 + 112219508266 + 112219508267 + 112219508268) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_569,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112205707196')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112219608269','112219608270','112219608271','112219608272')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112205707196) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112219608269 + 112219608270 + 112219608271 + 112219608272) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_570,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112205707197')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112219708273','112219708274','112219708275','112219708276')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112205707197) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112219708273 + 112219708274 + 112219708275 + 112219708276) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_571,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200405017')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201706058','112201706059','112201706060','112201706061','112201706062','112201706063','112201706064','112201706065')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200405017) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112201706058 + 112201706059 + 112201706060 + 112201706061 + 112201706062 + 112201706063 + 112201706064 + 112201706065) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_572,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200405018')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201806066','112201806067','112201806068','112201806069','112201806070')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200405018) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112201806066 + 112201806067 + 112201806068 + 112201806069 + 112201806070) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_573,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201806068')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112206807198','112206807199')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201806068) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112206807198 + 112206807199) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_574,

/*Capitalización de Intereses etapa 2*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200104005')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200505019','112200505020','112200505021')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200104005) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112200505019 + 112200505020 + 112200505021) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_575,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200505019')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201906071','112201906072','112201906073')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200505019) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112201906071 + 112201906072 + 112201906073) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_576,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201906071')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207107200','112207107201','112207107202','112207107203','112207107204','112207107205','112207107206','112207107207')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201906071) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112207107200 + 112207107201 + 112207107202 + 112207107203 + 112207107204 + 112207107205 + 112207107206 + 112207107207) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_577,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207107200')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220008277','112220008278')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112207107200) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112220008277 + 112220008278) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_578,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207107201')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220108279','112220108280','112220108281')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112207107201) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112220108279 + 112220108280 + 112220108281) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_579,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207107202')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220208282','112220208283')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112207107202) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112220208282 + 112220208283) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_580,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201906072')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207207208','112207207209')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201906072) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112207207208 + 112207207209) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_581,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207207208')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220808284','112220808285','112220808286')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112207207208) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112220808284 + 112220808285 + 112220808286) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_582,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207207209')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220908287','112220908288','112220908289')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112207207209) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112220908287 + 112220908288 + 112220908289) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_583,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201906073')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207307210','112207307211','112207307212','112207307213')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112201906073) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112207307210 + 112207307211 + 112207307212 + 112207307213) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_584,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207307211')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221108290','112221108291','112221108292','112221108293','112221108294')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112207307211) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112221108290 + 112221108291 + 112221108292 + 112221108293 + 112221108294) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_585,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207307212')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221208295','112221208296','112221208297','112221208298')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112207307212) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112221208295 + 112221208296 + 112221208297 + 112221208298) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_586,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207307213')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221308299','112221308300','112221308301','112221308302')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112207307213) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112221308299 + 112221308300 + 112221308301 + 112221308302) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_587,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200505020')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202006074','112202006075','112202006076','112202006077','112202006078','112202006079','112202006080','112202006081')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200505020) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112202006074 + 112202006075 + 112202006076 + 112202006077 + 112202006078 + 112202006079 + 112202006080 + 112202006081) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_588,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200505021')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202106082','112202106083','112202106084','112202106085','112202106086')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112200505021) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112202106082 + 112202106083 + 112202106084 + 112202106085 + 112202106086) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_589,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202106084')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112208407214','112208407215')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112202106084) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112208407214 + 112208407215) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_590,

/*Saldo final de cartera con riesgo de crédito etapa 2*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('101800104002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111800205005','111800205006','111800205007')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800104002) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111800205005 + 111800205006 + 111800205007) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_591,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111800205005')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111800506017','111800506018','111800506019')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111800205005) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111800506017 + 111800506018 + 111800506019) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_592,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111800506017')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801707018','111801707019','111801707020','111801707021','111801707022','111801707023','111801707024','111801707025')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111800506017) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111801707018 + 111801707019 + 111801707020 + 111801707021 + 111801707022 + 111801707023 + 111801707024 + 111801707025) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_593,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801707018')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801808027','111801808028')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111801707018) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111801808027 + 111801808028) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_594,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801707019')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801908029','111801908030','111801908031')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111801707019) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111801908029 + 111801908030 + 111801908031) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_595,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801707020')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111802008032','111802008033')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111801707020) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111802008032 + 111802008033) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_596,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111800506018')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801807026','111801807027')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111800506018) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111801807026 + 111801807027) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_597,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801807026')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111802608034','111802608035','111802608036')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111801807026) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111802608034 + 111802608035 + 111802608036) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_598,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801807027')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111802708037','111802708038','111802708039')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111801807027) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111802708037 + 111802708038 + 111802708039) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_599,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111800506019')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('9')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801907028','111801907029','111801907030','111801907031')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('9')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111800506019) con Moneda 9, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111801907028 + 111801907029 + 111801907030 + 111801907031) con Moneda 9, Tipo de Saldo 1.')    
AS VALIDACION_600
	
INTO IFRS9_R04A_0424_M9TS1_RESULT_6
FROM IFRS9_R04A_0424

END

BEGIN
	INSERT INTO 
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_X01])),
            SUM(CHARINDEX('ERR',[VALIDACION_X02])),
            SUM(CHARINDEX('ERR',[VALIDACION_X03])),
            SUM(CHARINDEX('ERR',[VALIDACION_X04])),
            SUM(CHARINDEX('ERR',[VALIDACION_X05])),
            SUM(CHARINDEX('ERR',[VALIDACION_X06])),
            SUM(CHARINDEX('ERR',[VALIDACION_X07])),
            SUM(CHARINDEX('ERR',[VALIDACION_X08])),
            SUM(CHARINDEX('ERR',[VALIDACION_X09])),
            SUM(CHARINDEX('ERR',[VALIDACION_X10])),
            SUM(CHARINDEX('ERR',[VALIDACION_X11])),
            SUM(CHARINDEX('ERR',[VALIDACION_X12])),
            SUM(CHARINDEX('ERR',[VALIDACION_X13])),
            SUM(CHARINDEX('ERR',[VALIDACION_X14])),
            SUM(CHARINDEX('ERR',[VALIDACION_X15])),
            SUM(CHARINDEX('ERR',[VALIDACION_X16])),
            SUM(CHARINDEX('ERR',[VALIDACION_X17])),
            SUM(CHARINDEX('ERR',[VALIDACION_X18])),
            SUM(CHARINDEX('ERR',[VALIDACION_X19])),
            SUM(CHARINDEX('ERR',[VALIDACION_X20])),
            SUM(CHARINDEX('ERR',[VALIDACION_X21])),
            SUM(CHARINDEX('ERR',[VALIDACION_X22])),
            SUM(CHARINDEX('ERR',[VALIDACION_X23])),
            SUM(CHARINDEX('ERR',[VALIDACION_X24])),
            SUM(CHARINDEX('ERR',[VALIDACION_X25])),
            SUM(CHARINDEX('ERR',[VALIDACION_X26])),
            SUM(CHARINDEX('ERR',[VALIDACION_X27])),
            SUM(CHARINDEX('ERR',[VALIDACION_X28])),
            SUM(CHARINDEX('ERR',[VALIDACION_X29])),
            SUM(CHARINDEX('ERR',[VALIDACION_X30])),
            SUM(CHARINDEX('ERR',[VALIDACION_X31])),
            SUM(CHARINDEX('ERR',[VALIDACION_X32])),
            SUM(CHARINDEX('ERR',[VALIDACION_X33])),
            SUM(CHARINDEX('ERR',[VALIDACION_X34])),
            SUM(CHARINDEX('ERR',[VALIDACION_X35])),
            SUM(CHARINDEX('ERR',[VALIDACION_X36])),
            SUM(CHARINDEX('ERR',[VALIDACION_X37])),
            SUM(CHARINDEX('ERR',[VALIDACION_X38])),
            SUM(CHARINDEX('ERR',[VALIDACION_X39])),
            SUM(CHARINDEX('ERR',[VALIDACION_X40])),
            SUM(CHARINDEX('ERR',[VALIDACION_X41])),
            SUM(CHARINDEX('ERR',[VALIDACION_X42])),
            SUM(CHARINDEX('ERR',[VALIDACION_X43])),
            SUM(CHARINDEX('ERR',[VALIDACION_X44])),
            SUM(CHARINDEX('ERR',[VALIDACION_X45])),
            SUM(CHARINDEX('ERR',[VALIDACION_X46])),
            SUM(CHARINDEX('ERR',[VALIDACION_X47])),
            SUM(CHARINDEX('ERR',[VALIDACION_X48])),
            SUM(CHARINDEX('ERR',[VALIDACION_X49])),
            SUM(CHARINDEX('ERR',[VALIDACION_X50])),
            SUM(CHARINDEX('ERR',[VALIDACION_X51])),
            SUM(CHARINDEX('ERR',[VALIDACION_X52])),
            SUM(CHARINDEX('ERR',[VALIDACION_X53])),
            SUM(CHARINDEX('ERR',[VALIDACION_X54])),
            SUM(CHARINDEX('ERR',[VALIDACION_X55])),
            SUM(CHARINDEX('ERR',[VALIDACION_X56])),
            SUM(CHARINDEX('ERR',[VALIDACION_X57])),
            SUM(CHARINDEX('ERR',[VALIDACION_X58])),
            SUM(CHARINDEX('ERR',[VALIDACION_X59])),
            SUM(CHARINDEX('ERR',[VALIDACION_X60])),
            SUM(CHARINDEX('ERR',[VALIDACION_X61])),
            SUM(CHARINDEX('ERR',[VALIDACION_X62])),
            SUM(CHARINDEX('ERR',[VALIDACION_X63])),
            SUM(CHARINDEX('ERR',[VALIDACION_X64])),
            SUM(CHARINDEX('ERR',[VALIDACION_X65])),
            SUM(CHARINDEX('ERR',[VALIDACION_X66])),
            SUM(CHARINDEX('ERR',[VALIDACION_X67])),
            SUM(CHARINDEX('ERR',[VALIDACION_X68])),
            SUM(CHARINDEX('ERR',[VALIDACION_X69])),
            SUM(CHARINDEX('ERR',[VALIDACION_X70])),
            SUM(CHARINDEX('ERR',[VALIDACION_X71])),
            SUM(CHARINDEX('ERR',[VALIDACION_X72])),
            SUM(CHARINDEX('ERR',[VALIDACION_X73])),
            SUM(CHARINDEX('ERR',[VALIDACION_X74])),
            SUM(CHARINDEX('ERR',[VALIDACION_X75])),
            SUM(CHARINDEX('ERR',[VALIDACION_X76])),
            SUM(CHARINDEX('ERR',[VALIDACION_X77])),
            SUM(CHARINDEX('ERR',[VALIDACION_X78])),
            SUM(CHARINDEX('ERR',[VALIDACION_X79])),
            SUM(CHARINDEX('ERR',[VALIDACION_X80])),
            SUM(CHARINDEX('ERR',[VALIDACION_X81])),
            SUM(CHARINDEX('ERR',[VALIDACION_X82])),
            SUM(CHARINDEX('ERR',[VALIDACION_X83])),
            SUM(CHARINDEX('ERR',[VALIDACION_X84])),
            SUM(CHARINDEX('ERR',[VALIDACION_X85])),
            SUM(CHARINDEX('ERR',[VALIDACION_X86])),
            SUM(CHARINDEX('ERR',[VALIDACION_X87])),
            SUM(CHARINDEX('ERR',[VALIDACION_X88])),
            SUM(CHARINDEX('ERR',[VALIDACION_X89])),
            SUM(CHARINDEX('ERR',[VALIDACION_X90])),
            SUM(CHARINDEX('ERR',[VALIDACION_X91])),
            SUM(CHARINDEX('ERR',[VALIDACION_X92])),
            SUM(CHARINDEX('ERR',[VALIDACION_X93])),
            SUM(CHARINDEX('ERR',[VALIDACION_X94])),
            SUM(CHARINDEX('ERR',[VALIDACION_X95])),
            SUM(CHARINDEX('ERR',[VALIDACION_X96])),
            SUM(CHARINDEX('ERR',[VALIDACION_X97])),
            SUM(CHARINDEX('ERR',[VALIDACION_X98])),
            SUM(CHARINDEX('ERR',[VALIDACION_X99])),
            SUM(CHARINDEX('ERR',[VALIDACION_X00]))
            


		FROMx 
END

BEGIN
	EXEC SP_
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


