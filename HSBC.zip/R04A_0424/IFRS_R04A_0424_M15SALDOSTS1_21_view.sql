﻿
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapas 1 y 2 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15SALDOS*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/


CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0424_M15SALDOSTS1_VIEW_21]
AS
BEGIN
	SELECT *
		
	FROM IFRS9_R04A_0424_M15SALDOSTS1_RESULT_21
	WHERE

        (VALIDACION_2001 <> '' ) OR
        (VALIDACION_2002 <> '' ) OR
        (VALIDACION_2003 <> '' ) OR
        (VALIDACION_2004 <> '' ) OR
        (VALIDACION_2005 <> '' ) OR
        (VALIDACION_2006 <> '' ) OR
        (VALIDACION_2007 <> '' ) OR
        (VALIDACION_2008 <> '' ) OR
        (VALIDACION_2009 <> '' ) OR
        (VALIDACION_2010 <> '' ) OR
        (VALIDACION_2011 <> '' ) OR
        (VALIDACION_2012 <> '' ) OR
        (VALIDACION_2013 <> '' ) OR
        (VALIDACION_2014 <> '' ) OR
        (VALIDACION_2015 <> '' ) OR
        (VALIDACION_2016 <> '' ) OR
        (VALIDACION_2017 <> '' ) OR
        (VALIDACION_2018 <> '' ) OR
        (VALIDACION_2019 <> '' ) OR
        (VALIDACION_2020 <> '' ) OR
        (VALIDACION_2021 <> '' ) OR
        (VALIDACION_2022 <> '' ) OR
        (VALIDACION_2023 <> '' ) OR
        (VALIDACION_2024 <> '' ) OR
        (VALIDACION_2025 <> '' ) OR
        (VALIDACION_2026 <> '' ) OR
        (VALIDACION_2027 <> '' ) OR
        (VALIDACION_2028 <> '' ) OR
        (VALIDACION_2029 <> '' ) OR
        (VALIDACION_2030 <> '' ) OR
        (VALIDACION_2031 <> '' ) OR
        (VALIDACION_2032 <> '' ) OR
        (VALIDACION_2033 <> '' ) OR
        (VALIDACION_2034 <> '' ) OR
        (VALIDACION_2035 <> '' ) OR
        (VALIDACION_2036 <> '' ) OR
        (VALIDACION_2037 <> '' ) OR
        (VALIDACION_2038 <> '' ) OR
        (VALIDACION_2039 <> '' ) OR
        (VALIDACION_2040 <> '' ) OR
        (VALIDACION_2041 <> '' ) OR
        (VALIDACION_2042 <> '' ) OR
        (VALIDACION_2043 <> '' ) OR
        (VALIDACION_2044 <> '' ) OR
        (VALIDACION_2045 <> '' ) OR
        (VALIDACION_2046 <> '' ) OR
        (VALIDACION_2047 <> '' ) OR
        (VALIDACION_2048 <> '' ) OR
        (VALIDACION_2049 <> '' ) OR
        (VALIDACION_2050 <> '' ) OR
        (VALIDACION_2051 <> '' ) OR
        (VALIDACION_2052 <> '' ) OR
        (VALIDACION_2053 <> '' ) OR
        (VALIDACION_2054 <> '' ) OR
        (VALIDACION_2055 <> '' ) OR
        (VALIDACION_2056 <> '' ) OR
        (VALIDACION_2057 <> '' ) OR
        (VALIDACION_2058 <> '' ) OR
        (VALIDACION_2059 <> '' ) OR
        (VALIDACION_2060 <> '' ) OR
        (VALIDACION_2061 <> '' ) OR
        (VALIDACION_2062 <> '' ) OR
        (VALIDACION_2063 <> '' ) OR
        (VALIDACION_2064 <> '' ) OR
        (VALIDACION_2065 <> '' ) OR
        (VALIDACION_2066 <> '' ) OR
        (VALIDACION_2067 <> '' ) OR
        (VALIDACION_2068 <> '' ) OR
        (VALIDACION_2069 <> '' ) OR
        (VALIDACION_2070 <> '' ) OR
        (VALIDACION_2071 <> '' ) OR
        (VALIDACION_2072 <> '' ) OR
        (VALIDACION_2073 <> '' ) OR
        (VALIDACION_2074 <> '' ) OR
        (VALIDACION_2075 <> '' ) OR
        (VALIDACION_2076 <> '' ) OR
        (VALIDACION_2077 <> '' ) OR
        (VALIDACION_2078 <> '' ) OR
        (VALIDACION_2079 <> '' ) OR
        (VALIDACION_2080 <> '' ) OR
        (VALIDACION_2081 <> '' ) OR
        (VALIDACION_2082 <> '' ) OR
        (VALIDACION_2083 <> '' ) OR
        (VALIDACION_2084 <> '' ) OR
        (VALIDACION_2085 <> '' ) OR
        (VALIDACION_2086 <> '' ) OR
        (VALIDACION_2087 <> '' ) OR
        (VALIDACION_2088 <> '' ) OR
        (VALIDACION_2089 <> '' ) OR
        (VALIDACION_2090 <> '' ) OR
        (VALIDACION_2091 <> '' ) OR
        (VALIDACION_2092 <> '' ) OR
        (VALIDACION_2093 <> '' ) OR
        (VALIDACION_2094 <> '' ) OR
        (VALIDACION_2095 <> '' ) OR
        (VALIDACION_2096 <> '' ) OR
        (VALIDACION_2097 <> '' ) OR
        (VALIDACION_2098 <> '' ) OR
        (VALIDACION_2099 <> '' ) OR
        (VALIDACION_2100 <> '' ) 
ORDER BY 1
END

