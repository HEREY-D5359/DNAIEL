﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapas 1 y 2 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15SALDOS*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0424_M15SALDOSTS1_COMP_23]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0424_M15SALDOSTS1_RESULT_23')
BEGIN
DROP TABLE IFRS9_R04A_0424_M15SALDOSTS1_RESULT_23
END 

BEGIN
SELECT DISTINCT
         /*id*/
CONVERT(VARCHAR,ID) AS ID, 
	/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112219708274')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112219708274')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112219708274) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112219708274) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2201,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112219708275')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112219708275')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112219708275) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112219708275) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2202,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112219708276')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112219708276')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112219708276) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112219708276) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2203,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200405017')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200405017')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112200405017) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112200405017) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2204,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201706058')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201706058')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201706058) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201706058) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2205,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201706059')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201706059')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201706059) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201706059) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2206,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201706060')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201706060')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201706060) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201706060) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2207,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201706061')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201706061')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201706061) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201706061) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2208,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201706062')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201706062')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201706062) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201706062) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2209,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201706063')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201706063')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201706063) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201706063) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2210,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201706064')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201706064')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201706064) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201706064) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2211,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201706065')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201706065')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201706065) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201706065) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2212,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200405018')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200405018')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112200405018) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112200405018) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2213,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201806066')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201806066')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201806066) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201806066) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2214,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201806067')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201806067')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201806067) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201806067) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2215,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201806068')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201806068')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201806068) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201806068) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2216,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112206807198')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112206807198')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112206807198) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112206807198) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2217,

/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112206807199')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112206807199')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112206807199) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112206807199) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2218,

/*Remodelación o mejoramiento con garantía otorgada por la Banca de Desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201806069')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201806069')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201806069) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201806069) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2219,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201806070')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201806070')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201806070) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201806070) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2220,

/*Capitalización de Intereses etapa 2*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200104005')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200104005')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112200104005) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112200104005) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2221,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200505019')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200505019')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112200505019) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112200505019) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2222,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201906071')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201906071')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201906071) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201906071) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2223,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207107200')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207107200')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112207107200) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112207107200) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2224,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220008277')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220008277')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220008277) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220008277) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2225,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220008278')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220008278')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220008278) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220008278) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2226,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207107201')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207107201')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112207107201) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112207107201) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2227,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220108279')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220108279')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220108279) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220108279) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2228,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220108280')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220108280')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220108280) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220108280) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2229,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220108281')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220108281')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220108281) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220108281) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2230,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207107202')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207107202')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112207107202) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112207107202) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2231,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220208282')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220208282')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220208282) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220208282) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2232,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220208283')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220208283')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220208283) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220208283) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2233,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207107203')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207107203')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112207107203) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112207107203) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2234,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207107204')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207107204')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112207107204) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112207107204) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2235,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207107205')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207107205')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112207107205) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112207107205) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2236,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207107206')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207107206')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112207107206) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112207107206) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2237,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207107207')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207107207')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112207107207) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112207107207) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2238,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201906072')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201906072')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201906072) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201906072) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2239,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207207208')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207207208')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112207207208) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112207207208) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2240,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220808284')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220808284')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220808284) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220808284) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2241,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220808285')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220808285')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220808285) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220808285) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2242,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220808286')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220808286')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220808286) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220808286) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2243,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207207209')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207207209')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112207207209) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112207207209) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2244,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220908287')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220908287')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220908287) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220908287) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2245,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220908288')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220908288')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220908288) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220908288) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2246,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220908289')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220908289')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220908289) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220908289) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2247,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201906073')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201906073')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201906073) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201906073) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2248,

/*Créditos al gobierno federal */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207307210')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207307210')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112207307210) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112207307210) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2249,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207307211')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207307211')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112207307211) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112207307211) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2250,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221108290')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221108290')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221108290) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221108290) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2251,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221108291')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221108291')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221108291) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221108291) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2252,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221108292')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221108292')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221108292) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221108292) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2253,

/*Fideicomisos públicos de contratación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221108293')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221108293')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221108293) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221108293) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2254,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221108294')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221108294')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221108294) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221108294) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2255,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207307212')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207307212')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112207307212) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112207307212) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2256,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221208295')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221208295')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221208295) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221208295) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2257,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221208296')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221208296')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221208296) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221208296) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2258,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221208297')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221208297')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221208297) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221208297) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2259,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221208298')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221208298')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221208298) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221208298) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2260,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112207307213')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112207307213')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112207307213) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112207307213) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2261,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221308299')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221308299')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221308299) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221308299) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2262,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221308300')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221308300')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221308300) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221308300) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2263,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221308301')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221308301')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221308301) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221308301) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2264,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221308302')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221308302')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221308302) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221308302) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2265,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200505020')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200505020')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112200505020) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112200505020) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2266,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202006074')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202006074')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112202006074) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112202006074) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2267,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202006075')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202006075')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112202006075) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112202006075) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2268,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202006076')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202006076')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112202006076) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112202006076) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2269,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202006077')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202006077')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112202006077) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112202006077) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2270,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202006078')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202006078')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112202006078) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112202006078) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2271,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202006079')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202006079')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112202006079) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112202006079) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2272,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202006080')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202006080')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112202006080) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112202006080) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2273,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202006081')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202006081')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112202006081) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112202006081) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2274,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200505021')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200505021')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112200505021) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112200505021) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2275,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202106082')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202106082')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112202106082) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112202106082) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2276,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202106083')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202106083')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112202106083) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112202106083) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2277,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202106084')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202106084')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112202106084) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112202106084) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2278,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112208407214')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112208407214')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112208407214) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112208407214) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2279,

/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112208407215')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112208407215')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112208407215) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112208407215) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2280,

/*Remodelación o mejoramiento con garantía otorgada por la Banca de Desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202106085')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202106085')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112202106085) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112202106085) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2281,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112202106086')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112202106086')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112202106086) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112202106086) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2282,

/*Saldo final de cartera con riesgo de crédito etapa 2*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('101800104002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('101800104002')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800104002) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800104002) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2283,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111800205005')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111800205005')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111800205005) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111800205005) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2284,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111800506017')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111800506017')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111800506017) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111800506017) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2285,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801707018')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801707018')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801707018) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801707018) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2286,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801808027')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801808027')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801808027) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801808027) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2287,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801808028')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801808028')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801808028) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801808028) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2288,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801707019')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801707019')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801707019) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801707019) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2289,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801908029')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801908029')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801908029) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801908029) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2290,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801908030')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801908030')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801908030) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801908030) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2291,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801908031')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801908031')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801908031) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801908031) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2292,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801707020')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801707020')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801707020) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801707020) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2293,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111802008032')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111802008032')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111802008032) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111802008032) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2294,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111802008033')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111802008033')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111802008033) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111802008033) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2295,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801707021')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801707021')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801707021) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801707021) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2296,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801707022')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801707022')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801707022) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801707022) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2297,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801707023')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801707023')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801707023) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801707023) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2298,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801707024')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801707024')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801707024) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801707024) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2299,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801707025')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111801707025')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801707025) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801707025) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2300
	
INTO IFRS9_R04A_0424_M15SALDOSTS1_RESULT_23
FROM IFRS9_R04A_0424

END

BEGIN
	INSERT INTO IFRS9_R04A_0424_M15SALDOSTS1_RESULT_23 
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_2201])),
            SUM(CHARINDEX('ERR',[VALIDACION_2202])),
            SUM(CHARINDEX('ERR',[VALIDACION_2203])),
            SUM(CHARINDEX('ERR',[VALIDACION_2204])),
            SUM(CHARINDEX('ERR',[VALIDACION_2205])),
            SUM(CHARINDEX('ERR',[VALIDACION_2206])),
            SUM(CHARINDEX('ERR',[VALIDACION_2207])),
            SUM(CHARINDEX('ERR',[VALIDACION_2208])),
            SUM(CHARINDEX('ERR',[VALIDACION_2209])),
            SUM(CHARINDEX('ERR',[VALIDACION_2210])),
            SUM(CHARINDEX('ERR',[VALIDACION_2211])),
            SUM(CHARINDEX('ERR',[VALIDACION_2212])),
            SUM(CHARINDEX('ERR',[VALIDACION_2213])),
            SUM(CHARINDEX('ERR',[VALIDACION_2214])),
            SUM(CHARINDEX('ERR',[VALIDACION_2215])),
            SUM(CHARINDEX('ERR',[VALIDACION_2216])),
            SUM(CHARINDEX('ERR',[VALIDACION_2217])),
            SUM(CHARINDEX('ERR',[VALIDACION_2218])),
            SUM(CHARINDEX('ERR',[VALIDACION_2219])),
            SUM(CHARINDEX('ERR',[VALIDACION_2220])),
            SUM(CHARINDEX('ERR',[VALIDACION_2221])),
            SUM(CHARINDEX('ERR',[VALIDACION_2222])),
            SUM(CHARINDEX('ERR',[VALIDACION_2223])),
            SUM(CHARINDEX('ERR',[VALIDACION_2224])),
            SUM(CHARINDEX('ERR',[VALIDACION_2225])),
            SUM(CHARINDEX('ERR',[VALIDACION_2226])),
            SUM(CHARINDEX('ERR',[VALIDACION_2227])),
            SUM(CHARINDEX('ERR',[VALIDACION_2228])),
            SUM(CHARINDEX('ERR',[VALIDACION_2229])),
            SUM(CHARINDEX('ERR',[VALIDACION_2230])),
            SUM(CHARINDEX('ERR',[VALIDACION_2231])),
            SUM(CHARINDEX('ERR',[VALIDACION_2232])),
            SUM(CHARINDEX('ERR',[VALIDACION_2233])),
            SUM(CHARINDEX('ERR',[VALIDACION_2234])),
            SUM(CHARINDEX('ERR',[VALIDACION_2235])),
            SUM(CHARINDEX('ERR',[VALIDACION_2236])),
            SUM(CHARINDEX('ERR',[VALIDACION_2237])),
            SUM(CHARINDEX('ERR',[VALIDACION_2238])),
            SUM(CHARINDEX('ERR',[VALIDACION_2239])),
            SUM(CHARINDEX('ERR',[VALIDACION_2240])),
            SUM(CHARINDEX('ERR',[VALIDACION_2241])),
            SUM(CHARINDEX('ERR',[VALIDACION_2242])),
            SUM(CHARINDEX('ERR',[VALIDACION_2243])),
            SUM(CHARINDEX('ERR',[VALIDACION_2244])),
            SUM(CHARINDEX('ERR',[VALIDACION_2245])),
            SUM(CHARINDEX('ERR',[VALIDACION_2246])),
            SUM(CHARINDEX('ERR',[VALIDACION_2247])),
            SUM(CHARINDEX('ERR',[VALIDACION_2248])),
            SUM(CHARINDEX('ERR',[VALIDACION_2249])),
            SUM(CHARINDEX('ERR',[VALIDACION_2250])),
            SUM(CHARINDEX('ERR',[VALIDACION_2251])),
            SUM(CHARINDEX('ERR',[VALIDACION_2252])),
            SUM(CHARINDEX('ERR',[VALIDACION_2253])),
            SUM(CHARINDEX('ERR',[VALIDACION_2254])),
            SUM(CHARINDEX('ERR',[VALIDACION_2255])),
            SUM(CHARINDEX('ERR',[VALIDACION_2256])),
            SUM(CHARINDEX('ERR',[VALIDACION_2257])),
            SUM(CHARINDEX('ERR',[VALIDACION_2258])),
            SUM(CHARINDEX('ERR',[VALIDACION_2259])),
            SUM(CHARINDEX('ERR',[VALIDACION_2260])),
            SUM(CHARINDEX('ERR',[VALIDACION_2261])),
            SUM(CHARINDEX('ERR',[VALIDACION_2262])),
            SUM(CHARINDEX('ERR',[VALIDACION_2263])),
            SUM(CHARINDEX('ERR',[VALIDACION_2264])),
            SUM(CHARINDEX('ERR',[VALIDACION_2265])),
            SUM(CHARINDEX('ERR',[VALIDACION_2266])),
            SUM(CHARINDEX('ERR',[VALIDACION_2267])),
            SUM(CHARINDEX('ERR',[VALIDACION_2268])),
            SUM(CHARINDEX('ERR',[VALIDACION_2269])),
            SUM(CHARINDEX('ERR',[VALIDACION_2270])),
            SUM(CHARINDEX('ERR',[VALIDACION_2271])),
            SUM(CHARINDEX('ERR',[VALIDACION_2272])),
            SUM(CHARINDEX('ERR',[VALIDACION_2273])),
            SUM(CHARINDEX('ERR',[VALIDACION_2274])),
            SUM(CHARINDEX('ERR',[VALIDACION_2275])),
            SUM(CHARINDEX('ERR',[VALIDACION_2276])),
            SUM(CHARINDEX('ERR',[VALIDACION_2277])),
            SUM(CHARINDEX('ERR',[VALIDACION_2278])),
            SUM(CHARINDEX('ERR',[VALIDACION_2279])),
            SUM(CHARINDEX('ERR',[VALIDACION_2280])),
            SUM(CHARINDEX('ERR',[VALIDACION_2281])),
            SUM(CHARINDEX('ERR',[VALIDACION_2282])),
            SUM(CHARINDEX('ERR',[VALIDACION_2283])),
            SUM(CHARINDEX('ERR',[VALIDACION_2284])),
            SUM(CHARINDEX('ERR',[VALIDACION_2285])),
            SUM(CHARINDEX('ERR',[VALIDACION_2286])),
            SUM(CHARINDEX('ERR',[VALIDACION_2287])),
            SUM(CHARINDEX('ERR',[VALIDACION_2288])),
            SUM(CHARINDEX('ERR',[VALIDACION_2289])),
            SUM(CHARINDEX('ERR',[VALIDACION_2290])),
            SUM(CHARINDEX('ERR',[VALIDACION_2291])),
            SUM(CHARINDEX('ERR',[VALIDACION_2292])),
            SUM(CHARINDEX('ERR',[VALIDACION_2293])),
            SUM(CHARINDEX('ERR',[VALIDACION_2294])),
            SUM(CHARINDEX('ERR',[VALIDACION_2295])),
            SUM(CHARINDEX('ERR',[VALIDACION_2296])),
            SUM(CHARINDEX('ERR',[VALIDACION_2297])),
            SUM(CHARINDEX('ERR',[VALIDACION_2298])),
            SUM(CHARINDEX('ERR',[VALIDACION_2299])),
            SUM(CHARINDEX('ERR',[VALIDACION_2300]))
            


		FROM IFRS9_R04A_0424_M15SALDOSTS1_RESULT_23 
END

BEGIN
	EXEC SP_IFRS9_R04A_0424_M15SALDOSTS1_VIEW_23
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


