﻿
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapas 1 y 2 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15SALDOS*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/


CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0424_M15SALDOSTS1_VIEW_23]
AS
BEGIN
	SELECT *
		
	FROM IFRS9_R04A_0424_M15SALDOSTS1_RESULT_23
	WHERE

        (VALIDACION_2201 <> '' ) OR
        (VALIDACION_2202 <> '' ) OR
        (VALIDACION_2203 <> '' ) OR
        (VALIDACION_2204 <> '' ) OR
        (VALIDACION_2205 <> '' ) OR
        (VALIDACION_2206 <> '' ) OR
        (VALIDACION_2207 <> '' ) OR
        (VALIDACION_2208 <> '' ) OR
        (VALIDACION_2209 <> '' ) OR
        (VALIDACION_2210 <> '' ) OR
        (VALIDACION_2211 <> '' ) OR
        (VALIDACION_2212 <> '' ) OR
        (VALIDACION_2213 <> '' ) OR
        (VALIDACION_2214 <> '' ) OR
        (VALIDACION_2215 <> '' ) OR
        (VALIDACION_2216 <> '' ) OR
        (VALIDACION_2217 <> '' ) OR
        (VALIDACION_2218 <> '' ) OR
        (VALIDACION_2219 <> '' ) OR
        (VALIDACION_2220 <> '' ) OR
        (VALIDACION_2221 <> '' ) OR
        (VALIDACION_2222 <> '' ) OR
        (VALIDACION_2223 <> '' ) OR
        (VALIDACION_2224 <> '' ) OR
        (VALIDACION_2225 <> '' ) OR
        (VALIDACION_2226 <> '' ) OR
        (VALIDACION_2227 <> '' ) OR
        (VALIDACION_2228 <> '' ) OR
        (VALIDACION_2229 <> '' ) OR
        (VALIDACION_2230 <> '' ) OR
        (VALIDACION_2231 <> '' ) OR
        (VALIDACION_2232 <> '' ) OR
        (VALIDACION_2233 <> '' ) OR
        (VALIDACION_2234 <> '' ) OR
        (VALIDACION_2235 <> '' ) OR
        (VALIDACION_2236 <> '' ) OR
        (VALIDACION_2237 <> '' ) OR
        (VALIDACION_2238 <> '' ) OR
        (VALIDACION_2239 <> '' ) OR
        (VALIDACION_2240 <> '' ) OR
        (VALIDACION_2241 <> '' ) OR
        (VALIDACION_2242 <> '' ) OR
        (VALIDACION_2243 <> '' ) OR
        (VALIDACION_2244 <> '' ) OR
        (VALIDACION_2245 <> '' ) OR
        (VALIDACION_2246 <> '' ) OR
        (VALIDACION_2247 <> '' ) OR
        (VALIDACION_2248 <> '' ) OR
        (VALIDACION_2249 <> '' ) OR
        (VALIDACION_2250 <> '' ) OR
        (VALIDACION_2251 <> '' ) OR
        (VALIDACION_2252 <> '' ) OR
        (VALIDACION_2253 <> '' ) OR
        (VALIDACION_2254 <> '' ) OR
        (VALIDACION_2255 <> '' ) OR
        (VALIDACION_2256 <> '' ) OR
        (VALIDACION_2257 <> '' ) OR
        (VALIDACION_2258 <> '' ) OR
        (VALIDACION_2259 <> '' ) OR
        (VALIDACION_2260 <> '' ) OR
        (VALIDACION_2261 <> '' ) OR
        (VALIDACION_2262 <> '' ) OR
        (VALIDACION_2263 <> '' ) OR
        (VALIDACION_2264 <> '' ) OR
        (VALIDACION_2265 <> '' ) OR
        (VALIDACION_2266 <> '' ) OR
        (VALIDACION_2267 <> '' ) OR
        (VALIDACION_2268 <> '' ) OR
        (VALIDACION_2269 <> '' ) OR
        (VALIDACION_2270 <> '' ) OR
        (VALIDACION_2271 <> '' ) OR
        (VALIDACION_2272 <> '' ) OR
        (VALIDACION_2273 <> '' ) OR
        (VALIDACION_2274 <> '' ) OR
        (VALIDACION_2275 <> '' ) OR
        (VALIDACION_2276 <> '' ) OR
        (VALIDACION_2277 <> '' ) OR
        (VALIDACION_2278 <> '' ) OR
        (VALIDACION_2279 <> '' ) OR
        (VALIDACION_2280 <> '' ) OR
        (VALIDACION_2281 <> '' ) OR
        (VALIDACION_2282 <> '' ) OR
        (VALIDACION_2283 <> '' ) OR
        (VALIDACION_2284 <> '' ) OR
        (VALIDACION_2285 <> '' ) OR
        (VALIDACION_2286 <> '' ) OR
        (VALIDACION_2287 <> '' ) OR
        (VALIDACION_2288 <> '' ) OR
        (VALIDACION_2289 <> '' ) OR
        (VALIDACION_2290 <> '' ) OR
        (VALIDACION_2291 <> '' ) OR
        (VALIDACION_2292 <> '' ) OR
        (VALIDACION_2293 <> '' ) OR
        (VALIDACION_2294 <> '' ) OR
        (VALIDACION_2295 <> '' ) OR
        (VALIDACION_2296 <> '' ) OR
        (VALIDACION_2297 <> '' ) OR
        (VALIDACION_2298 <> '' ) OR
        (VALIDACION_2299 <> '' ) OR
        (VALIDACION_2300 <> '' ) 
ORDER BY 1
END

