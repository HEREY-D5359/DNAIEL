﻿
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapas 1 y 2 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15SALDOS*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/


CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0424_M15SALDOSTS1_VIEW_16]
AS
BEGIN
	SELECT *
		
	FROM IFRS9_R04A_0424_M15SALDOSTS1_RESULT_16
	WHERE

        (VALIDACION_1501 <> '' ) OR
        (VALIDACION_1502 <> '' ) OR
        (VALIDACION_1503 <> '' ) OR
        (VALIDACION_1504 <> '' ) OR
        (VALIDACION_1505 <> '' ) OR
        (VALIDACION_1506 <> '' ) OR
        (VALIDACION_1507 <> '' ) OR
        (VALIDACION_1508 <> '' ) OR
        (VALIDACION_1509 <> '' ) OR
        (VALIDACION_1510 <> '' ) OR
        (VALIDACION_1511 <> '' ) OR
        (VALIDACION_1512 <> '' ) OR
        (VALIDACION_1513 <> '' ) OR
        (VALIDACION_1514 <> '' ) OR
        (VALIDACION_1515 <> '' ) OR
        (VALIDACION_1516 <> '' ) OR
        (VALIDACION_1517 <> '' ) OR
        (VALIDACION_1518 <> '' ) OR
        (VALIDACION_1519 <> '' ) OR
        (VALIDACION_1520 <> '' ) OR
        (VALIDACION_1521 <> '' ) OR
        (VALIDACION_1522 <> '' ) OR
        (VALIDACION_1523 <> '' ) OR
        (VALIDACION_1524 <> '' ) OR
        (VALIDACION_1525 <> '' ) OR
        (VALIDACION_1526 <> '' ) OR
        (VALIDACION_1527 <> '' ) OR
        (VALIDACION_1528 <> '' ) OR
        (VALIDACION_1529 <> '' ) OR
        (VALIDACION_1530 <> '' ) OR
        (VALIDACION_1531 <> '' ) OR
        (VALIDACION_1532 <> '' ) OR
        (VALIDACION_1533 <> '' ) OR
        (VALIDACION_1534 <> '' ) OR
        (VALIDACION_1535 <> '' ) OR
        (VALIDACION_1536 <> '' ) OR
        (VALIDACION_1537 <> '' ) OR
        (VALIDACION_1538 <> '' ) OR
        (VALIDACION_1539 <> '' ) OR
        (VALIDACION_1540 <> '' ) OR
        (VALIDACION_1541 <> '' ) OR
        (VALIDACION_1542 <> '' ) OR
        (VALIDACION_1543 <> '' ) OR
        (VALIDACION_1544 <> '' ) OR
        (VALIDACION_1545 <> '' ) OR
        (VALIDACION_1546 <> '' ) OR
        (VALIDACION_1547 <> '' ) OR
        (VALIDACION_1548 <> '' ) OR
        (VALIDACION_1549 <> '' ) OR
        (VALIDACION_1550 <> '' ) OR
        (VALIDACION_1551 <> '' ) OR
        (VALIDACION_1552 <> '' ) OR
        (VALIDACION_1553 <> '' ) OR
        (VALIDACION_1554 <> '' ) OR
        (VALIDACION_1555 <> '' ) OR
        (VALIDACION_1556 <> '' ) OR
        (VALIDACION_1557 <> '' ) OR
        (VALIDACION_1558 <> '' ) OR
        (VALIDACION_1559 <> '' ) OR
        (VALIDACION_1560 <> '' ) OR
        (VALIDACION_1561 <> '' ) OR
        (VALIDACION_1562 <> '' ) OR
        (VALIDACION_1563 <> '' ) OR
        (VALIDACION_1564 <> '' ) OR
        (VALIDACION_1565 <> '' ) OR
        (VALIDACION_1566 <> '' ) OR
        (VALIDACION_1567 <> '' ) OR
        (VALIDACION_1568 <> '' ) OR
        (VALIDACION_1569 <> '' ) OR
        (VALIDACION_1570 <> '' ) OR
        (VALIDACION_1571 <> '' ) OR
        (VALIDACION_1572 <> '' ) OR
        (VALIDACION_1573 <> '' ) OR
        (VALIDACION_1574 <> '' ) OR
        (VALIDACION_1575 <> '' ) OR
        (VALIDACION_1576 <> '' ) OR
        (VALIDACION_1577 <> '' ) OR
        (VALIDACION_1578 <> '' ) OR
        (VALIDACION_1579 <> '' ) OR
        (VALIDACION_1580 <> '' ) OR
        (VALIDACION_1581 <> '' ) OR
        (VALIDACION_1582 <> '' ) OR
        (VALIDACION_1583 <> '' ) OR
        (VALIDACION_1584 <> '' ) OR
        (VALIDACION_1585 <> '' ) OR
        (VALIDACION_1586 <> '' ) OR
        (VALIDACION_1587 <> '' ) OR
        (VALIDACION_1588 <> '' ) OR
        (VALIDACION_1589 <> '' ) OR
        (VALIDACION_1590 <> '' ) OR
        (VALIDACION_1591 <> '' ) OR
        (VALIDACION_1592 <> '' ) OR
        (VALIDACION_1593 <> '' ) OR
        (VALIDACION_1594 <> '' ) OR
        (VALIDACION_1595 <> '' ) OR
        (VALIDACION_1596 <> '' ) OR
        (VALIDACION_1597 <> '' ) OR
        (VALIDACION_1598 <> '' ) OR
        (VALIDACION_1599 <> '' ) OR
        (VALIDACION_1600 <> '' ) 
ORDER BY 1
END

