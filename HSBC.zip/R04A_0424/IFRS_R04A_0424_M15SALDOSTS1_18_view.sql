﻿
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapas 1 y 2 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15SALDOS*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/


CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0424_M15SALDOSTS1_VIEW_18]
AS
BEGIN
	SELECT *
		
	FROM IFRS9_R04A_0424_M15SALDOSTS1_RESULT_18
	WHERE

        (VALIDACION_1701 <> '' ) OR
        (VALIDACION_1702 <> '' ) OR
        (VALIDACION_1703 <> '' ) OR
        (VALIDACION_1704 <> '' ) OR
        (VALIDACION_1705 <> '' ) OR
        (VALIDACION_1706 <> '' ) OR
        (VALIDACION_1707 <> '' ) OR
        (VALIDACION_1708 <> '' ) OR
        (VALIDACION_1709 <> '' ) OR
        (VALIDACION_1710 <> '' ) OR
        (VALIDACION_1711 <> '' ) OR
        (VALIDACION_1712 <> '' ) OR
        (VALIDACION_1713 <> '' ) OR
        (VALIDACION_1714 <> '' ) OR
        (VALIDACION_1715 <> '' ) OR
        (VALIDACION_1716 <> '' ) OR
        (VALIDACION_1717 <> '' ) OR
        (VALIDACION_1718 <> '' ) OR
        (VALIDACION_1719 <> '' ) OR
        (VALIDACION_1720 <> '' ) OR
        (VALIDACION_1721 <> '' ) OR
        (VALIDACION_1722 <> '' ) OR
        (VALIDACION_1723 <> '' ) OR
        (VALIDACION_1724 <> '' ) OR
        (VALIDACION_1725 <> '' ) OR
        (VALIDACION_1726 <> '' ) OR
        (VALIDACION_1727 <> '' ) OR
        (VALIDACION_1728 <> '' ) OR
        (VALIDACION_1729 <> '' ) OR
        (VALIDACION_1730 <> '' ) OR
        (VALIDACION_1731 <> '' ) OR
        (VALIDACION_1732 <> '' ) OR
        (VALIDACION_1733 <> '' ) OR
        (VALIDACION_1734 <> '' ) OR
        (VALIDACION_1735 <> '' ) OR
        (VALIDACION_1736 <> '' ) OR
        (VALIDACION_1737 <> '' ) OR
        (VALIDACION_1738 <> '' ) OR
        (VALIDACION_1739 <> '' ) OR
        (VALIDACION_1740 <> '' ) OR
        (VALIDACION_1741 <> '' ) OR
        (VALIDACION_1742 <> '' ) OR
        (VALIDACION_1743 <> '' ) OR
        (VALIDACION_1744 <> '' ) OR
        (VALIDACION_1745 <> '' ) OR
        (VALIDACION_1746 <> '' ) OR
        (VALIDACION_1747 <> '' ) OR
        (VALIDACION_1748 <> '' ) OR
        (VALIDACION_1749 <> '' ) OR
        (VALIDACION_1750 <> '' ) OR
        (VALIDACION_1751 <> '' ) OR
        (VALIDACION_1752 <> '' ) OR
        (VALIDACION_1753 <> '' ) OR
        (VALIDACION_1754 <> '' ) OR
        (VALIDACION_1755 <> '' ) OR
        (VALIDACION_1756 <> '' ) OR
        (VALIDACION_1757 <> '' ) OR
        (VALIDACION_1758 <> '' ) OR
        (VALIDACION_1759 <> '' ) OR
        (VALIDACION_1760 <> '' ) OR
        (VALIDACION_1761 <> '' ) OR
        (VALIDACION_1762 <> '' ) OR
        (VALIDACION_1763 <> '' ) OR
        (VALIDACION_1764 <> '' ) OR
        (VALIDACION_1765 <> '' ) OR
        (VALIDACION_1766 <> '' ) OR
        (VALIDACION_1767 <> '' ) OR
        (VALIDACION_1768 <> '' ) OR
        (VALIDACION_1769 <> '' ) OR
        (VALIDACION_1770 <> '' ) OR
        (VALIDACION_1771 <> '' ) OR
        (VALIDACION_1772 <> '' ) OR
        (VALIDACION_1773 <> '' ) OR
        (VALIDACION_1774 <> '' ) OR
        (VALIDACION_1775 <> '' ) OR
        (VALIDACION_1776 <> '' ) OR
        (VALIDACION_1777 <> '' ) OR
        (VALIDACION_1778 <> '' ) OR
        (VALIDACION_1779 <> '' ) OR
        (VALIDACION_1780 <> '' ) OR
        (VALIDACION_1781 <> '' ) OR
        (VALIDACION_1782 <> '' ) OR
        (VALIDACION_1783 <> '' ) OR
        (VALIDACION_1784 <> '' ) OR
        (VALIDACION_1785 <> '' ) OR
        (VALIDACION_1786 <> '' ) OR
        (VALIDACION_1787 <> '' ) OR
        (VALIDACION_1788 <> '' ) OR
        (VALIDACION_1789 <> '' ) OR
        (VALIDACION_1790 <> '' ) OR
        (VALIDACION_1791 <> '' ) OR
        (VALIDACION_1792 <> '' ) OR
        (VALIDACION_1793 <> '' ) OR
        (VALIDACION_1794 <> '' ) OR
        (VALIDACION_1795 <> '' ) OR
        (VALIDACION_1796 <> '' ) OR
        (VALIDACION_1797 <> '' ) OR
        (VALIDACION_1798 <> '' ) OR
        (VALIDACION_1799 <> '' ) OR
        (VALIDACION_1800 <> '' ) 
ORDER BY 1
END

