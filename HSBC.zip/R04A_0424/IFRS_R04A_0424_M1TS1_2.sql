﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapas 1 y 2 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 1*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0424_M1TS1_COMP_2]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0424_M1TS1_RESULT_2')
BEGIN
DROP TABLE IFRS9_R04A_0424_M1TS1_RESULT_2
END 

BEGIN
SELECT DISTINCT
         /*id*/
CONVERT(VARCHAR,ID) AS ID, 
	/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112009808110')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112011009131','112011009132')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112009808110) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112011009131 + 112011009132) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_101,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112009808111')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112011109133','112011109134','112011109135')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112009808111) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112011109133 + 112011109134 + 112011109135) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_102,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112009808112')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112011209136','112011209137')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112009808112) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112011209136 + 112011209137) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_103,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112003507099')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112009908118','112009908119')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112003507099) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112009908118 + 112009908119) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_104,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112009908118')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112011809138','112011809139','112011809140')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112009908118) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112011809138 + 112011809139 + 112011809140) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_105,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112009908119')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112011909141','112011909142','112011909143')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112009908119) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112011909141 + 112011909142 + 112011909143) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_106,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112003507100')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112010008120','112010008121','112010008122','112010008123')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112003507100) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112010008120 + 112010008121 + 112010008122 + 112010008123) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_107,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112010008121')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112012109144','112012109145','112012109146','112012109147','112012109148')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112010008121) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112012109144 + 112012109145 + 112012109146 + 112012109147 + 112012109148) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_108,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112010008122')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112012209149','112012209150','112012209151','112012209152')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112010008122) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112012209149 + 112012209150 + 112012209151 + 112012209152) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_109,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112010008123')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112012309153','112012309154','112012309155','112012309156')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112010008123) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112012309153 + 112012309154 + 112012309155 + 112012309156) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_110,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112001006036')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112003607101','112003607102','112003607103','112003607104','112003607105','112003607106','112003607107','112003607108')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112001006036) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112003607101 + 112003607102 + 112003607103 + 112003607104 + 112003607105 + 112003607106 + 112003607107 + 112003607108) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_111,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112001006037')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112003707109','112003707110','112003707111','112003707112','112003707113')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112001006037) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112003707109 + 112003707110 + 112003707111 + 112003707112 + 112003707113) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_112,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112003707111')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112011108124','112011108125')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112003707111) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112011108124 + 112011108125) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_113,

/*Traspaso de cartera de crédito valuada a valor razonable*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112000205011')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112001106038','112001106039','112001106040')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112000205011) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112001106038 + 112001106039 + 112001106040) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_114,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112001106038')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112003807114','112003807115','112003807116')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112001106038) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112003807114 + 112003807115 + 112003807116) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_115,

/*Salidas de cartera con riesgo de crédito etapa 1*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112000104003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112000305012','112000305013','112000305014','112000305015','112000305016','112000305017')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112000104003) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112000305012 + 112000305013 + 112000305014 + 112000305015 + 112000305016 + 112000305017) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_116,

/*Reestructuras y renovaciones (2)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112000305012')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112001206041','112001206042','112001206043')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112000305012) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112001206041 + 112001206042 + 112001206043) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_117,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112001206041')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112004107117','112004107118','112004107119')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112001206041) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112004107117 + 112004107118 + 112004107119) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_118,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112004107117')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112011708126','112011708127','112011708128','112011708129','112011708130','112011708131','112011708132','112011708133')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112004107117) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112011708126 + 112011708127 + 112011708128 + 112011708129 + 112011708130 + 112011708131 + 112011708132 + 112011708133) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_119,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112011708126')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112012609157','112012609158')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112011708126) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112012609157 + 112012609158) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_120,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112011708127')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112012709159','112012709160','112012709161')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112011708127) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112012709159 + 112012709160 + 112012709161) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_121,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112011708128')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112012809162','112012809163')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112011708128) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112012809162 + 112012809163) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_122,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112004107118')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112011808134','112011808135')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112004107118) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112011808134 + 112011808135) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_123,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112011808134')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112013409164','112013409165','112013409166')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112011808134) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112013409164 + 112013409165 + 112013409166) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_124,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112011808135')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112013509167','112013509168','112013509169')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112011808135) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112013509167 + 112013509168 + 112013509169) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_125,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112004107119')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112011908136','112011908137','112011908138','112011908139')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112004107119) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112011908136 + 112011908137 + 112011908138 + 112011908139) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_126,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112011908137')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112013709170','112013709171','112013709172','112013709173','112013709174')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112011908137) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112013709170 + 112013709171 + 112013709172 + 112013709173 + 112013709174) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_127,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112011908138')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112013809175','112013809176','112013809177','112013809178')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112011908138) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112013809175 + 112013809176 + 112013809177 + 112013809178) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_128,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112011908139')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112013909179','112013909180','112013909181','112013909182')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112011908139) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112013909179 + 112013909180 + 112013909181 + 112013909182) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_129,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112001206042')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112004207120','112004207121','112004207122','112004207123','112004207124','112004207125','112004207126','112004207127')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112001206042) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112004207120 + 112004207121 + 112004207122 + 112004207123 + 112004207124 + 112004207125 + 112004207126 + 112004207127) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_130,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112001206043')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112004307128','112004307129','112004307130','112004307131','112004307132')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112001206043) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112004307128 + 112004307129 + 112004307130 + 112004307131 + 112004307132) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_131,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112004307130')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112013008140','112013008141','112013008142')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112004307130) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112013008140 + 112013008141 + 112013008142) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_132,

/*Créditos liquidados (3)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112000305013')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112001306045','112001306046','112001306047','112001306048','112001306049')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112000305013) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112001306045 + 112001306046 + 112001306047 + 112001306048 + 112001306049) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_133,

/*Cobranza en efectivo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112001306045')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112004507133','112004507134','112004507135')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112001306045) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112004507133 + 112004507134 + 112004507135) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_134,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112004507133')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112013308143','112013308144','112013308145')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112004507133) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112013308143 + 112013308144 + 112013308145) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_135,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112013308143')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112014309183','112014309184','112014309185','112014309186','112014309187','112014309188','112014309189','112014309190')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112013308143) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112014309183 + 112014309184 + 112014309185 + 112014309186 + 112014309187 + 112014309188 + 112014309189 + 112014309190) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_136,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112014309183')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112018310001','112018310002')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112014309183) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112018310001 + 112018310002) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_137,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112014309184')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112018410003','112018410004','112018410005')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112014309184) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112018410003 + 112018410004 + 112018410005) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_138,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112014309185')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112018510006','112018510007')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112014309185) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112018510006 + 112018510007) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_139,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112013308144')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112014409191','112014409192')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112013308144) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112014409191 + 112014409192) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_140,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112014409191')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112019110008','112019110009','112019110010')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112014409191) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112019110008 + 112019110009 + 112019110010) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_141,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112014409192')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112019210011','112019210012','112019210013')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112014409192) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112019210011 + 112019210012 + 112019210013) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_142,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112013308145')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112014509193','112014509194','112014509195','112014509196')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112013308145) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112014509193 + 112014509194 + 112014509195 + 112014509196) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_143,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112014509194')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112019410014','112019410015','112019410016','112019410017','112019410018')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112014509194) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112019410014 + 112019410015 + 112019410016 + 112019410017 + 112019410018) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_144,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112014509195')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112019510019','112019510020','112019510021','112019510022')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112014509195) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112019510019 + 112019510020 + 112019510021 + 112019510022) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_145,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112014509196')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112019610023','112019610024','112019610025','112019610026')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112014509196) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112019610023 + 112019610024 + 112019610025 + 112019610026) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_146,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112004507134')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112013408146','112013408147','112013408148','112013408149','112013408150','112013408151','112013408152','112013408153')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112004507134) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112013408146 + 112013408147 + 112013408148 + 112013408149 + 112013408150 + 112013408151 + 112013408152 + 112013408153) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_147,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112004507135')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112013508154','112013508155','112013508156','112013508157','112013508158')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112004507135) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112013508154 + 112013508155 + 112013508156 + 112013508157 + 112013508158) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_148,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112013508156')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112015609197','112015609198','112015609199')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112013508156) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112015609197 + 112015609198 + 112015609199) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_149,

/*Cobranza en especie (4)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112001306046')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112004607137','112004607138','112004607139')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112001306046) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112004607137 + 112004607138 + 112004607139) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_150,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112004607137')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112013708159','112013708160','112013708161')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112004607137) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112013708159 + 112013708160 + 112013708161) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_151,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112013708159')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112015909200','112015909201','112015909202','112015909203','112015909204','112015909205','112015909206','112015909207')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112013708159) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112015909200 + 112015909201 + 112015909202 + 112015909203 + 112015909204 + 112015909205 + 112015909206 + 112015909207) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_152,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112015909200')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112020010027','112020010028')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112015909200) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112020010027 + 112020010028) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_153,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112015909201')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112020110029','112020110030','112020110031')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112015909201) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112020110029 + 112020110030 + 112020110031) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_154,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112015909202')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112020210032','112020210033')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112015909202) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112020210032 + 112020210033) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_155,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112013708160')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112016009208','112016009209')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112013708160) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112016009208 + 112016009209) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_156,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112016009208')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112020810034','112020810035','112020810036')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112016009208) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112020810034 + 112020810035 + 112020810036) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_157,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112016009209')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112020910037','112020910038','112020910039')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112016009209) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112020910037 + 112020910038 + 112020910039) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_158,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112013708161')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112016109210','112016109211','112016109212','112016109213')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112013708161) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112016109210 + 112016109211 + 112016109212 + 112016109213) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_159,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112016109211')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112021110040','112021110041','112021110042','112021110043','112021110044')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112016109211) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112021110040 + 112021110041 + 112021110042 + 112021110043 + 112021110044) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_160,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112016109212')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112021210045','112021210046','112021210047','112021210048')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112016109212) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112021210045 + 112021210046 + 112021210047 + 112021210048) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_161,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112016109213')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112021310049','112021310050','112021310051','112021310052')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112016109213) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112021310049 + 112021310050 + 112021310051 + 112021310052) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_162,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112004607138')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112013808162','112013808163','112013808164','112013808165','112013808166','112013808167','112013808168','112013808169')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112004607138) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112013808162 + 112013808163 + 112013808164 + 112013808165 + 112013808166 + 112013808167 + 112013808168 + 112013808169) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_163,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112004607139')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112013908170','112013908171','112013908172','112013908173','112013908174')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112004607139) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112013908170 + 112013908171 + 112013908172 + 112013908173 + 112013908174) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_164,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112013908172')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112017209214','112017209215','112017209216')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112013908172) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112017209214 + 112017209215 + 112017209216) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_165,

/*Capitalización de adeudos a favor del banco */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112001306047')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112004707141','112004707142','112004707143')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112001306047) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112004707141 + 112004707142 + 112004707143) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_166,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112004707141')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112014108175','112014108176','112014108177')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112004707141) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112014108175 + 112014108176 + 112014108177) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_167,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112014108175')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112017509217','112017509218','112017509219','112017509220','112017509221','112017509222','112017509223','112017509224')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112014108175) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112017509217 + 112017509218 + 112017509219 + 112017509220 + 112017509221 + 112017509222 + 112017509223 + 112017509224) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_168,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112017509217')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112021710053','112021710054')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112017509217) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112021710053 + 112021710054) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_169,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112017509218')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112021810055','112021810056','112021810057')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112017509218) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112021810055 + 112021810056 + 112021810057) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_170,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112017509219')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112021910058','112021910059')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112017509219) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112021910058 + 112021910059) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_171,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112014108176')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112017609225','112017609226')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112014108176) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112017609225 + 112017609226) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_172,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112017609225')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112022510060','112022510061','112022510062')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112017609225) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112022510060 + 112022510061 + 112022510062) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_173,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112017609226')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112022610063','112022610064','112022610065')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112017609226) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112022610063 + 112022610064 + 112022610065) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_174,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112014108177')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112017709227','112017709228','112017709229','112017709230')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112014108177) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112017709227 + 112017709228 + 112017709229 + 112017709230) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_175,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112017709228')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112022810066','112022810067','112022810068','112022810069','112022810070')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112017709228) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112022810066 + 112022810067 + 112022810068 + 112022810069 + 112022810070) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_176,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112017709229')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112022910071','112022910072','112022910073','112022910074')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112017709229) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112022910071 + 112022910072 + 112022910073 + 112022910074) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_177,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112017709230')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112023010075','112023010076','112023010077','112023010078')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112017709230) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112023010075 + 112023010076 + 112023010077 + 112023010078) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_178,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112004707142')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112014208178','112014208179','112014208180','112014208181','112014208182','112014208183','112014208184','112014208185')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112004707142) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112014208178 + 112014208179 + 112014208180 + 112014208181 + 112014208182 + 112014208183 + 112014208184 + 112014208185) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_179,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112004707143')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112014308186','112014308187','112014308188','112014308189','112014308190')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112004707143) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112014308186 + 112014308187 + 112014308188 + 112014308189 + 112014308190) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_180,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112014308188')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112018809231','112018809232','112018809233')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112014308188) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112018809231 + 112018809232 + 112018809233) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_181,

/*Castigos, quitas y condonaciones por (3)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112001306048')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112004807145','112004807146','112004807147')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112001306048) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112004807145 + 112004807146 + 112004807147) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_182,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112004807145')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112014508191','112014508192','112014508193')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112004807145) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112014508191 + 112014508192 + 112014508193) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_183,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112014508191')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112019109234','112019109235','112019109236','112019109237','112019109238','112019109239','112019109240','112019109241')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112014508191) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112019109234 + 112019109235 + 112019109236 + 112019109237 + 112019109238 + 112019109239 + 112019109240 + 112019109241) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_184,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112019109234')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112023410079','112023410080')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112019109234) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112023410079 + 112023410080) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_185,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112019109235')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112023510081','112023510082','112023510083')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112019109235) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112023510081 + 112023510082 + 112023510083) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_186,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112019109236')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112023610084','112023610085')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112019109236) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112023610084 + 112023610085) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_187,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112014508192')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112019209242','112019209243')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112014508192) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112019209242 + 112019209243) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_188,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112019209242')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112024210086','112024210087','112024210088')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112019209242) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112024210086 + 112024210087 + 112024210088) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_189,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112019209243')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112024310089','112024310090','112024310091')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112019209243) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112024310089 + 112024310090 + 112024310091) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_190,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112014508193')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112019309244','112019309245','112019309246','112019309247')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112014508193) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112019309244 + 112019309245 + 112019309246 + 112019309247) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_191,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112019309245')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112024510092','112024510093','112024510094','112024510095','112024510096')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112019309245) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112024510092 + 112024510093 + 112024510094 + 112024510095 + 112024510096) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_192,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112019309246')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112024610097','112024610098','112024610099','112024610100')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112019309246) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112024610097 + 112024610098 + 112024610099 + 112024610100) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_193,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112019309247')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112024710101','112024710102','112024710103','112024710104')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112019309247) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112024710101 + 112024710102 + 112024710103 + 112024710104) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_194,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112004807146')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112014608194','112014608195','112014608196','112014608197','112014608198','112014608199','112014608200','112014608201')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112004807146) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112014608194 + 112014608195 + 112014608196 + 112014608197 + 112014608198 + 112014608199 + 112014608200 + 112014608201) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_195,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112004807147')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112014708202','112014708203','112014708204','112014708205','112014708206')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112004807147) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112014708202 + 112014708203 + 112014708204 + 112014708205 + 112014708206) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_196,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112014708204')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112020409248','112020409249','112020409250')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112014708204) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112020409248 + 112020409249 + 112020409250) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_197,

/*Bonificaciones y descuentos sobre (3)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112001306049')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112004907149','112004907150','112004907151')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112001306049) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112004907149 + 112004907150 + 112004907151) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_198,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112004907149')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112014908207','112014908208','112014908209')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112004907149) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112014908207 + 112014908208 + 112014908209) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_199,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112014908207')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112020709251','112020709252','112020709253','112020709254','112020709255','112020709256','112020709257','112020709258')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112014908207) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112020709251 + 112020709252 + 112020709253 + 112020709254 + 112020709255 + 112020709256 + 112020709257 + 112020709258) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_200
	
INTO IFRS9_R04A_0424_M1TS1_RESULT_2
FROM IFRS9_R04A_0424

END

BEGIN
	INSERT INTO IFRS9_R04A_0424_M1TS1_RESULT_2 
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_101])),
            SUM(CHARINDEX('ERR',[VALIDACION_102])),
            SUM(CHARINDEX('ERR',[VALIDACION_103])),
            SUM(CHARINDEX('ERR',[VALIDACION_104])),
            SUM(CHARINDEX('ERR',[VALIDACION_105])),
            SUM(CHARINDEX('ERR',[VALIDACION_106])),
            SUM(CHARINDEX('ERR',[VALIDACION_107])),
            SUM(CHARINDEX('ERR',[VALIDACION_108])),
            SUM(CHARINDEX('ERR',[VALIDACION_109])),
            SUM(CHARINDEX('ERR',[VALIDACION_110])),
            SUM(CHARINDEX('ERR',[VALIDACION_111])),
            SUM(CHARINDEX('ERR',[VALIDACION_112])),
            SUM(CHARINDEX('ERR',[VALIDACION_113])),
            SUM(CHARINDEX('ERR',[VALIDACION_114])),
            SUM(CHARINDEX('ERR',[VALIDACION_115])),
            SUM(CHARINDEX('ERR',[VALIDACION_116])),
            SUM(CHARINDEX('ERR',[VALIDACION_117])),
            SUM(CHARINDEX('ERR',[VALIDACION_118])),
            SUM(CHARINDEX('ERR',[VALIDACION_119])),
            SUM(CHARINDEX('ERR',[VALIDACION_120])),
            SUM(CHARINDEX('ERR',[VALIDACION_121])),
            SUM(CHARINDEX('ERR',[VALIDACION_122])),
            SUM(CHARINDEX('ERR',[VALIDACION_123])),
            SUM(CHARINDEX('ERR',[VALIDACION_124])),
            SUM(CHARINDEX('ERR',[VALIDACION_125])),
            SUM(CHARINDEX('ERR',[VALIDACION_126])),
            SUM(CHARINDEX('ERR',[VALIDACION_127])),
            SUM(CHARINDEX('ERR',[VALIDACION_128])),
            SUM(CHARINDEX('ERR',[VALIDACION_129])),
            SUM(CHARINDEX('ERR',[VALIDACION_130])),
            SUM(CHARINDEX('ERR',[VALIDACION_131])),
            SUM(CHARINDEX('ERR',[VALIDACION_132])),
            SUM(CHARINDEX('ERR',[VALIDACION_133])),
            SUM(CHARINDEX('ERR',[VALIDACION_134])),
            SUM(CHARINDEX('ERR',[VALIDACION_135])),
            SUM(CHARINDEX('ERR',[VALIDACION_136])),
            SUM(CHARINDEX('ERR',[VALIDACION_137])),
            SUM(CHARINDEX('ERR',[VALIDACION_138])),
            SUM(CHARINDEX('ERR',[VALIDACION_139])),
            SUM(CHARINDEX('ERR',[VALIDACION_140])),
            SUM(CHARINDEX('ERR',[VALIDACION_141])),
            SUM(CHARINDEX('ERR',[VALIDACION_142])),
            SUM(CHARINDEX('ERR',[VALIDACION_143])),
            SUM(CHARINDEX('ERR',[VALIDACION_144])),
            SUM(CHARINDEX('ERR',[VALIDACION_145])),
            SUM(CHARINDEX('ERR',[VALIDACION_146])),
            SUM(CHARINDEX('ERR',[VALIDACION_147])),
            SUM(CHARINDEX('ERR',[VALIDACION_148])),
            SUM(CHARINDEX('ERR',[VALIDACION_149])),
            SUM(CHARINDEX('ERR',[VALIDACION_150])),
            SUM(CHARINDEX('ERR',[VALIDACION_151])),
            SUM(CHARINDEX('ERR',[VALIDACION_152])),
            SUM(CHARINDEX('ERR',[VALIDACION_153])),
            SUM(CHARINDEX('ERR',[VALIDACION_154])),
            SUM(CHARINDEX('ERR',[VALIDACION_155])),
            SUM(CHARINDEX('ERR',[VALIDACION_156])),
            SUM(CHARINDEX('ERR',[VALIDACION_157])),
            SUM(CHARINDEX('ERR',[VALIDACION_158])),
            SUM(CHARINDEX('ERR',[VALIDACION_159])),
            SUM(CHARINDEX('ERR',[VALIDACION_160])),
            SUM(CHARINDEX('ERR',[VALIDACION_161])),
            SUM(CHARINDEX('ERR',[VALIDACION_162])),
            SUM(CHARINDEX('ERR',[VALIDACION_163])),
            SUM(CHARINDEX('ERR',[VALIDACION_164])),
            SUM(CHARINDEX('ERR',[VALIDACION_165])),
            SUM(CHARINDEX('ERR',[VALIDACION_166])),
            SUM(CHARINDEX('ERR',[VALIDACION_167])),
            SUM(CHARINDEX('ERR',[VALIDACION_168])),
            SUM(CHARINDEX('ERR',[VALIDACION_169])),
            SUM(CHARINDEX('ERR',[VALIDACION_170])),
            SUM(CHARINDEX('ERR',[VALIDACION_171])),
            SUM(CHARINDEX('ERR',[VALIDACION_172])),
            SUM(CHARINDEX('ERR',[VALIDACION_173])),
            SUM(CHARINDEX('ERR',[VALIDACION_174])),
            SUM(CHARINDEX('ERR',[VALIDACION_175])),
            SUM(CHARINDEX('ERR',[VALIDACION_176])),
            SUM(CHARINDEX('ERR',[VALIDACION_177])),
            SUM(CHARINDEX('ERR',[VALIDACION_178])),
            SUM(CHARINDEX('ERR',[VALIDACION_179])),
            SUM(CHARINDEX('ERR',[VALIDACION_180])),
            SUM(CHARINDEX('ERR',[VALIDACION_181])),
            SUM(CHARINDEX('ERR',[VALIDACION_182])),
            SUM(CHARINDEX('ERR',[VALIDACION_183])),
            SUM(CHARINDEX('ERR',[VALIDACION_184])),
            SUM(CHARINDEX('ERR',[VALIDACION_185])),
            SUM(CHARINDEX('ERR',[VALIDACION_186])),
            SUM(CHARINDEX('ERR',[VALIDACION_187])),
            SUM(CHARINDEX('ERR',[VALIDACION_188])),
            SUM(CHARINDEX('ERR',[VALIDACION_189])),
            SUM(CHARINDEX('ERR',[VALIDACION_190])),
            SUM(CHARINDEX('ERR',[VALIDACION_191])),
            SUM(CHARINDEX('ERR',[VALIDACION_192])),
            SUM(CHARINDEX('ERR',[VALIDACION_193])),
            SUM(CHARINDEX('ERR',[VALIDACION_194])),
            SUM(CHARINDEX('ERR',[VALIDACION_195])),
            SUM(CHARINDEX('ERR',[VALIDACION_196])),
            SUM(CHARINDEX('ERR',[VALIDACION_197])),
            SUM(CHARINDEX('ERR',[VALIDACION_198])),
            SUM(CHARINDEX('ERR',[VALIDACION_199])),
            SUM(CHARINDEX('ERR',[VALIDACION_200]))
            


		FROM IFRS9_R04A_0424_M1TS1_RESULT_2 
END

BEGIN
	EXEC SP_IFRS9_R04A_0424_M1TS1_VIEW_2
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


