﻿
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapas 1 y 2 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15SALDOS*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/


CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0424_M15SALDOSTS1_VIEW_6]
AS
BEGIN
	SELECT *
		
	FROM IFRS9_R04A_0424_M15SALDOSTS1_RESULT_6
	WHERE

        (VALIDACION_501 <> '' ) OR
        (VALIDACION_502 <> '' ) OR
        (VALIDACION_503 <> '' ) OR
        (VALIDACION_504 <> '' ) OR
        (VALIDACION_505 <> '' ) OR
        (VALIDACION_506 <> '' ) OR
        (VALIDACION_507 <> '' ) OR
        (VALIDACION_508 <> '' ) OR
        (VALIDACION_509 <> '' ) OR
        (VALIDACION_510 <> '' ) OR
        (VALIDACION_511 <> '' ) OR
        (VALIDACION_512 <> '' ) OR
        (VALIDACION_513 <> '' ) OR
        (VALIDACION_514 <> '' ) OR
        (VALIDACION_515 <> '' ) OR
        (VALIDACION_516 <> '' ) OR
        (VALIDACION_517 <> '' ) OR
        (VALIDACION_518 <> '' ) OR
        (VALIDACION_519 <> '' ) OR
        (VALIDACION_520 <> '' ) OR
        (VALIDACION_521 <> '' ) OR
        (VALIDACION_522 <> '' ) OR
        (VALIDACION_523 <> '' ) OR
        (VALIDACION_524 <> '' ) OR
        (VALIDACION_525 <> '' ) OR
        (VALIDACION_526 <> '' ) OR
        (VALIDACION_527 <> '' ) OR
        (VALIDACION_528 <> '' ) OR
        (VALIDACION_529 <> '' ) OR
        (VALIDACION_530 <> '' ) OR
        (VALIDACION_531 <> '' ) OR
        (VALIDACION_532 <> '' ) OR
        (VALIDACION_533 <> '' ) OR
        (VALIDACION_534 <> '' ) OR
        (VALIDACION_535 <> '' ) OR
        (VALIDACION_536 <> '' ) OR
        (VALIDACION_537 <> '' ) OR
        (VALIDACION_538 <> '' ) OR
        (VALIDACION_539 <> '' ) OR
        (VALIDACION_540 <> '' ) OR
        (VALIDACION_541 <> '' ) OR
        (VALIDACION_542 <> '' ) OR
        (VALIDACION_543 <> '' ) OR
        (VALIDACION_544 <> '' ) OR
        (VALIDACION_545 <> '' ) OR
        (VALIDACION_546 <> '' ) OR
        (VALIDACION_547 <> '' ) OR
        (VALIDACION_548 <> '' ) OR
        (VALIDACION_549 <> '' ) OR
        (VALIDACION_550 <> '' ) OR
        (VALIDACION_551 <> '' ) OR
        (VALIDACION_552 <> '' ) OR
        (VALIDACION_553 <> '' ) OR
        (VALIDACION_554 <> '' ) OR
        (VALIDACION_555 <> '' ) OR
        (VALIDACION_556 <> '' ) OR
        (VALIDACION_557 <> '' ) OR
        (VALIDACION_558 <> '' ) OR
        (VALIDACION_559 <> '' ) OR
        (VALIDACION_560 <> '' ) OR
        (VALIDACION_561 <> '' ) OR
        (VALIDACION_562 <> '' ) OR
        (VALIDACION_563 <> '' ) OR
        (VALIDACION_564 <> '' ) OR
        (VALIDACION_565 <> '' ) OR
        (VALIDACION_566 <> '' ) OR
        (VALIDACION_567 <> '' ) OR
        (VALIDACION_568 <> '' ) OR
        (VALIDACION_569 <> '' ) OR
        (VALIDACION_570 <> '' ) OR
        (VALIDACION_571 <> '' ) OR
        (VALIDACION_572 <> '' ) OR
        (VALIDACION_573 <> '' ) OR
        (VALIDACION_574 <> '' ) OR
        (VALIDACION_575 <> '' ) OR
        (VALIDACION_576 <> '' ) OR
        (VALIDACION_577 <> '' ) OR
        (VALIDACION_578 <> '' ) OR
        (VALIDACION_579 <> '' ) OR
        (VALIDACION_580 <> '' ) OR
        (VALIDACION_581 <> '' ) OR
        (VALIDACION_582 <> '' ) OR
        (VALIDACION_583 <> '' ) OR
        (VALIDACION_584 <> '' ) OR
        (VALIDACION_585 <> '' ) OR
        (VALIDACION_586 <> '' ) OR
        (VALIDACION_587 <> '' ) OR
        (VALIDACION_588 <> '' ) OR
        (VALIDACION_589 <> '' ) OR
        (VALIDACION_590 <> '' ) OR
        (VALIDACION_591 <> '' ) OR
        (VALIDACION_592 <> '' ) OR
        (VALIDACION_593 <> '' ) OR
        (VALIDACION_594 <> '' ) OR
        (VALIDACION_595 <> '' ) OR
        (VALIDACION_596 <> '' ) OR
        (VALIDACION_597 <> '' ) OR
        (VALIDACION_598 <> '' ) OR
        (VALIDACION_599 <> '' ) OR
        (VALIDACION_600 <> '' ) 
ORDER BY 1
END

