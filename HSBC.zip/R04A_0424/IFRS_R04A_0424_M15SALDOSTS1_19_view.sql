﻿
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapas 1 y 2 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15SALDOS*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/


CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0424_M15SALDOSTS1_VIEW_19]
AS
BEGIN
	SELECT *
		
	FROM IFRS9_R04A_0424_M15SALDOSTS1_RESULT_19
	WHERE

        (VALIDACION_1801 <> '' ) OR
        (VALIDACION_1802 <> '' ) OR
        (VALIDACION_1803 <> '' ) OR
        (VALIDACION_1804 <> '' ) OR
        (VALIDACION_1805 <> '' ) OR
        (VALIDACION_1806 <> '' ) OR
        (VALIDACION_1807 <> '' ) OR
        (VALIDACION_1808 <> '' ) OR
        (VALIDACION_1809 <> '' ) OR
        (VALIDACION_1810 <> '' ) OR
        (VALIDACION_1811 <> '' ) OR
        (VALIDACION_1812 <> '' ) OR
        (VALIDACION_1813 <> '' ) OR
        (VALIDACION_1814 <> '' ) OR
        (VALIDACION_1815 <> '' ) OR
        (VALIDACION_1816 <> '' ) OR
        (VALIDACION_1817 <> '' ) OR
        (VALIDACION_1818 <> '' ) OR
        (VALIDACION_1819 <> '' ) OR
        (VALIDACION_1820 <> '' ) OR
        (VALIDACION_1821 <> '' ) OR
        (VALIDACION_1822 <> '' ) OR
        (VALIDACION_1823 <> '' ) OR
        (VALIDACION_1824 <> '' ) OR
        (VALIDACION_1825 <> '' ) OR
        (VALIDACION_1826 <> '' ) OR
        (VALIDACION_1827 <> '' ) OR
        (VALIDACION_1828 <> '' ) OR
        (VALIDACION_1829 <> '' ) OR
        (VALIDACION_1830 <> '' ) OR
        (VALIDACION_1831 <> '' ) OR
        (VALIDACION_1832 <> '' ) OR
        (VALIDACION_1833 <> '' ) OR
        (VALIDACION_1834 <> '' ) OR
        (VALIDACION_1835 <> '' ) OR
        (VALIDACION_1836 <> '' ) OR
        (VALIDACION_1837 <> '' ) OR
        (VALIDACION_1838 <> '' ) OR
        (VALIDACION_1839 <> '' ) OR
        (VALIDACION_1840 <> '' ) OR
        (VALIDACION_1841 <> '' ) OR
        (VALIDACION_1842 <> '' ) OR
        (VALIDACION_1843 <> '' ) OR
        (VALIDACION_1844 <> '' ) OR
        (VALIDACION_1845 <> '' ) OR
        (VALIDACION_1846 <> '' ) OR
        (VALIDACION_1847 <> '' ) OR
        (VALIDACION_1848 <> '' ) OR
        (VALIDACION_1849 <> '' ) OR
        (VALIDACION_1850 <> '' ) OR
        (VALIDACION_1851 <> '' ) OR
        (VALIDACION_1852 <> '' ) OR
        (VALIDACION_1853 <> '' ) OR
        (VALIDACION_1854 <> '' ) OR
        (VALIDACION_1855 <> '' ) OR
        (VALIDACION_1856 <> '' ) OR
        (VALIDACION_1857 <> '' ) OR
        (VALIDACION_1858 <> '' ) OR
        (VALIDACION_1859 <> '' ) OR
        (VALIDACION_1860 <> '' ) OR
        (VALIDACION_1861 <> '' ) OR
        (VALIDACION_1862 <> '' ) OR
        (VALIDACION_1863 <> '' ) OR
        (VALIDACION_1864 <> '' ) OR
        (VALIDACION_1865 <> '' ) OR
        (VALIDACION_1866 <> '' ) OR
        (VALIDACION_1867 <> '' ) OR
        (VALIDACION_1868 <> '' ) OR
        (VALIDACION_1869 <> '' ) OR
        (VALIDACION_1870 <> '' ) OR
        (VALIDACION_1871 <> '' ) OR
        (VALIDACION_1872 <> '' ) OR
        (VALIDACION_1873 <> '' ) OR
        (VALIDACION_1874 <> '' ) OR
        (VALIDACION_1875 <> '' ) OR
        (VALIDACION_1876 <> '' ) OR
        (VALIDACION_1877 <> '' ) OR
        (VALIDACION_1878 <> '' ) OR
        (VALIDACION_1879 <> '' ) OR
        (VALIDACION_1880 <> '' ) OR
        (VALIDACION_1881 <> '' ) OR
        (VALIDACION_1882 <> '' ) OR
        (VALIDACION_1883 <> '' ) OR
        (VALIDACION_1884 <> '' ) OR
        (VALIDACION_1885 <> '' ) OR
        (VALIDACION_1886 <> '' ) OR
        (VALIDACION_1887 <> '' ) OR
        (VALIDACION_1888 <> '' ) OR
        (VALIDACION_1889 <> '' ) OR
        (VALIDACION_1890 <> '' ) OR
        (VALIDACION_1891 <> '' ) OR
        (VALIDACION_1892 <> '' ) OR
        (VALIDACION_1893 <> '' ) OR
        (VALIDACION_1894 <> '' ) OR
        (VALIDACION_1895 <> '' ) OR
        (VALIDACION_1896 <> '' ) OR
        (VALIDACION_1897 <> '' ) OR
        (VALIDACION_1898 <> '' ) OR
        (VALIDACION_1899 <> '' ) OR
        (VALIDACION_1900 <> '' ) 
ORDER BY 1
END

