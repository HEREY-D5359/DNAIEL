﻿
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapas 1 y 2 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15SALDOS*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/


CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0424_M15SALDOSTS1_VIEW_14]
AS
BEGIN
	SELECT *
		
	FROM IFRS9_R04A_0424_M15SALDOSTS1_RESULT_14
	WHERE

        (VALIDACION_1301 <> '' ) OR
        (VALIDACION_1302 <> '' ) OR
        (VALIDACION_1303 <> '' ) OR
        (VALIDACION_1304 <> '' ) OR
        (VALIDACION_1305 <> '' ) OR
        (VALIDACION_1306 <> '' ) OR
        (VALIDACION_1307 <> '' ) OR
        (VALIDACION_1308 <> '' ) OR
        (VALIDACION_1309 <> '' ) OR
        (VALIDACION_1310 <> '' ) OR
        (VALIDACION_1311 <> '' ) OR
        (VALIDACION_1312 <> '' ) OR
        (VALIDACION_1313 <> '' ) OR
        (VALIDACION_1314 <> '' ) OR
        (VALIDACION_1315 <> '' ) OR
        (VALIDACION_1316 <> '' ) OR
        (VALIDACION_1317 <> '' ) OR
        (VALIDACION_1318 <> '' ) OR
        (VALIDACION_1319 <> '' ) OR
        (VALIDACION_1320 <> '' ) OR
        (VALIDACION_1321 <> '' ) OR
        (VALIDACION_1322 <> '' ) OR
        (VALIDACION_1323 <> '' ) OR
        (VALIDACION_1324 <> '' ) OR
        (VALIDACION_1325 <> '' ) OR
        (VALIDACION_1326 <> '' ) OR
        (VALIDACION_1327 <> '' ) OR
        (VALIDACION_1328 <> '' ) OR
        (VALIDACION_1329 <> '' ) OR
        (VALIDACION_1330 <> '' ) OR
        (VALIDACION_1331 <> '' ) OR
        (VALIDACION_1332 <> '' ) OR
        (VALIDACION_1333 <> '' ) OR
        (VALIDACION_1334 <> '' ) OR
        (VALIDACION_1335 <> '' ) OR
        (VALIDACION_1336 <> '' ) OR
        (VALIDACION_1337 <> '' ) OR
        (VALIDACION_1338 <> '' ) OR
        (VALIDACION_1339 <> '' ) OR
        (VALIDACION_1340 <> '' ) OR
        (VALIDACION_1341 <> '' ) OR
        (VALIDACION_1342 <> '' ) OR
        (VALIDACION_1343 <> '' ) OR
        (VALIDACION_1344 <> '' ) OR
        (VALIDACION_1345 <> '' ) OR
        (VALIDACION_1346 <> '' ) OR
        (VALIDACION_1347 <> '' ) OR
        (VALIDACION_1348 <> '' ) OR
        (VALIDACION_1349 <> '' ) OR
        (VALIDACION_1350 <> '' ) OR
        (VALIDACION_1351 <> '' ) OR
        (VALIDACION_1352 <> '' ) OR
        (VALIDACION_1353 <> '' ) OR
        (VALIDACION_1354 <> '' ) OR
        (VALIDACION_1355 <> '' ) OR
        (VALIDACION_1356 <> '' ) OR
        (VALIDACION_1357 <> '' ) OR
        (VALIDACION_1358 <> '' ) OR
        (VALIDACION_1359 <> '' ) OR
        (VALIDACION_1360 <> '' ) OR
        (VALIDACION_1361 <> '' ) OR
        (VALIDACION_1362 <> '' ) OR
        (VALIDACION_1363 <> '' ) OR
        (VALIDACION_1364 <> '' ) OR
        (VALIDACION_1365 <> '' ) OR
        (VALIDACION_1366 <> '' ) OR
        (VALIDACION_1367 <> '' ) OR
        (VALIDACION_1368 <> '' ) OR
        (VALIDACION_1369 <> '' ) OR
        (VALIDACION_1370 <> '' ) OR
        (VALIDACION_1371 <> '' ) OR
        (VALIDACION_1372 <> '' ) OR
        (VALIDACION_1373 <> '' ) OR
        (VALIDACION_1374 <> '' ) OR
        (VALIDACION_1375 <> '' ) OR
        (VALIDACION_1376 <> '' ) OR
        (VALIDACION_1377 <> '' ) OR
        (VALIDACION_1378 <> '' ) OR
        (VALIDACION_1379 <> '' ) OR
        (VALIDACION_1380 <> '' ) OR
        (VALIDACION_1381 <> '' ) OR
        (VALIDACION_1382 <> '' ) OR
        (VALIDACION_1383 <> '' ) OR
        (VALIDACION_1384 <> '' ) OR
        (VALIDACION_1385 <> '' ) OR
        (VALIDACION_1386 <> '' ) OR
        (VALIDACION_1387 <> '' ) OR
        (VALIDACION_1388 <> '' ) OR
        (VALIDACION_1389 <> '' ) OR
        (VALIDACION_1390 <> '' ) OR
        (VALIDACION_1391 <> '' ) OR
        (VALIDACION_1392 <> '' ) OR
        (VALIDACION_1393 <> '' ) OR
        (VALIDACION_1394 <> '' ) OR
        (VALIDACION_1395 <> '' ) OR
        (VALIDACION_1396 <> '' ) OR
        (VALIDACION_1397 <> '' ) OR
        (VALIDACION_1398 <> '' ) OR
        (VALIDACION_1399 <> '' ) OR
        (VALIDACION_1400 <> '' ) 
ORDER BY 1
END

