﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapas 1 y 2 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 1*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0424_M1TS1_COMP_7]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0424_M1TS1_RESULT_7')
BEGIN
DROP TABLE IFRS9_R04A_0424_M1TS1_RESULT_7
END 

BEGIN
SELECT DISTINCT

	/*ID*/

	CONVERT(VARCHAR,ID)  AS ID,   
	/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801907029')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111802908040','111802908041','111802908042','111802908043','111802908044')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111801907029) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111802908040 + 111802908041 + 111802908042 + 111802908043 + 111802908044) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_601,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801907030')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111803008045','111803008046','111803008047','111803008048')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111801907030) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111803008045 + 111803008046 + 111803008047 + 111803008048) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_602,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111801907031')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111803108049','111803108050','111803108051','111803108052')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111801907031) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111803108049 + 111803108050 + 111803108051 + 111803108052) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_603,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111800205006')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111800606020','111800606021','111800606022','111800606023','111800606024','111800606025','111800606026','111800606027')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111800205006) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111800606020 + 111800606021 + 111800606022 + 111800606023 + 111800606024 + 111800606025 + 111800606026 + 111800606027) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_604,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111800205007')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111800706028','111800706029','111800706030','111800706031')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111800205007) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111800706028 + 111800706029 + 111800706030 + 111800706031) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_605,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111800706030')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111803007032','111803007033')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111800706030) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111803007032 + 111803007033) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_606
	
INTO IFRS9_R04A_0424_M1TS1_RESULT_7
FROM IFRS9_R04A_0424

END

BEGIN
	INSERT INTO IFRS9_R04A_0424_M1TS1_RESULT_7 
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_601])),
            SUM(CHARINDEX('ERR',[VALIDACION_602])),
            SUM(CHARINDEX('ERR',[VALIDACION_603])),
            SUM(CHARINDEX('ERR',[VALIDACION_604])),
            SUM(CHARINDEX('ERR',[VALIDACION_605])),
            SUM(CHARINDEX('ERR',[VALIDACION_606])),
            SUM(CHARINDEX('ERR',[VALIDACION_607])),
            SUM(CHARINDEX('ERR',[VALIDACION_608])),
            SUM(CHARINDEX('ERR',[VALIDACION_609])),
            SUM(CHARINDEX('ERR',[VALIDACION_610])),
            SUM(CHARINDEX('ERR',[VALIDACION_611])),
            SUM(CHARINDEX('ERR',[VALIDACION_612])),
            SUM(CHARINDEX('ERR',[VALIDACION_613])),
            SUM(CHARINDEX('ERR',[VALIDACION_614])),
            SUM(CHARINDEX('ERR',[VALIDACION_615])),
            SUM(CHARINDEX('ERR',[VALIDACION_616])),
            SUM(CHARINDEX('ERR',[VALIDACION_617])),
            SUM(CHARINDEX('ERR',[VALIDACION_618])),
            SUM(CHARINDEX('ERR',[VALIDACION_619])),
            SUM(CHARINDEX('ERR',[VALIDACION_620])),
            SUM(CHARINDEX('ERR',[VALIDACION_621])),
            SUM(CHARINDEX('ERR',[VALIDACION_622])),
            SUM(CHARINDEX('ERR',[VALIDACION_623])),
            SUM(CHARINDEX('ERR',[VALIDACION_624])),
            SUM(CHARINDEX('ERR',[VALIDACION_625])),
            SUM(CHARINDEX('ERR',[VALIDACION_626])),
            SUM(CHARINDEX('ERR',[VALIDACION_627])),
            SUM(CHARINDEX('ERR',[VALIDACION_628])),
            SUM(CHARINDEX('ERR',[VALIDACION_629])),
            SUM(CHARINDEX('ERR',[VALIDACION_630])),
            SUM(CHARINDEX('ERR',[VALIDACION_631])),
            SUM(CHARINDEX('ERR',[VALIDACION_632])),
            SUM(CHARINDEX('ERR',[VALIDACION_633])),
            SUM(CHARINDEX('ERR',[VALIDACION_634])),
            SUM(CHARINDEX('ERR',[VALIDACION_635])),
            SUM(CHARINDEX('ERR',[VALIDACION_636])),
            SUM(CHARINDEX('ERR',[VALIDACION_637])),
            SUM(CHARINDEX('ERR',[VALIDACION_638])),
            SUM(CHARINDEX('ERR',[VALIDACION_639])),
            SUM(CHARINDEX('ERR',[VALIDACION_640])),
            SUM(CHARINDEX('ERR',[VALIDACION_641])),
            SUM(CHARINDEX('ERR',[VALIDACION_642])),
            SUM(CHARINDEX('ERR',[VALIDACION_643])),
            SUM(CHARINDEX('ERR',[VALIDACION_644])),
            SUM(CHARINDEX('ERR',[VALIDACION_645])),
            SUM(CHARINDEX('ERR',[VALIDACION_646])),
            SUM(CHARINDEX('ERR',[VALIDACION_647])),
            SUM(CHARINDEX('ERR',[VALIDACION_648])),
            SUM(CHARINDEX('ERR',[VALIDACION_649])),
            SUM(CHARINDEX('ERR',[VALIDACION_650])),
            SUM(CHARINDEX('ERR',[VALIDACION_651])),
            SUM(CHARINDEX('ERR',[VALIDACION_652])),
            SUM(CHARINDEX('ERR',[VALIDACION_653])),
            SUM(CHARINDEX('ERR',[VALIDACION_654])),
            SUM(CHARINDEX('ERR',[VALIDACION_655])),
            SUM(CHARINDEX('ERR',[VALIDACION_656])),
            SUM(CHARINDEX('ERR',[VALIDACION_657])),
            SUM(CHARINDEX('ERR',[VALIDACION_658])),
            SUM(CHARINDEX('ERR',[VALIDACION_659])),
            SUM(CHARINDEX('ERR',[VALIDACION_660])),
            SUM(CHARINDEX('ERR',[VALIDACION_661])),
            SUM(CHARINDEX('ERR',[VALIDACION_662])),
            SUM(CHARINDEX('ERR',[VALIDACION_663])),
            SUM(CHARINDEX('ERR',[VALIDACION_664])),
            SUM(CHARINDEX('ERR',[VALIDACION_665])),
            SUM(CHARINDEX('ERR',[VALIDACION_666])),
            SUM(CHARINDEX('ERR',[VALIDACION_667])),
            SUM(CHARINDEX('ERR',[VALIDACION_668])),
            SUM(CHARINDEX('ERR',[VALIDACION_669])),
            SUM(CHARINDEX('ERR',[VALIDACION_670])),
            SUM(CHARINDEX('ERR',[VALIDACION_671])),
            SUM(CHARINDEX('ERR',[VALIDACION_672])),
            SUM(CHARINDEX('ERR',[VALIDACION_673])),
            SUM(CHARINDEX('ERR',[VALIDACION_674])),
            SUM(CHARINDEX('ERR',[VALIDACION_675])),
            SUM(CHARINDEX('ERR',[VALIDACION_676])),
            SUM(CHARINDEX('ERR',[VALIDACION_677])),
            SUM(CHARINDEX('ERR',[VALIDACION_678])),
            SUM(CHARINDEX('ERR',[VALIDACION_679])),
            SUM(CHARINDEX('ERR',[VALIDACION_680])),
            SUM(CHARINDEX('ERR',[VALIDACION_681])),
            SUM(CHARINDEX('ERR',[VALIDACION_682])),
            SUM(CHARINDEX('ERR',[VALIDACION_683])),
            SUM(CHARINDEX('ERR',[VALIDACION_684])),
            SUM(CHARINDEX('ERR',[VALIDACION_685])),
            SUM(CHARINDEX('ERR',[VALIDACION_686])),
            SUM(CHARINDEX('ERR',[VALIDACION_687])),
            SUM(CHARINDEX('ERR',[VALIDACION_688])),
            SUM(CHARINDEX('ERR',[VALIDACION_689])),
            SUM(CHARINDEX('ERR',[VALIDACION_690])),
            SUM(CHARINDEX('ERR',[VALIDACION_691])),
            SUM(CHARINDEX('ERR',[VALIDACION_692])),
            SUM(CHARINDEX('ERR',[VALIDACION_693])),
            SUM(CHARINDEX('ERR',[VALIDACION_694])),
            SUM(CHARINDEX('ERR',[VALIDACION_695])),
            SUM(CHARINDEX('ERR',[VALIDACION_696])),
            SUM(CHARINDEX('ERR',[VALIDACION_697])),
            SUM(CHARINDEX('ERR',[VALIDACION_698])),
            SUM(CHARINDEX('ERR',[VALIDACION_699])),
            SUM(CHARINDEX('ERR',[VALIDACION_700]))
            


		FROM IFRS9_R04A_0424_M1TS1_RESULT_7 
END

BEGIN
	EXEC SP_IFRS9_R04A_0424_M1TS1_VIEW_7
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


