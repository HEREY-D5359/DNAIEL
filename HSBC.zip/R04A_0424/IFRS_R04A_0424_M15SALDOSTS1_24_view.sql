﻿
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapas 1 y 2 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15SALDOS*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/


CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0424_M15SALDOSTS1_VIEW_24]
AS
BEGIN
	SELECT *
		
	FROM IFRS9_R04A_0424_M15SALDOSTS1_RESULT_24
	WHERE

        (VALIDACION_2301 <> '' ) OR
        (VALIDACION_2302 <> '' ) OR
        (VALIDACION_2303 <> '' ) OR
        (VALIDACION_2304 <> '' ) OR
        (VALIDACION_2305 <> '' ) OR
        (VALIDACION_2306 <> '' ) OR
        (VALIDACION_2307 <> '' ) OR
        (VALIDACION_2308 <> '' ) OR
        (VALIDACION_2309 <> '' ) OR
        (VALIDACION_2310 <> '' ) OR
        (VALIDACION_2311 <> '' ) OR
        (VALIDACION_2312 <> '' ) OR
        (VALIDACION_2313 <> '' ) OR
        (VALIDACION_2314 <> '' ) OR
        (VALIDACION_2315 <> '' ) OR
        (VALIDACION_2316 <> '' ) OR
        (VALIDACION_2317 <> '' ) OR
        (VALIDACION_2318 <> '' ) OR
        (VALIDACION_2319 <> '' ) OR
        (VALIDACION_2320 <> '' ) OR
        (VALIDACION_2321 <> '' ) OR
        (VALIDACION_2322 <> '' ) OR
        (VALIDACION_2323 <> '' ) OR
        (VALIDACION_2324 <> '' ) OR
        (VALIDACION_2325 <> '' ) OR
        (VALIDACION_2326 <> '' ) OR
        (VALIDACION_2327 <> '' ) OR
        (VALIDACION_2328 <> '' ) OR
        (VALIDACION_2329 <> '' ) OR
        (VALIDACION_2330 <> '' ) OR
        (VALIDACION_2331 <> '' ) OR
        (VALIDACION_2332 <> '' ) OR
        (VALIDACION_2333 <> '' ) OR
        (VALIDACION_2334 <> '' ) OR
        (VALIDACION_2335 <> '' ) OR
        (VALIDACION_2336 <> '' ) OR
        (VALIDACION_2337 <> '' ) OR
        (VALIDACION_2338 <> '' ) OR
        (VALIDACION_2339 <> '' ) OR
        (VALIDACION_2340 <> '' ) OR
        (VALIDACION_2341 <> '' ) OR
        (VALIDACION_2342 <> '' ) OR
        (VALIDACION_2343 <> '' ) OR
        (VALIDACION_2344 <> '' ) 
ORDER BY 1
END

