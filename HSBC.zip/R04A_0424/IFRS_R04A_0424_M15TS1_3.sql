﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapas 1 y 2 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0424_M15TS1_COMP_3]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0424_M15TS1_RESULT_3')
BEGIN
DROP TABLE IFRS9_R04A_0424_M15TS1_RESULT_3
END 

BEGIN
SELECT DISTINCT
         /*id*/
CONVERT(VARCHAR,ID) AS ID, 
	/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112020709251')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112025110105','112025110106')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112020709251) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112025110105 + 112025110106) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_201,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112020709252')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112025210107','112025210108','112025210109')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112020709252) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112025210107 + 112025210108 + 112025210109) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_202,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112020709253')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112025310110','112025310111')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112020709253) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112025310110 + 112025310111) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_203,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112014908208')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112020809259','112020809260')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112014908208) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112020809259 + 112020809260) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_204,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112020809259')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112025910112','112025910113','112025910114')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112020809259) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112025910112 + 112025910113 + 112025910114) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_205,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112020809260')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112026010115','112026010116','112026010117')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112020809260) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112026010115 + 112026010116 + 112026010117) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_206,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112014908209')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112020909261','112020909262','112020909263','112020909264')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112014908209) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112020909261 + 112020909262 + 112020909263 + 112020909264) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_207,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112020909262')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112026210118','112026210119','112026210120','112026210121','112026210122')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112020909262) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112026210118 + 112026210119 + 112026210120 + 112026210121 + 112026210122) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_208,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112020909263')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112026310123','112026310124','112026310125','112026310126')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112020909263) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112026310123 + 112026310124 + 112026310125 + 112026310126) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_209,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112020909264')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112026410127','112026410128','112026410129','112026410130')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112020909264) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112026410127 + 112026410128 + 112026410129 + 112026410130) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_210,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112004907150')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112015008210','112015008211','112015008212','112015008213','112015008214','112015008215','112015008216','112015008217')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112004907150) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112015008210 + 112015008211 + 112015008212 + 112015008213 + 112015008214 + 112015008215 + 112015008216 + 112015008217) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_211,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112004907151')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112015108218','112015108219','112015108220','112015108221','112015108222')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112004907151) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112015108218 + 112015108219 + 112015108220 + 112015108221 + 112015108222) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_212,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112015108220')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112022009265','112022009266','112022009267')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112015108220) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112022009265 + 112022009266 + 112022009267) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_213,

/*Ventas de cartera (5)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112000305014')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112001406050','112001406051','112001406052')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112000305014) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112001406050 + 112001406051 + 112001406052) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_214,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112001406050')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112005007153','112005007154','112005007155')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112001406050) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112005007153 + 112005007154 + 112005007155) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_215,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112005007153')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112015308223','112015308224','112015308225','112015308226','112015308227','112015308228','112015308229','112015308230')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112005007153) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112015308223 + 112015308224 + 112015308225 + 112015308226 + 112015308227 + 112015308228 + 112015308229 + 112015308230) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_216,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112015308223')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112022309268','112022309269')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112015308223) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112022309268 + 112022309269) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_217,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112015308224')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112022409270','112022409271','112022409272')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112015308224) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112022409270 + 112022409271 + 112022409272) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_218,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112015308225')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112022509273','112022509274')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112015308225) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112022509273 + 112022509274) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_219,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112005007154')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112015408231','112015408232')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112005007154) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112015408231 + 112015408232) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_220,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112015408231')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112023109275','112023109276','112023109277')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112015408231) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112023109275 + 112023109276 + 112023109277) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_221,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112015408232')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112023209278','112023209279','112023209280')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112015408232) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112023209278 + 112023209279 + 112023209280) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_222,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112005007155')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112015508233','112015508234','112015508235','112015508236')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112005007155) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112015508233 + 112015508234 + 112015508235 + 112015508236) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_223,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112015508234')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112023409281','112023409282','112023409283','112023409284','112023409285')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112015508234) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112023409281 + 112023409282 + 112023409283 + 112023409284 + 112023409285) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_224,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112015508235')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112023509286','112023509287','112023509288','112023509289')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112015508235) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112023509286 + 112023509287 + 112023509288 + 112023509289) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_225,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112015508236')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112023609290','112023609291','112023609292','112023609293')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112015508236) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112023609290 + 112023609291 + 112023609292 + 112023609293) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_226,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112001406051')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112005107156','112005107157','112005107158','112005107159','112005107160','112005107161','112005107162','112005107163')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112001406051) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112005107156 + 112005107157 + 112005107158 + 112005107159 + 112005107160 + 112005107161 + 112005107162 + 112005107163) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_227,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112001406052')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112005207164','112005207165','112005207166','112005207167','112005207168')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112001406052) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112005207164 + 112005207165 + 112005207166 + 112005207167 + 112005207168) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_228,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112005207166')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112016608237','112016608238','112016608239')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112005207166) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112016608237 + 112016608238 + 112016608239) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_229,

/*Traspaso a cartera con riesgo de crédito etapa 2*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112000305015')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112001506054','112001506055','112001506056')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112000305015) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112001506054 + 112001506055 + 112001506056) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_230,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112001506054')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112005407169','112005407170','112005407171')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112001506054) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112005407169 + 112005407170 + 112005407171) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_231,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112005407169')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112016908240','112016908241','112016908242','112016908243','112016908244','112016908245','112016908246','112016908247')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112005407169) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112016908240 + 112016908241 + 112016908242 + 112016908243 + 112016908244 + 112016908245 + 112016908246 + 112016908247) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_232,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112016908240')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112024009294','112024009295')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112016908240) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112024009294 + 112024009295) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_233,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112016908241')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112024109296','112024109297','112024109298')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112016908241) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112024109296 + 112024109297 + 112024109298) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_234,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112016908242')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112024209299','112024209300')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112016908242) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112024209299 + 112024209300) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_235,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112005407170')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112017008248','112017008249')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112005407170) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112017008248 + 112017008249) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_236,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112017008248')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112024809301','112024809302','112024809303')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112017008248) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112024809301 + 112024809302 + 112024809303) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_237,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112017008249')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112024909304','112024909305','112024909306')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112017008249) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112024909304 + 112024909305 + 112024909306) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_238,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112005407171')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112017108250','112017108251','112017108252','112017108253')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112005407171) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112017108250 + 112017108251 + 112017108252 + 112017108253) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_239,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112017108251')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112025109307','112025109308','112025109309','112025109310','112025109311')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112017108251) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112025109307 + 112025109308 + 112025109309 + 112025109310 + 112025109311) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_240,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112017108252')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112025209312','112025209313','112025209314','112025209315')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112017108252) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112025209312 + 112025209313 + 112025209314 + 112025209315) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_241,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112017108253')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112025309316','112025309317','112025309318','112025309319')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112017108253) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112025309316 + 112025309317 + 112025309318 + 112025309319) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_242,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112001506055')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112005507172','112005507173','112005507174','112005507175','112005507176','112005507177','112005507178','112005507179')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112001506055) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112005507172 + 112005507173 + 112005507174 + 112005507175 + 112005507176 + 112005507177 + 112005507178 + 112005507179) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_243,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112001506056')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112005607180','112005607181','112005607182','112005607183','112005607184')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112001506056) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112005607180 + 112005607181 + 112005607182 + 112005607183 + 112005607184) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_244,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112005607182')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112018208254','112018208255')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112005607182) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112018208254 + 112018208255) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_245,

/*Traspaso a cartera con riesgo de crédito etapa 3*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112000305016')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112001606057','112001606058','112001606059')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112000305016) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112001606057 + 112001606058 + 112001606059) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_246,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112001606057')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112005707185','112005707186','112005707187')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112001606057) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112005707185 + 112005707186 + 112005707187) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_247,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112005707185')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112018508256','112018508257','112018508258','112018508259','112018508260','112018508261','112018508262','112018508263')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112005707185) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112018508256 + 112018508257 + 112018508258 + 112018508259 + 112018508260 + 112018508261 + 112018508262 + 112018508263) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_248,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112018508256')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112025609320','112025609321')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112018508256) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112025609320 + 112025609321) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_249,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112018508257')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112025709322','112025709323','112025709324')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112018508257) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112025709322 + 112025709323 + 112025709324) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_250,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112018508258')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112025809325','112025809326')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112018508258) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112025809325 + 112025809326) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_251,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112005707186')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112018608264','112018608265')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112005707186) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112018608264 + 112018608265) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_252,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112018608264')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112026409327','112026409328','112026409329')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112018608264) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112026409327 + 112026409328 + 112026409329) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_253,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112018608265')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112026509330','112026509331','112026509332')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112018608265) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112026509330 + 112026509331 + 112026509332) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_254,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112005707187')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112018708266','112018708267','112018708268','112018708269')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112005707187) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112018708266 + 112018708267 + 112018708268 + 112018708269) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_255,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112018708267')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112026709333','112026709334','112026709335','112026709336','112026709337')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112018708267) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112026709333 + 112026709334 + 112026709335 + 112026709336 + 112026709337) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_256,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112018708268')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112026809338','112026809339','112026809340','112026809341')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112018708268) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112026809338 + 112026809339 + 112026809340 + 112026809341) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_257,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112018708269')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112026909342','112026909343','112026909344','112026909345')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112018708269) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112026909342 + 112026909343 + 112026909344 + 112026909345) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_258,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112001606058')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112005807188','112005807189','112005807190','112005807191','112005807192','112005807193','112005807194','112005807195')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112001606058) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112005807188 + 112005807189 + 112005807190 + 112005807191 + 112005807192 + 112005807193 + 112005807194 + 112005807195) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_259,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112001606059')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112005907196','112005907197','112005907198','112005907199','112005907200')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112001606059) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112005907196 + 112005907197 + 112005907198 + 112005907199 + 112005907200) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_260,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112005907198')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112019808270','112019808271')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112005907198) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112019808270 + 112019808271) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_261,

/*Traspaso a cartera de crédito valuada a valor razonable*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112000305017')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112001706060','112001706061','112001706062')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112000305017) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112001706060 + 112001706061 + 112001706062) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_262,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112001706060')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112006007201','112006007202','112006007203')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112001706060) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112006007201 + 112006007202 + 112006007203) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_263,

/*Ajuste cambiario etapa 1*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112000104004')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112000405018','112000405019','112000405020')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112000104004) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112000405018 + 112000405019 + 112000405020) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_264,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112000405018')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112001806063','112001806064','112001806065')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112000405018) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112001806063 + 112001806064 + 112001806065) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_265,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112001806063')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112006307204','112006307205','112006307206','112006307207','112006307208','112006307209','112006307210','112006307211')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112001806063) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112006307204 + 112006307205 + 112006307206 + 112006307207 + 112006307208 + 112006307209 + 112006307210 + 112006307211) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_266,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112006307204')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112020408272','112020408273')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112006307204) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112020408272 + 112020408273) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_267,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112006307205')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112020508274','112020508275','112020508276')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112006307205) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112020508274 + 112020508275 + 112020508276) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_268,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112006307206')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112020608277','112020608278')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112006307206) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112020608277 + 112020608278) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_269,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112001806064')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112006407212','112006407213')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112001806064) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112006407212 + 112006407213) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_270,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112006407212')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112021208279','112021208280','112021208281')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112006407212) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112021208279 + 112021208280 + 112021208281) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_271,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112006407213')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112021308282','112021308283','112021308284')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112006407213) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112021308282 + 112021308283 + 112021308284) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_272,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112001806065')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112006507214','112006507215','112006507216','112006507217')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112001806065) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112006507214 + 112006507215 + 112006507216 + 112006507217) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_273,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112006507215')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112021508285','112021508286','112021508287','112021508288','112021508289')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112006507215) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112021508285 + 112021508286 + 112021508287 + 112021508288 + 112021508289) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_274,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112006507216')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112021608290','112021608291','112021608292','112021608293')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112006507216) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112021608290 + 112021608291 + 112021608292 + 112021608293) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_275,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112006507217')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112021708294','112021708295','112021708296','112021708297')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112006507217) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112021708294 + 112021708295 + 112021708296 + 112021708297) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_276,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112000405019')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112001906066','112001906067','112001906068','112001906069','112001906070','112001906071','112001906072','112001906073')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112000405019) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112001906066 + 112001906067 + 112001906068 + 112001906069 + 112001906070 + 112001906071 + 112001906072 + 112001906073) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_277,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112000405020')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112002006074','112002006075','112002006076','112002006077','112002006078')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112000405020) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112002006074 + 112002006075 + 112002006076 + 112002006077 + 112002006078) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_278,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112002006076')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112007607218','112007607219','112007607220')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112002006076) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112007607218 + 112007607219 + 112007607220) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_279,

/*Capitalización de Intereses etapa 1*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112000104005')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112000505022','112000505023','112000505024')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112000104005) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112000505022 + 112000505023 + 112000505024) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_280,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112000505022')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112002206079','112002206080','112002206081')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112000505022) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112002206079 + 112002206080 + 112002206081) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_281,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112002206079')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112007907221','112007907222','112007907223','112007907224','112007907225','112007907226','112007907227','112007907228')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112002206079) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112007907221 + 112007907222 + 112007907223 + 112007907224 + 112007907225 + 112007907226 + 112007907227 + 112007907228) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_282,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112007907221')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112022108298','112022108299')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112007907221) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112022108298 + 112022108299) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_283,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112007907222')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112022208300','112022208301','112022208302')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112007907222) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112022208300 + 112022208301 + 112022208302) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_284,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112007907223')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112022308303','112022308304')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112007907223) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112022308303 + 112022308304) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_285,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112002206080')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112008007229','112008007230')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112002206080) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112008007229 + 112008007230) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_286,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112008007229')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112022908305','112022908306','112022908307')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112008007229) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112022908305 + 112022908306 + 112022908307) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_287,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112008007230')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112023008308','112023008309','112023008310')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112008007230) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112023008308 + 112023008309 + 112023008310) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_288,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112002206081')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112008107231','112008107232','112008107233','112008107234')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112002206081) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112008107231 + 112008107232 + 112008107233 + 112008107234) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_289,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112008107232')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112023208311','112023208312','112023208313','112023208314','112023208315')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112008107232) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112023208311 + 112023208312 + 112023208313 + 112023208314 + 112023208315) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_290,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112008107233')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112023308316','112023308317','112023308318','112023308319')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112008107233) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112023308316 + 112023308317 + 112023308318 + 112023308319) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_291,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112008107234')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112023408320','112023408321','112023408322','112023408323')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112008107234) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112023408320 + 112023408321 + 112023408322 + 112023408323) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_292,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112000505023')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112002306082','112002306083','112002306084','112002306085','112002306086','112002306087','112002306088','112002306089')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112000505023) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112002306082 + 112002306083 + 112002306084 + 112002306085 + 112002306086 + 112002306087 + 112002306088 + 112002306089) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_293,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112000505024')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112002406090','112002406091','112002406092','112002406093','112002406094')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112000505024) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112002406090 + 112002406091 + 112002406092 + 112002406093 + 112002406094) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_294,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112002406092')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112009207235','112009207236','112009207237')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112002406092) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112009207235 + 112009207236 + 112009207237) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_295,

/*Saldo final de cartera con riesgo de crédito etapa 1*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('101800104001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111800105001','111800105002','111800105003')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800104001) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111800105001 + 111800105002 + 111800105003) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_296,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111800105001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111800106001','111800106002','111800106003')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111800105001) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111800106001 + 111800106002 + 111800106003) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_297,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111800106001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111800107001','111800107002','111800107003','111800107004','111800107005','111800107006','111800107007','111800107008')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111800106001) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111800107001 + 111800107002 + 111800107003 + 111800107004 + 111800107005 + 111800107006 + 111800107007 + 111800107008) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_298,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111800107001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111800108001','111800108002')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111800107001) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111800108001 + 111800108002) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_299,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('111800107002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('111800208003','111800208004','111800208005')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('15')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111800107002) con Moneda 15, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (111800208003 + 111800208004 + 111800208005) con Moneda 15, Tipo de Saldo 1.')    
AS VALIDACION_300
	
INTO IFRS9_R04A_0424_M15TS1_RESULT_3
FROM IFRS9_R04A_0424

END

BEGIN
	INSERT INTO IFRS9_R04A_0424_M15TS1_RESULT_3 
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_201])),
            SUM(CHARINDEX('ERR',[VALIDACION_202])),
            SUM(CHARINDEX('ERR',[VALIDACION_203])),
            SUM(CHARINDEX('ERR',[VALIDACION_204])),
            SUM(CHARINDEX('ERR',[VALIDACION_205])),
            SUM(CHARINDEX('ERR',[VALIDACION_206])),
            SUM(CHARINDEX('ERR',[VALIDACION_207])),
            SUM(CHARINDEX('ERR',[VALIDACION_208])),
            SUM(CHARINDEX('ERR',[VALIDACION_209])),
            SUM(CHARINDEX('ERR',[VALIDACION_210])),
            SUM(CHARINDEX('ERR',[VALIDACION_211])),
            SUM(CHARINDEX('ERR',[VALIDACION_212])),
            SUM(CHARINDEX('ERR',[VALIDACION_213])),
            SUM(CHARINDEX('ERR',[VALIDACION_214])),
            SUM(CHARINDEX('ERR',[VALIDACION_215])),
            SUM(CHARINDEX('ERR',[VALIDACION_216])),
            SUM(CHARINDEX('ERR',[VALIDACION_217])),
            SUM(CHARINDEX('ERR',[VALIDACION_218])),
            SUM(CHARINDEX('ERR',[VALIDACION_219])),
            SUM(CHARINDEX('ERR',[VALIDACION_220])),
            SUM(CHARINDEX('ERR',[VALIDACION_221])),
            SUM(CHARINDEX('ERR',[VALIDACION_222])),
            SUM(CHARINDEX('ERR',[VALIDACION_223])),
            SUM(CHARINDEX('ERR',[VALIDACION_224])),
            SUM(CHARINDEX('ERR',[VALIDACION_225])),
            SUM(CHARINDEX('ERR',[VALIDACION_226])),
            SUM(CHARINDEX('ERR',[VALIDACION_227])),
            SUM(CHARINDEX('ERR',[VALIDACION_228])),
            SUM(CHARINDEX('ERR',[VALIDACION_229])),
            SUM(CHARINDEX('ERR',[VALIDACION_230])),
            SUM(CHARINDEX('ERR',[VALIDACION_231])),
            SUM(CHARINDEX('ERR',[VALIDACION_232])),
            SUM(CHARINDEX('ERR',[VALIDACION_233])),
            SUM(CHARINDEX('ERR',[VALIDACION_234])),
            SUM(CHARINDEX('ERR',[VALIDACION_235])),
            SUM(CHARINDEX('ERR',[VALIDACION_236])),
            SUM(CHARINDEX('ERR',[VALIDACION_237])),
            SUM(CHARINDEX('ERR',[VALIDACION_238])),
            SUM(CHARINDEX('ERR',[VALIDACION_239])),
            SUM(CHARINDEX('ERR',[VALIDACION_240])),
            SUM(CHARINDEX('ERR',[VALIDACION_241])),
            SUM(CHARINDEX('ERR',[VALIDACION_242])),
            SUM(CHARINDEX('ERR',[VALIDACION_243])),
            SUM(CHARINDEX('ERR',[VALIDACION_244])),
            SUM(CHARINDEX('ERR',[VALIDACION_245])),
            SUM(CHARINDEX('ERR',[VALIDACION_246])),
            SUM(CHARINDEX('ERR',[VALIDACION_247])),
            SUM(CHARINDEX('ERR',[VALIDACION_248])),
            SUM(CHARINDEX('ERR',[VALIDACION_249])),
            SUM(CHARINDEX('ERR',[VALIDACION_250])),
            SUM(CHARINDEX('ERR',[VALIDACION_251])),
            SUM(CHARINDEX('ERR',[VALIDACION_252])),
            SUM(CHARINDEX('ERR',[VALIDACION_253])),
            SUM(CHARINDEX('ERR',[VALIDACION_254])),
            SUM(CHARINDEX('ERR',[VALIDACION_255])),
            SUM(CHARINDEX('ERR',[VALIDACION_256])),
            SUM(CHARINDEX('ERR',[VALIDACION_257])),
            SUM(CHARINDEX('ERR',[VALIDACION_258])),
            SUM(CHARINDEX('ERR',[VALIDACION_259])),
            SUM(CHARINDEX('ERR',[VALIDACION_260])),
            SUM(CHARINDEX('ERR',[VALIDACION_261])),
            SUM(CHARINDEX('ERR',[VALIDACION_262])),
            SUM(CHARINDEX('ERR',[VALIDACION_263])),
            SUM(CHARINDEX('ERR',[VALIDACION_264])),
            SUM(CHARINDEX('ERR',[VALIDACION_265])),
            SUM(CHARINDEX('ERR',[VALIDACION_266])),
            SUM(CHARINDEX('ERR',[VALIDACION_267])),
            SUM(CHARINDEX('ERR',[VALIDACION_268])),
            SUM(CHARINDEX('ERR',[VALIDACION_269])),
            SUM(CHARINDEX('ERR',[VALIDACION_270])),
            SUM(CHARINDEX('ERR',[VALIDACION_271])),
            SUM(CHARINDEX('ERR',[VALIDACION_272])),
            SUM(CHARINDEX('ERR',[VALIDACION_273])),
            SUM(CHARINDEX('ERR',[VALIDACION_274])),
            SUM(CHARINDEX('ERR',[VALIDACION_275])),
            SUM(CHARINDEX('ERR',[VALIDACION_276])),
            SUM(CHARINDEX('ERR',[VALIDACION_277])),
            SUM(CHARINDEX('ERR',[VALIDACION_278])),
            SUM(CHARINDEX('ERR',[VALIDACION_279])),
            SUM(CHARINDEX('ERR',[VALIDACION_280])),
            SUM(CHARINDEX('ERR',[VALIDACION_281])),
            SUM(CHARINDEX('ERR',[VALIDACION_282])),
            SUM(CHARINDEX('ERR',[VALIDACION_283])),
            SUM(CHARINDEX('ERR',[VALIDACION_284])),
            SUM(CHARINDEX('ERR',[VALIDACION_285])),
            SUM(CHARINDEX('ERR',[VALIDACION_286])),
            SUM(CHARINDEX('ERR',[VALIDACION_287])),
            SUM(CHARINDEX('ERR',[VALIDACION_288])),
            SUM(CHARINDEX('ERR',[VALIDACION_289])),
            SUM(CHARINDEX('ERR',[VALIDACION_290])),
            SUM(CHARINDEX('ERR',[VALIDACION_291])),
            SUM(CHARINDEX('ERR',[VALIDACION_292])),
            SUM(CHARINDEX('ERR',[VALIDACION_293])),
            SUM(CHARINDEX('ERR',[VALIDACION_294])),
            SUM(CHARINDEX('ERR',[VALIDACION_295])),
            SUM(CHARINDEX('ERR',[VALIDACION_296])),
            SUM(CHARINDEX('ERR',[VALIDACION_297])),
            SUM(CHARINDEX('ERR',[VALIDACION_298])),
            SUM(CHARINDEX('ERR',[VALIDACION_299])),
            SUM(CHARINDEX('ERR',[VALIDACION_300]))
            


		FROM IFRS9_R04A_0424_M15TS1_RESULT_3 
END

BEGIN
	EXEC SP_IFRS9_R04A_0424_M15TS1_VIEW_3
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


