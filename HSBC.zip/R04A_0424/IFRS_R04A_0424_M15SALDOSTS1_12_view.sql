﻿
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapas 1 y 2 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15SALDOS*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/


CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0424_M15SALDOSTS1_VIEW_12]
AS
BEGIN
	SELECT *
		
	FROM IFRS9_R04A_0424_M15SALDOSTS1_RESULT_12
	WHERE

        (VALIDACION_1101 <> '' ) OR
        (VALIDACION_1102 <> '' ) OR
        (VALIDACION_1103 <> '' ) OR
        (VALIDACION_1104 <> '' ) OR
        (VALIDACION_1105 <> '' ) OR
        (VALIDACION_1106 <> '' ) OR
        (VALIDACION_1107 <> '' ) OR
        (VALIDACION_1108 <> '' ) OR
        (VALIDACION_1109 <> '' ) OR
        (VALIDACION_1110 <> '' ) OR
        (VALIDACION_1111 <> '' ) OR
        (VALIDACION_1112 <> '' ) OR
        (VALIDACION_1113 <> '' ) OR
        (VALIDACION_1114 <> '' ) OR
        (VALIDACION_1115 <> '' ) OR
        (VALIDACION_1116 <> '' ) OR
        (VALIDACION_1117 <> '' ) OR
        (VALIDACION_1118 <> '' ) OR
        (VALIDACION_1119 <> '' ) OR
        (VALIDACION_1120 <> '' ) OR
        (VALIDACION_1121 <> '' ) OR
        (VALIDACION_1122 <> '' ) OR
        (VALIDACION_1123 <> '' ) OR
        (VALIDACION_1124 <> '' ) OR
        (VALIDACION_1125 <> '' ) OR
        (VALIDACION_1126 <> '' ) OR
        (VALIDACION_1127 <> '' ) OR
        (VALIDACION_1128 <> '' ) OR
        (VALIDACION_1129 <> '' ) OR
        (VALIDACION_1130 <> '' ) OR
        (VALIDACION_1131 <> '' ) OR
        (VALIDACION_1132 <> '' ) OR
        (VALIDACION_1133 <> '' ) OR
        (VALIDACION_1134 <> '' ) OR
        (VALIDACION_1135 <> '' ) OR
        (VALIDACION_1136 <> '' ) OR
        (VALIDACION_1137 <> '' ) OR
        (VALIDACION_1138 <> '' ) OR
        (VALIDACION_1139 <> '' ) OR
        (VALIDACION_1140 <> '' ) OR
        (VALIDACION_1141 <> '' ) OR
        (VALIDACION_1142 <> '' ) OR
        (VALIDACION_1143 <> '' ) OR
        (VALIDACION_1144 <> '' ) OR
        (VALIDACION_1145 <> '' ) OR
        (VALIDACION_1146 <> '' ) OR
        (VALIDACION_1147 <> '' ) OR
        (VALIDACION_1148 <> '' ) OR
        (VALIDACION_1149 <> '' ) OR
        (VALIDACION_1150 <> '' ) OR
        (VALIDACION_1151 <> '' ) OR
        (VALIDACION_1152 <> '' ) OR
        (VALIDACION_1153 <> '' ) OR
        (VALIDACION_1154 <> '' ) OR
        (VALIDACION_1155 <> '' ) OR
        (VALIDACION_1156 <> '' ) OR
        (VALIDACION_1157 <> '' ) OR
        (VALIDACION_1158 <> '' ) OR
        (VALIDACION_1159 <> '' ) OR
        (VALIDACION_1160 <> '' ) OR
        (VALIDACION_1161 <> '' ) OR
        (VALIDACION_1162 <> '' ) OR
        (VALIDACION_1163 <> '' ) OR
        (VALIDACION_1164 <> '' ) OR
        (VALIDACION_1165 <> '' ) OR
        (VALIDACION_1166 <> '' ) OR
        (VALIDACION_1167 <> '' ) OR
        (VALIDACION_1168 <> '' ) OR
        (VALIDACION_1169 <> '' ) OR
        (VALIDACION_1170 <> '' ) OR
        (VALIDACION_1171 <> '' ) OR
        (VALIDACION_1172 <> '' ) OR
        (VALIDACION_1173 <> '' ) OR
        (VALIDACION_1174 <> '' ) OR
        (VALIDACION_1175 <> '' ) OR
        (VALIDACION_1176 <> '' ) OR
        (VALIDACION_1177 <> '' ) OR
        (VALIDACION_1178 <> '' ) OR
        (VALIDACION_1179 <> '' ) OR
        (VALIDACION_1180 <> '' ) OR
        (VALIDACION_1181 <> '' ) OR
        (VALIDACION_1182 <> '' ) OR
        (VALIDACION_1183 <> '' ) OR
        (VALIDACION_1184 <> '' ) OR
        (VALIDACION_1185 <> '' ) OR
        (VALIDACION_1186 <> '' ) OR
        (VALIDACION_1187 <> '' ) OR
        (VALIDACION_1188 <> '' ) OR
        (VALIDACION_1189 <> '' ) OR
        (VALIDACION_1190 <> '' ) OR
        (VALIDACION_1191 <> '' ) OR
        (VALIDACION_1192 <> '' ) OR
        (VALIDACION_1193 <> '' ) OR
        (VALIDACION_1194 <> '' ) OR
        (VALIDACION_1195 <> '' ) OR
        (VALIDACION_1196 <> '' ) OR
        (VALIDACION_1197 <> '' ) OR
        (VALIDACION_1198 <> '' ) OR
        (VALIDACION_1199 <> '' ) OR
        (VALIDACION_1200 <> '' ) 
ORDER BY 1
END

