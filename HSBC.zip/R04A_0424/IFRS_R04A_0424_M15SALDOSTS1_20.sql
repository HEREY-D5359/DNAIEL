﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapas 1 y 2 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15SALDOS*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0424_M15SALDOSTS1_COMP_20]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0424_M15SALDOSTS1_RESULT_20')
BEGIN
DROP TABLE IFRS9_R04A_0424_M15SALDOSTS1_RESULT_20
END 

BEGIN
SELECT DISTINCT
         /*id*/
CONVERT(VARCHAR,ID) AS ID, 
	/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112218409222')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112218409222')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112218409222) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112218409222) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1901,

/*Remodelación o mejoramiento con garantía otorgada por la Banca de Desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112212808185')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112212808185')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112212808185) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112212808185) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1902,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112212808186')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112212808186')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112212808186) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112212808186) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1903,

/*Bonificaciones y descuentos sobre (3)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201106042')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201106042')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201106042) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201106042) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1904,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112204207130')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112204207130')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112204207130) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112204207130) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1905,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213008187')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213008187')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112213008187) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112213008187) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1906,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112218709223')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112218709223')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112218709223) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112218709223) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1907,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112222310105')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112222310105')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112222310105) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112222310105) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1908,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112222310106')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112222310106')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112222310106) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112222310106) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1909,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112218709224')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112218709224')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112218709224) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112218709224) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1910,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112222410107')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112222410107')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112222410107) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112222410107) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1911,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112222410108')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112222410108')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112222410108) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112222410108) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1912,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112222410109')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112222410109')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112222410109) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112222410109) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1913,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112218709225')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112218709225')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112218709225) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112218709225) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1914,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112222510110')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112222510110')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112222510110) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112222510110) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1915,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112222510111')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112222510111')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112222510111) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112222510111) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1916,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112218709226')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112218709226')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112218709226) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112218709226) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1917,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112218709227')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112218709227')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112218709227) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112218709227) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1918,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112218709228')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112218709228')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112218709228) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112218709228) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1919,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112218709229')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112218709229')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112218709229) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112218709229) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1920,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112218709230')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112218709230')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112218709230) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112218709230) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1921,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213008188')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213008188')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112213008188) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112213008188) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1922,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112218809231')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112218809231')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112218809231) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112218809231) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1923,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112223110112')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112223110112')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112223110112) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112223110112) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1924,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112223110113')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112223110113')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112223110113) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112223110113) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1925,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112223110114')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112223110114')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112223110114) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112223110114) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1926,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112218809232')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112218809232')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112218809232) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112218809232) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1927,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112223210115')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112223210115')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112223210115) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112223210115) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1928,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112223210116')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112223210116')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112223210116) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112223210116) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1929,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112223210117')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112223210117')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112223210117) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112223210117) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1930,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213008189')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213008189')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112213008189) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112213008189) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1931,

/*Créditos al gobierno federal */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112218909233')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112218909233')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112218909233) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112218909233) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1932,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112218909234')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112218909234')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112218909234) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112218909234) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1933,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112223410118')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112223410118')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112223410118) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112223410118) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1934,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112223410119')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112223410119')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112223410119) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112223410119) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1935,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112223410120')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112223410120')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112223410120) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112223410120) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1936,

/*Fideicomisos públicos de contratación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112223410121')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112223410121')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112223410121) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112223410121) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1937,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112223410122')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112223410122')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112223410122) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112223410122) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1938,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112218909235')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112218909235')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112218909235) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112218909235) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1939,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112223510123')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112223510123')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112223510123) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112223510123) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1940,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112223510124')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112223510124')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112223510124) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112223510124) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1941,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112223510125')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112223510125')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112223510125) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112223510125) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1942,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112223510126')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112223510126')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112223510126) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112223510126) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1943,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112218909236')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112218909236')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112218909236) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112218909236) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1944,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112223610127')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112223610127')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112223610127) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112223610127) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1945,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112223610128')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112223610128')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112223610128) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112223610128) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1946,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112223610129')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112223610129')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112223610129) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112223610129) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1947,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112223610130')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112223610130')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112223610130) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112223610130) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1948,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112204207131')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112204207131')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112204207131) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112204207131) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1949,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213108190')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213108190')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112213108190) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112213108190) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1950,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213108191')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213108191')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112213108191) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112213108191) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1951,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213108192')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213108192')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112213108192) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112213108192) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1952,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213108193')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213108193')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112213108193) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112213108193) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1953,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213108194')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213108194')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112213108194) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112213108194) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1954,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213108195')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213108195')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112213108195) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112213108195) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1955,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213108196')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213108196')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112213108196) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112213108196) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1956,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213108197')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213108197')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112213108197) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112213108197) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1957,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112204207132')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112204207132')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112204207132) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112204207132) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1958,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213208198')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213208198')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112213208198) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112213208198) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1959,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213208199')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213208199')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112213208199) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112213208199) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1960,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213208200')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213208200')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112213208200) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112213208200) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1961,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220009237')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220009237')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220009237) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220009237) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1962,

/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220009238')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220009238')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220009238) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220009238) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1963,

/*Remodelación o mejoramiento con garantía otorgada por la Banca de Desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213208201')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213208201')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112213208201) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112213208201) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1964,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213208202')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213208202')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112213208202) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112213208202) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1965,

/*Ventas de cartera (5)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112200305012')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112200305012')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112200305012) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112200305012) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1966,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112201206043')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112201206043')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112201206043) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112201206043) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1967,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112204307133')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112204307133')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112204307133) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112204307133) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1968,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213308203')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213308203')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112213308203) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112213308203) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1969,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220309239')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220309239')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220309239) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220309239) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1970,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220309240')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220309240')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220309240) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220309240) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1971,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213308204')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213308204')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112213308204) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112213308204) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1972,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220409241')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220409241')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220409241) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220409241) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1973,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220409242')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220409242')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220409242) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220409242) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1974,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220409243')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220409243')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220409243) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220409243) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1975,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213308205')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213308205')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112213308205) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112213308205) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1976,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220509244')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220509244')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220509244) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220509244) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1977,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112220509245')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112220509245')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112220509245) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112220509245) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1978,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213308206')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213308206')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112213308206) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112213308206) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1979,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213308207')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213308207')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112213308207) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112213308207) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1980,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213308208')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213308208')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112213308208) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112213308208) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1981,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213308209')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213308209')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112213308209) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112213308209) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1982,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213308210')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213308210')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112213308210) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112213308210) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1983,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112204307134')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112204307134')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112204307134) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112204307134) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1984,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213408211')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213408211')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112213408211) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112213408211) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1985,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221109246')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221109246')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221109246) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221109246) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1986,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221109247')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221109247')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221109247) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221109247) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1987,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221109248')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221109248')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221109248) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221109248) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1988,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213408212')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213408212')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112213408212) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112213408212) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1989,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221209249')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221209249')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221209249) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221209249) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1990,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221209250')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221209250')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221209250) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221209250) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1991,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221209251')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221209251')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221209251) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221209251) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1992,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112204307135')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112204307135')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112204307135) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112204307135) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1993,

/*Créditos al gobierno federal */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213508213')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213508213')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112213508213) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112213508213) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1994,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112213508214')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112213508214')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112213508214) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112213508214) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1995,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221409252')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221409252')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221409252) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221409252) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1996,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221409253')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221409253')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221409253) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221409253) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1997,

/*Operaciones de  arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221409254')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221409254')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221409254) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221409254) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1998,

/*Fideicomisos públicos de contratación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221409255')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221409255')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221409255) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221409255) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1999,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0424   
WHERE [c04_CONCEPTO] IN ('112221409256')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0424     
WHERE [c04_CONCEPTO] IN ('112221409256')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1','4','9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112221409256) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112221409256) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2000
	
INTO IFRS9_R04A_0424_M15SALDOSTS1_RESULT_20
FROM IFRS9_R04A_0424

END

BEGIN
	INSERT INTO IFRS9_R04A_0424_M15SALDOSTS1_RESULT_20 
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_1901])),
            SUM(CHARINDEX('ERR',[VALIDACION_1902])),
            SUM(CHARINDEX('ERR',[VALIDACION_1903])),
            SUM(CHARINDEX('ERR',[VALIDACION_1904])),
            SUM(CHARINDEX('ERR',[VALIDACION_1905])),
            SUM(CHARINDEX('ERR',[VALIDACION_1906])),
            SUM(CHARINDEX('ERR',[VALIDACION_1907])),
            SUM(CHARINDEX('ERR',[VALIDACION_1908])),
            SUM(CHARINDEX('ERR',[VALIDACION_1909])),
            SUM(CHARINDEX('ERR',[VALIDACION_1910])),
            SUM(CHARINDEX('ERR',[VALIDACION_1911])),
            SUM(CHARINDEX('ERR',[VALIDACION_1912])),
            SUM(CHARINDEX('ERR',[VALIDACION_1913])),
            SUM(CHARINDEX('ERR',[VALIDACION_1914])),
            SUM(CHARINDEX('ERR',[VALIDACION_1915])),
            SUM(CHARINDEX('ERR',[VALIDACION_1916])),
            SUM(CHARINDEX('ERR',[VALIDACION_1917])),
            SUM(CHARINDEX('ERR',[VALIDACION_1918])),
            SUM(CHARINDEX('ERR',[VALIDACION_1919])),
            SUM(CHARINDEX('ERR',[VALIDACION_1920])),
            SUM(CHARINDEX('ERR',[VALIDACION_1921])),
            SUM(CHARINDEX('ERR',[VALIDACION_1922])),
            SUM(CHARINDEX('ERR',[VALIDACION_1923])),
            SUM(CHARINDEX('ERR',[VALIDACION_1924])),
            SUM(CHARINDEX('ERR',[VALIDACION_1925])),
            SUM(CHARINDEX('ERR',[VALIDACION_1926])),
            SUM(CHARINDEX('ERR',[VALIDACION_1927])),
            SUM(CHARINDEX('ERR',[VALIDACION_1928])),
            SUM(CHARINDEX('ERR',[VALIDACION_1929])),
            SUM(CHARINDEX('ERR',[VALIDACION_1930])),
            SUM(CHARINDEX('ERR',[VALIDACION_1931])),
            SUM(CHARINDEX('ERR',[VALIDACION_1932])),
            SUM(CHARINDEX('ERR',[VALIDACION_1933])),
            SUM(CHARINDEX('ERR',[VALIDACION_1934])),
            SUM(CHARINDEX('ERR',[VALIDACION_1935])),
            SUM(CHARINDEX('ERR',[VALIDACION_1936])),
            SUM(CHARINDEX('ERR',[VALIDACION_1937])),
            SUM(CHARINDEX('ERR',[VALIDACION_1938])),
            SUM(CHARINDEX('ERR',[VALIDACION_1939])),
            SUM(CHARINDEX('ERR',[VALIDACION_1940])),
            SUM(CHARINDEX('ERR',[VALIDACION_1941])),
            SUM(CHARINDEX('ERR',[VALIDACION_1942])),
            SUM(CHARINDEX('ERR',[VALIDACION_1943])),
            SUM(CHARINDEX('ERR',[VALIDACION_1944])),
            SUM(CHARINDEX('ERR',[VALIDACION_1945])),
            SUM(CHARINDEX('ERR',[VALIDACION_1946])),
            SUM(CHARINDEX('ERR',[VALIDACION_1947])),
            SUM(CHARINDEX('ERR',[VALIDACION_1948])),
            SUM(CHARINDEX('ERR',[VALIDACION_1949])),
            SUM(CHARINDEX('ERR',[VALIDACION_1950])),
            SUM(CHARINDEX('ERR',[VALIDACION_1951])),
            SUM(CHARINDEX('ERR',[VALIDACION_1952])),
            SUM(CHARINDEX('ERR',[VALIDACION_1953])),
            SUM(CHARINDEX('ERR',[VALIDACION_1954])),
            SUM(CHARINDEX('ERR',[VALIDACION_1955])),
            SUM(CHARINDEX('ERR',[VALIDACION_1956])),
            SUM(CHARINDEX('ERR',[VALIDACION_1957])),
            SUM(CHARINDEX('ERR',[VALIDACION_1958])),
            SUM(CHARINDEX('ERR',[VALIDACION_1959])),
            SUM(CHARINDEX('ERR',[VALIDACION_1960])),
            SUM(CHARINDEX('ERR',[VALIDACION_1961])),
            SUM(CHARINDEX('ERR',[VALIDACION_1962])),
            SUM(CHARINDEX('ERR',[VALIDACION_1963])),
            SUM(CHARINDEX('ERR',[VALIDACION_1964])),
            SUM(CHARINDEX('ERR',[VALIDACION_1965])),
            SUM(CHARINDEX('ERR',[VALIDACION_1966])),
            SUM(CHARINDEX('ERR',[VALIDACION_1967])),
            SUM(CHARINDEX('ERR',[VALIDACION_1968])),
            SUM(CHARINDEX('ERR',[VALIDACION_1969])),
            SUM(CHARINDEX('ERR',[VALIDACION_1970])),
            SUM(CHARINDEX('ERR',[VALIDACION_1971])),
            SUM(CHARINDEX('ERR',[VALIDACION_1972])),
            SUM(CHARINDEX('ERR',[VALIDACION_1973])),
            SUM(CHARINDEX('ERR',[VALIDACION_1974])),
            SUM(CHARINDEX('ERR',[VALIDACION_1975])),
            SUM(CHARINDEX('ERR',[VALIDACION_1976])),
            SUM(CHARINDEX('ERR',[VALIDACION_1977])),
            SUM(CHARINDEX('ERR',[VALIDACION_1978])),
            SUM(CHARINDEX('ERR',[VALIDACION_1979])),
            SUM(CHARINDEX('ERR',[VALIDACION_1980])),
            SUM(CHARINDEX('ERR',[VALIDACION_1981])),
            SUM(CHARINDEX('ERR',[VALIDACION_1982])),
            SUM(CHARINDEX('ERR',[VALIDACION_1983])),
            SUM(CHARINDEX('ERR',[VALIDACION_1984])),
            SUM(CHARINDEX('ERR',[VALIDACION_1985])),
            SUM(CHARINDEX('ERR',[VALIDACION_1986])),
            SUM(CHARINDEX('ERR',[VALIDACION_1987])),
            SUM(CHARINDEX('ERR',[VALIDACION_1988])),
            SUM(CHARINDEX('ERR',[VALIDACION_1989])),
            SUM(CHARINDEX('ERR',[VALIDACION_1990])),
            SUM(CHARINDEX('ERR',[VALIDACION_1991])),
            SUM(CHARINDEX('ERR',[VALIDACION_1992])),
            SUM(CHARINDEX('ERR',[VALIDACION_1993])),
            SUM(CHARINDEX('ERR',[VALIDACION_1994])),
            SUM(CHARINDEX('ERR',[VALIDACION_1995])),
            SUM(CHARINDEX('ERR',[VALIDACION_1996])),
            SUM(CHARINDEX('ERR',[VALIDACION_1997])),
            SUM(CHARINDEX('ERR',[VALIDACION_1998])),
            SUM(CHARINDEX('ERR',[VALIDACION_1999])),
            SUM(CHARINDEX('ERR',[VALIDACION_2000]))
            


		FROM IFRS9_R04A_0424_M15SALDOSTS1_RESULT_20 
END

BEGIN
	EXEC SP_IFRS9_R04A_0424_M15SALDOSTS1_VIEW_20
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


