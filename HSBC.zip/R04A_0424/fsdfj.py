
import sys
from typing import NewType


CADENA = "IFRS_R04A_0424_M15SALDOSTS1_1.sql*IFRS_R04A_0424_M15SALDOSTS1_10.sql*IFRS_R04A_0424_M15SALDOSTS1_10_view.sql*IFRS_R04A_0424_M15SALDOSTS1_11.sql*IFRS_R04A_0424_M15SALDOSTS1_11_view.sql*IFRS_R04A_0424_M15SALDOSTS1_12.sql*IFRS_R04A_0424_M15SALDOSTS1_12_view.sql*IFRS_R04A_0424_M15SALDOSTS1_13.sql*IFRS_R04A_0424_M15SALDOSTS1_13_view.sql*IFRS_R04A_0424_M15SALDOSTS1_14.sql*IFRS_R04A_0424_M15SALDOSTS1_14_view.sql*IFRS_R04A_0424_M15SALDOSTS1_15.sql*IFRS_R04A_0424_M15SALDOSTS1_15_view.sql*IFRS_R04A_0424_M15SALDOSTS1_16.sql*IFRS_R04A_0424_M15SALDOSTS1_16_view.sql*IFRS_R04A_0424_M15SALDOSTS1_17.sql*IFRS_R04A_0424_M15SALDOSTS1_17_view.sql*IFRS_R04A_0424_M15SALDOSTS1_18.sql*IFRS_R04A_0424_M15SALDOSTS1_18_view.sql*IFRS_R04A_0424_M15SALDOSTS1_19.sql*IFRS_R04A_0424_M15SALDOSTS1_19_view.sql*IFRS_R04A_0424_M15SALDOSTS1_1_view.sql*IFRS_R04A_0424_M15SALDOSTS1_2.sql*IFRS_R04A_0424_M15SALDOSTS1_20.sql*IFRS_R04A_0424_M15SALDOSTS1_20_view.sql*IFRS_R04A_0424_M15SALDOSTS1_21.sql*IFRS_R04A_0424_M15SALDOSTS1_21_view.sql*IFRS_R04A_0424_M15SALDOSTS1_22.sql*IFRS_R04A_0424_M15SALDOSTS1_22_view.sql*IFRS_R04A_0424_M15SALDOSTS1_23.sql*IFRS_R04A_0424_M15SALDOSTS1_23_view.sql*IFRS_R04A_0424_M15SALDOSTS1_24.sql*IFRS_R04A_0424_M15SALDOSTS1_24_view.sql*IFRS_R04A_0424_M15SALDOSTS1_2_view.sql*IFRS_R04A_0424_M15SALDOSTS1_3.sql*IFRS_R04A_0424_M15SALDOSTS1_3_view.sql*IFRS_R04A_0424_M15SALDOSTS1_4.sql*IFRS_R04A_0424_M15SALDOSTS1_4_view.sql*IFRS_R04A_0424_M15SALDOSTS1_5.sql*IFRS_R04A_0424_M15SALDOSTS1_5_view.sql*IFRS_R04A_0424_M15SALDOSTS1_6.sql*IFRS_R04A_0424_M15SALDOSTS1_6_view.sql*IFRS_R04A_0424_M15SALDOSTS1_7.sql*IFRS_R04A_0424_M15SALDOSTS1_7_view.sql*IFRS_R04A_0424_M15SALDOSTS1_8.sql*IFRS_R04A_0424_M15SALDOSTS1_8_view.sql*IFRS_R04A_0424_M15SALDOSTS1_9.sql*IFRS_R04A_0424_M15SALDOSTS1_9_view.sql*IFRS_R04A_0424_M15TS1_1.sql*IFRS_R04A_0424_M15TS1_1_view.sql*IFRS_R04A_0424_M15TS1_2.sql*IFRS_R04A_0424_M15TS1_2_view.sql*IFRS_R04A_0424_M15TS1_3.sql*IFRS_R04A_0424_M15TS1_3_view.sql*IFRS_R04A_0424_M15TS1_4.sql*IFRS_R04A_0424_M15TS1_4_view.sql*IFRS_R04A_0424_M15TS1_5.sql*IFRS_R04A_0424_M15TS1_5_view.sql*IFRS_R04A_0424_M15TS1_6.sql*IFRS_R04A_0424_M15TS1_6_view.sql*IFRS_R04A_0424_M15TS1_7.sql*IFRS_R04A_0424_M15TS1_7_view.sql*IFRS_R04A_0424_M1TS1_1.sql*IFRS_R04A_0424_M1TS1_1_view.sql*IFRS_R04A_0424_M1TS1_2.sql*IFRS_R04A_0424_M1TS1_2_view.sql*IFRS_R04A_0424_M1TS1_3.sql*IFRS_R04A_0424_M1TS1_3_view.sql*IFRS_R04A_0424_M1TS1_4.sql*IFRS_R04A_0424_M1TS1_4_view.sql*IFRS_R04A_0424_M1TS1_5.sql*IFRS_R04A_0424_M1TS1_5_view.sql*IFRS_R04A_0424_M1TS1_6.sql*IFRS_R04A_0424_M1TS1_6_view.sql*IFRS_R04A_0424_M1TS1_7.sql*IFRS_R04A_0424_M1TS1_7_view.sql*IFRS_R04A_0424_M4TS1_1.sql*IFRS_R04A_0424_M4TS1_1_view.sql*IFRS_R04A_0424_M4TS1_2.sql*IFRS_R04A_0424_M4TS1_2_view.sql*IFRS_R04A_0424_M4TS1_3.sql*IFRS_R04A_0424_M4TS1_3_view.sql*IFRS_R04A_0424_M4TS1_4.sql*IFRS_R04A_0424_M4TS1_4_view.sql*IFRS_R04A_0424_M4TS1_5.sql*IFRS_R04A_0424_M4TS1_5_view.sql*IFRS_R04A_0424_M4TS1_6.sql*IFRS_R04A_0424_M4TS1_6_view.sql*IFRS_R04A_0424_M4TS1_7.sql*IFRS_R04A_0424_M4TS1_7_view.sql*IFRS_R04A_0424_M9TS1_1.sql*IFRS_R04A_0424_M9TS1_1_view.sql*IFRS_R04A_0424_M9TS1_2.sql*IFRS_R04A_0424_M9TS1_2_view.sql*IFRS_R04A_0424_M9TS1_3.sql*IFRS_R04A_0424_M9TS1_3_view.sql*IFRS_R04A_0424_M9TS1_4.sql*IFRS_R04A_0424_M9TS1_4_view.sql*IFRS_R04A_0424_M9TS1_5.sql*IFRS_R04A_0424_M9TS1_5_view.sql*IFRS_R04A_0424_M9TS1_6.sql*IFRS_R04A_0424_M9TS1_6_view.sql*IFRS_R04A_0424_M9TS1_7.sql*IFRS_R04A_0424_M9TS1_7_view.sql"


dato = CADENA.split("*")

for stringn in dato:
    f = open(stringn,'r')
    filedata = f.read()
    f.close()
    
    try:
            if stringn.find("view.sql") > -1:
                op = stringn.replace("_view","")
               
                name= op[len(op)-(op[::-1].index("_")):op.index(".")]
                print(name)
                newdata = filedata.replace("(VALIDACION_x00","(VALIDACION_"+name+"00")
                
                newdata = newdata.replace("(VALIDACION_X","(VALIDACION_"+str(int(name)-1))
                f = open(stringn,'w')
                f.write(newdata)
                f.close()
            else:
                print('false')
                
            if stringn.find("view.sql") == -1:
                print("WWW")
                name= stringn.index(".")
                name= stringn[len(stringn)-(stringn[::-1].index("_")):stringn.index(".")]
                
                newdata = filedata.replace("SUM(CHARINDEX('ERR',[VALIDACION_X00","SUM(CHARINDEX('ERR',[VALIDACION_"+name+"00")
                newdata = newdata.replace("SUM(CHARINDEX('ERR',[VALIDACION_X","SUM(CHARINDEX('ERR',[VALIDACION_"+str(int(name)-1))
                
                newInsert = stringn[stringn.index("I"):stringn.index(".")-1].rstrip()
                
                newInsert1 = newdata[newdata.find("INTO I"):newdata.find("INSERT INTO")]
                newInsert = newInsert1[5:newInsert1.find("FROM")-1].rstrip()
                newdata = newdata.replace("INSERT INTO","INSERT INTO "+newInsert)
                print(newdata.find("fromx"))
                newdata = newdata.replace("EXEC SP_","EXEC SP_"+newInsert.replace("RESULT","VIEW"))
                #print(newdata.replace("EXEC SP_ ","EXECSP_"+newInsert.replace("RESULT","VIEW")))
                newdata = newdata.replace("fromx","FROM "+ newInsert+ "")
                #print(newdata)
                f = open(stringn,'w')
                f.write(newdata)
                f.close()
    except:
            print("error "+stringn)
            f.close()    
        
        