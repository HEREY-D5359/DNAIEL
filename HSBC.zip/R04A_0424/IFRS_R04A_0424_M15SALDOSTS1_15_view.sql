﻿
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapas 1 y 2 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15SALDOS*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/


CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0424_M15SALDOSTS1_VIEW_15]
AS
BEGIN
	SELECT *
		
	FROM IFRS9_R04A_0424_M15SALDOSTS1_RESULT_15
	WHERE

        (VALIDACION_1401 <> '' ) OR
        (VALIDACION_1402 <> '' ) OR
        (VALIDACION_1403 <> '' ) OR
        (VALIDACION_1404 <> '' ) OR
        (VALIDACION_1405 <> '' ) OR
        (VALIDACION_1406 <> '' ) OR
        (VALIDACION_1407 <> '' ) OR
        (VALIDACION_1408 <> '' ) OR
        (VALIDACION_1409 <> '' ) OR
        (VALIDACION_1410 <> '' ) OR
        (VALIDACION_1411 <> '' ) OR
        (VALIDACION_1412 <> '' ) OR
        (VALIDACION_1413 <> '' ) OR
        (VALIDACION_1414 <> '' ) OR
        (VALIDACION_1415 <> '' ) OR
        (VALIDACION_1416 <> '' ) OR
        (VALIDACION_1417 <> '' ) OR
        (VALIDACION_1418 <> '' ) OR
        (VALIDACION_1419 <> '' ) OR
        (VALIDACION_1420 <> '' ) OR
        (VALIDACION_1421 <> '' ) OR
        (VALIDACION_1422 <> '' ) OR
        (VALIDACION_1423 <> '' ) OR
        (VALIDACION_1424 <> '' ) OR
        (VALIDACION_1425 <> '' ) OR
        (VALIDACION_1426 <> '' ) OR
        (VALIDACION_1427 <> '' ) OR
        (VALIDACION_1428 <> '' ) OR
        (VALIDACION_1429 <> '' ) OR
        (VALIDACION_1430 <> '' ) OR
        (VALIDACION_1431 <> '' ) OR
        (VALIDACION_1432 <> '' ) OR
        (VALIDACION_1433 <> '' ) OR
        (VALIDACION_1434 <> '' ) OR
        (VALIDACION_1435 <> '' ) OR
        (VALIDACION_1436 <> '' ) OR
        (VALIDACION_1437 <> '' ) OR
        (VALIDACION_1438 <> '' ) OR
        (VALIDACION_1439 <> '' ) OR
        (VALIDACION_1440 <> '' ) OR
        (VALIDACION_1441 <> '' ) OR
        (VALIDACION_1442 <> '' ) OR
        (VALIDACION_1443 <> '' ) OR
        (VALIDACION_1444 <> '' ) OR
        (VALIDACION_1445 <> '' ) OR
        (VALIDACION_1446 <> '' ) OR
        (VALIDACION_1447 <> '' ) OR
        (VALIDACION_1448 <> '' ) OR
        (VALIDACION_1449 <> '' ) OR
        (VALIDACION_1450 <> '' ) OR
        (VALIDACION_1451 <> '' ) OR
        (VALIDACION_1452 <> '' ) OR
        (VALIDACION_1453 <> '' ) OR
        (VALIDACION_1454 <> '' ) OR
        (VALIDACION_1455 <> '' ) OR
        (VALIDACION_1456 <> '' ) OR
        (VALIDACION_1457 <> '' ) OR
        (VALIDACION_1458 <> '' ) OR
        (VALIDACION_1459 <> '' ) OR
        (VALIDACION_1460 <> '' ) OR
        (VALIDACION_1461 <> '' ) OR
        (VALIDACION_1462 <> '' ) OR
        (VALIDACION_1463 <> '' ) OR
        (VALIDACION_1464 <> '' ) OR
        (VALIDACION_1465 <> '' ) OR
        (VALIDACION_1466 <> '' ) OR
        (VALIDACION_1467 <> '' ) OR
        (VALIDACION_1468 <> '' ) OR
        (VALIDACION_1469 <> '' ) OR
        (VALIDACION_1470 <> '' ) OR
        (VALIDACION_1471 <> '' ) OR
        (VALIDACION_1472 <> '' ) OR
        (VALIDACION_1473 <> '' ) OR
        (VALIDACION_1474 <> '' ) OR
        (VALIDACION_1475 <> '' ) OR
        (VALIDACION_1476 <> '' ) OR
        (VALIDACION_1477 <> '' ) OR
        (VALIDACION_1478 <> '' ) OR
        (VALIDACION_1479 <> '' ) OR
        (VALIDACION_1480 <> '' ) OR
        (VALIDACION_1481 <> '' ) OR
        (VALIDACION_1482 <> '' ) OR
        (VALIDACION_1483 <> '' ) OR
        (VALIDACION_1484 <> '' ) OR
        (VALIDACION_1485 <> '' ) OR
        (VALIDACION_1486 <> '' ) OR
        (VALIDACION_1487 <> '' ) OR
        (VALIDACION_1488 <> '' ) OR
        (VALIDACION_1489 <> '' ) OR
        (VALIDACION_1490 <> '' ) OR
        (VALIDACION_1491 <> '' ) OR
        (VALIDACION_1492 <> '' ) OR
        (VALIDACION_1493 <> '' ) OR
        (VALIDACION_1494 <> '' ) OR
        (VALIDACION_1495 <> '' ) OR
        (VALIDACION_1496 <> '' ) OR
        (VALIDACION_1497 <> '' ) OR
        (VALIDACION_1498 <> '' ) OR
        (VALIDACION_1499 <> '' ) OR
        (VALIDACION_1500 <> '' ) 
ORDER BY 1
END

