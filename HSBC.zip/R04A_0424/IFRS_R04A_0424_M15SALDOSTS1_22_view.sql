﻿
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en cartera con riesgo de crédito etapas 1 y 2 */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15SALDOS*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/


CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0424_M15SALDOSTS1_VIEW_22]
AS
BEGIN
	SELECT *
		
	FROM IFRS9_R04A_0424_M15SALDOSTS1_RESULT_22
	WHERE

        (VALIDACION_2101 <> '' ) OR
        (VALIDACION_2102 <> '' ) OR
        (VALIDACION_2103 <> '' ) OR
        (VALIDACION_2104 <> '' ) OR
        (VALIDACION_2105 <> '' ) OR
        (VALIDACION_2106 <> '' ) OR
        (VALIDACION_2107 <> '' ) OR
        (VALIDACION_2108 <> '' ) OR
        (VALIDACION_2109 <> '' ) OR
        (VALIDACION_2110 <> '' ) OR
        (VALIDACION_2111 <> '' ) OR
        (VALIDACION_2112 <> '' ) OR
        (VALIDACION_2113 <> '' ) OR
        (VALIDACION_2114 <> '' ) OR
        (VALIDACION_2115 <> '' ) OR
        (VALIDACION_2116 <> '' ) OR
        (VALIDACION_2117 <> '' ) OR
        (VALIDACION_2118 <> '' ) OR
        (VALIDACION_2119 <> '' ) OR
        (VALIDACION_2120 <> '' ) OR
        (VALIDACION_2121 <> '' ) OR
        (VALIDACION_2122 <> '' ) OR
        (VALIDACION_2123 <> '' ) OR
        (VALIDACION_2124 <> '' ) OR
        (VALIDACION_2125 <> '' ) OR
        (VALIDACION_2126 <> '' ) OR
        (VALIDACION_2127 <> '' ) OR
        (VALIDACION_2128 <> '' ) OR
        (VALIDACION_2129 <> '' ) OR
        (VALIDACION_2130 <> '' ) OR
        (VALIDACION_2131 <> '' ) OR
        (VALIDACION_2132 <> '' ) OR
        (VALIDACION_2133 <> '' ) OR
        (VALIDACION_2134 <> '' ) OR
        (VALIDACION_2135 <> '' ) OR
        (VALIDACION_2136 <> '' ) OR
        (VALIDACION_2137 <> '' ) OR
        (VALIDACION_2138 <> '' ) OR
        (VALIDACION_2139 <> '' ) OR
        (VALIDACION_2140 <> '' ) OR
        (VALIDACION_2141 <> '' ) OR
        (VALIDACION_2142 <> '' ) OR
        (VALIDACION_2143 <> '' ) OR
        (VALIDACION_2144 <> '' ) OR
        (VALIDACION_2145 <> '' ) OR
        (VALIDACION_2146 <> '' ) OR
        (VALIDACION_2147 <> '' ) OR
        (VALIDACION_2148 <> '' ) OR
        (VALIDACION_2149 <> '' ) OR
        (VALIDACION_2150 <> '' ) OR
        (VALIDACION_2151 <> '' ) OR
        (VALIDACION_2152 <> '' ) OR
        (VALIDACION_2153 <> '' ) OR
        (VALIDACION_2154 <> '' ) OR
        (VALIDACION_2155 <> '' ) OR
        (VALIDACION_2156 <> '' ) OR
        (VALIDACION_2157 <> '' ) OR
        (VALIDACION_2158 <> '' ) OR
        (VALIDACION_2159 <> '' ) OR
        (VALIDACION_2160 <> '' ) OR
        (VALIDACION_2161 <> '' ) OR
        (VALIDACION_2162 <> '' ) OR
        (VALIDACION_2163 <> '' ) OR
        (VALIDACION_2164 <> '' ) OR
        (VALIDACION_2165 <> '' ) OR
        (VALIDACION_2166 <> '' ) OR
        (VALIDACION_2167 <> '' ) OR
        (VALIDACION_2168 <> '' ) OR
        (VALIDACION_2169 <> '' ) OR
        (VALIDACION_2170 <> '' ) OR
        (VALIDACION_2171 <> '' ) OR
        (VALIDACION_2172 <> '' ) OR
        (VALIDACION_2173 <> '' ) OR
        (VALIDACION_2174 <> '' ) OR
        (VALIDACION_2175 <> '' ) OR
        (VALIDACION_2176 <> '' ) OR
        (VALIDACION_2177 <> '' ) OR
        (VALIDACION_2178 <> '' ) OR
        (VALIDACION_2179 <> '' ) OR
        (VALIDACION_2180 <> '' ) OR
        (VALIDACION_2181 <> '' ) OR
        (VALIDACION_2182 <> '' ) OR
        (VALIDACION_2183 <> '' ) OR
        (VALIDACION_2184 <> '' ) OR
        (VALIDACION_2185 <> '' ) OR
        (VALIDACION_2186 <> '' ) OR
        (VALIDACION_2187 <> '' ) OR
        (VALIDACION_2188 <> '' ) OR
        (VALIDACION_2189 <> '' ) OR
        (VALIDACION_2190 <> '' ) OR
        (VALIDACION_2191 <> '' ) OR
        (VALIDACION_2192 <> '' ) OR
        (VALIDACION_2193 <> '' ) OR
        (VALIDACION_2194 <> '' ) OR
        (VALIDACION_2195 <> '' ) OR
        (VALIDACION_2196 <> '' ) OR
        (VALIDACION_2197 <> '' ) OR
        (VALIDACION_2198 <> '' ) OR
        (VALIDACION_2199 <> '' ) OR
        (VALIDACION_2200 <> '' ) 
ORDER BY 1
END

