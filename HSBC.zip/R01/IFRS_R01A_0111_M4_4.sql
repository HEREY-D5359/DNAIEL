﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Serie R01 Catálogo mínimo */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: Julio 2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/

/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 4*/
/*TIPO SALDO: NA*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER  PROCEDURE [dbo].[SP_IFRS9_R01A_0111_M4_COMP_4]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R01A_0111_M4_RESULT_4')
BEGIN
DROP TABLE IFRS9_R01A_0111_M4_RESULT_4
END 

BEGIN
SELECT DISTINCT

    /*ID*/

    CONVERT(VARCHAR,ID) AS ID,                                    /*Acreedores diversos y otras cuentas por pagar*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('202400102005')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('202400503015','202400503016','202400503017','202400503018','202400503019','202400503020','202400503021','202400503022')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (202400102005) con Moneda 4, debe ser igual a la sumatoria de las cuentas (202400503015 + 202400503016 + 202400503017 + 202400503018 + 202400503019 + 202400503020 + 202400503021 + 202400503022) con Moneda 4.')    
AS VALIDACION_925,

/*Pasivos derivados de la prestación de servicios bancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('202400503015')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('202401504001','202401504002','202401504003','202401504004','202401504005','202401504006','202401504007','202401504008','202401504009','202401504010')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (202400503015) con Moneda 4, debe ser igual a la sumatoria de las cuentas (202401504001 + 202401504002 + 202401504003 + 202401504004 + 202401504005 + 202401504006 + 202401504007 + 202401504008 + 202401504009 + 202401504010) con Moneda 4.')    
AS VALIDACION_926,

/*Provisiones para obligaciones diversas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('202400503021')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('202402104011','202402104012','202402104013','202402104014','202402104015','202402104016')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (202400503021) con Moneda 4, debe ser igual a la sumatoria de las cuentas (202402104011 + 202402104012 + 202402104013 + 202402104014 + 202402104015 + 202402104016) con Moneda 4.')    
AS VALIDACION_927,

/*Instrumentos financieros que califican como pasivo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('203000001001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('203000102001','203000102002','203000102003')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (203000001001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (203000102001 + 203000102002 + 203000102003) con Moneda 4.')    
AS VALIDACION_928,

/*Obligaciones subordinadas en circulación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('203000102001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('203000103001','203000103002','203000103003','203000103004')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (203000102001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (203000103001 + 203000103002 + 203000103003 + 203000103004) con Moneda 4.')    
AS VALIDACION_929,

/*De conversión forzosa*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('203000103001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('203000104001','203000104002','203000104003')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (203000103001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (203000104001 + 203000104002 + 203000104003) con Moneda 4.')    
AS VALIDACION_930,

/*De conversión por decisión del tenedor*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('203000103002')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('203000204004','203000204005','203000204006')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (203000103002) con Moneda 4, debe ser igual a la sumatoria de las cuentas (203000204004 + 203000204005 + 203000204006) con Moneda 4.')    
AS VALIDACION_931,

/*De conversión por decisión de la entidad emisora*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('203000103003')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('203000304007','203000304008','203000304009')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (203000103003) con Moneda 4, debe ser igual a la sumatoria de las cuentas (203000304007 + 203000304008 + 203000304009) con Moneda 4.')    
AS VALIDACION_932,

/*No convertibles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('203000103004')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('203000404010','203000404011','203000404012')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (203000103004) con Moneda 4, debe ser igual a la sumatoria de las cuentas (203000404010 + 203000404011 + 203000404012) con Moneda 4.')    
AS VALIDACION_933,

/*Pasivo por impuestos a la utilidad*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('203400001001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('203400102001','203400102002')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (203400001001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (203400102001 + 203400102002) con Moneda 4.')    
AS VALIDACION_934,

/*Impuestos causados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('203400102001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('203400103001','203400103002')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (203400102001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (203400103001 + 203400103002) con Moneda 4.')    
AS VALIDACION_935,

/*Impuestos diferidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('203400102002')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('203400203003')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (203400102002) con Moneda 4, debe ser igual a la sumatoria de las cuentas (203400203003) con Moneda 4.')    
AS VALIDACION_936,

/*Pasivo por beneficios a los empleados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('203600001001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('203600102001','203600102002','203600102003','203600102004','203600102005','203600102006')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (203600001001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (203600102001 + 203600102002 + 203600102003 + 203600102004 + 203600102005 + 203600102006) con Moneda 4.')    
AS VALIDACION_937,

/*Beneficios post-empleo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('203600102003')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('203600303001','203600303002','203600303003')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (203600102003) con Moneda 4, debe ser igual a la sumatoria de las cuentas (203600303001 + 203600303002 + 203600303003) con Moneda 4.')    
AS VALIDACION_938,

/*Beneficios por terminación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('203600102004')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('203600403004','203600403005')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (203600102004) con Moneda 4, debe ser igual a la sumatoria de las cuentas (203600403004 + 203600403005) con Moneda 4.')    
AS VALIDACION_939,

/*Créditos diferidos y cobros anticipados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('203800001001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('203800102001','203800102002')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (203800001001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (203800102001 + 203800102002) con Moneda 4.')    
AS VALIDACION_940,

/*Créditos diferidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('203800102001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('203800103001','203800103002','203800103003','203800103004','203800103005','203800103006','203800103007','203800103008')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (203800102001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (203800103001 + 203800103002 + 203800103003 + 203800103004 + 203800103005 + 203800103006 + 203800103007 + 203800103008) con Moneda 4.')    
AS VALIDACION_941,

/*Cobros anticipados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('203800102002')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('203800203009','203800203010','203800203011','203800203012','203800203013','203800203014')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (203800102002) con Moneda 4, debe ser igual a la sumatoria de las cuentas (203800203009 + 203800203010 + 203800203011 + 203800203012 + 203800203013 + 203800203014) con Moneda 4.')    
AS VALIDACION_942,

/*CAPITAL CONTABLE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400000000000')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400200102001','400200102002')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400000000000) con Moneda 4, debe ser igual a la sumatoria de las cuentas (400200102001 + 400200102002) con Moneda 4.')    
AS VALIDACION_943,

/*Capital contribuido*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400200102001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400200103001','400200103002','400200103003','400200103004','400200103005','400200103006','400200103007','400200103008','400200103009')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400200102001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (400200103001 + 400200103002 + 400200103003 + 400200103004 + 400200103005 + 400200103006 + 400200103007 + 400200103008 + 400200103009) con Moneda 4.')    
AS VALIDACION_944,

/*Capital ganado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400200102002')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400200203010','400200203011','400200203012','400200203013','400200203014','400200203015')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400200102002) con Moneda 4, debe ser igual a la sumatoria de las cuentas (400200203010 + 400200203011 + 400200203012 + 400200203013 + 400200203014 + 400200203015) con Moneda 4.')    
AS VALIDACION_945,

/*Reservas de capital*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400200203010')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400201004001','400201004002')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400200203010) con Moneda 4, debe ser igual a la sumatoria de las cuentas (400201004001 + 400201004002) con Moneda 4.')    
AS VALIDACION_946,

/*Resultados acumulados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400200203012')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400201204003','400201204004')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400200203012) con Moneda 4, debe ser igual a la sumatoria de las cuentas (400201204003 + 400201204004) con Moneda 4.')    
AS VALIDACION_947,

/*Resultado de ejercicios anteriores*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400201204003')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400200305001','400200305002')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400201204003) con Moneda 4, debe ser igual a la sumatoria de las cuentas (400200305001 + 400200305002) con Moneda 4.')    
AS VALIDACION_948,

/*Otros resultados integrales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400200203013')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400201304006','400201304007','400201304008','400201304009','400201304010','400201304011','400201304012','400201304013','400201304014','400201304015','400201304016','400201304017')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400200203013) con Moneda 4, debe ser igual a la sumatoria de las cuentas (400201304006 + 400201304007 + 400201304008 + 400201304009 + 400201304010 + 400201304011 + 400201304012 + 400201304013 + 400201304014 + 400201304015 + 400201304016 + 400201304017) con Moneda 4.')    
AS VALIDACION_949,

/*Valuación de instrumentos financieros para cobrar o vender*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400201304006')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400200605003','400200605004')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400201304006) con Moneda 4, debe ser igual a la sumatoria de las cuentas (400200605003 + 400200605004) con Moneda 4.')    
AS VALIDACION_950,

/*Instrumentos financieros (valores)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400200605003')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400200306001','400200306002','400200306003')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400200605003) con Moneda 4, debe ser igual a la sumatoria de las cuentas (400200306001 + 400200306002 + 400200306003) con Moneda 4.')    
AS VALIDACION_951,

/*Cartera de crédito valuada a valor razonable*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400200605004')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400200406004','400200406005','400200406006')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400200605004) con Moneda 4, debe ser igual a la sumatoria de las cuentas (400200406004 + 400200406005 + 400200406006) con Moneda 4.')    
AS VALIDACION_952,

/*Valuación de instrumentos financieros derivados de cobertura de flujos de efectivo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400201304008')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400200805005','400200805006','400200805007')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400201304008) con Moneda 4, debe ser igual a la sumatoria de las cuentas (400200805005 + 400200805006 + 400200805007) con Moneda 4.')    
AS VALIDACION_953,

/*Ingresos y gastos relacionados con activos mantenidos para su disposición*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400201304010')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400201005008','400201005009','400201005010')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400201304010) con Moneda 4, debe ser igual a la sumatoria de las cuentas (400201005008 + 400201005009 + 400201005010) con Moneda 4.')    
AS VALIDACION_954,

/*Remedición de beneficios definidos a los empleados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400201304012')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400201205011','400201205012')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400201304012) con Moneda 4, debe ser igual a la sumatoria de las cuentas (400201205011 + 400201205012) con Moneda 4.')    
AS VALIDACION_955,

/*Resultados actuariales en obligaciones*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400201205011')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400201106007','400201106008','400201106009')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400201205011) con Moneda 4, debe ser igual a la sumatoria de las cuentas (400201106007 + 400201106008 + 400201106009) con Moneda 4.')    
AS VALIDACION_956,

/*Resultado en el retorno de los activos del plan*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400201205012')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400201206010','400201206011','400201206012')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400201205012) con Moneda 4, debe ser igual a la sumatoria de las cuentas (400201206010 + 400201206011 + 400201206012) con Moneda 4.')    
AS VALIDACION_957,

/*Efecto acumulado por conversión*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400201304014')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400201405013','400201405014','400201405015')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400201304014) con Moneda 4, debe ser igual a la sumatoria de las cuentas (400201405013 + 400201405014 + 400201405015) con Moneda 4.')    
AS VALIDACION_958,

/*Resultado por tenencia de activos no monetarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400201304016')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400201605016','400201605017')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400201304016) con Moneda 4, debe ser igual a la sumatoria de las cuentas (400201605016 + 400201605017) con Moneda 4.')    
AS VALIDACION_959,

/*Participación en ORI de otras entidades*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400200203014')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('400201404018','400201404019','400201404020')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (400200203014) con Moneda 4, debe ser igual a la sumatoria de las cuentas (400201404018 + 400201404019 + 400201404020) con Moneda 4.')    
AS VALIDACION_960,

/*CUENTAS DE ORDEN*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('700000000000')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('700200001001','700400001001','700600001001','700800001001','701200001001','701400001001','701600001001','701800001001','702000001001','500200101001','600400101002','500600101003','600800201004','501000301005','601200301006','501400301007','501600301008','602000301010','502200401011','602400501012','502600601013','502800701014','503000701015')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (700000000000) con Moneda 4, debe ser igual a la sumatoria de las cuentas (700200001001 + 700400001001 + 700600001001 + 700800001001 + 701200001001 + 701400001001 + 701600001001 + 701800001001 + 702000001001 + 500200101001 + 600400101002 + 500600101003 + 600800201004 + 501000301005 + 601200301006 + 501400301007 + 501600301008 + 602000301010 + 502200401011 + 602400501012 + 502600601013 + 502800701014 + 503000701015) con Moneda 4.')    
AS VALIDACION_961,

/*Activos y pasivos contingentes*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('700400001001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('700400102001','700400102002','700400102003')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (700400001001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (700400102001 + 700400102002 + 700400102003) con Moneda 4.')    
AS VALIDACION_962,

/*Líneas de crédito irrevocables no ejercidas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('700400102001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('700400103001','700400103002','700400103003')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (700400102001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (700400103001 + 700400103002 + 700400103003) con Moneda 4.')    
AS VALIDACION_963,

/*Compromisos crediticios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('700600001001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('700600102001','700600102002','700600102003')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (700600001001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (700600102001 + 700600102002 + 700600102003) con Moneda 4.')    
AS VALIDACION_964,

/*Líneas de crédito revocables no ejercidas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('700600102002')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('700600203001','700600203002','700600203003')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (700600102002) con Moneda 4, debe ser igual a la sumatoria de las cuentas (700600203001 + 700600203002 + 700600203003) con Moneda 4.')    
AS VALIDACION_965,

/*Bienes en fideicomiso o mandato*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('700800001001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('700800102001','700800102002')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (700800001001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (700800102001 + 700800102002) con Moneda 4.')    
AS VALIDACION_966,

/*Fideicomisos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('700800102001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('700800103001','700800103002','700800103003','700800103004','700800103005')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (700800102001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (700800103001 + 700800103002 + 700800103003 + 700800103004 + 700800103005) con Moneda 4.')    
AS VALIDACION_967,

/*Bienes en custodia o en administración*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('701200001001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('701200102001','701200102002')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (701200001001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (701200102001 + 701200102002) con Moneda 4.')    
AS VALIDACION_968,

/*Bienes en custodia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('701200102001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('701200103001','701200103002','701200103003','701200103004','701200103005')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (701200102001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (701200103001 + 701200103002 + 701200103003 + 701200103004 + 701200103005) con Moneda 4.')    
AS VALIDACION_969,

/*Bienes en administración*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('701200102002')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('701200203006','701200203007')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (701200102002) con Moneda 4, debe ser igual a la sumatoria de las cuentas (701200203006 + 701200203007) con Moneda 4.')    
AS VALIDACION_970,

/*Operaciones de banca de inversión por cuenta de terceros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('701200203006')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('701200604001','701200604002','701200604003')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (701200203006) con Moneda 4, debe ser igual a la sumatoria de las cuentas (701200604001 + 701200604002 + 701200604003) con Moneda 4.')    
AS VALIDACION_971,

/*Colaterales recibidos por la entidad*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('701400001001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('701400102001','701400102002','701400102003','701400102004','701400102005','701400102006')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (701400001001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (701400102001 + 701400102002 + 701400102003 + 701400102004 + 701400102005 + 701400102006) con Moneda 4.')    
AS VALIDACION_972,

/*Colaterales recibidos y vendidos o entregados en garantía por la entidad*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('701600001001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('701600102001','701600102002','701600102003','701600102004','701600102005')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (701600001001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (701600102001 + 701600102002 + 701600102003 + 701600102004 + 701600102005) con Moneda 4.')    
AS VALIDACION_973,

/*ACTIVO = PASIVO + CAPITAL*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100000000000')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('200000000000','400000000000')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100000000000) con Moneda 4, debe ser igual a la sumatoria de las cuentas (200000000000 + 400000000000) con Moneda 4.')    
AS VALIDACION_974,

/*Ingresos por intereses*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200101001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200102001','500200102002','500200102003','500200102004','500200102005','500200102006','500200102007','500200102008','500200102009','500200102010','500200102011','500200102012','500200102013','500200102014','500200102015','500200102016')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200101001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500200102001 + 500200102002 + 500200102003 + 500200102004 + 500200102005 + 500200102006 + 500200102007 + 500200102008 + 500200102009 + 500200102010 + 500200102011 + 500200102012 + 500200102013 + 500200102014 + 500200102015 + 500200102016) con Moneda 4.')    
AS VALIDACION_975,

/*Intereses de efectivo y equivalentes de efectivo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200102001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200103001','500200103002','500200103003')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200102001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500200103001 + 500200103002 + 500200103003) con Moneda 4.')    
AS VALIDACION_976,

/*Intereses y rendimientos a favor provenientes de cuentas de margen*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200102002')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200203004','500200203005','500200203006')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200102002) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500200203004 + 500200203005 + 500200203006) con Moneda 4.')    
AS VALIDACION_977,

/*Intereses y rendimientos a favor provenientes de inversiones en instrumentos financieros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200102003')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200303007','500200303008','500200303009')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200102003) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500200303007 + 500200303008 + 500200303009) con Moneda 4.')    
AS VALIDACION_978,

/*Intereses de cartera de crédito con riesgo de crédito etapa 1*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200102006')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200603010','500200603011','500200603012')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200102006) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500200603010 + 500200603011 + 500200603012) con Moneda 4.')    
AS VALIDACION_979,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200603010')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201004001','500201004002')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200603010) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500201004001 + 500201004002) con Moneda 4.')    
AS VALIDACION_980,

/*Créditos comerciales sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201004001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200105001','500200105002','500200105003')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201004001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500200105001 + 500200105002 + 500200105003) con Moneda 4.')    
AS VALIDACION_981,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200105001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200106001','500200106002','500200106003','500200106004','500200106005','500200106006','500200106007','500200106008')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200105001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500200106001 + 500200106002 + 500200106003 + 500200106004 + 500200106005 + 500200106006 + 500200106007 + 500200106008) con Moneda 4.')    
AS VALIDACION_982,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200106001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200107001','500200107002')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200106001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500200107001 + 500200107002) con Moneda 4.')    
AS VALIDACION_983,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200106002')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200207003','500200207004','500200207005')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200106002) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500200207003 + 500200207004 + 500200207005) con Moneda 4.')    
AS VALIDACION_984,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200106003')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200307006','500200307007')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200106003) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500200307006 + 500200307007) con Moneda 4.')    
AS VALIDACION_985,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200105002')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200206009','500200206010')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200105002) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500200206009 + 500200206010) con Moneda 4.')    
AS VALIDACION_986,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200206009')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200907008','500200907009','500200907010')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200206009) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500200907008 + 500200907009 + 500200907010) con Moneda 4.')    
AS VALIDACION_987,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200206010')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201007011','500201007012','500201007013')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200206010) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500201007011 + 500201007012 + 500201007013) con Moneda 4.')    
AS VALIDACION_988,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200105003')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200306011','500200306012','500200306013','500200306014')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200105003) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500200306011 + 500200306012 + 500200306013 + 500200306014) con Moneda 4.')    
AS VALIDACION_989,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200306012')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201207014','500201207015','500201207016','500201207017','500201207018')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200306012) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500201207014 + 500201207015 + 500201207016 + 500201207017 + 500201207018) con Moneda 4.')    
AS VALIDACION_990,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200306013')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201307019','500201307020','500201307021','500201307022')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200306013) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500201307019 + 500201307020 + 500201307021 + 500201307022) con Moneda 4.')    
AS VALIDACION_991,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200306014')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201407023','500201407024','500201407025','500201407026')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200306014) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500201407023 + 500201407024 + 500201407025 + 500201407026) con Moneda 4.')    
AS VALIDACION_992,

/*Créditos comerciales restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201004002')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200205004','500200205005','500200205006')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201004002) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500200205004 + 500200205005 + 500200205006) con Moneda 4.')    
AS VALIDACION_993,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200205004')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200406015','500200406016','500200406017','500200406018','500200406019','500200406020','500200406021','500200406022')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200205004) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500200406015 + 500200406016 + 500200406017 + 500200406018 + 500200406019 + 500200406020 + 500200406021 + 500200406022) con Moneda 4.')    
AS VALIDACION_994,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200406015')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201507027','500201507028')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200406015) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500201507027 + 500201507028) con Moneda 4.')    
AS VALIDACION_995,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200406016')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201607029','500201607030','500201607031')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200406016) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500201607029 + 500201607030 + 500201607031) con Moneda 4.')    
AS VALIDACION_996,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200406017')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201707032','500201707033')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200406017) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500201707032 + 500201707033) con Moneda 4.')    
AS VALIDACION_997,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200205005')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200506023','500200506024')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200205005) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500200506023 + 500200506024) con Moneda 4.')    
AS VALIDACION_998,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200506023')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500202307034','500202307035','500202307036')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200506023) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500202307034 + 500202307035 + 500202307036) con Moneda 4.')    
AS VALIDACION_999,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200506024')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500202407037','500202407038','500202407039')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200506024) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500202407037 + 500202407038 + 500202407039) con Moneda 4.')    
AS VALIDACION_1000,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200205006')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200606025','500200606026','500200606027','500200606028')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200205006) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500200606025 + 500200606026 + 500200606027 + 500200606028) con Moneda 4.')    
AS VALIDACION_1001,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200606026')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500202607040','500202607041','500202607042','500202607043','500202607044')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200606026) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500202607040 + 500202607041 + 500202607042 + 500202607043 + 500202607044) con Moneda 4.')    
AS VALIDACION_1002,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200606027')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500202707045','500202707046','500202707047','500202707048')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200606027) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500202707045 + 500202707046 + 500202707047 + 500202707048) con Moneda 4.')    
AS VALIDACION_1003,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200606028')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500202807049','500202807050','500202807051','500202807052')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200606028) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500202807049 + 500202807050 + 500202807051 + 500202807052) con Moneda 4.')    
AS VALIDACION_1004,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200603011')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201104003','500201104004')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200603011) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500201104003 + 500201104004) con Moneda 4.')    
AS VALIDACION_1005,

/*Créditos de consumo sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201104003')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200305007','500200305008','500200305009','500200305010','500200305011','500200305012','500200305013','500200305014')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201104003) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500200305007 + 500200305008 + 500200305009 + 500200305010 + 500200305011 + 500200305012 + 500200305013 + 500200305014) con Moneda 4.')    
AS VALIDACION_1006,

/*Créditos de consumo restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201104004')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200405015','500200405016','500200405017','500200405018','500200405019','500200405020','500200405021','500200405022')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201104004) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500200405015 + 500200405016 + 500200405017 + 500200405018 + 500200405019 + 500200405020 + 500200405021 + 500200405022) con Moneda 4.')    
AS VALIDACION_1007,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200603012')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201204005','500201204006')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200603012) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500201204005 + 500201204006) con Moneda 4.')    
AS VALIDACION_1008,

/*Créditos a la vivienda sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201204005')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200505023','500200505024','500200505025','500200505026','500200505027')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201204005) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500200505023 + 500200505024 + 500200505025 + 500200505026 + 500200505027) con Moneda 4.')    
AS VALIDACION_1009,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200505025')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500202506029','500202506030','500202506031')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200505025) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500202506029 + 500202506030 + 500202506031) con Moneda 4.')    
AS VALIDACION_1010,

/*Créditos a la vivienda restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201204006')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200605028','500200605029','500200605030','500200605031','500200605032')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201204006) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500200605028 + 500200605029 + 500200605030 + 500200605031 + 500200605032) con Moneda 4.')    
AS VALIDACION_1011,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200605030')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500203006032','500203006033','500203006034')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200605030) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500203006032 + 500203006033 + 500203006034) con Moneda 4.')    
AS VALIDACION_1012,

/*Intereses de cartera de crédito con riesgo de crédito etapa 2*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200102007')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200703014','500200703015','500200703016')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200102007) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500200703014 + 500200703015 + 500200703016) con Moneda 4.')    
AS VALIDACION_1013,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200703014')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201404007','500201404008','500201404009')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200703014) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500201404007 + 500201404008 + 500201404009) con Moneda 4.')    
AS VALIDACION_1014,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201404007')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200705033','500200705034','500200705035','500200705036','500200705037','500200705038','500200705039','500200705040')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201404007) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500200705033 + 500200705034 + 500200705035 + 500200705036 + 500200705037 + 500200705038 + 500200705039 + 500200705040) con Moneda 4.')    
AS VALIDACION_1015,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200705033')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500203306035','500203306036')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200705033) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500203306035 + 500203306036) con Moneda 4.')    
AS VALIDACION_1016,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200705034')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500203406037','500203406038','500203406039')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200705034) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500203406037 + 500203406038 + 500203406039) con Moneda 4.')    
AS VALIDACION_1017,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200705035')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500203506040','500203506041')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200705035) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500203506040 + 500203506041) con Moneda 4.')    
AS VALIDACION_1018,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201404008')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200805041','500200805042')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201404008) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500200805041 + 500200805042) con Moneda 4.')    
AS VALIDACION_1019,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200805041')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500204106042','500204106043','500204106044')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200805041) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500204106042 + 500204106043 + 500204106044) con Moneda 4.')    
AS VALIDACION_1020,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200805042')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500204206045','500204206046','500204206047')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200805042) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500204206045 + 500204206046 + 500204206047) con Moneda 4.')    
AS VALIDACION_1021,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201404009')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200905043','500200905044','500200905045','500200905046')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201404009) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500200905043 + 500200905044 + 500200905045 + 500200905046) con Moneda 4.')    
AS VALIDACION_1022,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200905044')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500204406048','500204406049','500204406050','500204406051','500204406052')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200905044) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500204406048 + 500204406049 + 500204406050 + 500204406051 + 500204406052) con Moneda 4.')    
AS VALIDACION_1023,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200905045')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500204506053','500204506054','500204506055','500204506056')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200905045) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500204506053 + 500204506054 + 500204506055 + 500204506056) con Moneda 4.')    
AS VALIDACION_1024
	
INTO IFRS9_R01A_0111_M4_RESULT_4
FROM IFRS9_R01A_0111

END

BEGIN
	INSERT INTO IFRS9_R01A_0111_M4_RESULT_4
		select 'TOTAL ERRORES',  SUM(CHARINDEX('ERR',[VALIDACION_925])),
SUM(CHARINDEX('ERR',[VALIDACION_926])),
SUM(CHARINDEX('ERR',[VALIDACION_927])),
SUM(CHARINDEX('ERR',[VALIDACION_928])),
SUM(CHARINDEX('ERR',[VALIDACION_929])),
SUM(CHARINDEX('ERR',[VALIDACION_930])),
SUM(CHARINDEX('ERR',[VALIDACION_931])),
SUM(CHARINDEX('ERR',[VALIDACION_932])),
SUM(CHARINDEX('ERR',[VALIDACION_933])),
SUM(CHARINDEX('ERR',[VALIDACION_934])),
SUM(CHARINDEX('ERR',[VALIDACION_935])),
SUM(CHARINDEX('ERR',[VALIDACION_936])),
SUM(CHARINDEX('ERR',[VALIDACION_937])),
SUM(CHARINDEX('ERR',[VALIDACION_938])),
SUM(CHARINDEX('ERR',[VALIDACION_939])),
SUM(CHARINDEX('ERR',[VALIDACION_940])),
SUM(CHARINDEX('ERR',[VALIDACION_941])),
SUM(CHARINDEX('ERR',[VALIDACION_942])),
SUM(CHARINDEX('ERR',[VALIDACION_943])),
SUM(CHARINDEX('ERR',[VALIDACION_944])),
SUM(CHARINDEX('ERR',[VALIDACION_945])),
SUM(CHARINDEX('ERR',[VALIDACION_946])),
SUM(CHARINDEX('ERR',[VALIDACION_947])),
SUM(CHARINDEX('ERR',[VALIDACION_948])),
SUM(CHARINDEX('ERR',[VALIDACION_949])),
SUM(CHARINDEX('ERR',[VALIDACION_950])),
SUM(CHARINDEX('ERR',[VALIDACION_951])),
SUM(CHARINDEX('ERR',[VALIDACION_952])),
SUM(CHARINDEX('ERR',[VALIDACION_953])),
SUM(CHARINDEX('ERR',[VALIDACION_954])),
SUM(CHARINDEX('ERR',[VALIDACION_955])),
SUM(CHARINDEX('ERR',[VALIDACION_956])),
SUM(CHARINDEX('ERR',[VALIDACION_957])),
SUM(CHARINDEX('ERR',[VALIDACION_958])),
SUM(CHARINDEX('ERR',[VALIDACION_959])),
SUM(CHARINDEX('ERR',[VALIDACION_960])),
SUM(CHARINDEX('ERR',[VALIDACION_961])),
SUM(CHARINDEX('ERR',[VALIDACION_962])),
SUM(CHARINDEX('ERR',[VALIDACION_963])),
SUM(CHARINDEX('ERR',[VALIDACION_964])),
SUM(CHARINDEX('ERR',[VALIDACION_965])),
SUM(CHARINDEX('ERR',[VALIDACION_966])),
SUM(CHARINDEX('ERR',[VALIDACION_967])),
SUM(CHARINDEX('ERR',[VALIDACION_968])),
SUM(CHARINDEX('ERR',[VALIDACION_969])),
SUM(CHARINDEX('ERR',[VALIDACION_970])),
SUM(CHARINDEX('ERR',[VALIDACION_971])),
SUM(CHARINDEX('ERR',[VALIDACION_972])),
SUM(CHARINDEX('ERR',[VALIDACION_973])),
SUM(CHARINDEX('ERR',[VALIDACION_974])),
SUM(CHARINDEX('ERR',[VALIDACION_975])),
SUM(CHARINDEX('ERR',[VALIDACION_976])),
SUM(CHARINDEX('ERR',[VALIDACION_977])),
SUM(CHARINDEX('ERR',[VALIDACION_978])),
SUM(CHARINDEX('ERR',[VALIDACION_979])),
SUM(CHARINDEX('ERR',[VALIDACION_980])),
SUM(CHARINDEX('ERR',[VALIDACION_981])),
SUM(CHARINDEX('ERR',[VALIDACION_982])),
SUM(CHARINDEX('ERR',[VALIDACION_983])),
SUM(CHARINDEX('ERR',[VALIDACION_984])),
SUM(CHARINDEX('ERR',[VALIDACION_985])),
SUM(CHARINDEX('ERR',[VALIDACION_986])),
SUM(CHARINDEX('ERR',[VALIDACION_987])),
SUM(CHARINDEX('ERR',[VALIDACION_988])),
SUM(CHARINDEX('ERR',[VALIDACION_989])),
SUM(CHARINDEX('ERR',[VALIDACION_990])),
SUM(CHARINDEX('ERR',[VALIDACION_991])),
SUM(CHARINDEX('ERR',[VALIDACION_992])),
SUM(CHARINDEX('ERR',[VALIDACION_993])),
SUM(CHARINDEX('ERR',[VALIDACION_994])),
SUM(CHARINDEX('ERR',[VALIDACION_995])),
SUM(CHARINDEX('ERR',[VALIDACION_996])),
SUM(CHARINDEX('ERR',[VALIDACION_997])),
SUM(CHARINDEX('ERR',[VALIDACION_998])),
SUM(CHARINDEX('ERR',[VALIDACION_999])),
SUM(CHARINDEX('ERR',[VALIDACION_1000])),
SUM(CHARINDEX('ERR',[VALIDACION_1001])),
SUM(CHARINDEX('ERR',[VALIDACION_1002])),
SUM(CHARINDEX('ERR',[VALIDACION_1003])),
SUM(CHARINDEX('ERR',[VALIDACION_1004])),
SUM(CHARINDEX('ERR',[VALIDACION_1005])),
SUM(CHARINDEX('ERR',[VALIDACION_1006])),
SUM(CHARINDEX('ERR',[VALIDACION_1007])),
SUM(CHARINDEX('ERR',[VALIDACION_1008])),
SUM(CHARINDEX('ERR',[VALIDACION_1009])),
SUM(CHARINDEX('ERR',[VALIDACION_1010])),
SUM(CHARINDEX('ERR',[VALIDACION_1011])),
SUM(CHARINDEX('ERR',[VALIDACION_1012])),
SUM(CHARINDEX('ERR',[VALIDACION_1013])),
SUM(CHARINDEX('ERR',[VALIDACION_1014])),
SUM(CHARINDEX('ERR',[VALIDACION_1015])),
SUM(CHARINDEX('ERR',[VALIDACION_1016])),
SUM(CHARINDEX('ERR',[VALIDACION_1017])),
SUM(CHARINDEX('ERR',[VALIDACION_1018])),
SUM(CHARINDEX('ERR',[VALIDACION_1019])),
SUM(CHARINDEX('ERR',[VALIDACION_1020])),
SUM(CHARINDEX('ERR',[VALIDACION_1021])),
SUM(CHARINDEX('ERR',[VALIDACION_1022])),
SUM(CHARINDEX('ERR',[VALIDACION_1023])),
SUM(CHARINDEX('ERR',[VALIDACION_1024]))


		from IFRS9_R01A_0111_M4_RESULT_4
END

BEGIN
	EXEC SP_IFRS9_R01A_0111_M4_VIEW_4
END

COMMIT


END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


