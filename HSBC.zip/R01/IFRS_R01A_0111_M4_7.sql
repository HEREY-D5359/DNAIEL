﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Serie R01 Catálogo mínimo */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: Julio 2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/

/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 4*/
/*TIPO SALDO: NA*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER  PROCEDURE [dbo].[SP_IFRS9_R01A_0111_M4_COMP_7]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R01A_0111_M4_RESULT_7')
BEGIN
DROP TABLE IFRS9_R01A_0111_M4_RESULT_7
END 

BEGIN
SELECT DISTINCT

/*ID*/
	CONVERT(VARCHAR,ID) AS ID, 

	/*Resultado del ejercicio de subsidiarias no consolidadas, asociadas y negocios conjuntos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502201102131')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502213103094','502213103095','502213103096')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502201102131) con Moneda 4, debe ser igual a la sumatoria de las cuentas (502213103094 + 502213103095 + 502213103096) con Moneda 4.')    
AS VALIDACION_1225,

/*En subsidiarias no consolidadas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502213103094')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502209404117','502209404118')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502213103094) con Moneda 4, debe ser igual a la sumatoria de las cuentas (502209404117 + 502209404118) con Moneda 4.')    
AS VALIDACION_1226,

/*En asociadas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502213103095')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502209504119','502209504120')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502213103095) con Moneda 4, debe ser igual a la sumatoria de las cuentas (502209504119 + 502209504120) con Moneda 4.')    
AS VALIDACION_1227,

/*En negocios conjuntos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502213103096')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502209604121','502209604122')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502213103096) con Moneda 4, debe ser igual a la sumatoria de las cuentas (502209604121 + 502209604122) con Moneda 4.')    
AS VALIDACION_1228,

/*Impuestos a la utilidad*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602400501012')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602401202137','602401202138','602401202139','602401202140')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (602400501012) con Moneda 4, debe ser igual a la sumatoria de las cuentas (602401202137 + 602401202138 + 602401202139 + 602401202140) con Moneda 4.')    
AS VALIDACION_1229,

/*Impuestos a la utilidad causados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602401202137')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602413703097','602413703098')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (602401202137) con Moneda 4, debe ser igual a la sumatoria de las cuentas (602413703097 + 602413703098) con Moneda 4.')    
AS VALIDACION_1230,

/*Impuestos a la utilidad diferidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602401202138')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602413803099','602413803100','602413803101')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (602401202138) con Moneda 4, debe ser igual a la sumatoria de las cuentas (602413803099 + 602413803100 + 602413803101) con Moneda 4.')    
AS VALIDACION_1231,

/*Estimación por impuestos a la utilidad no recuperables*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602401202139')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602413903102','602413903103','602413903104')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (602401202139) con Moneda 4, debe ser igual a la sumatoria de las cuentas (602413903102 + 602413903103 + 602413903104) con Moneda 4.')    
AS VALIDACION_1232,

/*Operaciones discontinuadas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502600601013')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502601302141','502601302142')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502600601013) con Moneda 4, debe ser igual a la sumatoria de las cuentas (502601302141 + 502601302142) con Moneda 4.')    
AS VALIDACION_1233,

/*Otros resultados integrales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502800701014')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502801402143','502801402144','502801402145','502801402146','502801402147','502801402148')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502800701014) con Moneda 4, debe ser igual a la sumatoria de las cuentas (502801402143 + 502801402144 + 502801402145 + 502801402146 + 502801402147 + 502801402148) con Moneda 4.')    
AS VALIDACION_1234,

/*Valuación de instrumentos financieros para cobrar o vender*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502801402143')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502814303105','502814303106')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502801402143) con Moneda 4, debe ser igual a la sumatoria de las cuentas (502814303105 + 502814303106) con Moneda 4.')    
AS VALIDACION_1235,

/*Efecto del periodo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502814303105')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502810504123','502810504124','502810504125')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502814303105) con Moneda 4, debe ser igual a la sumatoria de las cuentas (502810504123 + 502810504124 + 502810504125) con Moneda 4.')    
AS VALIDACION_1236,

/*Valuación de instrumentos financieros derivados de cobertura de flujos de efectivo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502801402144')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502814403107','502814403108')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502801402144) con Moneda 4, debe ser igual a la sumatoria de las cuentas (502814403107 + 502814403108) con Moneda 4.')    
AS VALIDACION_1237,

/*Efecto del periodo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502814403107')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502810704126','502810704127','502810704128')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502814403107) con Moneda 4, debe ser igual a la sumatoria de las cuentas (502810704126 + 502810704127 + 502810704128) con Moneda 4.')    
AS VALIDACION_1238,

/*Ingresos y gastos relacionados con activos mantenidos para su disposición*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502801402145')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502814503109','502814503110')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502801402145) con Moneda 4, debe ser igual a la sumatoria de las cuentas (502814503109 + 502814503110) con Moneda 4.')    
AS VALIDACION_1239,

/*Efecto del periodo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502814503109')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502810904129','502810904130','502810904131')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502814503109) con Moneda 4, debe ser igual a la sumatoria de las cuentas (502810904129 + 502810904130 + 502810904131) con Moneda 4.')    
AS VALIDACION_1240,

/*Remedición de beneficios definidos a los empleados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502801402146')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502814603111','502814603112')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502801402146) con Moneda 4, debe ser igual a la sumatoria de las cuentas (502814603111 + 502814603112) con Moneda 4.')    
AS VALIDACION_1241,

/*Efecto del periodo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502814603111')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502811104132','502811104133','502811104134')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502814603111) con Moneda 4, debe ser igual a la sumatoria de las cuentas (502811104132 + 502811104133 + 502811104134) con Moneda 4.')    
AS VALIDACION_1242,

/*Efecto acumulado por conversión*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502801402147')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502814703113','502814703114')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502801402147) con Moneda 4, debe ser igual a la sumatoria de las cuentas (502814703113 + 502814703114) con Moneda 4.')    
AS VALIDACION_1243,

/*Efecto del periodo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502814703113')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502811304135','502811304136','502811304137')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502814703113) con Moneda 4, debe ser igual a la sumatoria de las cuentas (502811304135 + 502811304136 + 502811304137) con Moneda 4.')    
AS VALIDACION_1244,

/*Resultado por tenencia de activos no monetarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502801402148')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502814803115','502814803116')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502801402148) con Moneda 4, debe ser igual a la sumatoria de las cuentas (502814803115 + 502814803116) con Moneda 4.')    
AS VALIDACION_1245,

/*Efecto del periodo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502814803115')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502811504138','502811504139','502811504140')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502814803115) con Moneda 4, debe ser igual a la sumatoria de las cuentas (502811504138 + 502811504139 + 502811504140) con Moneda 4.')    
AS VALIDACION_1246,

/*Participación en ORI de otras entidades*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('503000701015')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('503001502149')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (503000701015) con Moneda 4, debe ser igual a la sumatoria de las cuentas (503001502149) con Moneda 4.')    
AS VALIDACION_1247,

/*Efecto del periodo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('503001502149')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('503014903117','503014903118','503014903119')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (503001502149) con Moneda 4, debe ser igual a la sumatoria de las cuentas (503014903117 + 503014903118 + 503014903119) con Moneda 4.')    
AS VALIDACION_1248,

/* VALIDACION Tipo de Dato */

 IIF(ISNUMERIC(c04_concepto)=0,   CONCAT('ERROR: EN LA FILA: ',ID,', El campo CONCEPTO (',[c04_concepto],') no es numerico.'),'') as VALIDACION_1249,

/* VALIDACION Longitud */

IIF(LEN([c04_concepto])>12, CONCAT('ERROR: EN LA FILA: ',ID,', El campo CONCEPTO (',[c04_concepto],') tiene una longitud mayor a 12 caracteres.'), '')  AS VALIDACION_1250,

/* VALIDACION Decimales */

IIF(CHARINDEX('.',[c04_concepto])>0, CONCAT('ERROR: EN LA FILA: ',ID,', El campo CONCEPTO (',[c04_concepto],') no puede tener mas de 0 decimales.'),'')  AS VALIDACION_1251,

/* VALIDACION Obligatorio */

IIF([c04_concepto] IS NULL or [c04_concepto] = '' ,   CONCAT('ERROR: EN LA FILA: ',ID,', El campo CONCEPTO (',[c04_concepto],') es obligatorio, no puede estar vacío.'),'')  AS VALIDACION_1252,

/* VALIDACION Caracteres especiales */

IIF(PATINDEX('%[^0-9].%', [c04_concepto]) <> 0 ,   CONCAT('ERROR: EN LA FILA: ',ID,',  El campo CONCEPTO (',[c04_concepto],') no puede tener caracteres especiales ni espacios en blanco.'),'')  AS VALIDACION_1253,

/* VALIDACION Tipo de Dato */

 IIF(ISNUMERIC([c04_concepto])=0,   CONCAT('ERROR: EN LA FILA: ',ID,', El campo MONEDA (',[c05_moneda],') no es numerico.'),'') as VALIDACION_1254,

/* VALIDACION Longitud */

IIF(LEN([c05_moneda])>4, CONCAT('ERROR: EN LA FILA: ',ID,', El campo MONEDA (',[c05_moneda],') tiene una longitud mayor a 4 caracteres.'), '')  AS VALIDACION_1255,

/* VALIDACION Decimales */

IIF(CHARINDEX('.',[c05_moneda])>0, CONCAT('ERROR: EN LA FILA: ',ID,', El campo MONEDA (',[c05_moneda],') no puede tener mas de 0 decimales.'),'')  AS VALIDACION_1256,

/* VALIDACION Obligatorio */

IIF([c05_moneda] IS NULL or [c05_moneda] = '' ,   CONCAT('ERROR: EN LA FILA: ',ID,', El campo MONEDA (',[c05_moneda],') es obligatorio, no puede estar vacío.'),'')  AS VALIDACION_1257,

/* VALIDACION Caracteres especiales */

IIF(PATINDEX('%[^0-9].%', [c05_moneda]) <> 0 ,   CONCAT('ERROR: EN LA FILA: ',ID,',  El campo MONEDA (',[c05_moneda],') no puede tener caracteres especiales ni espacios en blanco.'),'')  AS VALIDACION_1258,

/* VALIDACION Catalogo */

 IIF(CONVERT(decimal,[c05_moneda]) not in (4,14),   CONCAT('ERROR: EN LA FILA: ',ID,', El campo MONEDA (',[c05_moneda],') no está dentro de los valores permitidos (4,14).'),'') as VALIDACION_1259,


/* VALIDACION Tipo de Dato */

 IIF(ISNUMERIC([c05_moneda])=0,   CONCAT('ERROR: EN LA FILA: ',ID,', El campo DATO (',[c06_dato],') no es numerico.'),'') as VALIDACION_1260,

/* VALIDACION Longitud */

IIF(LEN([c06_dato])>21, CONCAT('ERROR: EN LA FILA: ',ID,', El campo DATO (',[c06_dato],') tiene una longitud mayor a 21 caracteres.'), '')  AS VALIDACION_1261,

/* VALIDACION Decimales */

IIF(CHARINDEX('.',[c06_dato])>2, CONCAT('ERROR: EN LA FILA: ',ID,', El campo DATO (',[c06_dato],') no puede tener mas de 2 decimales.'),'')  AS VALIDACION_1262,

/* VALIDACION Obligatorio */

IIF([c06_dato] IS NULL or [c06_dato] = '' ,   CONCAT('ERROR: EN LA FILA: ',ID,', El campo DATO (',[c06_dato],') es obligatorio, no puede estar vacío.'),'')  AS VALIDACION_1263,

/* VALIDACION Caracteres especiales */

IIF(PATINDEX('%[^0-9].%', [c06_dato]) <> 0 ,   CONCAT('ERROR: EN LA FILA: ',ID,',  El campo DATO (',[c06_dato],') no puede tener caracteres especiales ni espacios en blanco.'),'')  AS VALIDACION_1264

	
INTO IFRS9_R01A_0111_M4_RESULT_7
FROM IFRS9_R01A_0111

END

BEGIN
	INSERT INTO IFRS9_R01A_0111_M4_RESULT_7
		select 'TOTAL ERRORES',  SUM(CHARINDEX('ERR',[VALIDACION_1225])),
SUM(CHARINDEX('ERR',[VALIDACION_1226])),
SUM(CHARINDEX('ERR',[VALIDACION_1227])),
SUM(CHARINDEX('ERR',[VALIDACION_1228])),
SUM(CHARINDEX('ERR',[VALIDACION_1229])),
SUM(CHARINDEX('ERR',[VALIDACION_1230])),
SUM(CHARINDEX('ERR',[VALIDACION_1231])),
SUM(CHARINDEX('ERR',[VALIDACION_1232])),
SUM(CHARINDEX('ERR',[VALIDACION_1233])),
SUM(CHARINDEX('ERR',[VALIDACION_1234])),
SUM(CHARINDEX('ERR',[VALIDACION_1235])),
SUM(CHARINDEX('ERR',[VALIDACION_1236])),
SUM(CHARINDEX('ERR',[VALIDACION_1237])),
SUM(CHARINDEX('ERR',[VALIDACION_1238])),
SUM(CHARINDEX('ERR',[VALIDACION_1239])),
SUM(CHARINDEX('ERR',[VALIDACION_1240])),
SUM(CHARINDEX('ERR',[VALIDACION_1241])),
SUM(CHARINDEX('ERR',[VALIDACION_1242])),
SUM(CHARINDEX('ERR',[VALIDACION_1243])),
SUM(CHARINDEX('ERR',[VALIDACION_1244])),
SUM(CHARINDEX('ERR',[VALIDACION_1245])),
SUM(CHARINDEX('ERR',[VALIDACION_1246])),
SUM(CHARINDEX('ERR',[VALIDACION_1247])),
SUM(CHARINDEX('ERR',[VALIDACION_1248])),
SUM(CHARINDEX('ERR',[VALIDACION_1249])),
SUM(CHARINDEX('ERR',[VALIDACION_1250])),
SUM(CHARINDEX('ERR',[VALIDACION_1251])),
SUM(CHARINDEX('ERR',[VALIDACION_1252])),
SUM(CHARINDEX('ERR',[VALIDACION_1253])),
SUM(CHARINDEX('ERR',[VALIDACION_1254])),
SUM(CHARINDEX('ERR',[VALIDACION_1255])),
SUM(CHARINDEX('ERR',[VALIDACION_1256])),
SUM(CHARINDEX('ERR',[VALIDACION_1257])),
SUM(CHARINDEX('ERR',[VALIDACION_1258])),
SUM(CHARINDEX('ERR',[VALIDACION_1259])),
SUM(CHARINDEX('ERR',[VALIDACION_1260])),
SUM(CHARINDEX('ERR',[VALIDACION_1261])),
SUM(CHARINDEX('ERR',[VALIDACION_1262])),
SUM(CHARINDEX('ERR',[VALIDACION_1263])),
SUM(CHARINDEX('ERR',[VALIDACION_1264]))


		from IFRS9_R01A_0111_M4_RESULT_7
END

BEGIN
	EXEC SP_IFRS9_R01A_0111_M4_VIEW_7
END

COMMIT


END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


