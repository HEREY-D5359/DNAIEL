﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Serie R01 Catálogo mínimo */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: Julio 2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/



/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 14*/
/*TIPO SALDO: NA*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER  PROCEDURE [dbo].[SP_IFRS9_R01A_0111_M14_COMP_7]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R01A_0111_M14_RESULT_7')
BEGIN
DROP TABLE IFRS9_R01A_0111_M14_RESULT_7
END 

BEGIN
SELECT DISTINCT

	/*ID*/
	CONVERT(VARCHAR,ID) AS ID, 

	/*Resultado del ejercicio de subsidiarias no consolidadas, asociadas y negocios conjuntos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502201102131')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502213103094','502213103095','502213103096')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502201102131) con MONEDA 14, debe ser igual a la sumatoria de las cuentas (502213103094 + 502213103095 + 502213103096) con MONEDA 14.')    
AS VALIDACION_601,

/*En subsidiarias no consolidadas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502213103094')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502209404117','502209404118')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502213103094) con MONEDA 14, debe ser igual a la sumatoria de las cuentas (502209404117 + 502209404118) con MONEDA 14.')    
AS VALIDACION_602,

/*En asociadas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502213103095')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502209504119','502209504120')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502213103095) con MONEDA 14, debe ser igual a la sumatoria de las cuentas (502209504119 + 502209504120) con MONEDA 14.')    
AS VALIDACION_603,

/*En negocios conjuntos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502213103096')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502209604121','502209604122')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502213103096) con MONEDA 14, debe ser igual a la sumatoria de las cuentas (502209604121 + 502209604122) con MONEDA 14.')    
AS VALIDACION_604,

/*Impuestos a la utilidad*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602400501012')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602401202137','602401202138','602401202139','602401202140')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (602400501012) con MONEDA 14, debe ser igual a la sumatoria de las cuentas (602401202137 + 602401202138 + 602401202139 + 602401202140) con MONEDA 14.')    
AS VALIDACION_605,

/*Impuestos a la utilidad causados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602401202137')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602413703097','602413703098')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (602401202137) con MONEDA 14, debe ser igual a la sumatoria de las cuentas (602413703097 + 602413703098) con MONEDA 14.')    
AS VALIDACION_606,

/*Impuestos a la utilidad diferidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602401202138')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602413803099','602413803100','602413803101')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (602401202138) con MONEDA 14, debe ser igual a la sumatoria de las cuentas (602413803099 + 602413803100 + 602413803101) con MONEDA 14.')    
AS VALIDACION_607,

/*Estimación por impuestos a la utilidad no recuperables*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602401202139')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602413903102','602413903103','602413903104')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (602401202139) con MONEDA 14, debe ser igual a la sumatoria de las cuentas (602413903102 + 602413903103 + 602413903104) con MONEDA 14.')    
AS VALIDACION_608,

/*Operaciones discontinuadas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502600601013')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502601302141','502601302142')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502600601013) con MONEDA 14, debe ser igual a la sumatoria de las cuentas (502601302141 + 502601302142) con MONEDA 14.')    
AS VALIDACION_609,

/*Otros resultados integrales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502800701014')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502801402143','502801402144','502801402145','502801402146','502801402147','502801402148')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502800701014) con MONEDA 14, debe ser igual a la sumatoria de las cuentas (502801402143 + 502801402144 + 502801402145 + 502801402146 + 502801402147 + 502801402148) con MONEDA 14.')    
AS VALIDACION_610,

/*Valuación de instrumentos financieros para cobrar o vender*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502801402143')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502814303105','502814303106')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502801402143) con MONEDA 14, debe ser igual a la sumatoria de las cuentas (502814303105 + 502814303106) con MONEDA 14.')    
AS VALIDACION_611,

/*Efecto del periodo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502814303105')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502810504123','502810504124','502810504125')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502814303105) con MONEDA 14, debe ser igual a la sumatoria de las cuentas (502810504123 + 502810504124 + 502810504125) con MONEDA 14.')    
AS VALIDACION_612,

/*Valuación de instrumentos financieros derivados de cobertura de flujos de efectivo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502801402144')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502814403107','502814403108')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502801402144) con MONEDA 14, debe ser igual a la sumatoria de las cuentas (502814403107 + 502814403108) con MONEDA 14.')    
AS VALIDACION_613,

/*Efecto del periodo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502814403107')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502810704126','502810704127','502810704128')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502814403107) con MONEDA 14, debe ser igual a la sumatoria de las cuentas (502810704126 + 502810704127 + 502810704128) con MONEDA 14.')    
AS VALIDACION_614,

/*Ingresos y gastos relacionados con activos mantenidos para su disposición*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502801402145')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502814503109','502814503110')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502801402145) con MONEDA 14, debe ser igual a la sumatoria de las cuentas (502814503109 + 502814503110) con MONEDA 14.')    
AS VALIDACION_615,

/*Efecto del periodo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502814503109')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502810904129','502810904130','502810904131')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502814503109) con MONEDA 14, debe ser igual a la sumatoria de las cuentas (502810904129 + 502810904130 + 502810904131) con MONEDA 14.')    
AS VALIDACION_616,

/*Remedición de beneficios definidos a los empleados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502801402146')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502814603111','502814603112')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502801402146) con MONEDA 14, debe ser igual a la sumatoria de las cuentas (502814603111 + 502814603112) con MONEDA 14.')    
AS VALIDACION_617,

/*Efecto del periodo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502814603111')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502811104132','502811104133','502811104134')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502814603111) con MONEDA 14, debe ser igual a la sumatoria de las cuentas (502811104132 + 502811104133 + 502811104134) con MONEDA 14.')    
AS VALIDACION_618,

/*Efecto acumulado por conversión*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502801402147')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502814703113','502814703114')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502801402147) con MONEDA 14, debe ser igual a la sumatoria de las cuentas (502814703113 + 502814703114) con MONEDA 14.')    
AS VALIDACION_619,

/*Efecto del periodo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502814703113')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502811304135','502811304136','502811304137')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502814703113) con MONEDA 14, debe ser igual a la sumatoria de las cuentas (502811304135 + 502811304136 + 502811304137) con MONEDA 14.')    
AS VALIDACION_620,

/*Resultado por tenencia de activos no monetarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502801402148')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502814803115','502814803116')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502801402148) con MONEDA 14, debe ser igual a la sumatoria de las cuentas (502814803115 + 502814803116) con MONEDA 14.')    
AS VALIDACION_621,

/*Efecto del periodo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502814803115')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502811504138','502811504139','502811504140')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502814803115) con MONEDA 14, debe ser igual a la sumatoria de las cuentas (502811504138 + 502811504139 + 502811504140) con MONEDA 14.')    
AS VALIDACION_622,

/*Participación en ORI de otras entidades*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('503000701015')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('503001502149')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (503000701015) con MONEDA 14, debe ser igual a la sumatoria de las cuentas (503001502149) con MONEDA 14.')    
AS VALIDACION_623,

/*Efecto del periodo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('503001502149')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('503014903117','503014903118','503014903119')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (503001502149) con MONEDA 14, debe ser igual a la sumatoria de las cuentas (503014903117 + 503014903118 + 503014903119) con MONEDA 14.')    
AS VALIDACION_624
	
INTO IFRS9_R01A_0111_M14_RESULT_7
FROM IFRS9_R01A_0111

END

BEGIN
	INSERT INTO IFRS9_R01A_0111_M14_RESULT_7
		select 'TOTAL ERRORES',  SUM(CHARINDEX('ERR',[VALIDACION_601])),
SUM(CHARINDEX('ERR',[VALIDACION_602])),
SUM(CHARINDEX('ERR',[VALIDACION_603])),
SUM(CHARINDEX('ERR',[VALIDACION_604])),
SUM(CHARINDEX('ERR',[VALIDACION_605])),
SUM(CHARINDEX('ERR',[VALIDACION_606])),
SUM(CHARINDEX('ERR',[VALIDACION_607])),
SUM(CHARINDEX('ERR',[VALIDACION_608])),
SUM(CHARINDEX('ERR',[VALIDACION_609])),
SUM(CHARINDEX('ERR',[VALIDACION_610])),
SUM(CHARINDEX('ERR',[VALIDACION_611])),
SUM(CHARINDEX('ERR',[VALIDACION_612])),
SUM(CHARINDEX('ERR',[VALIDACION_613])),
SUM(CHARINDEX('ERR',[VALIDACION_614])),
SUM(CHARINDEX('ERR',[VALIDACION_615])),
SUM(CHARINDEX('ERR',[VALIDACION_616])),
SUM(CHARINDEX('ERR',[VALIDACION_617])),
SUM(CHARINDEX('ERR',[VALIDACION_618])),
SUM(CHARINDEX('ERR',[VALIDACION_619])),
SUM(CHARINDEX('ERR',[VALIDACION_620])),
SUM(CHARINDEX('ERR',[VALIDACION_621])),
SUM(CHARINDEX('ERR',[VALIDACION_622])),
SUM(CHARINDEX('ERR',[VALIDACION_623])),
SUM(CHARINDEX('ERR',[VALIDACION_624]))

		from IFRS9_R01A_0111_M14_RESULT_7
END

BEGIN
	EXEC SP_IFRS9_R01A_0111_M14_VIEW_7
END

COMMIT


END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


