﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Serie R01 Catálogo mínimo */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: Julio 2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/

/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 4*/
/*TIPO SALDO: NA*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER  PROCEDURE [dbo].[SP_IFRS9_R01A_0111_M4_COMP_5]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R01A_0111_M4_RESULT_5')
BEGIN
DROP TABLE IFRS9_R01A_0111_M4_RESULT_5
END 

BEGIN
SELECT DISTINCT

	/*ID*/

	CONVERT(VARCHAR,ID)  AS ID,   
	/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200905046')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500204606057','500204606058','500204606059','500204606060')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200905046) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500204606057 + 500204606058 + 500204606059 + 500204606060) con Moneda 4.')    
AS VALIDACION_1025,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200703015')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201504010','500201504011','500201504012','500201504013','500201504014','500201504015','500201504016','500201504017')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200703015) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500201504010 + 500201504011 + 500201504012 + 500201504013 + 500201504014 + 500201504015 + 500201504016 + 500201504017) con Moneda 4.')    
AS VALIDACION_1026,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200703016')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201604018','500201604019','500201604020','500201604021','500201604022')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200703016) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500201604018 + 500201604019 + 500201604020 + 500201604021 + 500201604022) con Moneda 4.')    
AS VALIDACION_1027,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201604020')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500202005047','500202005048')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201604020) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500202005047 + 500202005048) con Moneda 4.')    
AS VALIDACION_1028,

/*Intereses de cartera de crédito con riesgo de crédito etapa 3*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200102008')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200803017','500200803018','500200803019')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200102008) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500200803017 + 500200803018 + 500200803019) con Moneda 4.')    
AS VALIDACION_1029,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200803017')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201704023','500201704024','500201704025')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200803017) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500201704023 + 500201704024 + 500201704025) con Moneda 4.')    
AS VALIDACION_1030,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201704023')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500202305049','500202305050','500202305051','500202305052','500202305053','500202305054','500202305055','500202305056')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201704023) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500202305049 + 500202305050 + 500202305051 + 500202305052 + 500202305053 + 500202305054 + 500202305055 + 500202305056) con Moneda 4.')    
AS VALIDACION_1031,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500202305049')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500204906061','500204906062')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500202305049) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500204906061 + 500204906062) con Moneda 4.')    
AS VALIDACION_1032,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500202305050')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500205006063','500205006064','500205006065')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500202305050) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500205006063 + 500205006064 + 500205006065) con Moneda 4.')    
AS VALIDACION_1033,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500202305051')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500205106066','500205106067')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500202305051) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500205106066 + 500205106067) con Moneda 4.')    
AS VALIDACION_1034,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201704024')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500202405057','500202405058')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201704024) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500202405057 + 500202405058) con Moneda 4.')    
AS VALIDACION_1035,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500202405057')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500205706068','500205706069','500205706070')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500202405057) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500205706068 + 500205706069 + 500205706070) con Moneda 4.')    
AS VALIDACION_1036,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500202405058')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500205806071','500205806072','500205806073')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500202405058) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500205806071 + 500205806072 + 500205806073) con Moneda 4.')    
AS VALIDACION_1037,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201704025')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500202505059','500202505060','500202505061','500202505062')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201704025) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500202505059 + 500202505060 + 500202505061 + 500202505062) con Moneda 4.')    
AS VALIDACION_1038,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500202505060')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500206006074','500206006075','500206006076','500206006077','500206006078')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500202505060) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500206006074 + 500206006075 + 500206006076 + 500206006077 + 500206006078) con Moneda 4.')    
AS VALIDACION_1039,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500202505061')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500206106079','500206106080','500206106081','500206106082')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500202505061) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500206106079 + 500206106080 + 500206106081 + 500206106082) con Moneda 4.')    
AS VALIDACION_1040,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500202505062')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500206206083','500206206084','500206206085','500206206086')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500202505062) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500206206083 + 500206206084 + 500206206085 + 500206206086) con Moneda 4.')    
AS VALIDACION_1041,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200803018')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201804026','500201804027','500201804028','500201804029','500201804030','500201804031','500201804032','500201804033')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200803018) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500201804026 + 500201804027 + 500201804028 + 500201804029 + 500201804030 + 500201804031 + 500201804032 + 500201804033) con Moneda 4.')    
AS VALIDACION_1042,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200803019')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201904034','500201904035','500201904036','500201904037','500201904038')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200803019) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500201904034 + 500201904035 + 500201904036 + 500201904037 + 500201904038) con Moneda 4.')    
AS VALIDACION_1043,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201904036')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500203605063','500203605064')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201904036) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500203605063 + 500203605064) con Moneda 4.')    
AS VALIDACION_1044,

/*Ingresos por cartera de crédito valuada a valor razonable*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200102009')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200903020','500200903021','500200903022')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200102009) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500200903020 + 500200903021 + 500200903022) con Moneda 4.')    
AS VALIDACION_1045,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200903020')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500202004039','500202004040','500202004041')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200903020) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500202004039 + 500202004040 + 500202004041) con Moneda 4.')    
AS VALIDACION_1046,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500202004039')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500203905065','500203905066','500203905067','500203905068','500203905069','500203905070','500203905071','500203905072')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500202004039) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500203905065 + 500203905066 + 500203905067 + 500203905068 + 500203905069 + 500203905070 + 500203905071 + 500203905072) con Moneda 4.')    
AS VALIDACION_1047,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500203905065')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500206506087','500206506088')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500203905065) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500206506087 + 500206506088) con Moneda 4.')    
AS VALIDACION_1048,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500203905066')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500206606089','500206606090','500206606091')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500203905066) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500206606089 + 500206606090 + 500206606091) con Moneda 4.')    
AS VALIDACION_1049,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500203905067')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500206706092','500206706093')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500203905067) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500206706092 + 500206706093) con Moneda 4.')    
AS VALIDACION_1050,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500202004040')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500204005073','500204005074')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500202004040) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500204005073 + 500204005074) con Moneda 4.')    
AS VALIDACION_1051,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500204005073')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500207306094','500207306095','500207306096')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500204005073) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500207306094 + 500207306095 + 500207306096) con Moneda 4.')    
AS VALIDACION_1052,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500204005074')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500207406097','500207406098','500207406099')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500204005074) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500207406097 + 500207406098 + 500207406099) con Moneda 4.')    
AS VALIDACION_1053,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500202004041')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500204105075','500204105076','500204105077','500204105078')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500202004041) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500204105075 + 500204105076 + 500204105077 + 500204105078) con Moneda 4.')    
AS VALIDACION_1054,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500204105076')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500207606100','500207606101','500207606102','500207606103','500207606104')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500204105076) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500207606100 + 500207606101 + 500207606102 + 500207606103 + 500207606104) con Moneda 4.')    
AS VALIDACION_1055,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500204105077')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500207706105','500207706106','500207706107','500207706108')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500204105077) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500207706105 + 500207706106 + 500207706107 + 500207706108) con Moneda 4.')    
AS VALIDACION_1056,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500204105078')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500207806109','500207806110','500207806111','500207806112')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500204105078) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500207806109 + 500207806110 + 500207806111 + 500207806112) con Moneda 4.')    
AS VALIDACION_1057,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200903021')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500202104042','500202104043','500202104044','500202104045','500202104046','500202104047','500202104048','500202104049')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200903021) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500202104042 + 500202104043 + 500202104044 + 500202104045 + 500202104046 + 500202104047 + 500202104048 + 500202104049) con Moneda 4.')    
AS VALIDACION_1058,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200903022')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500202204050','500202204051','500202204052','500202204053','500202204054')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200903022) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500202204050 + 500202204051 + 500202204052 + 500202204053 + 500202204054) con Moneda 4.')    
AS VALIDACION_1059,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500202204052')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500205205079','500205205080')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500202204052) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500205205079 + 500205205080) con Moneda 4.')    
AS VALIDACION_1060,

/*Comisiones por el otorgamiento del crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200102011')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201103023','500201103024','500201103025')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200102011) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500201103023 + 500201103024 + 500201103025) con Moneda 4.')    
AS VALIDACION_1061,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201103023')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500202304055','500202304056','500202304057')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201103023) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500202304055 + 500202304056 + 500202304057) con Moneda 4.')    
AS VALIDACION_1062,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500202304055')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500205505081','500205505082','500205505083','500205505084','500205505085','500205505086','500205505087','500205505088')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500202304055) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500205505081 + 500205505082 + 500205505083 + 500205505084 + 500205505085 + 500205505086 + 500205505087 + 500205505088) con Moneda 4.')    
AS VALIDACION_1063,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500205505081')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500208106113','500208106114')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500205505081) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500208106113 + 500208106114) con Moneda 4.')    
AS VALIDACION_1064,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500205505082')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500208206115','500208206116','500208206117')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500205505082) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500208206115 + 500208206116 + 500208206117) con Moneda 4.')    
AS VALIDACION_1065,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500205505083')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500208306118','500208306119')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500205505083) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500208306118 + 500208306119) con Moneda 4.')    
AS VALIDACION_1066,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500202304056')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500205605089','500205605090')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500202304056) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500205605089 + 500205605090) con Moneda 4.')    
AS VALIDACION_1067,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500205605089')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500208906120','500208906121','500208906122')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500205605089) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500208906120 + 500208906121 + 500208906122) con Moneda 4.')    
AS VALIDACION_1068,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500205605090')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500209006123','500209006124','500209006125')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500205605090) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500209006123 + 500209006124 + 500209006125) con Moneda 4.')    
AS VALIDACION_1069,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500202304057')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500205705091','500205705092','500205705093','500205705094')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500202304057) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500205705091 + 500205705092 + 500205705093 + 500205705094) con Moneda 4.')    
AS VALIDACION_1070,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500205705092')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500209206126','500209206127','500209206128','500209206129','500209206130')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500205705092) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500209206126 + 500209206127 + 500209206128 + 500209206129 + 500209206130) con Moneda 4.')    
AS VALIDACION_1071,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500205705093')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500209306131','500209306132','500209306133','500209306134')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500205705093) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500209306131 + 500209306132 + 500209306133 + 500209306134) con Moneda 4.')    
AS VALIDACION_1072,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500205705094')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500209406135','500209406136','500209406137','500209406138')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500205705094) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500209406135 + 500209406136 + 500209406137 + 500209406138) con Moneda 4.')    
AS VALIDACION_1073,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201103024')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500202404058','500202404059','500202404060','500202404061','500202404062','500202404063','500202404064','500202404065')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201103024) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500202404058 + 500202404059 + 500202404060 + 500202404061 + 500202404062 + 500202404063 + 500202404064 + 500202404065) con Moneda 4.')    
AS VALIDACION_1074,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201103025')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500202504066','500202504067','500202504068','500202504069','500202504070')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500201103025) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500202504066 + 500202504067 + 500202504068 + 500202504069 + 500202504070) con Moneda 4.')    
AS VALIDACION_1075,

/*Primas por colocación de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200102013')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201303026','500201303027')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200102013) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500201303026 + 500201303027) con Moneda 4.')    
AS VALIDACION_1076,

/*Utilidad por valorización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500200102015')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500201503028','500201503029','500201503030','500201503031','500201503032')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500200102015) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500201503028 + 500201503029 + 500201503030 + 500201503031 + 500201503032) con Moneda 4.')    
AS VALIDACION_1077,

/*Gastos por intereses*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600400101002')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600400202017','600400202018','600400202019','600400202020','600400202021','600400202022','600400202023','600400202024','600400202025','600400202026','600400202027','600400202028','600400202029')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600400101002) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600400202017 + 600400202018 + 600400202019 + 600400202020 + 600400202021 + 600400202022 + 600400202023 + 600400202024 + 600400202025 + 600400202026 + 600400202027 + 600400202028 + 600400202029) con Moneda 4.')    
AS VALIDACION_1078,

/*Intereses, costos de transacción y descuentos a cargo por emisión de instrumentos financieros que califican como pasivo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600400202020')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600402003033','600402003034')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600400202020) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600402003033 + 600402003034) con Moneda 4.')    
AS VALIDACION_1079,

/*Obligaciones subordinadas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600402003033')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600403304071','600403304072','600403304073','600403304074')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600402003033) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600403304071 + 600403304072 + 600403304073 + 600403304074) con Moneda 4.')    
AS VALIDACION_1080,

/*Pérdida por valorización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600400202026')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600402603035','600402603036','600402603037','600402603038','600402603039')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600400202026) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600402603035 + 600402603036 + 600402603037 + 600402603038 + 600402603039) con Moneda 4.')    
AS VALIDACION_1081,

/*Resultado por posición monetaria neto (margen financiero)(1)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500600101003')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('500600302030','500600302031','500600302032')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (500600101003) con Moneda 4, debe ser igual a la sumatoria de las cuentas (500600302030 + 500600302031 + 500600302032) con Moneda 4.')    
AS VALIDACION_1082,

/*Estimación preventiva para riesgos crediticios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600800201004')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600800402033','600800402034','600800402035','600800402036','600800402037')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600800201004) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600800402033 + 600800402034 + 600800402035 + 600800402036 + 600800402037) con Moneda 4.')    
AS VALIDACION_1083,

/*Estimación preventiva para riesgos crediticios derivada de la calificación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600800402033')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600803303040','600803303041','600803303042','600803303043')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600800402033) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600803303040 + 600803303041 + 600803303042 + 600803303043) con Moneda 4.')    
AS VALIDACION_1084,

/*Cartera con riesgo de crédito etapa 1*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600803303040')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600804004075','600804004076','600804004077')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600803303040) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600804004075 + 600804004076 + 600804004077) con Moneda 4.')    
AS VALIDACION_1085,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600804004075')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600807505095','600807505096')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600804004075) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600807505095 + 600807505096) con Moneda 4.')    
AS VALIDACION_1086,

/*Créditos comerciales sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600807505095')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600809506139','600809506140','600809506141')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600807505095) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600809506139 + 600809506140 + 600809506141) con Moneda 4.')    
AS VALIDACION_1087,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600809506139')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600813907053','600813907054','600813907055','600813907056','600813907057','600813907058','600813907059','600813907060')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600809506139) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600813907053 + 600813907054 + 600813907055 + 600813907056 + 600813907057 + 600813907058 + 600813907059 + 600813907060) con Moneda 4.')    
AS VALIDACION_1088,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600813907053')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600805308001','600805308002')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600813907053) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600805308001 + 600805308002) con Moneda 4.')    
AS VALIDACION_1089,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600813907054')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600805408003','600805408004','600805408005')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600813907054) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600805408003 + 600805408004 + 600805408005) con Moneda 4.')    
AS VALIDACION_1090,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600813907055')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600805508006','600805508007')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600813907055) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600805508006 + 600805508007) con Moneda 4.')    
AS VALIDACION_1091,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600809506140')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600814007061','600814007062')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600809506140) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600814007061 + 600814007062) con Moneda 4.')    
AS VALIDACION_1092,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600814007061')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600806108008','600806108009','600806108010')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600814007061) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600806108008 + 600806108009 + 600806108010) con Moneda 4.')    
AS VALIDACION_1093,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600814007062')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600806208011','600806208012','600806208013')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600814007062) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600806208011 + 600806208012 + 600806208013) con Moneda 4.')    
AS VALIDACION_1094,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600809506141')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600814107063','600814107064','600814107065','600814107066')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600809506141) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600814107063 + 600814107064 + 600814107065 + 600814107066) con Moneda 4.')    
AS VALIDACION_1095,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600814107064')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600806408014','600806408015','600806408016','600806408017','600806408018')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600814107064) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600806408014 + 600806408015 + 600806408016 + 600806408017 + 600806408018) con Moneda 4.')    
AS VALIDACION_1096,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600814107065')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600806508019','600806508020','600806508021','600806508022')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600814107065) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600806508019 + 600806508020 + 600806508021 + 600806508022) con Moneda 4.')    
AS VALIDACION_1097,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600814107066')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600806608023','600806608024','600806608025','600806608026')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600814107066) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600806608023 + 600806608024 + 600806608025 + 600806608026) con Moneda 4.')    
AS VALIDACION_1098,

/*Créditos comerciales restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600807505096')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600809606142','600809606143','600809606144')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600807505096) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600809606142 + 600809606143 + 600809606144) con Moneda 4.')    
AS VALIDACION_1099,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600809606142')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600814207067','600814207068','600814207069','600814207070','600814207071','600814207072','600814207073','600814207074')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600809606142) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600814207067 + 600814207068 + 600814207069 + 600814207070 + 600814207071 + 600814207072 + 600814207073 + 600814207074) con Moneda 4.')    
AS VALIDACION_1100,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600814207067')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600806708027','600806708028')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600814207067) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600806708027 + 600806708028) con Moneda 4.')    
AS VALIDACION_1101,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600814207068')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600806808029','600806808030','600806808031')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600814207068) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600806808029 + 600806808030 + 600806808031) con Moneda 4.')    
AS VALIDACION_1102,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600814207069')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600806908032','600806908033')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600814207069) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600806908032 + 600806908033) con Moneda 4.')    
AS VALIDACION_1103,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600809606143')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600814307075','600814307076')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600809606143) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600814307075 + 600814307076) con Moneda 4.')    
AS VALIDACION_1104,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600814307075')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600807508034','600807508035','600807508036')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600814307075) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600807508034 + 600807508035 + 600807508036) con Moneda 4.')    
AS VALIDACION_1105,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600814307076')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600807608037','600807608038','600807608039')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600814307076) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600807608037 + 600807608038 + 600807608039) con Moneda 4.')    
AS VALIDACION_1106,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600809606144')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600814407077','600814407078','600814407079','600814407080')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600809606144) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600814407077 + 600814407078 + 600814407079 + 600814407080) con Moneda 4.')    
AS VALIDACION_1107,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600814407078')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600807808040','600807808041','600807808042','600807808043','600807808044')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600814407078) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600807808040 + 600807808041 + 600807808042 + 600807808043 + 600807808044) con Moneda 4.')    
AS VALIDACION_1108,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600814407079')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600807908045','600807908046','600807908047','600807908048')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600814407079) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600807908045 + 600807908046 + 600807908047 + 600807908048) con Moneda 4.')    
AS VALIDACION_1109,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600814407080')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600808008049','600808008050','600808008051','600808008052')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600814407080) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600808008049 + 600808008050 + 600808008051 + 600808008052) con Moneda 4.')    
AS VALIDACION_1110,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600804004076')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600807605097','600807605098')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600804004076) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600807605097 + 600807605098) con Moneda 4.')    
AS VALIDACION_1111,

/*Créditos de consumo sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600807605097')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600809706145','600809706146','600809706147','600809706148','600809706149','600809706150','600809706151','600809706152')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600807605097) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600809706145 + 600809706146 + 600809706147 + 600809706148 + 600809706149 + 600809706150 + 600809706151 + 600809706152) con Moneda 4.')    
AS VALIDACION_1112,

/*Créditos de consumo restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600807605098')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600809806153','600809806154','600809806155','600809806156','600809806157','600809806158','600809806159','600809806160')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600807605098) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600809806153 + 600809806154 + 600809806155 + 600809806156 + 600809806157 + 600809806158 + 600809806159 + 600809806160) con Moneda 4.')    
AS VALIDACION_1113,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600804004077')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600807705099','600807705100')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600804004077) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600807705099 + 600807705100) con Moneda 4.')    
AS VALIDACION_1114,

/*Créditos a la vivienda sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600807705099')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600809906161','600809906162','600809906163','600809906164','600809906165')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600807705099) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600809906161 + 600809906162 + 600809906163 + 600809906164 + 600809906165) con Moneda 4.')    
AS VALIDACION_1115,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600809906163')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600816307081','600816307082','600816307083')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600809906163) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600816307081 + 600816307082 + 600816307083) con Moneda 4.')    
AS VALIDACION_1116,

/*Créditos a la vivienda restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600807705100')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600810006166','600810006167','600810006168','600810006169','600810006170')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600807705100) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600810006166 + 600810006167 + 600810006168 + 600810006169 + 600810006170) con Moneda 4.')    
AS VALIDACION_1117,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600810006168')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600816807084','600816807085','600816807086')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600810006168) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600816807084 + 600816807085 + 600816807086) con Moneda 4.')    
AS VALIDACION_1118,

/*Cartera con riesgo de crédito etapa 2*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600803303041')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600804104079','600804104080','600804104081')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600803303041) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600804104079 + 600804104080 + 600804104081) con Moneda 4.')    
AS VALIDACION_1119,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600804104079')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600807905101','600807905102','600807905103')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600804104079) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600807905101 + 600807905102 + 600807905103) con Moneda 4.')    
AS VALIDACION_1120,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600807905101')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600810106171','600810106172','600810106173','600810106174','600810106175','600810106176','600810106177','600810106178')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600807905101) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600810106171 + 600810106172 + 600810106173 + 600810106174 + 600810106175 + 600810106176 + 600810106177 + 600810106178) con Moneda 4.')    
AS VALIDACION_1121,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600810106171')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600817107087','600817107088')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600810106171) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600817107087 + 600817107088) con Moneda 4.')    
AS VALIDACION_1122,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600810106172')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600817207089','600817207090','600817207091')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600810106172) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600817207089 + 600817207090 + 600817207091) con Moneda 4.')    
AS VALIDACION_1123,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600810106173')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600817307092','600817307093')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600810106173) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600817307092 + 600817307093) con Moneda 4.')    
AS VALIDACION_1124
	
INTO IFRS9_R01A_0111_M4_RESULT_5
FROM IFRS9_R01A_0111

END

BEGIN
	INSERT INTO IFRS9_R01A_0111_M4_RESULT_5
		select 'TOTAL ERRORES',  SUM(CHARINDEX('ERR',[VALIDACION_1025])),
SUM(CHARINDEX('ERR',[VALIDACION_1026])),
SUM(CHARINDEX('ERR',[VALIDACION_1027])),
SUM(CHARINDEX('ERR',[VALIDACION_1028])),
SUM(CHARINDEX('ERR',[VALIDACION_1029])),
SUM(CHARINDEX('ERR',[VALIDACION_1030])),
SUM(CHARINDEX('ERR',[VALIDACION_1031])),
SUM(CHARINDEX('ERR',[VALIDACION_1032])),
SUM(CHARINDEX('ERR',[VALIDACION_1033])),
SUM(CHARINDEX('ERR',[VALIDACION_1034])),
SUM(CHARINDEX('ERR',[VALIDACION_1035])),
SUM(CHARINDEX('ERR',[VALIDACION_1036])),
SUM(CHARINDEX('ERR',[VALIDACION_1037])),
SUM(CHARINDEX('ERR',[VALIDACION_1038])),
SUM(CHARINDEX('ERR',[VALIDACION_1039])),
SUM(CHARINDEX('ERR',[VALIDACION_1040])),
SUM(CHARINDEX('ERR',[VALIDACION_1041])),
SUM(CHARINDEX('ERR',[VALIDACION_1042])),
SUM(CHARINDEX('ERR',[VALIDACION_1043])),
SUM(CHARINDEX('ERR',[VALIDACION_1044])),
SUM(CHARINDEX('ERR',[VALIDACION_1045])),
SUM(CHARINDEX('ERR',[VALIDACION_1046])),
SUM(CHARINDEX('ERR',[VALIDACION_1047])),
SUM(CHARINDEX('ERR',[VALIDACION_1048])),
SUM(CHARINDEX('ERR',[VALIDACION_1049])),
SUM(CHARINDEX('ERR',[VALIDACION_1050])),
SUM(CHARINDEX('ERR',[VALIDACION_1051])),
SUM(CHARINDEX('ERR',[VALIDACION_1052])),
SUM(CHARINDEX('ERR',[VALIDACION_1053])),
SUM(CHARINDEX('ERR',[VALIDACION_1054])),
SUM(CHARINDEX('ERR',[VALIDACION_1055])),
SUM(CHARINDEX('ERR',[VALIDACION_1056])),
SUM(CHARINDEX('ERR',[VALIDACION_1057])),
SUM(CHARINDEX('ERR',[VALIDACION_1058])),
SUM(CHARINDEX('ERR',[VALIDACION_1059])),
SUM(CHARINDEX('ERR',[VALIDACION_1060])),
SUM(CHARINDEX('ERR',[VALIDACION_1061])),
SUM(CHARINDEX('ERR',[VALIDACION_1062])),
SUM(CHARINDEX('ERR',[VALIDACION_1063])),
SUM(CHARINDEX('ERR',[VALIDACION_1064])),
SUM(CHARINDEX('ERR',[VALIDACION_1065])),
SUM(CHARINDEX('ERR',[VALIDACION_1066])),
SUM(CHARINDEX('ERR',[VALIDACION_1067])),
SUM(CHARINDEX('ERR',[VALIDACION_1068])),
SUM(CHARINDEX('ERR',[VALIDACION_1069])),
SUM(CHARINDEX('ERR',[VALIDACION_1070])),
SUM(CHARINDEX('ERR',[VALIDACION_1071])),
SUM(CHARINDEX('ERR',[VALIDACION_1072])),
SUM(CHARINDEX('ERR',[VALIDACION_1073])),
SUM(CHARINDEX('ERR',[VALIDACION_1074])),
SUM(CHARINDEX('ERR',[VALIDACION_1075])),
SUM(CHARINDEX('ERR',[VALIDACION_1076])),
SUM(CHARINDEX('ERR',[VALIDACION_1077])),
SUM(CHARINDEX('ERR',[VALIDACION_1078])),
SUM(CHARINDEX('ERR',[VALIDACION_1079])),
SUM(CHARINDEX('ERR',[VALIDACION_1080])),
SUM(CHARINDEX('ERR',[VALIDACION_1081])),
SUM(CHARINDEX('ERR',[VALIDACION_1082])),
SUM(CHARINDEX('ERR',[VALIDACION_1083])),
SUM(CHARINDEX('ERR',[VALIDACION_1084])),
SUM(CHARINDEX('ERR',[VALIDACION_1085])),
SUM(CHARINDEX('ERR',[VALIDACION_1086])),
SUM(CHARINDEX('ERR',[VALIDACION_1087])),
SUM(CHARINDEX('ERR',[VALIDACION_1088])),
SUM(CHARINDEX('ERR',[VALIDACION_1089])),
SUM(CHARINDEX('ERR',[VALIDACION_1090])),
SUM(CHARINDEX('ERR',[VALIDACION_1091])),
SUM(CHARINDEX('ERR',[VALIDACION_1092])),
SUM(CHARINDEX('ERR',[VALIDACION_1093])),
SUM(CHARINDEX('ERR',[VALIDACION_1094])),
SUM(CHARINDEX('ERR',[VALIDACION_1095])),
SUM(CHARINDEX('ERR',[VALIDACION_1096])),
SUM(CHARINDEX('ERR',[VALIDACION_1097])),
SUM(CHARINDEX('ERR',[VALIDACION_1098])),
SUM(CHARINDEX('ERR',[VALIDACION_1099])),
SUM(CHARINDEX('ERR',[VALIDACION_1100])),
SUM(CHARINDEX('ERR',[VALIDACION_1101])),
SUM(CHARINDEX('ERR',[VALIDACION_1102])),
SUM(CHARINDEX('ERR',[VALIDACION_1103])),
SUM(CHARINDEX('ERR',[VALIDACION_1104])),
SUM(CHARINDEX('ERR',[VALIDACION_1105])),
SUM(CHARINDEX('ERR',[VALIDACION_1106])),
SUM(CHARINDEX('ERR',[VALIDACION_1107])),
SUM(CHARINDEX('ERR',[VALIDACION_1108])),
SUM(CHARINDEX('ERR',[VALIDACION_1109])),
SUM(CHARINDEX('ERR',[VALIDACION_1110])),
SUM(CHARINDEX('ERR',[VALIDACION_1111])),
SUM(CHARINDEX('ERR',[VALIDACION_1112])),
SUM(CHARINDEX('ERR',[VALIDACION_1113])),
SUM(CHARINDEX('ERR',[VALIDACION_1114])),
SUM(CHARINDEX('ERR',[VALIDACION_1115])),
SUM(CHARINDEX('ERR',[VALIDACION_1116])),
SUM(CHARINDEX('ERR',[VALIDACION_1117])),
SUM(CHARINDEX('ERR',[VALIDACION_1118])),
SUM(CHARINDEX('ERR',[VALIDACION_1119])),
SUM(CHARINDEX('ERR',[VALIDACION_1120])),
SUM(CHARINDEX('ERR',[VALIDACION_1121])),
SUM(CHARINDEX('ERR',[VALIDACION_1122])),
SUM(CHARINDEX('ERR',[VALIDACION_1123])),
SUM(CHARINDEX('ERR',[VALIDACION_1124]))


		from IFRS9_R01A_0111_M4_RESULT_5
END

BEGIN
	EXEC SP_IFRS9_R01A_0111_M4_VIEW_5
END

COMMIT


END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


