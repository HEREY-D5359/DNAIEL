﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Serie R01 Catálogo mínimo */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: Julio 2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/

/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 4*/
/*TIPO SALDO: NA*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER  PROCEDURE [dbo].[SP_IFRS9_R01A_0111_M4_COMP_1]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R01A_0111_M4_RESULT_1')
BEGIN
DROP TABLE IFRS9_R01A_0111_M4_RESULT_1
END 

BEGIN
SELECT DISTINCT

    /*ID*/

    CONVERT(VARCHAR,ID) AS ID,                                    /*ACTIVO*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100000000000')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100200001001','100400001001','100600001001','100800001001','101000001001','101200001001','101400001001','101600001001','101800104001','101800104002','101800104003','101800104004','101800103003','101800203004','101800203005','102000001001','102200001001','102400102001','102400102002','102600102001','102600102002','102800001001','103000001001','103200001001','103400102001','103400102002','103600102001','103600102002','103800001001','104000001001','104200102001','104200102002','104400102001','104400102002','104600001001')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100000000000) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100200001001 + 100400001001 + 100600001001 + 100800001001 + 101000001001 + 101200001001 + 101400001001 + 101600001001 + 101800104001 + 101800104002 + 101800104003 + 101800104004 + 101800103003 + 101800203004 + 101800203005 + 102000001001 + 102200001001 + 102400102001 + 102400102002 + 102600102001 + 102600102002 + 102800001001 + 103000001001 + 103200001001 + 103400102001 + 103400102002 + 103600102001 + 103600102002 + 103800001001 + 104000001001 + 104200102001 + 104200102002 + 104400102001 + 104400102002 + 104600001001) con Moneda 4.')    
AS VALIDACION_625,

/*Efectivo y equivalentes de efectivo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100200001001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100200102001','100200102002','100200102003','100200102004','100200102005','100200102006','100200102007')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100200001001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100200102001 + 100200102002 + 100200102003 + 100200102004 + 100200102005 + 100200102006 + 100200102007) con Moneda 4.')    
AS VALIDACION_626,

/*Bancos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100200102002')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100200203001','100200203002','100200203003')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100200102002) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100200203001 + 100200203002 + 100200203003) con Moneda 4.')    
AS VALIDACION_627,

/*Efectivo y equivalentes de efectivo restringidos o dados en garantía*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100200102006')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100200603004','100200603005','100200603006','100200603007','100200603008')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100200102006) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100200603004 + 100200603005 + 100200603006 + 100200603007 + 100200603008) con Moneda 4.')    
AS VALIDACION_628,

/*Cuentas de margen (instrumentos financieros derivados)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100400001001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100400102001','100400102002','100400102003')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100400001001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100400102001 + 100400102002 + 100400102003) con Moneda 4.')    
AS VALIDACION_629,

/*Inversiones en instrumentos financieros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600001001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600102001','100600102002','100600102003')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600001001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100600102001 + 100600102002 + 100600102003) con Moneda 4.')    
AS VALIDACION_630,

/*Instrumentos financieros negociables*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600102001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600103001','100600103002','100600103003','100600103004')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600102001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100600103001 + 100600103002 + 100600103003 + 100600103004) con Moneda 4.')    
AS VALIDACION_631,

/*Instrumentos financieros negociables sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600103001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600104001','100600104002','100600104003','100600104004')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600103001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100600104001 + 100600104002 + 100600104003 + 100600104004) con Moneda 4.')    
AS VALIDACION_632,

/*Deuda gubernamental*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600104001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600105001','100600105002')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600104001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100600105001 + 100600105002) con Moneda 4.')    
AS VALIDACION_633,

/*Deuda bancaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600104002')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600205003','100600205004')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600104002) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100600205003 + 100600205004) con Moneda 4.')    
AS VALIDACION_634,

/*Otros títulos de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600104003')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600305005','100600305006')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600104003) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100600305005 + 100600305006) con Moneda 4.')    
AS VALIDACION_635,

/*Instrumentos financieros de capital*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600104004')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600405007','100600405008')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600104004) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100600405007 + 100600405008) con Moneda 4.')    
AS VALIDACION_636,

/*Instrumentos financieros negociables restringidos o dados en garantía en operaciones de reporto*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600103002')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600204005','100600204006','100600204007','100600204008')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600103002) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100600204005 + 100600204006 + 100600204007 + 100600204008) con Moneda 4.')    
AS VALIDACION_637,

/*Instrumentos financieros negociables restringidos o dados en garantía en operaciones de préstamo de valores*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600103003')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600304009','100600304010','100600304011','100600304012')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600103003) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100600304009 + 100600304010 + 100600304011 + 100600304012) con Moneda 4.')    
AS VALIDACION_638,

/*Instrumentos financieros negociables restringidos o dados en garantía (otros)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600103004')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600404013','100600404014','100600404015','100600404016')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600103004) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100600404013 + 100600404014 + 100600404015 + 100600404016) con Moneda 4.')    
AS VALIDACION_639,

/*Deuda gubernamental*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600404013')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100601305009','100601305010')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600404013) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100601305009 + 100601305010) con Moneda 4.')    
AS VALIDACION_640,

/*Deuda bancaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600404014')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100601405011','100601405012')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600404014) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100601405011 + 100601405012) con Moneda 4.')    
AS VALIDACION_641,

/*Otros títulos de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600404015')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100601505013','100601505014')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600404015) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100601505013 + 100601505014) con Moneda 4.')    
AS VALIDACION_642,

/*Instrumentos financieros de capital*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600404016')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100601605015','100601605016')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600404016) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100601605015 + 100601605016) con Moneda 4.')    
AS VALIDACION_643,

/*Instrumentos financieros para cobrar o vender*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600102002')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600203005','100600203006','100600203007','100600203008')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600102002) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100600203005 + 100600203006 + 100600203007 + 100600203008) con Moneda 4.')    
AS VALIDACION_644,

/*Instrumentos financieros para cobrar o vender sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600203005')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600504017','100600504018','100600504019')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600203005) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100600504017 + 100600504018 + 100600504019) con Moneda 4.')    
AS VALIDACION_645,

/*Deuda gubernamental*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600504017')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100601705017','100601705018')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600504017) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100601705017 + 100601705018) con Moneda 4.')    
AS VALIDACION_646,

/*Deuda bancaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600504018')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100601805019','100601805020')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600504018) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100601805019 + 100601805020) con Moneda 4.')    
AS VALIDACION_647,

/*Otros títulos de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600504019')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100601905021','100601905022')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600504019) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100601905021 + 100601905022) con Moneda 4.')    
AS VALIDACION_648,

/*Instrumentos financieros para cobrar o vender restringidos o dados en garantía en operaciones de reporto*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600203006')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600604020','100600604021','100600604022')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600203006) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100600604020 + 100600604021 + 100600604022) con Moneda 4.')    
AS VALIDACION_649,

/*Instrumentos financieros para cobrar o vender restringidos o dados en garantía en operaciones de préstamo de valores*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600203007')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600704023','100600704024','100600704025')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600203007) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100600704023 + 100600704024 + 100600704025) con Moneda 4.')    
AS VALIDACION_650,

/*Instrumentos financieros para cobrar o vender restringidos o dados en garantía (otros)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600203008')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600804026','100600804027','100600804028')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600203008) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100600804026 + 100600804027 + 100600804028) con Moneda 4.')    
AS VALIDACION_651,

/*Deuda gubernamental*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600804026')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100602605023','100602605024')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600804026) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100602605023 + 100602605024) con Moneda 4.')    
AS VALIDACION_652,

/*Deuda bancaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600804027')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100602705025','100602705026')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600804027) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100602705025 + 100602705026) con Moneda 4.')    
AS VALIDACION_653,

/*Otros títulos de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600804028')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100602805027','100602805028')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600804028) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100602805027 + 100602805028) con Moneda 4.')    
AS VALIDACION_654,

/*Instrumentos financieros para cobrar principal e interés (valores)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600102003')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600303009','100600303010','100600303011','100600303012')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600102003) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100600303009 + 100600303010 + 100600303011 + 100600303012) con Moneda 4.')    
AS VALIDACION_655,

/*Instrumentos financieros para cobrar principal e interés sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600303009')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600904029','100600904030','100600904031')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600303009) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100600904029 + 100600904030 + 100600904031) con Moneda 4.')    
AS VALIDACION_656,

/*Deuda gubernamental*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600904029')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100602905029','100602905030')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600904029) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100602905029 + 100602905030) con Moneda 4.')    
AS VALIDACION_657,

/*Deuda bancaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600904030')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100603005031','100603005032')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600904030) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100603005031 + 100603005032) con Moneda 4.')    
AS VALIDACION_658,

/*Otros títulos de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600904031')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100603105033','100603105034')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600904031) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100603105033 + 100603105034) con Moneda 4.')    
AS VALIDACION_659,

/*Instrumentos financieros para cobrar principal e interés restringidos o dados en garantía en operaciones de reporto*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600303010')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100601004032','100601004033','100601004034')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600303010) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100601004032 + 100601004033 + 100601004034) con Moneda 4.')    
AS VALIDACION_660,

/*Instrumentos financieros para cobrar principal e interés restringidos o dados en garantía en operaciones de préstamo de valores*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600303011')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100601104035','100601104036','100601104037')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600303011) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100601104035 + 100601104036 + 100601104037) con Moneda 4.')    
AS VALIDACION_661,

/*Instrumentos financieros para cobrar principal e interés restringidos o dados en garantía (otros)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100600303012')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100601204038','100601204039','100601204040')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100600303012) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100601204038 + 100601204039 + 100601204040) con Moneda 4.')    
AS VALIDACION_662,

/*Deuda gubernamental*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100601204038')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100603805035','100603805036')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100601204038) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100603805035 + 100603805036) con Moneda 4.')    
AS VALIDACION_663,

/*Deuda bancaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100601204039')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100603905037','100603905038')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100601204039) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100603905037 + 100603905038) con Moneda 4.')    
AS VALIDACION_664,

/*Otros títulos de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100601204040')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100604005039','100604005040')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100601204040) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100604005039 + 100604005040) con Moneda 4.')    
AS VALIDACION_665,

/*Estimación de pérdidas crediticias esperadas para inversiones en instrumentos financieros para cobrar principal e interés (valores)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100800001001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100800102001','100800102002','100800102003','100800102004')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100800001001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100800102001 + 100800102002 + 100800102003 + 100800102004) con Moneda 4.')    
AS VALIDACION_666,

/*Instrumentos financieros para cobrar principal e interés sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100800102001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100800103001','100800103002','100800103003')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100800102001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100800103001 + 100800103002 + 100800103003) con Moneda 4.')    
AS VALIDACION_667,

/*Deuda gubernamental*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100800103001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100800104001','100800104002')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100800103001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100800104001 + 100800104002) con Moneda 4.')    
AS VALIDACION_668,

/*Deuda bancaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100800103002')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100800204003','100800204004')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100800103002) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100800204003 + 100800204004) con Moneda 4.')    
AS VALIDACION_669,

/*Otros títulos de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100800103003')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100800304005','100800304006')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100800103003) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100800304005 + 100800304006) con Moneda 4.')    
AS VALIDACION_670,

/*Instrumentos financieros para cobrar principal e interés restringidos o dados en garantía en operaciones de reporto*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100800102002')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100800203004','100800203005','100800203006')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100800102002) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100800203004 + 100800203005 + 100800203006) con Moneda 4.')    
AS VALIDACION_671,

/*Instrumentos financieros para cobrar principal e interés restringidos o dados en garantía en operaciones de préstamo de valores*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100800102003')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100800303007','100800303008','100800303009')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100800102003) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100800303007 + 100800303008 + 100800303009) con Moneda 4.')    
AS VALIDACION_672,

/*Instrumentos financieros para cobrar principal e interés restringidos o dados en garantía (otros)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100800102004')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100800403010','100800403011','100800403012')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100800102004) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100800403010 + 100800403011 + 100800403012) con Moneda 4.')    
AS VALIDACION_673,

/*Deuda gubernamental*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100800403010')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100801004007','100801004008')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100800403010) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100801004007 + 100801004008) con Moneda 4.')    
AS VALIDACION_674,

/*Deuda bancaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100800403011')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100801104009','100801104010')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100800403011) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100801104009 + 100801104010) con Moneda 4.')    
AS VALIDACION_675,

/*Otros títulos de deuda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100800403012')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('100801204011','100801204012')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (100800403012) con Moneda 4, debe ser igual a la sumatoria de las cuentas (100801204011 + 100801204012) con Moneda 4.')    
AS VALIDACION_676,

/*Instrumentos financieros derivados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101400001001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101400102001','101400102002')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400001001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101400102001 + 101400102002) con Moneda 4.')    
AS VALIDACION_677,

/*Con fines de negociación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101400102001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101400103001','101400103002','101400103003','101400103004','101400103005','101400103006','101400103007')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400102001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101400103001 + 101400103002 + 101400103003 + 101400103004 + 101400103005 + 101400103006 + 101400103007) con Moneda 4.')    
AS VALIDACION_678,

/*Futuros a recibir*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101400103001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101400104001')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400103001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101400104001) con Moneda 4.')    
AS VALIDACION_679,

/*Contratos adelantados a recibir*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101400103002')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101400204002','101400204003')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400103002) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101400204002 + 101400204003) con Moneda 4.')    
AS VALIDACION_680,

/*Opciones*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101400103003')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101400304004','101400304005')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400103003) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101400304004 + 101400304005) con Moneda 4.')    
AS VALIDACION_681,

/*Swaps*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101400103004')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101400404006','101400404007')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400103004) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101400404006 + 101400404007) con Moneda 4.')    
AS VALIDACION_682,

/*Instrumentos financieros derivados crediticios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101400103005')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101400504008','101400504009')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400103005) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101400504008 + 101400504009) con Moneda 4.')    
AS VALIDACION_683,

/*Operaciones estructuradas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101400103006')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101400604010','101400604011')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400103006) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101400604010 + 101400604011) con Moneda 4.')    
AS VALIDACION_684,

/*Paquetes de instrumentos financieros derivados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101400103007')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101400704012','101400704013')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400103007) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101400704012 + 101400704013) con Moneda 4.')    
AS VALIDACION_685,

/*Con fines de cobertura*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101400102002')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101400203008','101400203009','101400203010','101400203011','101400203012','101400203013','101400203014')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400102002) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101400203008 + 101400203009 + 101400203010 + 101400203011 + 101400203012 + 101400203013 + 101400203014) con Moneda 4.')    
AS VALIDACION_686,

/*Futuros a recibir*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101400203008')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101400804014','101400804015')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400203008) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101400804014 + 101400804015) con Moneda 4.')    
AS VALIDACION_687,

/*Contratos adelantados a recibir*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101400203009')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101400904016','101400904017','101400904018')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400203009) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101400904016 + 101400904017 + 101400904018) con Moneda 4.')    
AS VALIDACION_688,

/*Opciones*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101400203010')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101401004019','101401004020','101401004021')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400203010) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101401004019 + 101401004020 + 101401004021) con Moneda 4.')    
AS VALIDACION_689,

/*Swaps*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101400203011')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101401104022','101401104023','101401104024')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400203011) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101401104022 + 101401104023 + 101401104024) con Moneda 4.')    
AS VALIDACION_690,

/*Instrumentos financieros derivados crediticios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101400203012')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101401204025','101401204026','101401204027')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400203012) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101401204025 + 101401204026 + 101401204027) con Moneda 4.')    
AS VALIDACION_691,

/*Operaciones estructuradas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101400203013')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101401304028','101401304029','101401304030')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400203013) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101401304028 + 101401304029 + 101401304030) con Moneda 4.')    
AS VALIDACION_692,

/*Paquetes de instrumentos financieros derivados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101400203014')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101401404031','101401404032','101401404033')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101400203014) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101401404031 + 101401404032 + 101401404033) con Moneda 4.')    
AS VALIDACION_693,

/*Cartera de crédito con riesgo de crédito etapa 1*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800104001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800105001','101800105002','101800105003')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800104001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101800105001 + 101800105002 + 101800105003) con Moneda 4.')    
AS VALIDACION_694,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800105001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800106001','101800106002')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800105001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101800106001 + 101800106002) con Moneda 4.')    
AS VALIDACION_695,

/*Créditos comerciales sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800106001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800107001','101800107002','101800107003')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800106001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101800107001 + 101800107002 + 101800107003) con Moneda 4.')    
AS VALIDACION_696,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800107001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800108001','101800108002','101800108003','101800108004','101800108005','101800108006','101800108007','101800108008')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800107001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101800108001 + 101800108002 + 101800108003 + 101800108004 + 101800108005 + 101800108006 + 101800108007 + 101800108008) con Moneda 4.')    
AS VALIDACION_697,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800108001')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800109001','101800109002')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800108001) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101800109001 + 101800109002) con Moneda 4.')    
AS VALIDACION_698,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800108002')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800209003','101800209004','101800209005')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800108002) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101800209003 + 101800209004 + 101800209005) con Moneda 4.')    
AS VALIDACION_699,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800108003')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800309006','101800309007')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800108003) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101800309006 + 101800309007) con Moneda 4.')    
AS VALIDACION_700,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800107002')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800208009','101800208010')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800107002) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101800208009 + 101800208010) con Moneda 4.')    
AS VALIDACION_701,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800208009')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800909009','101800909010','101800909011')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800208009) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101800909009 + 101800909010 + 101800909011) con Moneda 4.')    
AS VALIDACION_702,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800208010')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101801009014','101801009015','101801009016')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800208010) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101801009014 + 101801009015 + 101801009016) con Moneda 4.')    
AS VALIDACION_703,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800107003')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800308011','101800308012','101800308013','101800308014')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800107003) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101800308011 + 101800308012 + 101800308013 + 101800308014) con Moneda 4.')    
AS VALIDACION_704,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800308012')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101801209018','101801209019','101801209020','101801209021','101801209022')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800308012) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101801209018 + 101801209019 + 101801209020 + 101801209021 + 101801209022) con Moneda 4.')    
AS VALIDACION_705,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800308013')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101801309023','101801309024','101801309025','101801309026')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800308013) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101801309023 + 101801309024 + 101801309025 + 101801309026) con Moneda 4.')    
AS VALIDACION_706,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800308014')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101801409027','101801409028','101801409029','101801409030')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800308014) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101801409027 + 101801409028 + 101801409029 + 101801409030) con Moneda 4.')    
AS VALIDACION_707,

/*Créditos comerciales restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800106002')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800207004','101800207005','101800207006')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800106002) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101800207004 + 101800207005 + 101800207006) con Moneda 4.')    
AS VALIDACION_708,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800207004')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800408015','101800408016','101800408017','101800408018','101800408019','101800408020','101800408021','101800408022')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800207004) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101800408015 + 101800408016 + 101800408017 + 101800408018 + 101800408019 + 101800408020 + 101800408021 + 101800408022) con Moneda 4.')    
AS VALIDACION_709,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800408015')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101801509031','101801509032')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800408015) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101801509031 + 101801509032) con Moneda 4.')    
AS VALIDACION_710,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800408016')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101801609033','101801609034','101801609035')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800408016) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101801609033 + 101801609034 + 101801609035) con Moneda 4.')    
AS VALIDACION_711,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800408017')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101801709036','101801709037')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800408017) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101801709036 + 101801709037) con Moneda 4.')    
AS VALIDACION_712,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800207005')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800508023','101800508024')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800207005) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101800508023 + 101800508024) con Moneda 4.')    
AS VALIDACION_713,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800508023')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101802309039','101802309040','101802309041')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800508023) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101802309039 + 101802309040 + 101802309041) con Moneda 4.')    
AS VALIDACION_714,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800508024')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101802409044','101802409045','101802409046')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800508024) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101802409044 + 101802409045 + 101802409046) con Moneda 4.')    
AS VALIDACION_715,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800207006')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800608025','101800608026','101800608027','101800608028')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800207006) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101800608025 + 101800608026 + 101800608027 + 101800608028) con Moneda 4.')    
AS VALIDACION_716,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800608026')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101802609048','101802609049','101802609050','101802609051','101802609052')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800608026) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101802609048 + 101802609049 + 101802609050 + 101802609051 + 101802609052) con Moneda 4.')    
AS VALIDACION_717,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800608027')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101802709053','101802709054','101802709055','101802709056')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800608027) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101802709053 + 101802709054 + 101802709055 + 101802709056) con Moneda 4.')    
AS VALIDACION_718,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800608028')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101802809057','101802809058','101802809059','101802809060')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800608028) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101802809057 + 101802809058 + 101802809059 + 101802809060) con Moneda 4.')    
AS VALIDACION_719,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800105002')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800206003','101800206004')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800105002) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101800206003 + 101800206004) con Moneda 4.')    
AS VALIDACION_720,

/*Créditos de consumo sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800206003')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800307007','101800307008','101800307009','101800307010','101800307011','101800307012','101800307013','101800307014')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800206003) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101800307007 + 101800307008 + 101800307009 + 101800307010 + 101800307011 + 101800307012 + 101800307013 + 101800307014) con Moneda 4.')    
AS VALIDACION_721,

/*Créditos de consumo restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800206004')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800407015','101800407016','101800407017','101800407018','101800407019','101800407020','101800407021','101800407022')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800206004) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101800407015 + 101800407016 + 101800407017 + 101800407018 + 101800407019 + 101800407020 + 101800407021 + 101800407022) con Moneda 4.')    
AS VALIDACION_722,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800105003')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800306005','101800306006')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800105003) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101800306005 + 101800306006) con Moneda 4.')    
AS VALIDACION_723,

/*Créditos a la vivienda sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800306005')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('101800507023','101800507024','101800507025','101800507026','101800507027')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800306005) con Moneda 4, debe ser igual a la sumatoria de las cuentas (101800507023 + 101800507024 + 101800507025 + 101800507026 + 101800507027) con Moneda 4.')    
AS VALIDACION_724
	
INTO IFRS9_R01A_0111_M4_RESULT_1
FROM IFRS9_R01A_0111

END

BEGIN
	INSERT INTO IFRS9_R01A_0111_M4_RESULT_1
		select 'TOTAL ERRORES',  SUM(CHARINDEX('ERR',[VALIDACION_625])),
SUM(CHARINDEX('ERR',[VALIDACION_626])),
SUM(CHARINDEX('ERR',[VALIDACION_627])),
SUM(CHARINDEX('ERR',[VALIDACION_628])),
SUM(CHARINDEX('ERR',[VALIDACION_629])),
SUM(CHARINDEX('ERR',[VALIDACION_630])),
SUM(CHARINDEX('ERR',[VALIDACION_631])),
SUM(CHARINDEX('ERR',[VALIDACION_632])),
SUM(CHARINDEX('ERR',[VALIDACION_633])),
SUM(CHARINDEX('ERR',[VALIDACION_634])),
SUM(CHARINDEX('ERR',[VALIDACION_635])),
SUM(CHARINDEX('ERR',[VALIDACION_636])),
SUM(CHARINDEX('ERR',[VALIDACION_637])),
SUM(CHARINDEX('ERR',[VALIDACION_638])),
SUM(CHARINDEX('ERR',[VALIDACION_639])),
SUM(CHARINDEX('ERR',[VALIDACION_640])),
SUM(CHARINDEX('ERR',[VALIDACION_641])),
SUM(CHARINDEX('ERR',[VALIDACION_642])),
SUM(CHARINDEX('ERR',[VALIDACION_643])),
SUM(CHARINDEX('ERR',[VALIDACION_644])),
SUM(CHARINDEX('ERR',[VALIDACION_645])),
SUM(CHARINDEX('ERR',[VALIDACION_646])),
SUM(CHARINDEX('ERR',[VALIDACION_647])),
SUM(CHARINDEX('ERR',[VALIDACION_648])),
SUM(CHARINDEX('ERR',[VALIDACION_649])),
SUM(CHARINDEX('ERR',[VALIDACION_650])),
SUM(CHARINDEX('ERR',[VALIDACION_651])),
SUM(CHARINDEX('ERR',[VALIDACION_652])),
SUM(CHARINDEX('ERR',[VALIDACION_653])),
SUM(CHARINDEX('ERR',[VALIDACION_654])),
SUM(CHARINDEX('ERR',[VALIDACION_655])),
SUM(CHARINDEX('ERR',[VALIDACION_656])),
SUM(CHARINDEX('ERR',[VALIDACION_657])),
SUM(CHARINDEX('ERR',[VALIDACION_658])),
SUM(CHARINDEX('ERR',[VALIDACION_659])),
SUM(CHARINDEX('ERR',[VALIDACION_660])),
SUM(CHARINDEX('ERR',[VALIDACION_661])),
SUM(CHARINDEX('ERR',[VALIDACION_662])),
SUM(CHARINDEX('ERR',[VALIDACION_663])),
SUM(CHARINDEX('ERR',[VALIDACION_664])),
SUM(CHARINDEX('ERR',[VALIDACION_665])),
SUM(CHARINDEX('ERR',[VALIDACION_666])),
SUM(CHARINDEX('ERR',[VALIDACION_667])),
SUM(CHARINDEX('ERR',[VALIDACION_668])),
SUM(CHARINDEX('ERR',[VALIDACION_669])),
SUM(CHARINDEX('ERR',[VALIDACION_670])),
SUM(CHARINDEX('ERR',[VALIDACION_671])),
SUM(CHARINDEX('ERR',[VALIDACION_672])),
SUM(CHARINDEX('ERR',[VALIDACION_673])),
SUM(CHARINDEX('ERR',[VALIDACION_674])),
SUM(CHARINDEX('ERR',[VALIDACION_675])),
SUM(CHARINDEX('ERR',[VALIDACION_676])),
SUM(CHARINDEX('ERR',[VALIDACION_677])),
SUM(CHARINDEX('ERR',[VALIDACION_678])),
SUM(CHARINDEX('ERR',[VALIDACION_679])),
SUM(CHARINDEX('ERR',[VALIDACION_680])),
SUM(CHARINDEX('ERR',[VALIDACION_681])),
SUM(CHARINDEX('ERR',[VALIDACION_682])),
SUM(CHARINDEX('ERR',[VALIDACION_683])),
SUM(CHARINDEX('ERR',[VALIDACION_684])),
SUM(CHARINDEX('ERR',[VALIDACION_685])),
SUM(CHARINDEX('ERR',[VALIDACION_686])),
SUM(CHARINDEX('ERR',[VALIDACION_687])),
SUM(CHARINDEX('ERR',[VALIDACION_688])),
SUM(CHARINDEX('ERR',[VALIDACION_689])),
SUM(CHARINDEX('ERR',[VALIDACION_690])),
SUM(CHARINDEX('ERR',[VALIDACION_691])),
SUM(CHARINDEX('ERR',[VALIDACION_692])),
SUM(CHARINDEX('ERR',[VALIDACION_693])),
SUM(CHARINDEX('ERR',[VALIDACION_694])),
SUM(CHARINDEX('ERR',[VALIDACION_695])),
SUM(CHARINDEX('ERR',[VALIDACION_696])),
SUM(CHARINDEX('ERR',[VALIDACION_697])),
SUM(CHARINDEX('ERR',[VALIDACION_698])),
SUM(CHARINDEX('ERR',[VALIDACION_699])),
SUM(CHARINDEX('ERR',[VALIDACION_700])),
SUM(CHARINDEX('ERR',[VALIDACION_701])),
SUM(CHARINDEX('ERR',[VALIDACION_702])),
SUM(CHARINDEX('ERR',[VALIDACION_703])),
SUM(CHARINDEX('ERR',[VALIDACION_704])),
SUM(CHARINDEX('ERR',[VALIDACION_705])),
SUM(CHARINDEX('ERR',[VALIDACION_706])),
SUM(CHARINDEX('ERR',[VALIDACION_707])),
SUM(CHARINDEX('ERR',[VALIDACION_708])),
SUM(CHARINDEX('ERR',[VALIDACION_709])),
SUM(CHARINDEX('ERR',[VALIDACION_710])),
SUM(CHARINDEX('ERR',[VALIDACION_711])),
SUM(CHARINDEX('ERR',[VALIDACION_712])),
SUM(CHARINDEX('ERR',[VALIDACION_713])),
SUM(CHARINDEX('ERR',[VALIDACION_714])),
SUM(CHARINDEX('ERR',[VALIDACION_715])),
SUM(CHARINDEX('ERR',[VALIDACION_716])),
SUM(CHARINDEX('ERR',[VALIDACION_717])),
SUM(CHARINDEX('ERR',[VALIDACION_718])),
SUM(CHARINDEX('ERR',[VALIDACION_719])),
SUM(CHARINDEX('ERR',[VALIDACION_720])),
SUM(CHARINDEX('ERR',[VALIDACION_721])),
SUM(CHARINDEX('ERR',[VALIDACION_722])),
SUM(CHARINDEX('ERR',[VALIDACION_723])),
SUM(CHARINDEX('ERR',[VALIDACION_724]))


		from IFRS9_R01A_0111_M4_RESULT_1
END

BEGIN
	EXEC SP_IFRS9_R01A_0111_M4_VIEW_1
END

COMMIT


END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


