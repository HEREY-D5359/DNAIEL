﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Serie R01 Catálogo mínimo */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: Julio 2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/

/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 4*/
/*TIPO SALDO: NA*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER  PROCEDURE [dbo].[SP_IFRS9_R01A_0111_M4_COMP_6]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R01A_0111_M4_RESULT_6')
BEGIN
DROP TABLE IFRS9_R01A_0111_M4_RESULT_6
END 

BEGIN
SELECT DISTINCT

	/*ID*/

	CONVERT(VARCHAR,ID)  AS ID,   
	/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600807905102')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600810206179','600810206180')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600807905102) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600810206179 + 600810206180) con Moneda 4.')    
AS VALIDACION_1125,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600810206179')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600817907094','600817907095','600817907096')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600810206179) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600817907094 + 600817907095 + 600817907096) con Moneda 4.')    
AS VALIDACION_1126,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600810206180')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600818007097','600818007098','600818007099')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600810206180) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600818007097 + 600818007098 + 600818007099) con Moneda 4.')    
AS VALIDACION_1127,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600807905103')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600810306181','600810306182','600810306183','600810306184')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600807905103) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600810306181 + 600810306182 + 600810306183 + 600810306184) con Moneda 4.')    
AS VALIDACION_1128,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600810306182')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600818207100','600818207101','600818207102','600818207103','600818207104')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600810306182) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600818207100 + 600818207101 + 600818207102 + 600818207103 + 600818207104) con Moneda 4.')    
AS VALIDACION_1129,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600810306183')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600818307105','600818307106','600818307107','600818307108')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600810306183) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600818307105 + 600818307106 + 600818307107 + 600818307108) con Moneda 4.')    
AS VALIDACION_1130,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600810306184')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600818407109','600818407110','600818407111','600818407112')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600810306184) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600818407109 + 600818407110 + 600818407111 + 600818407112) con Moneda 4.')    
AS VALIDACION_1131,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600804104080')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600808005104','600808005105','600808005106','600808005107','600808005108','600808005109','600808005110','600808005111')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600804104080) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600808005104 + 600808005105 + 600808005106 + 600808005107 + 600808005108 + 600808005109 + 600808005110 + 600808005111) con Moneda 4.')    
AS VALIDACION_1132,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600804104081')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600808105112','600808105113','600808105114','600808105115','600808105116')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600804104081) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600808105112 + 600808105113 + 600808105114 + 600808105115 + 600808105116) con Moneda 4.')    
AS VALIDACION_1133,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600808105114')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600811406185','600811406186')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600808105114) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600811406185 + 600811406186) con Moneda 4.')    
AS VALIDACION_1134,

/*Cartera con riesgo de crédito etapa 3*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600803303042')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600804204082','600804204083','600804204084')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600803303042) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600804204082 + 600804204083 + 600804204084) con Moneda 4.')    
AS VALIDACION_1135,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600804204082')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600808205117','600808205118','600808205119')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600804204082) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600808205117 + 600808205118 + 600808205119) con Moneda 4.')    
AS VALIDACION_1136,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600808205117')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600811706187','600811706188','600811706189','600811706190','600811706191','600811706192','600811706193','600811706194')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600808205117) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600811706187 + 600811706188 + 600811706189 + 600811706190 + 600811706191 + 600811706192 + 600811706193 + 600811706194) con Moneda 4.')    
AS VALIDACION_1137,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600811706187')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600818707113','600818707114')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600811706187) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600818707113 + 600818707114) con Moneda 4.')    
AS VALIDACION_1138,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600811706188')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600818807115','600818807116','600818807117')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600811706188) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600818807115 + 600818807116 + 600818807117) con Moneda 4.')    
AS VALIDACION_1139,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600811706189')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600818907118','600818907119')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600811706189) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600818907118 + 600818907119) con Moneda 4.')    
AS VALIDACION_1140,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600808205118')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600811806195','600811806196')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600808205118) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600811806195 + 600811806196) con Moneda 4.')    
AS VALIDACION_1141,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600811806195')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600819507120','600819507121','600819507122')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600811806195) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600819507120 + 600819507121 + 600819507122) con Moneda 4.')    
AS VALIDACION_1142,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600811806196')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600819607123','600819607124','600819607125')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600811806196) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600819607123 + 600819607124 + 600819607125) con Moneda 4.')    
AS VALIDACION_1143,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600808205119')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600811906197','600811906198','600811906199','600811906200')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600808205119) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600811906197 + 600811906198 + 600811906199 + 600811906200) con Moneda 4.')    
AS VALIDACION_1144,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600811906198')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600819807126','600819807127','600819807128','600819807129','600819807130')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600811906198) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600819807126 + 600819807127 + 600819807128 + 600819807129 + 600819807130) con Moneda 4.')    
AS VALIDACION_1145,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600811906199')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600819907131','600819907132','600819907133','600819907134')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600811906199) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600819907131 + 600819907132 + 600819907133 + 600819907134) con Moneda 4.')    
AS VALIDACION_1146,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600811906200')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600820007135','600820007136','600820007137','600820007138')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600811906200) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600820007135 + 600820007136 + 600820007137 + 600820007138) con Moneda 4.')    
AS VALIDACION_1147,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600804204083')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600808305120','600808305121','600808305122','600808305123','600808305124','600808305125','600808305126','600808305127')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600804204083) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600808305120 + 600808305121 + 600808305122 + 600808305123 + 600808305124 + 600808305125 + 600808305126 + 600808305127) con Moneda 4.')    
AS VALIDACION_1148,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600804204084')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600808405128','600808405129','600808405130','600808405131','600808405132')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600804204084) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600808405128 + 600808405129 + 600808405130 + 600808405131 + 600808405132) con Moneda 4.')    
AS VALIDACION_1149,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600808405130')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600813006201','600813006202')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600808405130) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600813006201 + 600813006202) con Moneda 4.')    
AS VALIDACION_1150,

/*Recuperación de cartera de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600800402034')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600803403044','600803403045','600803403046')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600800402034) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600803403044 + 600803403045 + 600803403046) con Moneda 4.')    
AS VALIDACION_1151,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600803403044')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600804404085','600804404086','600804404087')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600803403044) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600804404085 + 600804404086 + 600804404087) con Moneda 4.')    
AS VALIDACION_1152,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600804404085')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600808505133','600808505134','600808505135','600808505136','600808505137','600808505138','600808505139','600808505140')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600804404085) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600808505133 + 600808505134 + 600808505135 + 600808505136 + 600808505137 + 600808505138 + 600808505139 + 600808505140) con Moneda 4.')    
AS VALIDACION_1153,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600808505133')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600813306203','600813306204')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600808505133) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600813306203 + 600813306204) con Moneda 4.')    
AS VALIDACION_1154,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600808505134')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600813406205','600813406206','600813406207')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600808505134) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600813406205 + 600813406206 + 600813406207) con Moneda 4.')    
AS VALIDACION_1155,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600808505135')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600813506208','600813506209')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600808505135) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600813506208 + 600813506209) con Moneda 4.')    
AS VALIDACION_1156,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600804404086')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600808605141','600808605142')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600804404086) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600808605141 + 600808605142) con Moneda 4.')    
AS VALIDACION_1157,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600808605141')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600814106210','600814106211','600814106212')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600808605141) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600814106210 + 600814106211 + 600814106212) con Moneda 4.')    
AS VALIDACION_1158,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600808605142')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600814206213','600814206214','600814206215')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600808605142) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600814206213 + 600814206214 + 600814206215) con Moneda 4.')    
AS VALIDACION_1159,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600804404087')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600808705143','600808705144','600808705145','600808705146')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600804404087) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600808705143 + 600808705144 + 600808705145 + 600808705146) con Moneda 4.')    
AS VALIDACION_1160,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600808705144')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600814406216','600814406217','600814406218','600814406219','600814406220')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600808705144) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600814406216 + 600814406217 + 600814406218 + 600814406219 + 600814406220) con Moneda 4.')    
AS VALIDACION_1161,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600808705145')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600814506221','600814506222','600814506223','600814506224')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600808705145) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600814506221 + 600814506222 + 600814506223 + 600814506224) con Moneda 4.')    
AS VALIDACION_1162,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600808705146')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600814606225','600814606226','600814606227','600814606228')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600808705146) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600814606225 + 600814606226 + 600814606227 + 600814606228) con Moneda 4.')    
AS VALIDACION_1163,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600803403045')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600804504088','600804504089','600804504090','600804504091','600804504092','600804504093','600804504094','600804504095')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600803403045) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600804504088 + 600804504089 + 600804504090 + 600804504091 + 600804504092 + 600804504093 + 600804504094 + 600804504095) con Moneda 4.')    
AS VALIDACION_1164,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600803403046')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600804604096','600804604097','600804604098','600804604099','600804604100')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600803403046) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600804604096 + 600804604097 + 600804604098 + 600804604099 + 600804604100) con Moneda 4.')    
AS VALIDACION_1165,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600804604098')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600809805147','600809805148')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600804604098) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600809805147 + 600809805148) con Moneda 4.')    
AS VALIDACION_1166,

/*Estimación preventiva para riesgos crediticios adicional*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600800402035')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('600803503047','600803503048','600803503049','600803503050','600803503051','600803503052')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (600800402035) con Moneda 4, debe ser igual a la sumatoria de las cuentas (600803503047 + 600803503048 + 600803503049 + 600803503050 + 600803503051 + 600803503052) con Moneda 4.')    
AS VALIDACION_1167,

/*Comisiones y tarifas cobradas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501000301005')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501000502038','501000502039','501000502040','501000502041','501000502042','501000502043','501000502044','501000502045','501000502046','501000502047','501000502048','501000502049','501000502050','501000502051','501000502052','501000502053','501000502054','501000502055','501000502056')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501000301005) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501000502038 + 501000502039 + 501000502040 + 501000502041 + 501000502042 + 501000502043 + 501000502044 + 501000502045 + 501000502046 + 501000502047 + 501000502048 + 501000502049 + 501000502050 + 501000502051 + 501000502052 + 501000502053 + 501000502054 + 501000502055 + 501000502056) con Moneda 4.')    
AS VALIDACION_1168,

/*Operaciones de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501000502038')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501003803053','501003803054','501003803055')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501000502038) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501003803053 + 501003803054 + 501003803055) con Moneda 4.')    
AS VALIDACION_1169,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501003803053')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501005304101','501005304102')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501003803053) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501005304101 + 501005304102) con Moneda 4.')    
AS VALIDACION_1170,

/*Créditos comerciales sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501005304101')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501010105149','501010105150','501010105151')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501005304101) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501010105149 + 501010105150 + 501010105151) con Moneda 4.')    
AS VALIDACION_1171,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501010105149')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501014906229','501014906230','501014906231','501014906232','501014906233','501014906234','501014906235','501014906236')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501010105149) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501014906229 + 501014906230 + 501014906231 + 501014906232 + 501014906233 + 501014906234 + 501014906235 + 501014906236) con Moneda 4.')    
AS VALIDACION_1172,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501014906229')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501022907139','501022907140')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501014906229) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501022907139 + 501022907140) con Moneda 4.')    
AS VALIDACION_1173,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501014906230')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501023007141','501023007142','501023007143')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501014906230) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501023007141 + 501023007142 + 501023007143) con Moneda 4.')    
AS VALIDACION_1174,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501014906231')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501023107144','501023107145')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501014906231) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501023107144 + 501023107145) con Moneda 4.')    
AS VALIDACION_1175,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501010105150')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501015006237','501015006238')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501010105150) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501015006237 + 501015006238) con Moneda 4.')    
AS VALIDACION_1176,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501015006237')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501023707146','501023707147','501023707148')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501015006237) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501023707146 + 501023707147 + 501023707148) con Moneda 4.')    
AS VALIDACION_1177,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501015006238')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501023807149','501023807150','501023807151')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501015006238) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501023807149 + 501023807150 + 501023807151) con Moneda 4.')    
AS VALIDACION_1178,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501010105151')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501015106239','501015106240','501015106241','501015106242')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501010105151) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501015106239 + 501015106240 + 501015106241 + 501015106242) con Moneda 4.')    
AS VALIDACION_1179,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501015106240')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501024007152','501024007153','501024007154','501024007155','501024007156')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501015106240) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501024007152 + 501024007153 + 501024007154 + 501024007155 + 501024007156) con Moneda 4.')    
AS VALIDACION_1180,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501015106241')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501024107157','501024107158','501024107159','501024107160')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501015106241) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501024107157 + 501024107158 + 501024107159 + 501024107160) con Moneda 4.')    
AS VALIDACION_1181,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501015106242')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501024207161','501024207162','501024207163','501024207164')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501015106242) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501024207161 + 501024207162 + 501024207163 + 501024207164) con Moneda 4.')    
AS VALIDACION_1182,

/*Créditos comerciales restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501005304102')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501010205152','501010205153','501010205154')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501005304102) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501010205152 + 501010205153 + 501010205154) con Moneda 4.')    
AS VALIDACION_1183,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501010205152')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501015206243','501015206244','501015206245','501015206246','501015206247','501015206248','501015206249','501015206250')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501010205152) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501015206243 + 501015206244 + 501015206245 + 501015206246 + 501015206247 + 501015206248 + 501015206249 + 501015206250) con Moneda 4.')    
AS VALIDACION_1184,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501015206243')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501024307165','501024307166')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501015206243) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501024307165 + 501024307166) con Moneda 4.')    
AS VALIDACION_1185,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501015206244')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501024407167','501024407168','501024407169')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501015206244) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501024407167 + 501024407168 + 501024407169) con Moneda 4.')    
AS VALIDACION_1186,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501015206245')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501024507170','501024507171')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501015206245) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501024507170 + 501024507171) con Moneda 4.')    
AS VALIDACION_1187,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501010205153')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501015306251','501015306252')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501010205153) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501015306251 + 501015306252) con Moneda 4.')    
AS VALIDACION_1188,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501015306251')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501025107172','501025107173','501025107174')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501015306251) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501025107172 + 501025107173 + 501025107174) con Moneda 4.')    
AS VALIDACION_1189,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501015306252')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501025207175','501025207176','501025207177')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501015306252) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501025207175 + 501025207176 + 501025207177) con Moneda 4.')    
AS VALIDACION_1190,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501010205154')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501015406253','501015406254','501015406255','501015406256')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501010205154) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501015406253 + 501015406254 + 501015406255 + 501015406256) con Moneda 4.')    
AS VALIDACION_1191,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501015406254')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501025407178','501025407179','501025407180','501025407181','501025407182')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501015406254) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501025407178 + 501025407179 + 501025407180 + 501025407181 + 501025407182) con Moneda 4.')    
AS VALIDACION_1192,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501015406255')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501025507183','501025507184','501025507185','501025507186')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501015406255) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501025507183 + 501025507184 + 501025507185 + 501025507186) con Moneda 4.')    
AS VALIDACION_1193,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501015406256')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501025607187','501025607188','501025607189','501025607190')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501015406256) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501025607187 + 501025607188 + 501025607189 + 501025607190) con Moneda 4.')    
AS VALIDACION_1194,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501003803054')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501005404103','501005404104')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501003803054) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501005404103 + 501005404104) con Moneda 4.')    
AS VALIDACION_1195,

/*Créditos de consumo sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501005404103')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501010305155','501010305156','501010305157','501010305158','501010305159','501010305160','501010305161','501010305162')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501005404103) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501010305155 + 501010305156 + 501010305157 + 501010305158 + 501010305159 + 501010305160 + 501010305161 + 501010305162) con Moneda 4.')    
AS VALIDACION_1196,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501010305155')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501015506257','501015506258')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501010305155) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501015506257 + 501015506258) con Moneda 4.')    
AS VALIDACION_1197,

/*Créditos de consumo restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501005404104')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501010405163','501010405164','501010405165','501010405166','501010405167','501010405168','501010405169','501010405170')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501005404104) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501010405163 + 501010405164 + 501010405165 + 501010405166 + 501010405167 + 501010405168 + 501010405169 + 501010405170) con Moneda 4.')    
AS VALIDACION_1198,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501010405163')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501016306259','501016306260')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501010405163) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501016306259 + 501016306260) con Moneda 4.')    
AS VALIDACION_1199,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501003803055')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501005504105','501005504106')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501003803055) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501005504105 + 501005504106) con Moneda 4.')    
AS VALIDACION_1200,

/*Créditos a la vivienda sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501005504105')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501010505171','501010505172','501010505173','501010505174','501010505175')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501005504105) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501010505171 + 501010505172 + 501010505173 + 501010505174 + 501010505175) con Moneda 4.')    
AS VALIDACION_1201,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501010505173')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501017306261','501017306262','501017306263')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501010505173) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501017306261 + 501017306262 + 501017306263) con Moneda 4.')    
AS VALIDACION_1202,

/*Créditos a la vivienda restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501005504106')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501010605176','501010605177','501010605178','501010605179','501010605180')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501005504106) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501010605176 + 501010605177 + 501010605178 + 501010605179 + 501010605180) con Moneda 4.')    
AS VALIDACION_1203,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501010605178')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501017806264','501017806265','501017806266')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501010605178) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501017806264 + 501017806265 + 501017806266) con Moneda 4.')    
AS VALIDACION_1204,

/*Comisiones y tarifas pagadas*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('601200301006')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('601200602057','601200602058','601200602059','601200602060','601200602061','601200602062','601200602063','601200602064')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (601200301006) con Moneda 4, debe ser igual a la sumatoria de las cuentas (601200602057 + 601200602058 + 601200602059 + 601200602060 + 601200602061 + 601200602062 + 601200602063 + 601200602064) con Moneda 4.')    
AS VALIDACION_1205,

/*Resultado por intermediación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501400301007')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501400702065','501400702066','501400702067','501400702068','501400702069','501400702070','501400702071','501400702072','501400702073','501400702074','501400702075','501400702076','501400702077','501400702078')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501400301007) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501400702065 + 501400702066 + 501400702067 + 501400702068 + 501400702069 + 501400702070 + 501400702071 + 501400702072 + 501400702073 + 501400702074 + 501400702075 + 501400702076 + 501400702077 + 501400702078) con Moneda 4.')    
AS VALIDACION_1206,

/*Resultado por valuación de instrumentos financieros a valor razonable*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501400702065')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501406503057','501406503058','501406503059','501406503060','501406503061','501406503062')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501400702065) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501406503057 + 501406503058 + 501406503059 + 501406503060 + 501406503061 + 501406503062) con Moneda 4.')    
AS VALIDACION_1207,

/*Estimación de pérdidas crediticias esperadas para inversiones en instrumentos financieros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501400702066')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501406603063','501406603064')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501400702066) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501406603063 + 501406603064) con Moneda 4.')    
AS VALIDACION_1208,

/*Resultado por compraventa de instrumentos financieros e instrumentos financieros derivados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501400702071')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501407103065','501407103066','501407103067','501407103068','501407103069')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501400702071) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501407103065 + 501407103066 + 501407103067 + 501407103068 + 501407103069) con Moneda 4.')    
AS VALIDACION_1209,

/*Costos de transacción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501400702076')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501407603070','501407603071','501407603072','501407603073')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501400702076) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501407603070 + 501407603071 + 501407603072 + 501407603073) con Moneda 4.')    
AS VALIDACION_1210,

/*Otros ingresos (egresos) de la operación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501600301008')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501600802079','501600802080','501600802081','501600802082','501600802083','501600802084','501600802085','501600802086','501600802087','501600802088','501600802089','501600802090','501600802091','501600802092','501600802093','501600802094','501600802095','501600802096','501600802097','501600802098','501600802099','501600802100','501600802101','501600802102','501600802103','501600802104','501600802105','501600802106','501600802107','501600802108','501600802109','501600802110','501600802111')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501600301008) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501600802079 + 501600802080 + 501600802081 + 501600802082 + 501600802083 + 501600802084 + 501600802085 + 501600802086 + 501600802087 + 501600802088 + 501600802089 + 501600802090 + 501600802091 + 501600802092 + 501600802093 + 501600802094 + 501600802095 + 501600802096 + 501600802097 + 501600802098 + 501600802099 + 501600802100 + 501600802101 + 501600802102 + 501600802103 + 501600802104 + 501600802105 + 501600802106 + 501600802107 + 501600802108 + 501600802109 + 501600802110 + 501600802111) con Moneda 4.')    
AS VALIDACION_1211,

/*Recuperaciones*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501600802080')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501608003074','501608003075','501608003076','501608003077')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501600802080) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501608003074 + 501608003075 + 501608003076 + 501608003077) con Moneda 4.')    
AS VALIDACION_1212,

/*Quebrantos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501600802088')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501608803078','501608803079','501608803080','501608803081','501608803082','501608803083','501608803084')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501600802088) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501608803078 + 501608803079 + 501608803080 + 501608803081 + 501608803082 + 501608803083 + 501608803084) con Moneda 4.')    
AS VALIDACION_1213,

/*Fraudes*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501608803079')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('501607904107','501607904108')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (501608803079) con Moneda 4, debe ser igual a la sumatoria de las cuentas (501607904107 + 501607904108) con Moneda 4.')    
AS VALIDACION_1214,

/*Gastos de administración y promoción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602000301010')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602001002114','602001002115','602001002116','602001002117','602001002118','602001002119','602001002120','602001002121','602001002122','602001002123','602001002124','602001002125','602001002126','602001002127','602001002128','602001002129','602001002130')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (602000301010) con Moneda 4, debe ser igual a la sumatoria de las cuentas (602001002114 + 602001002115 + 602001002116 + 602001002117 + 602001002118 + 602001002119 + 602001002120 + 602001002121 + 602001002122 + 602001002123 + 602001002124 + 602001002125 + 602001002126 + 602001002127 + 602001002128 + 602001002129 + 602001002130) con Moneda 4.')    
AS VALIDACION_1215,

/*Beneficios directos a corto plazo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602001002114')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602011403085','602011403086')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (602001002114) con Moneda 4, debe ser igual a la sumatoria de las cuentas (602011403085 + 602011403086) con Moneda 4.')    
AS VALIDACION_1216,

/*Participación de los trabajadores en las utilidades*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602011403085')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602008504109')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (602011403085) con Moneda 4, debe ser igual a la sumatoria de las cuentas (602008504109) con Moneda 4.')    
AS VALIDACION_1217,

/*Costo neto del periodo derivado de beneficios a los empleados a largo plazo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602001002115')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602011503087','602011503088','602011503089')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (602001002115) con Moneda 4, debe ser igual a la sumatoria de las cuentas (602011503087 + 602011503088 + 602011503089) con Moneda 4.')    
AS VALIDACION_1218,

/*Beneficios directos a largo plazo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602011503087')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602008704110','602008704111')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (602011503087) con Moneda 4, debe ser igual a la sumatoria de las cuentas (602008704110 + 602008704111) con Moneda 4.')    
AS VALIDACION_1219,

/*Beneficios post-empleo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602011503088')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602008804112','602008804113','602008804114')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (602011503088) con Moneda 4, debe ser igual a la sumatoria de las cuentas (602008804112 + 602008804113 + 602008804114) con Moneda 4.')    
AS VALIDACION_1220,

/*Beneficios por terminación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602011503089')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602008904115','602008904116')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (602011503089) con Moneda 4, debe ser igual a la sumatoria de las cuentas (602008904115 + 602008904116) con Moneda 4.')    
AS VALIDACION_1221,

/*Depreciaciones*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602001002123')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602012303090','602012303091')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (602001002123) con Moneda 4, debe ser igual a la sumatoria de las cuentas (602012303090 + 602012303091) con Moneda 4.')    
AS VALIDACION_1222,

/*Amortizaciones*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602001002124')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('602012403092','602012403093')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (602001002124) con Moneda 4, debe ser igual a la sumatoria de las cuentas (602012403092 + 602012403093) con Moneda 4.')    
AS VALIDACION_1223,

/*Participación en el resultado neto de otras entidades*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)     
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502200401011')    
AND c05_moneda IN ('4')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c06_dato AS DECIMAL)),0)      
FROM IFRS9_R01A_0111   
WHERE [c04_concepto] IN ('502201102131','502201102132','502201102133','502201102134','502201102135','502201102136')     
AND c05_moneda IN ('4')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (502200401011) con Moneda 4, debe ser igual a la sumatoria de las cuentas (502201102131 + 502201102132 + 502201102133 + 502201102134 + 502201102135 + 502201102136) con Moneda 4.')    
AS VALIDACION_1224
	
INTO IFRS9_R01A_0111_M4_RESULT_6
FROM IFRS9_R01A_0111

END

BEGIN
	INSERT INTO IFRS9_R01A_0111_M4_RESULT_6
		select 'TOTAL ERRORES',  SUM(CHARINDEX('ERR',[VALIDACION_1125])),
SUM(CHARINDEX('ERR',[VALIDACION_1126])),
SUM(CHARINDEX('ERR',[VALIDACION_1127])),
SUM(CHARINDEX('ERR',[VALIDACION_1128])),
SUM(CHARINDEX('ERR',[VALIDACION_1129])),
SUM(CHARINDEX('ERR',[VALIDACION_1130])),
SUM(CHARINDEX('ERR',[VALIDACION_1131])),
SUM(CHARINDEX('ERR',[VALIDACION_1132])),
SUM(CHARINDEX('ERR',[VALIDACION_1133])),
SUM(CHARINDEX('ERR',[VALIDACION_1134])),
SUM(CHARINDEX('ERR',[VALIDACION_1135])),
SUM(CHARINDEX('ERR',[VALIDACION_1136])),
SUM(CHARINDEX('ERR',[VALIDACION_1137])),
SUM(CHARINDEX('ERR',[VALIDACION_1138])),
SUM(CHARINDEX('ERR',[VALIDACION_1139])),
SUM(CHARINDEX('ERR',[VALIDACION_1140])),
SUM(CHARINDEX('ERR',[VALIDACION_1141])),
SUM(CHARINDEX('ERR',[VALIDACION_1142])),
SUM(CHARINDEX('ERR',[VALIDACION_1143])),
SUM(CHARINDEX('ERR',[VALIDACION_1144])),
SUM(CHARINDEX('ERR',[VALIDACION_1145])),
SUM(CHARINDEX('ERR',[VALIDACION_1146])),
SUM(CHARINDEX('ERR',[VALIDACION_1147])),
SUM(CHARINDEX('ERR',[VALIDACION_1148])),
SUM(CHARINDEX('ERR',[VALIDACION_1149])),
SUM(CHARINDEX('ERR',[VALIDACION_1150])),
SUM(CHARINDEX('ERR',[VALIDACION_1151])),
SUM(CHARINDEX('ERR',[VALIDACION_1152])),
SUM(CHARINDEX('ERR',[VALIDACION_1153])),
SUM(CHARINDEX('ERR',[VALIDACION_1154])),
SUM(CHARINDEX('ERR',[VALIDACION_1155])),
SUM(CHARINDEX('ERR',[VALIDACION_1156])),
SUM(CHARINDEX('ERR',[VALIDACION_1157])),
SUM(CHARINDEX('ERR',[VALIDACION_1158])),
SUM(CHARINDEX('ERR',[VALIDACION_1159])),
SUM(CHARINDEX('ERR',[VALIDACION_1160])),
SUM(CHARINDEX('ERR',[VALIDACION_1161])),
SUM(CHARINDEX('ERR',[VALIDACION_1162])),
SUM(CHARINDEX('ERR',[VALIDACION_1163])),
SUM(CHARINDEX('ERR',[VALIDACION_1164])),
SUM(CHARINDEX('ERR',[VALIDACION_1165])),
SUM(CHARINDEX('ERR',[VALIDACION_1166])),
SUM(CHARINDEX('ERR',[VALIDACION_1167])),
SUM(CHARINDEX('ERR',[VALIDACION_1168])),
SUM(CHARINDEX('ERR',[VALIDACION_1169])),
SUM(CHARINDEX('ERR',[VALIDACION_1170])),
SUM(CHARINDEX('ERR',[VALIDACION_1171])),
SUM(CHARINDEX('ERR',[VALIDACION_1172])),
SUM(CHARINDEX('ERR',[VALIDACION_1173])),
SUM(CHARINDEX('ERR',[VALIDACION_1174])),
SUM(CHARINDEX('ERR',[VALIDACION_1175])),
SUM(CHARINDEX('ERR',[VALIDACION_1176])),
SUM(CHARINDEX('ERR',[VALIDACION_1177])),
SUM(CHARINDEX('ERR',[VALIDACION_1178])),
SUM(CHARINDEX('ERR',[VALIDACION_1179])),
SUM(CHARINDEX('ERR',[VALIDACION_1180])),
SUM(CHARINDEX('ERR',[VALIDACION_1181])),
SUM(CHARINDEX('ERR',[VALIDACION_1182])),
SUM(CHARINDEX('ERR',[VALIDACION_1183])),
SUM(CHARINDEX('ERR',[VALIDACION_1184])),
SUM(CHARINDEX('ERR',[VALIDACION_1185])),
SUM(CHARINDEX('ERR',[VALIDACION_1186])),
SUM(CHARINDEX('ERR',[VALIDACION_1187])),
SUM(CHARINDEX('ERR',[VALIDACION_1188])),
SUM(CHARINDEX('ERR',[VALIDACION_1189])),
SUM(CHARINDEX('ERR',[VALIDACION_1190])),
SUM(CHARINDEX('ERR',[VALIDACION_1191])),
SUM(CHARINDEX('ERR',[VALIDACION_1192])),
SUM(CHARINDEX('ERR',[VALIDACION_1193])),
SUM(CHARINDEX('ERR',[VALIDACION_1194])),
SUM(CHARINDEX('ERR',[VALIDACION_1195])),
SUM(CHARINDEX('ERR',[VALIDACION_1196])),
SUM(CHARINDEX('ERR',[VALIDACION_1197])),
SUM(CHARINDEX('ERR',[VALIDACION_1198])),
SUM(CHARINDEX('ERR',[VALIDACION_1199])),
SUM(CHARINDEX('ERR',[VALIDACION_1200])),
SUM(CHARINDEX('ERR',[VALIDACION_1201])),
SUM(CHARINDEX('ERR',[VALIDACION_1202])),
SUM(CHARINDEX('ERR',[VALIDACION_1203])),
SUM(CHARINDEX('ERR',[VALIDACION_1204])),
SUM(CHARINDEX('ERR',[VALIDACION_1205])),
SUM(CHARINDEX('ERR',[VALIDACION_1206])),
SUM(CHARINDEX('ERR',[VALIDACION_1207])),
SUM(CHARINDEX('ERR',[VALIDACION_1208])),
SUM(CHARINDEX('ERR',[VALIDACION_1209])),
SUM(CHARINDEX('ERR',[VALIDACION_1210])),
SUM(CHARINDEX('ERR',[VALIDACION_1211])),
SUM(CHARINDEX('ERR',[VALIDACION_1212])),
SUM(CHARINDEX('ERR',[VALIDACION_1213])),
SUM(CHARINDEX('ERR',[VALIDACION_1214])),
SUM(CHARINDEX('ERR',[VALIDACION_1215])),
SUM(CHARINDEX('ERR',[VALIDACION_1216])),
SUM(CHARINDEX('ERR',[VALIDACION_1217])),
SUM(CHARINDEX('ERR',[VALIDACION_1218])),
SUM(CHARINDEX('ERR',[VALIDACION_1219])),
SUM(CHARINDEX('ERR',[VALIDACION_1220])),
SUM(CHARINDEX('ERR',[VALIDACION_1221])),
SUM(CHARINDEX('ERR',[VALIDACION_1222])),
SUM(CHARINDEX('ERR',[VALIDACION_1223])),
SUM(CHARINDEX('ERR',[VALIDACION_1224]))


		from IFRS9_R01A_0111_M4_RESULT_6
END

BEGIN
	EXEC SP_IFRS9_R01A_0111_M4_VIEW_6
END

COMMIT


END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


