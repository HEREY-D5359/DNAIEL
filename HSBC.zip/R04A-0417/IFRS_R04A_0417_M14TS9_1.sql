﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Calificación de la cartera de crédito y estimación preventiva para riesgos crediticios */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 14*/
/*TIPO SALDO: 9*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROCEDURE [dbo].[SP_IFRS9_R04A_0417_M14TS9_COMP_1]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0417_M14TS9_RESULT_1')
BEGIN
DROP TABLE IFRS9_R04A_0417_M14TS9_RESULT_1
END 

BEGIN
SELECT DISTINCT

    /*ID*/

    CONVERT(VARCHAR,ID) AS ID,

	/*I. Cartera base y estimaciones derivadas de la calificación sobre créditos con riesgo  de crédito etapa 1*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('111800304001')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('101800505014','111800505015')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111800304001) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (101800505014 + 111800505015) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_1,

/*A). Cartera de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101800505014')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('101801406055','101801406056','101801406057')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800505014) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (101801406055 + 101801406056 + 101801406057) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_2,

/*1. Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101801406055')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('101808208125','101808208126','101808208127')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101801406055) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (101808208125 + 101808208126 + 101808208127) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_3,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101808208125')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('101812509169','101812509170','101812509171','101812509172','101812509173','101812509174','101812509175','101812509176')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101808208125) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (101812509169 + 101812509170 + 101812509171 + 101812509172 + 101812509173 + 101812509174 + 101812509175 + 101812509176) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_4,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101812509169')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('101816910145','101816910146')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812509169) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (101816910145 + 101816910146) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_5,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101816910145')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111814511049','111814511050','111814511051','111814511052','111814511053','111814511054','111814511055','111814511056','111814511057','111814511058')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101816910145) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111814511049 + 111814511050 + 111814511051 + 111814511052 + 111814511053 + 111814511054 + 111814511055 + 111814511056 + 111814511057 + 111814511058) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_6,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101816910146')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111814611059','111814611060','111814611061','111814611062','111814611063','111814611064','111814611065','111814611066','111814611067','111814611068')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101816910146) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111814611059 + 111814611060 + 111814611061 + 111814611062 + 111814611063 + 111814611064 + 111814611065 + 111814611066 + 111814611067 + 111814611068) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_7,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101812509170')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('101817010147','101817010148','101817010149')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812509170) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (101817010147 + 101817010148 + 101817010149) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_8,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101817010147')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111814711069','111814711070','111814711071','111814711072','111814711073','111814711074','111814711075','111814711076','111814711077','111814711078')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101817010147) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111814711069 + 111814711070 + 111814711071 + 111814711072 + 111814711073 + 111814711074 + 111814711075 + 111814711076 + 111814711077 + 111814711078) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_9,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101817010148')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111814811079','111814811080','111814811081','111814811082','111814811083','111814811084','111814811085','111814811086','111814811087','111814811088')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101817010148) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111814811079 + 111814811080 + 111814811081 + 111814811082 + 111814811083 + 111814811084 + 111814811085 + 111814811086 + 111814811087 + 111814811088) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_10,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101817010149')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111814911089','111814911090','111814911091','111814911092','111814911093','111814911094','111814911095','111814911096','111814911097','111814911098')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101817010149) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111814911089 + 111814911090 + 111814911091 + 111814911092 + 111814911093 + 111814911094 + 111814911095 + 111814911096 + 111814911097 + 111814911098) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_11,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101812509171')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('101817110150','101817110151')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812509171) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (101817110150 + 101817110151) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_12,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101817110150')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111815011099','111815011100','111815011101','111815011102','111815011103','111815011104','111815011105','111815011106','111815011107','111815011108')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101817110150) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111815011099 + 111815011100 + 111815011101 + 111815011102 + 111815011103 + 111815011104 + 111815011105 + 111815011106 + 111815011107 + 111815011108) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_13,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101817110151')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111815111109','111815111110','111815111111','111815111112','111815111113','111815111114','111815111115','111815111116','111815111117','111815111118')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101817110151) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111815111109 + 111815111110 + 111815111111 + 111815111112 + 111815111113 + 111815111114 + 111815111115 + 111815111116 + 111815111117 + 111815111118) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_14,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101812509172')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111817210152','111817210153','111817210154','111817210155','111817210156','111817210157','111817210158','111817210159','111817210160','111817210161')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812509172) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111817210152 + 111817210153 + 111817210154 + 111817210155 + 111817210156 + 111817210157 + 111817210158 + 111817210159 + 111817210160 + 111817210161) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_15,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101812509173')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111817310162','111817310163','111817310164','111817310165','111817310166','111817310167','111817310168','111817310169','111817310170','111817310171')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812509173) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111817310162 + 111817310163 + 111817310164 + 111817310165 + 111817310166 + 111817310167 + 111817310168 + 111817310169 + 111817310170 + 111817310171) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_16,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101812509174')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111817410172','111817410173','111817410174','111817410175','111817410176','111817410177','111817410178','111817410179','111817410180','111817410181')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812509174) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111817410172 + 111817410173 + 111817410174 + 111817410175 + 111817410176 + 111817410177 + 111817410178 + 111817410179 + 111817410180 + 111817410181) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_17,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101812509175')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111817510182','111817510183','111817510184','111817510185','111817510186','111817510187','111817510188','111817510189','111817510190','111817510191')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812509175) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111817510182 + 111817510183 + 111817510184 + 111817510185 + 111817510186 + 111817510187 + 111817510188 + 111817510189 + 111817510190 + 111817510191) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_18,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101812509176')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111817610192','111817610193','111817610194','111817610195','111817610196','111817610197','111817610198','111817610199','111817610200','111817610201')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812509176) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111817610192 + 111817610193 + 111817610194 + 111817610195 + 111817610196 + 111817610197 + 111817610198 + 111817610199 + 111817610200 + 111817610201) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_19,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101808208126')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('101812609177','101812609178')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101808208126) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (101812609177 + 101812609178) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_20,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101812609177')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('101817710202','101817710203','101817710204')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812609177) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (101817710202 + 101817710203 + 101817710204) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_21,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101817710202')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111820211119','111820211120','111820211121','111820211122','111820211123','111820211124','111820211125','111820211126','111820211127','111820211128')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101817710202) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111820211119 + 111820211120 + 111820211121 + 111820211122 + 111820211123 + 111820211124 + 111820211125 + 111820211126 + 111820211127 + 111820211128) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_22,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101817710203')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111820311129','111820311130','111820311131','111820311132','111820311133','111820311134','111820311135','111820311136','111820311137','111820311138')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101817710203) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111820311129 + 111820311130 + 111820311131 + 111820311132 + 111820311133 + 111820311134 + 111820311135 + 111820311136 + 111820311137 + 111820311138) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_23,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101817710204')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111820411139','111820411140','111820411141','111820411142','111820411143','111820411144','111820411145','111820411146','111820411147','111820411148')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101817710204) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111820411139 + 111820411140 + 111820411141 + 111820411142 + 111820411143 + 111820411144 + 111820411145 + 111820411146 + 111820411147 + 111820411148) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_24,

/*Créditos a entidades financieras  no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101812609178')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('101817810205','101817810206','101817810207')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812609178) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (101817810205 + 101817810206 + 101817810207) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_25,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101817810205')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111820511149','111820511150','111820511151','111820511152','111820511153','111820511154','111820511155','111820511156','111820511157','111820511158')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101817810205) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111820511149 + 111820511150 + 111820511151 + 111820511152 + 111820511153 + 111820511154 + 111820511155 + 111820511156 + 111820511157 + 111820511158) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_26,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101817810206')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111820611159','111820611160','111820611161','111820611162','111820611163','111820611164','111820611165','111820611166','111820611167','111820611168')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101817810206) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111820611159 + 111820611160 + 111820611161 + 111820611162 + 111820611163 + 111820611164 + 111820611165 + 111820611166 + 111820611167 + 111820611168) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_27,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101817810207')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111820711169','111820711170','111820711171','111820711172','111820711173','111820711174','111820711175','111820711176','111820711177','111820711178')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101817810207) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111820711169 + 111820711170 + 111820711171 + 111820711172 + 111820711173 + 111820711174 + 111820711175 + 111820711176 + 111820711177 + 111820711178) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_28,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101808208127')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('101812709179','101812709180','101812709181','101812709182')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101808208127) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (101812709179 + 101812709180 + 101812709181 + 101812709182) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_29,

/*Créditos al gobierno federal */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101812709179')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111817910208','111817910209','111817910210','111817910211','111817910212','111817910213','111817910214','111817910215','111817910216','111817910217','111817910218')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812709179) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111817910208 + 111817910209 + 111817910210 + 111817910211 + 111817910212 + 111817910213 + 111817910214 + 111817910215 + 111817910216 + 111817910217 + 111817910218) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_30,

/*Créditos a estados y municipios */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101812709180')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('101818010219','101818010220','101818010221','101818010222','101818010223')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812709180) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (101818010219 + 101818010220 + 101818010221 + 101818010222 + 101818010223) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_31,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101818010219')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111821911179','111821911180','111821911181','111821911182','111821911183','111821911184','111821911185','111821911186','111821911187','111821911188')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101818010219) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111821911179 + 111821911180 + 111821911181 + 111821911182 + 111821911183 + 111821911184 + 111821911185 + 111821911186 + 111821911187 + 111821911188) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_32,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101818010220')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111822011189','111822011190','111822011191','111822011192','111822011193','111822011194','111822011195','111822011196','111822011197','111822011198')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101818010220) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111822011189 + 111822011190 + 111822011191 + 111822011192 + 111822011193 + 111822011194 + 111822011195 + 111822011196 + 111822011197 + 111822011198) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_33,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101818010221')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111822111199','111822111200','111822111201','111822111202','111822111203','111822111204','111822111205','111822111206','111822111207','111822111208')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101818010221) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111822111199 + 111822111200 + 111822111201 + 111822111202 + 111822111203 + 111822111204 + 111822111205 + 111822111206 + 111822111207 + 111822111208) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_34,

/*Fideicomisos públicos de contratación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101818010222')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111822211209','111822211210','111822211211','111822211212','111822211213','111822211214','111822211215','111822211216','111822211217','111822211218')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101818010222) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111822211209 + 111822211210 + 111822211211 + 111822211212 + 111822211213 + 111822211214 + 111822211215 + 111822211216 + 111822211217 + 111822211218) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_35,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101818010223')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111822311219','111822311220','111822311221','111822311222','111822311223','111822311224','111822311225','111822311226','111822311227','111822311228')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101818010223) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111822311219 + 111822311220 + 111822311221 + 111822311222 + 111822311223 + 111822311224 + 111822311225 + 111822311226 + 111822311227 + 111822311228) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_36,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101812709181')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('101818110224','101818110225','101818110226','101818110227')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812709181) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (101818110224 + 101818110225 + 101818110226 + 101818110227) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_37,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101818110224')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111822411229','111822411230','111822411231','111822411232','111822411233','111822411234','111822411235','111822411236','111822411237','111822411238')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101818110224) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111822411229 + 111822411230 + 111822411231 + 111822411232 + 111822411233 + 111822411234 + 111822411235 + 111822411236 + 111822411237 + 111822411238) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_38,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101818110225')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111822511239','111822511240','111822511241','111822511242','111822511243','111822511244','111822511245','111822511246','111822511247','111822511248')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101818110225) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111822511239 + 111822511240 + 111822511241 + 111822511242 + 111822511243 + 111822511244 + 111822511245 + 111822511246 + 111822511247 + 111822511248) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_39,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101818110226')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111822611249','111822611250','111822611251','111822611252','111822611253','111822611254','111822611255','111822611256','111822611257','111822611258')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101818110226) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111822611249 + 111822611250 + 111822611251 + 111822611252 + 111822611253 + 111822611254 + 111822611255 + 111822611256 + 111822611257 + 111822611258) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_40,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101818110227')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111822711259','111822711260','111822711261','111822711262','111822711263','111822711264','111822711265','111822711266','111822711267','111822711268')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101818110227) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111822711259 + 111822711260 + 111822711261 + 111822711262 + 111822711263 + 111822711264 + 111822711265 + 111822711266 + 111822711267 + 111822711268) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_41,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101812709182')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('101818210228','101818210229','101818210230','101818210231')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812709182) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (101818210228 + 101818210229 + 101818210230 + 101818210231) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_42,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101818210228')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111822811269','111822811270','111822811271','111822811272','111822811273','111822811274','111822811275','111822811276','111822811277','111822811278')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101818210228) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111822811269 + 111822811270 + 111822811271 + 111822811272 + 111822811273 + 111822811274 + 111822811275 + 111822811276 + 111822811277 + 111822811278) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_43,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101818210229')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111822911279','111822911280','111822911281','111822911282','111822911283','111822911284','111822911285','111822911286','111822911287','111822911288')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101818210229) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111822911279 + 111822911280 + 111822911281 + 111822911282 + 111822911283 + 111822911284 + 111822911285 + 111822911286 + 111822911287 + 111822911288) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_44,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101818210230')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111823011289','111823011290','111823011291','111823011292','111823011293','111823011294','111823011295','111823011296','111823011297','111823011298')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101818210230) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111823011289 + 111823011290 + 111823011291 + 111823011292 + 111823011293 + 111823011294 + 111823011295 + 111823011296 + 111823011297 + 111823011298) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_45,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101818210231')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111823111299','111823111300','111823111301','111823111302','111823111303','111823111304','111823111305','111823111306','111823111307','111823111308')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101818210231) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111823111299 + 111823111300 + 111823111301 + 111823111302 + 111823111303 + 111823111304 + 111823111305 + 111823111306 + 111823111307 + 111823111308) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_46,

/*2. Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101801406056')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('101808408131','101808408132','101808408133','101808408134','101808408135','101808408136','101808408137','101808408138')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101801406056) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (101808408131 + 101808408132 + 101808408133 + 101808408134 + 101808408135 + 101808408136 + 101808408137 + 101808408138) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_47,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101808408131')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111813109197','111813109198','111813109199','111813109200','111813109201','111813109202','111813109203','111813109204','111813109205','111813109206')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101808408131) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111813109197 + 111813109198 + 111813109199 + 111813109200 + 111813109201 + 111813109202 + 111813109203 + 111813109204 + 111813109205 + 111813109206) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_48,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101808408132')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111813209207','111813209208','111813209209','111813209210','111813209211','111813209212','111813209213','111813209214','111813209215','111813209216')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101808408132) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111813209207 + 111813209208 + 111813209209 + 111813209210 + 111813209211 + 111813209212 + 111813209213 + 111813209214 + 111813209215 + 111813209216) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_49,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101808408133')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111813309217','111813309218','111813309219','111813309220','111813309221','111813309222','111813309223','111813309224','111813309225','111813309226')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101808408133) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111813309217 + 111813309218 + 111813309219 + 111813309220 + 111813309221 + 111813309222 + 111813309223 + 111813309224 + 111813309225 + 111813309226) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_50,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101808408134')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111813409227','111813409228','111813409229','111813409230','111813409231','111813409232','111813409233','111813409234','111813409235','111813409236')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101808408134) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111813409227 + 111813409228 + 111813409229 + 111813409230 + 111813409231 + 111813409232 + 111813409233 + 111813409234 + 111813409235 + 111813409236) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_51,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101808408135')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111813509237','111813509238','111813509239','111813509240','111813509241','111813509242','111813509243','111813509244','111813509245','111813509246')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101808408135) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111813509237 + 111813509238 + 111813509239 + 111813509240 + 111813509241 + 111813509242 + 111813509243 + 111813509244 + 111813509245 + 111813509246) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_52,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101808408136')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111813609247','111813609248','111813609249','111813609250','111813609251','111813609252','111813609253','111813609254','111813609255','111813609256')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101808408136) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111813609247 + 111813609248 + 111813609249 + 111813609250 + 111813609251 + 111813609252 + 111813609253 + 111813609254 + 111813609255 + 111813609256) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_53,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101808408137')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111813709257','111813709258','111813709259','111813709260','111813709261','111813709262','111813709263','111813709264','111813709265','111813709266')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101808408137) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111813709257 + 111813709258 + 111813709259 + 111813709260 + 111813709261 + 111813709262 + 111813709263 + 111813709264 + 111813709265 + 111813709266) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_54,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101808408138')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111813809267','111813809268','111813809269','111813809270','111813809271','111813809272','111813809273','111813809274','111813809275','111813809276')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101808408138) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111813809267 + 111813809268 + 111813809269 + 111813809270 + 111813809271 + 111813809272 + 111813809273 + 111813809274 + 111813809275 + 111813809276) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_55,

/*3. Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101801406057')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('101808608147','101808608148','101808608149','101808608150','101808608151')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101801406057) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (101808608147 + 101808608148 + 101808608149 + 101808608150 + 101808608151) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_56,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101808608147')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111814709277','111814709278','111814709279','111814709280','111814709281','111814709282','111814709283','111814709284','111814709285','111814709286')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101808608147) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111814709277 + 111814709278 + 111814709279 + 111814709280 + 111814709281 + 111814709282 + 111814709283 + 111814709284 + 111814709285 + 111814709286) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_57,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101808608148')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111814809287','111814809288','111814809289','111814809290','111814809291','111814809292','111814809293','111814809294','111814809295','111814809296')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101808608148) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111814809287 + 111814809288 + 111814809289 + 111814809290 + 111814809291 + 111814809292 + 111814809293 + 111814809294 + 111814809295 + 111814809296) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_58,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101808608149')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('101814909297','101814909298','101814909299')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101808608149) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (101814909297 + 101814909298 + 101814909299) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_59,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101814909297')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111829710258','111829710259','111829710260','111829710261','111829710262','111829710263','111829710264','111829710265','111829710266','111829710267')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101814909297) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111829710258 + 111829710259 + 111829710260 + 111829710261 + 111829710262 + 111829710263 + 111829710264 + 111829710265 + 111829710266 + 111829710267) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_60,

/*Cartera en prórroga*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101814909298')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111829810268','111829810269','111829810270','111829810271','111829810272','111829810273','111829810274','111829810275','111829810276','111829810277')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101814909298) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111829810268 + 111829810269 + 111829810270 + 111829810271 + 111829810272 + 111829810273 + 111829810274 + 111829810275 + 111829810276 + 111829810277) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_61,

/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101814909299')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111829910278','111829910279','111829910280','111829910281','111829910282','111829910283','111829910284','111829910285','111829910286','111829910287')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101814909299) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111829910278 + 111829910279 + 111829910280 + 111829910281 + 111829910282 + 111829910283 + 111829910284 + 111829910285 + 111829910286 + 111829910287) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_62,

/*Remodelación o mejoramiento con garantía otorgada por la Banca de Desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101808608150')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111815009300','111815009301','111815009302','111815009303','111815009304','111815009305','111815009306','111815009307','111815009308','111815009309')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101808608150) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111815009300 + 111815009301 + 111815009302 + 111815009303 + 111815009304 + 111815009305 + 111815009306 + 111815009307 + 111815009308 + 111815009309) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_63,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101808608151')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111815109310','111815109311','111815109312','111815109313','111815109314','111815109315','111815109316','111815109317','111815109318','111815109319')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101808608151) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111815109310 + 111815109311 + 111815109312 + 111815109313 + 111815109314 + 111815109315 + 111815109316 + 111815109317 + 111815109318 + 111815109319) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_64,

/*B). Operaciones fuera de balance*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('111800505015')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111801506059','111801506060')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111800505015) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111801506059 + 111801506060) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_65,

/*1. Avales otorgados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('111801506059')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111805907099','111805907100','111805907101','111805907102','111805907103','111805907104','111805907105','111805907106','111805907107','111805907108')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111801506059) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111805907099 + 111805907100 + 111805907101 + 111805907102 + 111805907103 + 111805907104 + 111805907105 + 111805907106 + 111805907107 + 111805907108) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_66,

/*2. Compromisos crediticios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('111801506060')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111806007109','111806007110','111806007111','111806007112','111806007113','111806007114','111806007115','111806007116','111806007117','111806007118')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111801506060) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111806007109 + 111806007110 + 111806007111 + 111806007112 + 111806007113 + 111806007114 + 111806007115 + 111806007116 + 111806007117 + 111806007118) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_67,

/*II. Cartera base y estimaciones derivadas de la calificación sobre créditos con riesgo  de crédito etapa 2*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('111800304002')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('101800505016','111800505017')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (111800304002) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (101800505016 + 111800505017) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_68,

/*A). Cartera de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101800505016')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('101801606061','101801606062','101801606063')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800505016) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (101801606061 + 101801606062 + 101801606063) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_69,

/*1. Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101801606061')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('101806107119','101806107120','101806107121')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101801606061) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (101806107119 + 101806107120 + 101806107121) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_70,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101806107119')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('101811908157','101811908158','101811908159','101811908160','101811908161','101811908162','101811908163','101811908164')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101806107119) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (101811908157 + 101811908158 + 101811908159 + 101811908160 + 101811908161 + 101811908162 + 101811908163 + 101811908164) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_71,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101811908157')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('101815709323','101815709324')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101811908157) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (101815709323 + 101815709324) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_72,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101815709323')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111832310288','111832310289','111832310290','111832310291','111832310292','111832310293','111832310294','111832310295','111832310296','111832310297')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101815709323) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111832310288 + 111832310289 + 111832310290 + 111832310291 + 111832310292 + 111832310293 + 111832310294 + 111832310295 + 111832310296 + 111832310297) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_73,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101815709324')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111832410298','111832410299','111832410300','111832410301','111832410302','111832410303','111832410304','111832410305','111832410306','111832410307')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101815709324) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111832410298 + 111832410299 + 111832410300 + 111832410301 + 111832410302 + 111832410303 + 111832410304 + 111832410305 + 111832410306 + 111832410307) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_74,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101811908158')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('101815809325','101815809326','101815809327')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101811908158) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (101815809325 + 101815809326 + 101815809327) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_75,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101815809325')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111832510308','111832510309','111832510310','111832510311','111832510312','111832510313','111832510314','111832510315','111832510316','111832510317')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101815809325) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111832510308 + 111832510309 + 111832510310 + 111832510311 + 111832510312 + 111832510313 + 111832510314 + 111832510315 + 111832510316 + 111832510317) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_76,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101815809326')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111832610318','111832610319','111832610320','111832610321','111832610322','111832610323','111832610324','111832610325','111832610326','111832610327')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101815809326) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111832610318 + 111832610319 + 111832610320 + 111832610321 + 111832610322 + 111832610323 + 111832610324 + 111832610325 + 111832610326 + 111832610327) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_77,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101815809327')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111832710328','111832710329','111832710330','111832710331','111832710332','111832710333','111832710334','111832710335','111832710336','111832710337')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101815809327) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111832710328 + 111832710329 + 111832710330 + 111832710331 + 111832710332 + 111832710333 + 111832710334 + 111832710335 + 111832710336 + 111832710337) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_78,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101811908159')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('101815909328','101815909329')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101811908159) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (101815909328 + 101815909329) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_79,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101815909328')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111832810338','111832810339','111832810340','111832810341','111832810342','111832810343','111832810344','111832810345','111832810346','111832810347')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101815909328) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111832810338 + 111832810339 + 111832810340 + 111832810341 + 111832810342 + 111832810343 + 111832810344 + 111832810345 + 111832810346 + 111832810347) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_80,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101815909329')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111832910348','111832910349','111832910350','111832910351','111832910352','111832910353','111832910354','111832910355','111832910356','111832910357')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101815909329) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111832910348 + 111832910349 + 111832910350 + 111832910351 + 111832910352 + 111832910353 + 111832910354 + 111832910355 + 111832910356 + 111832910357) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_81,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101811908160')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111816009330','111816009331','111816009332','111816009333','111816009334','111816009335','111816009336','111816009337','111816009338','111816009339')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101811908160) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111816009330 + 111816009331 + 111816009332 + 111816009333 + 111816009334 + 111816009335 + 111816009336 + 111816009337 + 111816009338 + 111816009339) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_82,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101811908161')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111816109340','111816109341','111816109342','111816109343','111816109344','111816109345','111816109346','111816109347','111816109348','111816109349')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101811908161) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111816109340 + 111816109341 + 111816109342 + 111816109343 + 111816109344 + 111816109345 + 111816109346 + 111816109347 + 111816109348 + 111816109349) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_83,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101811908162')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111816209350','111816209351','111816209352','111816209353','111816209354','111816209355','111816209356','111816209357','111816209358','111816209359')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101811908162) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111816209350 + 111816209351 + 111816209352 + 111816209353 + 111816209354 + 111816209355 + 111816209356 + 111816209357 + 111816209358 + 111816209359) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_84,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101811908163')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111816309360','111816309361','111816309362','111816309363','111816309364','111816309365','111816309366','111816309367','111816309368','111816309369')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101811908163) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111816309360 + 111816309361 + 111816309362 + 111816309363 + 111816309364 + 111816309365 + 111816309366 + 111816309367 + 111816309368 + 111816309369) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_85,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101811908164')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111816409370','111816409371','111816409372','111816409373','111816409374','111816409375','111816409376','111816409377','111816409378','111816409379')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101811908164) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111816409370 + 111816409371 + 111816409372 + 111816409373 + 111816409374 + 111816409375 + 111816409376 + 111816409377 + 111816409378 + 111816409379) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_86,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101806107120')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('101812008165','101812008166')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101806107120) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (101812008165 + 101812008166) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_87,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101812008165')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('101816509380','101816509381','101816509382')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812008165) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (101816509380 + 101816509381 + 101816509382) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_88,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101816509380')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111838010358','111838010359','111838010360','111838010361','111838010362','111838010363','111838010364','111838010365','111838010366','111838010367')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101816509380) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111838010358 + 111838010359 + 111838010360 + 111838010361 + 111838010362 + 111838010363 + 111838010364 + 111838010365 + 111838010366 + 111838010367) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_89,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101816509381')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111838110368','111838110369','111838110370','111838110371','111838110372','111838110373','111838110374','111838110375','111838110376','111838110377')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101816509381) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111838110368 + 111838110369 + 111838110370 + 111838110371 + 111838110372 + 111838110373 + 111838110374 + 111838110375 + 111838110376 + 111838110377) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_90,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101816509382')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111838210378','111838210379','111838210380','111838210381','111838210382','111838210383','111838210384','111838210385','111838210386','111838210387')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101816509382) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111838210378 + 111838210379 + 111838210380 + 111838210381 + 111838210382 + 111838210383 + 111838210384 + 111838210385 + 111838210386 + 111838210387) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_91,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101812008166')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('101816609383','101816609384','101816609385')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812008166) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (101816609383 + 101816609384 + 101816609385) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_92,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101816609383')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111838310388','111838310389','111838310390','111838310391','111838310392','111838310393','111838310394','111838310395','111838310396','111838310397')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101816609383) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111838310388 + 111838310389 + 111838310390 + 111838310391 + 111838310392 + 111838310393 + 111838310394 + 111838310395 + 111838310396 + 111838310397) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_93,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101816609384')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111838410398','111838410399','111838410400','111838410401','111838410402','111838410403','111838410404','111838410405','111838410406','111838410407')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101816609384) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111838410398 + 111838410399 + 111838410400 + 111838410401 + 111838410402 + 111838410403 + 111838410404 + 111838410405 + 111838410406 + 111838410407) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_94,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101816609385')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111838510408','111838510409','111838510410','111838510411','111838510412','111838510413','111838510414','111838510415','111838510416','111838510417')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101816609385) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111838510408 + 111838510409 + 111838510410 + 111838510411 + 111838510412 + 111838510413 + 111838510414 + 111838510415 + 111838510416 + 111838510417) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_95,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101806107121')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('101812108167','101812108168','101812108169','101812108170')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101806107121) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (101812108167 + 101812108168 + 101812108169 + 101812108170) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_96,

/*Créditos al gobierno federal */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101812108167')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111816709386','111816709387','111816709388','111816709389','111816709390','111816709391','111816709392','111816709393','111816709394','111816709395','111816709396')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812108167) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111816709386 + 111816709387 + 111816709388 + 111816709389 + 111816709390 + 111816709391 + 111816709392 + 111816709393 + 111816709394 + 111816709395 + 111816709396) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_97,

/*Créditos a estados y municipios */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101812108168')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('101816809397','101816809398','101816809399','101816809400','101816809401')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101812108168) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (101816809397 + 101816809398 + 101816809399 + 101816809400 + 101816809401) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_98,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101816809397')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111839710418','111839710419','111839710420','111839710421','111839710422','111839710423','111839710424','111839710425','111839710426','111839710427')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101816809397) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111839710418 + 111839710419 + 111839710420 + 111839710421 + 111839710422 + 111839710423 + 111839710424 + 111839710425 + 111839710426 + 111839710427) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_99,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0417   
WHERE [c04_CONCEPTO] IN ('101816809398')   
AND c06_tipo_saldo IN ('9')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0417     
WHERE [c04_CONCEPTO] IN ('111839810428','111839810429','111839810430','111839810431','111839810432','111839810433','111839810434','111839810435','111839810436','111839810437')
AND c06_tipo_saldo IN ('9')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101816809398) con Moneda 14, Tipo de Saldo 9, debe ser igual a la sumatoria de las cuentas (111839810428 + 111839810429 + 111839810430 + 111839810431 + 111839810432 + 111839810433 + 111839810434 + 111839810435 + 111839810436 + 111839810437) con Moneda 14, Tipo de Saldo 9.')    
AS VALIDACION_100
	
INTO IFRS9_R04A_0417_M14TS9_RESULT_1
FROM IFRS9_R04A_0417

END

BEGIN
	INSERT INTO IFRS9_R04A_0417_M14TS9_RESULT_1
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_1])),
            SUM(CHARINDEX('ERR',[VALIDACION_2])),
            SUM(CHARINDEX('ERR',[VALIDACION_3])),
            SUM(CHARINDEX('ERR',[VALIDACION_4])),
            SUM(CHARINDEX('ERR',[VALIDACION_5])),
            SUM(CHARINDEX('ERR',[VALIDACION_6])),
            SUM(CHARINDEX('ERR',[VALIDACION_7])),
            SUM(CHARINDEX('ERR',[VALIDACION_8])),
            SUM(CHARINDEX('ERR',[VALIDACION_9])),
            SUM(CHARINDEX('ERR',[VALIDACION_10])),
            SUM(CHARINDEX('ERR',[VALIDACION_11])),
            SUM(CHARINDEX('ERR',[VALIDACION_12])),
            SUM(CHARINDEX('ERR',[VALIDACION_13])),
            SUM(CHARINDEX('ERR',[VALIDACION_14])),
            SUM(CHARINDEX('ERR',[VALIDACION_15])),
            SUM(CHARINDEX('ERR',[VALIDACION_16])),
            SUM(CHARINDEX('ERR',[VALIDACION_17])),
            SUM(CHARINDEX('ERR',[VALIDACION_18])),
            SUM(CHARINDEX('ERR',[VALIDACION_19])),
            SUM(CHARINDEX('ERR',[VALIDACION_20])),
            SUM(CHARINDEX('ERR',[VALIDACION_21])),
            SUM(CHARINDEX('ERR',[VALIDACION_22])),
            SUM(CHARINDEX('ERR',[VALIDACION_23])),
            SUM(CHARINDEX('ERR',[VALIDACION_24])),
            SUM(CHARINDEX('ERR',[VALIDACION_25])),
            SUM(CHARINDEX('ERR',[VALIDACION_26])),
            SUM(CHARINDEX('ERR',[VALIDACION_27])),
            SUM(CHARINDEX('ERR',[VALIDACION_28])),
            SUM(CHARINDEX('ERR',[VALIDACION_29])),
            SUM(CHARINDEX('ERR',[VALIDACION_30])),
            SUM(CHARINDEX('ERR',[VALIDACION_31])),
            SUM(CHARINDEX('ERR',[VALIDACION_32])),
            SUM(CHARINDEX('ERR',[VALIDACION_33])),
            SUM(CHARINDEX('ERR',[VALIDACION_34])),
            SUM(CHARINDEX('ERR',[VALIDACION_35])),
            SUM(CHARINDEX('ERR',[VALIDACION_36])),
            SUM(CHARINDEX('ERR',[VALIDACION_37])),
            SUM(CHARINDEX('ERR',[VALIDACION_38])),
            SUM(CHARINDEX('ERR',[VALIDACION_39])),
            SUM(CHARINDEX('ERR',[VALIDACION_40])),
            SUM(CHARINDEX('ERR',[VALIDACION_41])),
            SUM(CHARINDEX('ERR',[VALIDACION_42])),
            SUM(CHARINDEX('ERR',[VALIDACION_43])),
            SUM(CHARINDEX('ERR',[VALIDACION_44])),
            SUM(CHARINDEX('ERR',[VALIDACION_45])),
            SUM(CHARINDEX('ERR',[VALIDACION_46])),
            SUM(CHARINDEX('ERR',[VALIDACION_47])),
            SUM(CHARINDEX('ERR',[VALIDACION_48])),
            SUM(CHARINDEX('ERR',[VALIDACION_49])),
            SUM(CHARINDEX('ERR',[VALIDACION_50])),
            SUM(CHARINDEX('ERR',[VALIDACION_51])),
            SUM(CHARINDEX('ERR',[VALIDACION_52])),
            SUM(CHARINDEX('ERR',[VALIDACION_53])),
            SUM(CHARINDEX('ERR',[VALIDACION_54])),
            SUM(CHARINDEX('ERR',[VALIDACION_55])),
            SUM(CHARINDEX('ERR',[VALIDACION_56])),
            SUM(CHARINDEX('ERR',[VALIDACION_57])),
            SUM(CHARINDEX('ERR',[VALIDACION_58])),
            SUM(CHARINDEX('ERR',[VALIDACION_59])),
            SUM(CHARINDEX('ERR',[VALIDACION_60])),
            SUM(CHARINDEX('ERR',[VALIDACION_61])),
            SUM(CHARINDEX('ERR',[VALIDACION_62])),
            SUM(CHARINDEX('ERR',[VALIDACION_63])),
            SUM(CHARINDEX('ERR',[VALIDACION_64])),
            SUM(CHARINDEX('ERR',[VALIDACION_65])),
            SUM(CHARINDEX('ERR',[VALIDACION_66])),
            SUM(CHARINDEX('ERR',[VALIDACION_67])),
            SUM(CHARINDEX('ERR',[VALIDACION_68])),
            SUM(CHARINDEX('ERR',[VALIDACION_69])),
            SUM(CHARINDEX('ERR',[VALIDACION_70])),
            SUM(CHARINDEX('ERR',[VALIDACION_71])),
            SUM(CHARINDEX('ERR',[VALIDACION_72])),
            SUM(CHARINDEX('ERR',[VALIDACION_73])),
            SUM(CHARINDEX('ERR',[VALIDACION_74])),
            SUM(CHARINDEX('ERR',[VALIDACION_75])),
            SUM(CHARINDEX('ERR',[VALIDACION_76])),
            SUM(CHARINDEX('ERR',[VALIDACION_77])),
            SUM(CHARINDEX('ERR',[VALIDACION_78])),
            SUM(CHARINDEX('ERR',[VALIDACION_79])),
            SUM(CHARINDEX('ERR',[VALIDACION_80])),
            SUM(CHARINDEX('ERR',[VALIDACION_81])),
            SUM(CHARINDEX('ERR',[VALIDACION_82])),
            SUM(CHARINDEX('ERR',[VALIDACION_83])),
            SUM(CHARINDEX('ERR',[VALIDACION_84])),
            SUM(CHARINDEX('ERR',[VALIDACION_85])),
            SUM(CHARINDEX('ERR',[VALIDACION_86])),
            SUM(CHARINDEX('ERR',[VALIDACION_87])),
            SUM(CHARINDEX('ERR',[VALIDACION_88])),
            SUM(CHARINDEX('ERR',[VALIDACION_89])),
            SUM(CHARINDEX('ERR',[VALIDACION_90])),
            SUM(CHARINDEX('ERR',[VALIDACION_91])),
            SUM(CHARINDEX('ERR',[VALIDACION_92])),
            SUM(CHARINDEX('ERR',[VALIDACION_93])),
            SUM(CHARINDEX('ERR',[VALIDACION_94])),
            SUM(CHARINDEX('ERR',[VALIDACION_95])),
            SUM(CHARINDEX('ERR',[VALIDACION_96])),
            SUM(CHARINDEX('ERR',[VALIDACION_97])),
            SUM(CHARINDEX('ERR',[VALIDACION_98])),
            SUM(CHARINDEX('ERR',[VALIDACION_99])),
            SUM(CHARINDEX('ERR',[VALIDACION_100]))


		from IFRS9_R04A_0417_M14TS9_RESULT_1
END

BEGIN
	EXEC SP_IFRS9_R04A_0417_M14TS9_VIEW_1
END

COMMIT
END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


