SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en la estimación preventiva para riesgos crediticios */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/



CREATE TABLE [dbo].[IFRS9_R04A_0419](
	[c04_concepto] [varchar](255) NULL,
	[c05_moneda] [varchar](255) NULL,
	[c06_tipo_saldo] [varchar](255) NULL,
	[c07_dato] [varchar](255) NULL,
	[ID] INT IDENTITY (1,1)
) ON [PRIMARY]
GO


