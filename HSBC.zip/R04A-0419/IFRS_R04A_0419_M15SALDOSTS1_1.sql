﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en la estimación preventiva para riesgos crediticios */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15SALDOS*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0419_M15SALDOSTS1_COMP_1]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0419_M15SALDOSTS1_RESULT_1')
BEGIN
DROP TABLE IFRS9_R04A_0419_M15SALDOSTS1_RESULT_1
END 

BEGIN
SELECT DISTINCT
         /*id*/
CONVERT(VARCHAR,ID) AS ID, 
	/*Saldo inicial del mes*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800103001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800103001')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800103001) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800103001) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_1,

/*CARGOS*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800103002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800103002')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800103002) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800103002) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_2,

/*Castigos, eliminaciones y recuperaciones de cartera:*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800204001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800204001')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800204001) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800204001) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_3,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800105001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800105001')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800105001) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800105001) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_4,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800106001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800106001')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800106001) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800106001) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_5,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800107001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800107001')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800107001) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800107001) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_6,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800108001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800108001')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800108001) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800108001) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_7,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800108002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800108002')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800108002) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800108002) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_8,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800107002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800107002')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800107002) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800107002) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_9,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800208003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800208003')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800208003) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800208003) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_10,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800208004')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800208004')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800208004) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800208004) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_11,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800208005')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800208005')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800208005) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800208005) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_12,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800107003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800107003')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800107003) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800107003) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_13,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800308006')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800308006')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800308006) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800308006) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_14,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800308007')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800308007')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800308007) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800308007) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_15,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800107004')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800107004')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800107004) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800107004) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_16,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800107005')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800107005')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800107005) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800107005) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_17,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800107006')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800107006')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800107006) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800107006) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_18,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800107007')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800107007')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800107007) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800107007) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_19,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800107008')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800107008')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800107008) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800107008) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_20,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800106002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800106002')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800106002) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800106002) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_21,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800207009')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800207009')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800207009) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800207009) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_22,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800908008')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800908008')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800908008) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800908008) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_23,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800908009')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800908009')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800908009) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800908009) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_24,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800908010')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800908010')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800908010) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800908010) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_25,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800207010')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800207010')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800207010) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800207010) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_26,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801008011')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801008011')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801008011) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801008011) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_27,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801008012')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801008012')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801008012) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801008012) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_28,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801008013')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801008013')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801008013) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801008013) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_29,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800106003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800106003')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800106003) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800106003) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_30,

/*Créditos al gobierno federal */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800307011')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800307011')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800307011) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800307011) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_31,

/*Créditos a estados y municipios */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800307012')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800307012')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800307012) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800307012) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_32,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801208014')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801208014')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801208014) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801208014) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_33,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801208015')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801208015')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801208015) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801208015) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_34,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801208016')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801208016')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801208016) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801208016) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_35,

/*Fideicomisos públicos de contratación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801208017')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801208017')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801208017) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801208017) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_36,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801208018')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801208018')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801208018) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801208018) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_37,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800307013')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800307013')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800307013) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800307013) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_38,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801308019')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801308019')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801308019) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801308019) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_39,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801308020')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801308020')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801308020) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801308020) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_40,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801308021')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801308021')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801308021) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801308021) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_41,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801308022')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801308022')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801308022) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801308022) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_42,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800307014')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800307014')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800307014) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800307014) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_43,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801408023')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801408023')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801408023) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801408023) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_44,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801408024')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801408024')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801408024) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801408024) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_45,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801408025')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801408025')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801408025) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801408025) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_46,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801408026')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801408026')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801408026) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801408026) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_47,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800105002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800105002')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800105002) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800105002) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_48,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800206004')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800206004')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800206004) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800206004) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_49,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800206005')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800206005')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800206005) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800206005) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_50,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800206006')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800206006')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800206006) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800206006) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_51,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800206007')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800206007')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800206007) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800206007) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_52,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800206008')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800206008')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800206008) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800206008) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_53,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800206009')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800206009')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800206009) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800206009) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_54,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800206010')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800206010')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800206010) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800206010) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_55,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800206011')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800206011')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800206011) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800206011) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_56,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800105003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800105003')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800105003) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800105003) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_57,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800306012')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800306012')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800306012) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800306012) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_58,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800306013')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800306013')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800306013) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800306013) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_59,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800306014')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800306014')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800306014) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800306014) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_60,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801407015')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801407015')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801407015) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801407015) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_61,

/*Cartera en prórroga*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801407016')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801407016')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801407016) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801407016) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_62,

/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801407017')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801407017')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801407017) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801407017) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_63,

/*Remodelación o mejoramiento con garantía otorgada por la Banca de Desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800306015')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800306015')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800306015) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800306015) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_64,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800306016')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800306016')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800306016) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800306016) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_65,

/*Otros castigos, eliminaciones y recuperaciones*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800204002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800204002')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800204002) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800204002) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_66,

/*Quitas, condonaciones, bonificaciones y descuentos:*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800204003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800204003')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800204003) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800204003) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_67,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800305005')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800305005')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800305005) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800305005) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_68,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800506017')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800506017')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800506017) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800506017) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_69,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801707018')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801707018')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801707018) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801707018) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_70,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801808027')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801808027')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801808027) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801808027) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_71,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801808028')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801808028')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801808028) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801808028) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_72,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801707019')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801707019')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801707019) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801707019) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_73,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801908029')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801908029')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801908029) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801908029) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_74,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801908030')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801908030')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801908030) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801908030) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_75,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801908031')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801908031')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801908031) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801908031) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_76,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801707020')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801707020')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801707020) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801707020) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_77,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802008032')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802008032')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802008032) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802008032) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_78,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802008033')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802008033')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802008033) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802008033) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_79,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801707021')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801707021')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801707021) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801707021) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_80,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801707022')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801707022')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801707022) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801707022) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_81,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801707023')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801707023')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801707023) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801707023) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_82,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801707024')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801707024')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801707024) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801707024) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_83,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801707025')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801707025')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801707025) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801707025) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_84,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800506018')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800506018')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800506018) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800506018) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_85,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801807026')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801807026')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801807026) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801807026) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_86,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802608034')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802608034')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802608034) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802608034) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_87,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802608035')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802608035')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802608035) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802608035) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_88,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802608036')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802608036')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802608036) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802608036) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_89,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801807027')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801807027')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801807027) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801807027) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_90,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802708037')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802708037')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802708037) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802708037) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_91,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802708038')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802708038')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802708038) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802708038) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_92,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802708039')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802708039')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802708039) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802708039) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_93,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800506019')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800506019')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800506019) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800506019) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_94,

/*Créditos al gobierno federal */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801907028')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801907028')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801907028) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801907028) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_95,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801907029')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801907029')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801907029) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801907029) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_96,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802908040')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802908040')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802908040) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802908040) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_97,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802908041')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802908041')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802908041) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802908041) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_98,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802908042')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802908042')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802908042) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802908042) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_99,

/*Fideicomisos públicos de contratación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802908043')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802908043')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802908043) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802908043) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_100
	
INTO IFRS9_R04A_0419_M15SALDOSTS1_RESULT_1
FROM IFRS9_R04A_0419

END


BEGIN
	INSERT INTO IFRS9_R04A_0419_M15SALDOSTS1_RESULT_1
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_1])),
            SUM(CHARINDEX('ERR',[VALIDACION_2])),
            SUM(CHARINDEX('ERR',[VALIDACION_3])),
            SUM(CHARINDEX('ERR',[VALIDACION_4])),
            SUM(CHARINDEX('ERR',[VALIDACION_5])),
            SUM(CHARINDEX('ERR',[VALIDACION_6])),
            SUM(CHARINDEX('ERR',[VALIDACION_7])),
            SUM(CHARINDEX('ERR',[VALIDACION_8])),
            SUM(CHARINDEX('ERR',[VALIDACION_9])),
            SUM(CHARINDEX('ERR',[VALIDACION_10])),
            SUM(CHARINDEX('ERR',[VALIDACION_11])),
            SUM(CHARINDEX('ERR',[VALIDACION_12])),
            SUM(CHARINDEX('ERR',[VALIDACION_13])),
            SUM(CHARINDEX('ERR',[VALIDACION_14])),
            SUM(CHARINDEX('ERR',[VALIDACION_15])),
            SUM(CHARINDEX('ERR',[VALIDACION_16])),
            SUM(CHARINDEX('ERR',[VALIDACION_17])),
            SUM(CHARINDEX('ERR',[VALIDACION_18])),
            SUM(CHARINDEX('ERR',[VALIDACION_19])),
            SUM(CHARINDEX('ERR',[VALIDACION_20])),
            SUM(CHARINDEX('ERR',[VALIDACION_21])),
            SUM(CHARINDEX('ERR',[VALIDACION_22])),
            SUM(CHARINDEX('ERR',[VALIDACION_23])),
            SUM(CHARINDEX('ERR',[VALIDACION_24])),
            SUM(CHARINDEX('ERR',[VALIDACION_25])),
            SUM(CHARINDEX('ERR',[VALIDACION_26])),
            SUM(CHARINDEX('ERR',[VALIDACION_27])),
            SUM(CHARINDEX('ERR',[VALIDACION_28])),
            SUM(CHARINDEX('ERR',[VALIDACION_29])),
            SUM(CHARINDEX('ERR',[VALIDACION_30])),
            SUM(CHARINDEX('ERR',[VALIDACION_31])),
            SUM(CHARINDEX('ERR',[VALIDACION_32])),
            SUM(CHARINDEX('ERR',[VALIDACION_33])),
            SUM(CHARINDEX('ERR',[VALIDACION_34])),
            SUM(CHARINDEX('ERR',[VALIDACION_35])),
            SUM(CHARINDEX('ERR',[VALIDACION_36])),
            SUM(CHARINDEX('ERR',[VALIDACION_37])),
            SUM(CHARINDEX('ERR',[VALIDACION_38])),
            SUM(CHARINDEX('ERR',[VALIDACION_39])),
            SUM(CHARINDEX('ERR',[VALIDACION_40])),
            SUM(CHARINDEX('ERR',[VALIDACION_41])),
            SUM(CHARINDEX('ERR',[VALIDACION_42])),
            SUM(CHARINDEX('ERR',[VALIDACION_43])),
            SUM(CHARINDEX('ERR',[VALIDACION_44])),
            SUM(CHARINDEX('ERR',[VALIDACION_45])),
            SUM(CHARINDEX('ERR',[VALIDACION_46])),
            SUM(CHARINDEX('ERR',[VALIDACION_47])),
            SUM(CHARINDEX('ERR',[VALIDACION_48])),
            SUM(CHARINDEX('ERR',[VALIDACION_49])),
            SUM(CHARINDEX('ERR',[VALIDACION_50])),
            SUM(CHARINDEX('ERR',[VALIDACION_51])),
            SUM(CHARINDEX('ERR',[VALIDACION_52])),
            SUM(CHARINDEX('ERR',[VALIDACION_53])),
            SUM(CHARINDEX('ERR',[VALIDACION_54])),
            SUM(CHARINDEX('ERR',[VALIDACION_55])),
            SUM(CHARINDEX('ERR',[VALIDACION_56])),
            SUM(CHARINDEX('ERR',[VALIDACION_57])),
            SUM(CHARINDEX('ERR',[VALIDACION_58])),
            SUM(CHARINDEX('ERR',[VALIDACION_59])),
            SUM(CHARINDEX('ERR',[VALIDACION_60])),
            SUM(CHARINDEX('ERR',[VALIDACION_61])),
            SUM(CHARINDEX('ERR',[VALIDACION_62])),
            SUM(CHARINDEX('ERR',[VALIDACION_63])),
            SUM(CHARINDEX('ERR',[VALIDACION_64])),
            SUM(CHARINDEX('ERR',[VALIDACION_65])),
            SUM(CHARINDEX('ERR',[VALIDACION_66])),
            SUM(CHARINDEX('ERR',[VALIDACION_67])),
            SUM(CHARINDEX('ERR',[VALIDACION_68])),
            SUM(CHARINDEX('ERR',[VALIDACION_69])),
            SUM(CHARINDEX('ERR',[VALIDACION_70])),
            SUM(CHARINDEX('ERR',[VALIDACION_71])),
            SUM(CHARINDEX('ERR',[VALIDACION_72])),
            SUM(CHARINDEX('ERR',[VALIDACION_73])),
            SUM(CHARINDEX('ERR',[VALIDACION_74])),
            SUM(CHARINDEX('ERR',[VALIDACION_75])),
            SUM(CHARINDEX('ERR',[VALIDACION_76])),
            SUM(CHARINDEX('ERR',[VALIDACION_77])),
            SUM(CHARINDEX('ERR',[VALIDACION_78])),
            SUM(CHARINDEX('ERR',[VALIDACION_79])),
            SUM(CHARINDEX('ERR',[VALIDACION_80])),
            SUM(CHARINDEX('ERR',[VALIDACION_81])),
            SUM(CHARINDEX('ERR',[VALIDACION_82])),
            SUM(CHARINDEX('ERR',[VALIDACION_83])),
            SUM(CHARINDEX('ERR',[VALIDACION_84])),
            SUM(CHARINDEX('ERR',[VALIDACION_85])),
            SUM(CHARINDEX('ERR',[VALIDACION_86])),
            SUM(CHARINDEX('ERR',[VALIDACION_87])),
            SUM(CHARINDEX('ERR',[VALIDACION_88])),
            SUM(CHARINDEX('ERR',[VALIDACION_89])),
            SUM(CHARINDEX('ERR',[VALIDACION_90])),
            SUM(CHARINDEX('ERR',[VALIDACION_91])),
            SUM(CHARINDEX('ERR',[VALIDACION_92])),
            SUM(CHARINDEX('ERR',[VALIDACION_93])),
            SUM(CHARINDEX('ERR',[VALIDACION_94])),
            SUM(CHARINDEX('ERR',[VALIDACION_95])),
            SUM(CHARINDEX('ERR',[VALIDACION_96])),
            SUM(CHARINDEX('ERR',[VALIDACION_97])),
            SUM(CHARINDEX('ERR',[VALIDACION_98])),
            SUM(CHARINDEX('ERR',[VALIDACION_99])),
            SUM(CHARINDEX('ERR',[VALIDACION_100]))
            


		from IFRS9_R04A_0419_M15SALDOSTS1_RESULT_1
END

BEGIN
	EXEC SP_IFRS9_R04A_0419_M15SALDOSTS1_VIEW_1
END

COMMIT








END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


