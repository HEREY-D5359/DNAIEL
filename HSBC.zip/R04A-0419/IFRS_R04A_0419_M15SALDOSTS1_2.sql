﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en la estimación preventiva para riesgos crediticios */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15SALDOS*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0419_M15SALDOSTS1_COMP_2]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0419_M15SALDOSTS1_RESULT_2')
BEGIN
DROP TABLE IFRS9_R04A_0419_M15SALDOSTS1_RESULT_2
END 

BEGIN
SELECT DISTINCT
         /*id*/
CONVERT(VARCHAR,ID) AS ID, 
	/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802908044')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802908044')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802908044) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802908044) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_101,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801907030')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801907030')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801907030) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801907030) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_102,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803008045')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803008045')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803008045) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803008045) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_103,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803008046')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803008046')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803008046) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803008046) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_104,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803008047')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803008047')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803008047) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803008047) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_105,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803008048')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803008048')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803008048) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803008048) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_106,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801907031')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801907031')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801907031) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801907031) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_107,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803108049')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803108049')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803108049) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803108049) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_108,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803108050')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803108050')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803108050) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803108050) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_109,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803108051')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803108051')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803108051) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803108051) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_110,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803108052')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803108052')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803108052) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803108052) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_111,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800305006')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800305006')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800305006) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800305006) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_112,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800606020')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800606020')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800606020) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800606020) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_113,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800606021')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800606021')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800606021) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800606021) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_114,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800606022')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800606022')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800606022) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800606022) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_115,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800606023')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800606023')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800606023) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800606023) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_116,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800606024')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800606024')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800606024) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800606024) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_117,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800606025')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800606025')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800606025) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800606025) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_118,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800606026')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800606026')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800606026) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800606026) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_119,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800606027')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800606027')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800606027) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800606027) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_120,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800305007')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800305007')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800305007) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800305007) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_121,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800706028')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800706028')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800706028) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800706028) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_122,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800706029')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800706029')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800706029) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800706029) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_123,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800706030')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800706030')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800706030) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800706030) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_124,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803007032')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803007032')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803007032) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803007032) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_125,

/*Cartera en prórroga*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803007033')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803007033')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803007033) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803007033) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_126,

/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803007034')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803007034')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803007034) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803007034) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_127,

/*Remodelación o mejoramiento con garantía otorgada por la Banca de Desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800706031')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800706031')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800706031) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800706031) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_128,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800706032')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800706032')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800706032) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800706032) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_129,

/*Otras quitas, condonaciones bonificaciones y descuentos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800204004')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800204004')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800204004) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800204004) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_130,

/*Estimaciones traspasadas a otras instituciones por cesiones de:*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800204005')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800204005')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800204005) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800204005) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_131,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800505009')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800505009')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800505009) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800505009) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_132,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800906033')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800906033')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800906033) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800906033) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_133,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803307035')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803307035')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803307035) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803307035) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_134,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803508053')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803508053')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803508053) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803508053) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_135,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803508054')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803508054')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803508054) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803508054) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_136,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803307036')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803307036')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803307036) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803307036) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_137,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803608055')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803608055')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803608055) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803608055) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_138,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803608056')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803608056')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803608056) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803608056) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_139,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803608057')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803608057')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803608057) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803608057) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_140,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803307037')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803307037')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803307037) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803307037) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_141,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803708058')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803708058')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803708058) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803708058) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_142,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803708059')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803708059')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803708059) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803708059) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_143,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803307038')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803307038')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803307038) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803307038) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_144,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803307039')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803307039')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803307039) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803307039) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_145,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803307040')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803307040')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803307040) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803307040) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_146,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803307041')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803307041')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803307041) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803307041) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_147,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803307042')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803307042')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803307042) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803307042) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_148,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800906034')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800906034')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800906034) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800906034) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_149,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803407043')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803407043')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803407043) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803407043) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_150,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112804308060')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112804308060')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112804308060) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112804308060) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_151,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112804308061')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112804308061')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112804308061) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112804308061) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_152,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112804308062')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112804308062')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112804308062) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112804308062) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_153,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803407044')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803407044')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803407044) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803407044) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_154,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112804408063')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112804408063')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112804408063) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112804408063) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_155,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112804408064')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112804408064')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112804408064) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112804408064) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_156,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112804408065')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112804408065')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112804408065) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112804408065) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_157,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800906035')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800906035')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800906035) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800906035) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_158,

/*Créditos al gobierno federal */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803507045')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803507045')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803507045) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803507045) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_159,

/*Créditos a estados y municipios */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803507046')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803507046')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803507046) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803507046) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_160,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112804608066')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112804608066')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112804608066) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112804608066) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_161,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112804608067')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112804608067')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112804608067) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112804608067) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_162,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112804608068')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112804608068')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112804608068) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112804608068) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_163,

/*Fideicomisos públicos de contratación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112804608069')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112804608069')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112804608069) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112804608069) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_164,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112804608070')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112804608070')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112804608070) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112804608070) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_165,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803507047')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803507047')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803507047) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803507047) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_166,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112804708071')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112804708071')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112804708071) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112804708071) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_167,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112804708072')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112804708072')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112804708072) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112804708072) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_168,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112804708073')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112804708073')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112804708073) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112804708073) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_169,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112804708074')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112804708074')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112804708074) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112804708074) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_170,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803507048')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803507048')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803507048) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803507048) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_171,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112804808075')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112804808075')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112804808075) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112804808075) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_172,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112804808076')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112804808076')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112804808076) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112804808076) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_173,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112804808077')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112804808077')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112804808077) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112804808077) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_174,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112804808078')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112804808078')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112804808078) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112804808078) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_175,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800505010')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800505010')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800505010) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800505010) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_176,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801006036')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801006036')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801006036) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801006036) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_177,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801006037')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801006037')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801006037) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801006037) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_178,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801006038')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801006038')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801006038) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801006038) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_179,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801006039')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801006039')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801006039) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801006039) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_180,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801006040')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801006040')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801006040) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801006040) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_181,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801006041')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801006041')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801006041) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801006041) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_182,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801006042')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801006042')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801006042) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801006042) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_183,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801006043')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801006043')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801006043) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801006043) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_184,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800505011')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800505011')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800505011) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800505011) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_185,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801106044')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801106044')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801106044) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801106044) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_186,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801106045')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801106045')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801106045) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801106045) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_187,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801106046')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801106046')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801106046) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801106046) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_188,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112804607049')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112804607049')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112804607049) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112804607049) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_189,

/*Cartera en prórroga*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112804607050')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112804607050')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112804607050) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112804607050) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_190,

/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112804607051')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112804607051')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112804607051) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112804607051) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_191,

/*Remodelación o mejoramiento con garantía otorgada por la Banca de Desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801106047')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801106047')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801106047) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801106047) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_192,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801106048')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801106048')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801106048) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801106048) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_193,

/*Cancelación de estimaciones por cobro de cartera, adjudicación o recepción de bienes como dación en pago en:*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800204006')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800204006')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800204006) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800204006) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_194,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800605013')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800605013')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800605013) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800605013) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_195,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801306049')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801306049')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801306049) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801306049) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_196,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112804907052')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112804907052')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112804907052) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112804907052) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_197,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112805208079')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112805208079')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112805208079) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112805208079) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_198,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112805208080')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112805208080')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112805208080) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112805208080) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_199,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112804907053')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112804907053')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112804907053) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112804907053) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_200
	
INTO IFRS9_R04A_0419_M15SALDOSTS1_RESULT_2
FROM IFRS9_R04A_0419

END

BEGIN
	INSERT INTO IFRS9_R04A_0419_M15SALDOSTS1_RESULT_2
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_101])),
            SUM(CHARINDEX('ERR',[VALIDACION_102])),
            SUM(CHARINDEX('ERR',[VALIDACION_103])),
            SUM(CHARINDEX('ERR',[VALIDACION_104])),
            SUM(CHARINDEX('ERR',[VALIDACION_105])),
            SUM(CHARINDEX('ERR',[VALIDACION_106])),
            SUM(CHARINDEX('ERR',[VALIDACION_107])),
            SUM(CHARINDEX('ERR',[VALIDACION_108])),
            SUM(CHARINDEX('ERR',[VALIDACION_109])),
            SUM(CHARINDEX('ERR',[VALIDACION_110])),
            SUM(CHARINDEX('ERR',[VALIDACION_111])),
            SUM(CHARINDEX('ERR',[VALIDACION_112])),
            SUM(CHARINDEX('ERR',[VALIDACION_113])),
            SUM(CHARINDEX('ERR',[VALIDACION_114])),
            SUM(CHARINDEX('ERR',[VALIDACION_115])),
            SUM(CHARINDEX('ERR',[VALIDACION_116])),
            SUM(CHARINDEX('ERR',[VALIDACION_117])),
            SUM(CHARINDEX('ERR',[VALIDACION_118])),
            SUM(CHARINDEX('ERR',[VALIDACION_119])),
            SUM(CHARINDEX('ERR',[VALIDACION_120])),
            SUM(CHARINDEX('ERR',[VALIDACION_121])),
            SUM(CHARINDEX('ERR',[VALIDACION_122])),
            SUM(CHARINDEX('ERR',[VALIDACION_123])),
            SUM(CHARINDEX('ERR',[VALIDACION_124])),
            SUM(CHARINDEX('ERR',[VALIDACION_125])),
            SUM(CHARINDEX('ERR',[VALIDACION_126])),
            SUM(CHARINDEX('ERR',[VALIDACION_127])),
            SUM(CHARINDEX('ERR',[VALIDACION_128])),
            SUM(CHARINDEX('ERR',[VALIDACION_129])),
            SUM(CHARINDEX('ERR',[VALIDACION_130])),
            SUM(CHARINDEX('ERR',[VALIDACION_131])),
            SUM(CHARINDEX('ERR',[VALIDACION_132])),
            SUM(CHARINDEX('ERR',[VALIDACION_133])),
            SUM(CHARINDEX('ERR',[VALIDACION_134])),
            SUM(CHARINDEX('ERR',[VALIDACION_135])),
            SUM(CHARINDEX('ERR',[VALIDACION_136])),
            SUM(CHARINDEX('ERR',[VALIDACION_137])),
            SUM(CHARINDEX('ERR',[VALIDACION_138])),
            SUM(CHARINDEX('ERR',[VALIDACION_139])),
            SUM(CHARINDEX('ERR',[VALIDACION_140])),
            SUM(CHARINDEX('ERR',[VALIDACION_141])),
            SUM(CHARINDEX('ERR',[VALIDACION_142])),
            SUM(CHARINDEX('ERR',[VALIDACION_143])),
            SUM(CHARINDEX('ERR',[VALIDACION_144])),
            SUM(CHARINDEX('ERR',[VALIDACION_145])),
            SUM(CHARINDEX('ERR',[VALIDACION_146])),
            SUM(CHARINDEX('ERR',[VALIDACION_147])),
            SUM(CHARINDEX('ERR',[VALIDACION_148])),
            SUM(CHARINDEX('ERR',[VALIDACION_149])),
            SUM(CHARINDEX('ERR',[VALIDACION_150])),
            SUM(CHARINDEX('ERR',[VALIDACION_151])),
            SUM(CHARINDEX('ERR',[VALIDACION_152])),
            SUM(CHARINDEX('ERR',[VALIDACION_153])),
            SUM(CHARINDEX('ERR',[VALIDACION_154])),
            SUM(CHARINDEX('ERR',[VALIDACION_155])),
            SUM(CHARINDEX('ERR',[VALIDACION_156])),
            SUM(CHARINDEX('ERR',[VALIDACION_157])),
            SUM(CHARINDEX('ERR',[VALIDACION_158])),
            SUM(CHARINDEX('ERR',[VALIDACION_159])),
            SUM(CHARINDEX('ERR',[VALIDACION_160])),
            SUM(CHARINDEX('ERR',[VALIDACION_161])),
            SUM(CHARINDEX('ERR',[VALIDACION_162])),
            SUM(CHARINDEX('ERR',[VALIDACION_163])),
            SUM(CHARINDEX('ERR',[VALIDACION_164])),
            SUM(CHARINDEX('ERR',[VALIDACION_165])),
            SUM(CHARINDEX('ERR',[VALIDACION_166])),
            SUM(CHARINDEX('ERR',[VALIDACION_167])),
            SUM(CHARINDEX('ERR',[VALIDACION_168])),
            SUM(CHARINDEX('ERR',[VALIDACION_169])),
            SUM(CHARINDEX('ERR',[VALIDACION_170])),
            SUM(CHARINDEX('ERR',[VALIDACION_171])),
            SUM(CHARINDEX('ERR',[VALIDACION_172])),
            SUM(CHARINDEX('ERR',[VALIDACION_173])),
            SUM(CHARINDEX('ERR',[VALIDACION_174])),
            SUM(CHARINDEX('ERR',[VALIDACION_175])),
            SUM(CHARINDEX('ERR',[VALIDACION_176])),
            SUM(CHARINDEX('ERR',[VALIDACION_177])),
            SUM(CHARINDEX('ERR',[VALIDACION_178])),
            SUM(CHARINDEX('ERR',[VALIDACION_179])),
            SUM(CHARINDEX('ERR',[VALIDACION_180])),
            SUM(CHARINDEX('ERR',[VALIDACION_181])),
            SUM(CHARINDEX('ERR',[VALIDACION_182])),
            SUM(CHARINDEX('ERR',[VALIDACION_183])),
            SUM(CHARINDEX('ERR',[VALIDACION_184])),
            SUM(CHARINDEX('ERR',[VALIDACION_185])),
            SUM(CHARINDEX('ERR',[VALIDACION_186])),
            SUM(CHARINDEX('ERR',[VALIDACION_187])),
            SUM(CHARINDEX('ERR',[VALIDACION_188])),
            SUM(CHARINDEX('ERR',[VALIDACION_189])),
            SUM(CHARINDEX('ERR',[VALIDACION_190])),
            SUM(CHARINDEX('ERR',[VALIDACION_191])),
            SUM(CHARINDEX('ERR',[VALIDACION_192])),
            SUM(CHARINDEX('ERR',[VALIDACION_193])),
            SUM(CHARINDEX('ERR',[VALIDACION_194])),
            SUM(CHARINDEX('ERR',[VALIDACION_195])),
            SUM(CHARINDEX('ERR',[VALIDACION_196])),
            SUM(CHARINDEX('ERR',[VALIDACION_197])),
            SUM(CHARINDEX('ERR',[VALIDACION_198])),
            SUM(CHARINDEX('ERR',[VALIDACION_199])),
            SUM(CHARINDEX('ERR',[VALIDACION_200]))
            


		from IFRS9_R04A_0419_M15SALDOSTS1_RESULT_2
END

BEGIN
	EXEC SP_IFRS9_R04A_0419_M15SALDOSTS1_VIEW_2
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


