﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en la estimación preventiva para riesgos crediticios */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15SALDOS*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0419_M15SALDOSTS1_COMP_4]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0419_M15SALDOSTS1_RESULT_4')
BEGIN
DROP TABLE IFRS9_R04A_0419_M15SALDOSTS1_RESULT_4
END 

BEGIN
SELECT DISTINCT
         /*id*/
CONVERT(VARCHAR,ID) AS ID, 
	/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112808208130')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112808208130')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112808208130) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112808208130) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_301,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800705018')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800705018')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800705018) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800705018) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_302,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801806068')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801806068')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801806068) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801806068) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_303,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801806069')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801806069')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801806069) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801806069) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_304,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801806070')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801806070')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801806070) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801806070) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_305,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801806071')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801806071')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801806071) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801806071) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_306,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801806072')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801806072')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801806072) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801806072) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_307,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801806073')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801806073')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801806073) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801806073) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_308,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801806074')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801806074')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801806074) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801806074) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_309,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801806075')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801806075')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801806075) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801806075) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_310,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800705019')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800705019')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800705019) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800705019) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_311,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801906076')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801906076')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801906076) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801906076) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_312,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801906077')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801906077')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801906077) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801906077) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_313,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801906078')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801906078')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801906078) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801906078) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_314,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112807807083')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112807807083')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112807807083) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112807807083) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_315,

/*Cartera en prórroga*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112807807084')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112807807084')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112807807084) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112807807084) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_316,

/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112807807085')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112807807085')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112807807085) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112807807085) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_317,

/*Remodelación o mejoramiento con garantía otorgada por la Banca de Desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801906079')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801906079')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801906079) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801906079) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_318,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801906080')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801906080')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801906080) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801906080) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_319,

/*Efecto de valuación de estimaciones en ME, VSM, UMA o UDIS por deslizamiento cambiario (2)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800204008')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800204008')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800204008) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800204008) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_320,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800805021')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800805021')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800805021) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800805021) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_321,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802106081')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802106081')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802106081) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802106081) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_322,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112808107086')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112808107086')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112808107086) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112808107086) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_323,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112808608131')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112808608131')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112808608131) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112808608131) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_324,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112808608132')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112808608132')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112808608132) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112808608132) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_325,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112808107087')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112808107087')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112808107087) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112808107087) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_326,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112808708133')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112808708133')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112808708133) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112808708133) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_327,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112808708134')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112808708134')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112808708134) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112808708134) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_328,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112808708135')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112808708135')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112808708135) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112808708135) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_329,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112808107088')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112808107088')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112808107088) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112808107088) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_330,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112808808136')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112808808136')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112808808136) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112808808136) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_331,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112808808137')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112808808137')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112808808137) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112808808137) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_332,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112808107089')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112808107089')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112808107089) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112808107089) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_333,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112808107090')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112808107090')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112808107090) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112808107090) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_334,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112808107091')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112808107091')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112808107091) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112808107091) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_335,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112808107092')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112808107092')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112808107092) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112808107092) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_336,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112808107093')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112808107093')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112808107093) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112808107093) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_337,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802106082')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802106082')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802106082) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802106082) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_338,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112808207094')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112808207094')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112808207094) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112808207094) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_339,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809408138')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809408138')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809408138) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809408138) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_340,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809408139')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809408139')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809408139) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809408139) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_341,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809408140')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809408140')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809408140) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809408140) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_342,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112808207095')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112808207095')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112808207095) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112808207095) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_343,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809508141')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809508141')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809508141) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809508141) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_344,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809508142')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809508142')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809508142) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809508142) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_345,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809508143')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809508143')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809508143) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809508143) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_346,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802106083')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802106083')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802106083) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802106083) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_347,

/*Créditos al gobierno federal */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112808307096')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112808307096')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112808307096) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112808307096) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_348,

/*Créditos a estados y municipios */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112808307097')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112808307097')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112808307097) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112808307097) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_349,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809708144')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809708144')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809708144) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809708144) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_350,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809708145')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809708145')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809708145) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809708145) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_351,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809708146')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809708146')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809708146) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809708146) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_352,

/*Fideicomisos públicos de contratación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809708147')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809708147')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809708147) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809708147) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_353,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809708148')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809708148')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809708148) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809708148) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_354,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112808307098')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112808307098')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112808307098) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112808307098) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_355,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809808149')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809808149')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809808149) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809808149) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_356,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809808150')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809808150')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809808150) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809808150) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_357,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809808151')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809808151')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809808151) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809808151) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_358,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809808152')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809808152')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809808152) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809808152) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_359,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112808307099')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112808307099')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112808307099) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112808307099) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_360,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809908153')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809908153')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809908153) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809908153) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_361,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809908154')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809908154')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809908154) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809908154) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_362,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809908155')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809908155')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809908155) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809908155) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_363,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809908156')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809908156')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809908156) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809908156) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_364,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800805022')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800805022')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800805022) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800805022) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_365,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802206084')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802206084')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802206084) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802206084) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_366,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802206085')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802206085')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802206085) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802206085) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_367,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802206086')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802206086')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802206086) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802206086) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_368,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802206087')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802206087')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802206087) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802206087) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_369,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802206088')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802206088')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802206088) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802206088) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_370,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802206089')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802206089')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802206089) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802206089) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_371,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802206090')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802206090')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802206090) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802206090) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_372,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802206091')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802206091')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802206091) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802206091) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_373,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800805023')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800805023')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800805023) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800805023) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_374,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802306092')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802306092')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802306092) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802306092) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_375,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802306093')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802306093')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802306093) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802306093) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_376,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802306094')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802306094')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802306094) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802306094) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_377,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809407100')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809407100')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809407100) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809407100) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_378,

/*Cartera en prórroga*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809407101')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809407101')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809407101) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809407101) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_379,

/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809407102')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809407102')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809407102) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809407102) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_380,

/*Remodelación o mejoramiento con garantía otorgada por la Banca de Desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802306095')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802306095')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802306095) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802306095) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_381,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802306096')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802306096')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802306096) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802306096) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_382,

/*Cancelación de estimaciones preventivas para riesgo crediticio adicionales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800204009')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800204009')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800204009) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800204009) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_383,

/*Otros cargos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800204010')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800204010')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800204010) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800204010) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_384,

/*ABONOS*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800103003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800103003')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800103003) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800103003) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_385,

/*Creación de estimaciones preventivas para riesgo crediticio por calificación de:*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800304011')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800304011')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800304011) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800304011) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_386,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801105025')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801105025')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801105025) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801105025) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_387,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802506097')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802506097')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802506097) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802506097) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_388,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809707103')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809707103')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809707103) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809707103) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_389,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112810308157')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112810308157')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112810308157) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112810308157) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_390,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112810308158')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112810308158')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112810308158) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112810308158) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_391,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809707104')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809707104')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809707104) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809707104) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_392,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112810408159')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112810408159')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112810408159) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112810408159) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_393,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112810408160')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112810408160')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112810408160) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112810408160) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_394,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112810408161')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112810408161')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112810408161) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112810408161) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_395,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809707105')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809707105')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809707105) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809707105) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_396,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112810508162')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112810508162')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112810508162) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112810508162) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_397,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112810508163')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112810508163')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112810508163) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112810508163) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_398,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809707106')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809707106')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809707106) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809707106) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_399,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809707107')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809707107')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809707107) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809707107) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_400
	
INTO IFRS9_R04A_0419_M15SALDOSTS1_RESULT_4
FROM IFRS9_R04A_0419

END

BEGIN
	INSERT INTO IFRS9_R04A_0419_M15SALDOSTS1_RESULT_4
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_301])),
            SUM(CHARINDEX('ERR',[VALIDACION_302])),
            SUM(CHARINDEX('ERR',[VALIDACION_303])),
            SUM(CHARINDEX('ERR',[VALIDACION_304])),
            SUM(CHARINDEX('ERR',[VALIDACION_305])),
            SUM(CHARINDEX('ERR',[VALIDACION_306])),
            SUM(CHARINDEX('ERR',[VALIDACION_307])),
            SUM(CHARINDEX('ERR',[VALIDACION_308])),
            SUM(CHARINDEX('ERR',[VALIDACION_309])),
            SUM(CHARINDEX('ERR',[VALIDACION_310])),
            SUM(CHARINDEX('ERR',[VALIDACION_311])),
            SUM(CHARINDEX('ERR',[VALIDACION_312])),
            SUM(CHARINDEX('ERR',[VALIDACION_313])),
            SUM(CHARINDEX('ERR',[VALIDACION_314])),
            SUM(CHARINDEX('ERR',[VALIDACION_315])),
            SUM(CHARINDEX('ERR',[VALIDACION_316])),
            SUM(CHARINDEX('ERR',[VALIDACION_317])),
            SUM(CHARINDEX('ERR',[VALIDACION_318])),
            SUM(CHARINDEX('ERR',[VALIDACION_319])),
            SUM(CHARINDEX('ERR',[VALIDACION_320])),
            SUM(CHARINDEX('ERR',[VALIDACION_321])),
            SUM(CHARINDEX('ERR',[VALIDACION_322])),
            SUM(CHARINDEX('ERR',[VALIDACION_323])),
            SUM(CHARINDEX('ERR',[VALIDACION_324])),
            SUM(CHARINDEX('ERR',[VALIDACION_325])),
            SUM(CHARINDEX('ERR',[VALIDACION_326])),
            SUM(CHARINDEX('ERR',[VALIDACION_327])),
            SUM(CHARINDEX('ERR',[VALIDACION_328])),
            SUM(CHARINDEX('ERR',[VALIDACION_329])),
            SUM(CHARINDEX('ERR',[VALIDACION_330])),
            SUM(CHARINDEX('ERR',[VALIDACION_331])),
            SUM(CHARINDEX('ERR',[VALIDACION_332])),
            SUM(CHARINDEX('ERR',[VALIDACION_333])),
            SUM(CHARINDEX('ERR',[VALIDACION_334])),
            SUM(CHARINDEX('ERR',[VALIDACION_335])),
            SUM(CHARINDEX('ERR',[VALIDACION_336])),
            SUM(CHARINDEX('ERR',[VALIDACION_337])),
            SUM(CHARINDEX('ERR',[VALIDACION_338])),
            SUM(CHARINDEX('ERR',[VALIDACION_339])),
            SUM(CHARINDEX('ERR',[VALIDACION_340])),
            SUM(CHARINDEX('ERR',[VALIDACION_341])),
            SUM(CHARINDEX('ERR',[VALIDACION_342])),
            SUM(CHARINDEX('ERR',[VALIDACION_343])),
            SUM(CHARINDEX('ERR',[VALIDACION_344])),
            SUM(CHARINDEX('ERR',[VALIDACION_345])),
            SUM(CHARINDEX('ERR',[VALIDACION_346])),
            SUM(CHARINDEX('ERR',[VALIDACION_347])),
            SUM(CHARINDEX('ERR',[VALIDACION_348])),
            SUM(CHARINDEX('ERR',[VALIDACION_349])),
            SUM(CHARINDEX('ERR',[VALIDACION_350])),
            SUM(CHARINDEX('ERR',[VALIDACION_351])),
            SUM(CHARINDEX('ERR',[VALIDACION_352])),
            SUM(CHARINDEX('ERR',[VALIDACION_353])),
            SUM(CHARINDEX('ERR',[VALIDACION_354])),
            SUM(CHARINDEX('ERR',[VALIDACION_355])),
            SUM(CHARINDEX('ERR',[VALIDACION_356])),
            SUM(CHARINDEX('ERR',[VALIDACION_357])),
            SUM(CHARINDEX('ERR',[VALIDACION_358])),
            SUM(CHARINDEX('ERR',[VALIDACION_359])),
            SUM(CHARINDEX('ERR',[VALIDACION_360])),
            SUM(CHARINDEX('ERR',[VALIDACION_361])),
            SUM(CHARINDEX('ERR',[VALIDACION_362])),
            SUM(CHARINDEX('ERR',[VALIDACION_363])),
            SUM(CHARINDEX('ERR',[VALIDACION_364])),
            SUM(CHARINDEX('ERR',[VALIDACION_365])),
            SUM(CHARINDEX('ERR',[VALIDACION_366])),
            SUM(CHARINDEX('ERR',[VALIDACION_367])),
            SUM(CHARINDEX('ERR',[VALIDACION_368])),
            SUM(CHARINDEX('ERR',[VALIDACION_369])),
            SUM(CHARINDEX('ERR',[VALIDACION_370])),
            SUM(CHARINDEX('ERR',[VALIDACION_371])),
            SUM(CHARINDEX('ERR',[VALIDACION_372])),
            SUM(CHARINDEX('ERR',[VALIDACION_373])),
            SUM(CHARINDEX('ERR',[VALIDACION_374])),
            SUM(CHARINDEX('ERR',[VALIDACION_375])),
            SUM(CHARINDEX('ERR',[VALIDACION_376])),
            SUM(CHARINDEX('ERR',[VALIDACION_377])),
            SUM(CHARINDEX('ERR',[VALIDACION_378])),
            SUM(CHARINDEX('ERR',[VALIDACION_379])),
            SUM(CHARINDEX('ERR',[VALIDACION_380])),
            SUM(CHARINDEX('ERR',[VALIDACION_381])),
            SUM(CHARINDEX('ERR',[VALIDACION_382])),
            SUM(CHARINDEX('ERR',[VALIDACION_383])),
            SUM(CHARINDEX('ERR',[VALIDACION_384])),
            SUM(CHARINDEX('ERR',[VALIDACION_385])),
            SUM(CHARINDEX('ERR',[VALIDACION_386])),
            SUM(CHARINDEX('ERR',[VALIDACION_387])),
            SUM(CHARINDEX('ERR',[VALIDACION_388])),
            SUM(CHARINDEX('ERR',[VALIDACION_389])),
            SUM(CHARINDEX('ERR',[VALIDACION_390])),
            SUM(CHARINDEX('ERR',[VALIDACION_391])),
            SUM(CHARINDEX('ERR',[VALIDACION_392])),
            SUM(CHARINDEX('ERR',[VALIDACION_393])),
            SUM(CHARINDEX('ERR',[VALIDACION_394])),
            SUM(CHARINDEX('ERR',[VALIDACION_395])),
            SUM(CHARINDEX('ERR',[VALIDACION_396])),
            SUM(CHARINDEX('ERR',[VALIDACION_397])),
            SUM(CHARINDEX('ERR',[VALIDACION_398])),
            SUM(CHARINDEX('ERR',[VALIDACION_399])),
            SUM(CHARINDEX('ERR',[VALIDACION_400]))
            


		from IFRS9_R04A_0419_M15SALDOSTS1_RESULT_4
END

BEGIN
	EXEC SP_IFRS9_R04A_0419_M15SALDOSTS1_VIEW_4
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


