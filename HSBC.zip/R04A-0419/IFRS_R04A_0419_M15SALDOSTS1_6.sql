﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en la estimación preventiva para riesgos crediticios */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15SALDOS*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0419_M15SALDOSTS1_COMP_6]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0419_M15SALDOSTS1_RESULT_6')
BEGIN
DROP TABLE IFRS9_R04A_0419_M15SALDOSTS1_RESULT_6
END 

BEGIN
SELECT DISTINCT
      /*ID*/
      CONVERT(VARCHAR,ID) AS ID, 
	/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803006122')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803006122')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803006122) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803006122) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_501,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803006123')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803006123')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803006123) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803006123) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_502,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801205031')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801205031')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801205031) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801205031) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_503,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803106124')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803106124')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803106124) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803106124) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_504,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803106125')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803106125')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803106125) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803106125) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_505,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803106126')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803106126')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803106126) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803106126) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_506,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112812607134')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112812607134')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112812607134) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112812607134) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_507,

/*Cartera en prórroga*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112812607135')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112812607135')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112812607135) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112812607135) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_508,

/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112812607136')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112812607136')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112812607136) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112812607136) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_509,

/*Remodelación o mejoramiento con garantía otorgada por la Banca de Desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803106127')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803106127')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803106127) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803106127) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_510,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803106128')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803106128')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803106128) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803106128) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_511,

/*Efecto de valuación de estimaciones en ME, VSM, UMA o UDIS por deslizamiento cambiario (3)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800304013')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800304013')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800304013) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800304013) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_512,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801305033')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801305033')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801305033) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801305033) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_513,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803306129')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803306129')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803306129) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803306129) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_514,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112812907137')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112812907137')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112812907137) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112812907137) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_515,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112813708209')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813708209')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112813708209) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112813708209) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_516,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112813708210')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813708210')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112813708210) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112813708210) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_517,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112812907138')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112812907138')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112812907138) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112812907138) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_518,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112813808211')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813808211')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112813808211) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112813808211) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_519,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112813808212')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813808212')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112813808212) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112813808212) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_520,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112813808213')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813808213')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112813808213) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112813808213) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_521,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112812907139')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112812907139')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112812907139) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112812907139) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_522,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112813908214')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813908214')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112813908214) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112813908214) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_523,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112813908215')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813908215')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112813908215) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112813908215) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_524,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112812907140')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112812907140')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112812907140) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112812907140) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_525,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112812907141')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112812907141')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112812907141) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112812907141) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_526,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112812907142')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112812907142')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112812907142) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112812907142) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_527,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112812907143')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112812907143')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112812907143) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112812907143) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_528,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112812907144')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112812907144')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112812907144) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112812907144) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_529,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803306130')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803306130')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803306130) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803306130) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_530,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112813007145')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813007145')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112813007145) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112813007145) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_531,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112814508216')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112814508216')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112814508216) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112814508216) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_532,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112814508217')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112814508217')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112814508217) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112814508217) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_533,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112814508218')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112814508218')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112814508218) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112814508218) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_534,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112813007146')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813007146')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112813007146) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112813007146) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_535,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112814608219')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112814608219')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112814608219) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112814608219) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_536,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112814608220')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112814608220')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112814608220) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112814608220) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_537,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112814608221')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112814608221')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112814608221) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112814608221) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_538,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803306131')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803306131')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803306131) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803306131) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_539,

/*Créditos al gobierno federal */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112813107147')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813107147')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112813107147) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112813107147) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_540,

/*Créditos a estados y municipios */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112813107148')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813107148')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112813107148) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112813107148) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_541,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112814808222')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112814808222')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112814808222) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112814808222) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_542,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112814808223')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112814808223')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112814808223) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112814808223) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_543,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112814808224')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112814808224')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112814808224) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112814808224) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_544,

/*Fideicomisos públicos de contratación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112814808225')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112814808225')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112814808225) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112814808225) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_545,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112814808226')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112814808226')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112814808226) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112814808226) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_546,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112813107149')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813107149')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112813107149) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112813107149) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_547,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112814908227')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112814908227')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112814908227) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112814908227) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_548,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112814908228')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112814908228')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112814908228) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112814908228) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_549,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112814908229')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112814908229')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112814908229) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112814908229) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_550,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112814908230')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112814908230')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112814908230) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112814908230) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_551,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112813107150')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813107150')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112813107150) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112813107150) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_552,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112815008231')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112815008231')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112815008231) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112815008231) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_553,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112815008232')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112815008232')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112815008232) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112815008232) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_554,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112815008233')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112815008233')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112815008233) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112815008233) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_555,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112815008234')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112815008234')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112815008234) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112815008234) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_556,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801305034')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801305034')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801305034) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801305034) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_557,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803406132')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803406132')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803406132) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803406132) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_558,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803406133')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803406133')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803406133) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803406133) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_559,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803406134')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803406134')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803406134) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803406134) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_560,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803406135')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803406135')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803406135) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803406135) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_561,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803406136')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803406136')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803406136) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803406136) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_562,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803406137')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803406137')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803406137) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803406137) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_563,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803406138')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803406138')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803406138) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803406138) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_564,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803406139')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803406139')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803406139) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803406139) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_565,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801305035')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801305035')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801305035) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801305035) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_566,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803506140')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803506140')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803506140) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803506140) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_567,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803506141')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803506141')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803506141) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803506141) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_568,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803506142')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803506142')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803506142) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803506142) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_569,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112814207151')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112814207151')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112814207151) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112814207151) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_570,

/*Cartera en prórroga*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112814207152')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112814207152')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112814207152) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112814207152) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_571,

/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112814207153')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112814207153')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112814207153) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112814207153) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_572,

/*Remodelación o mejoramiento con garantía otorgada por la Banca de Desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803506143')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803506143')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803506143) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803506143) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_573,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803506144')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803506144')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803506144) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803506144) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_574,

/*Creación de estimaciones preventivas para riesgo crediticio adicionales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800304014')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800304014')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800304014) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800304014) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_575,

/*Otros Abonos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800304015')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800304015')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800304015) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800304015) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_576,

/*Saldo final del mes*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('101800103003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('101800103003')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800103003) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800103003) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_577
	
INTO IFRS9_R04A_0419_M15SALDOSTS1_RESULT_6
FROM IFRS9_R04A_0419

END

BEGIN
	INSERT INTO IFRS9_R04A_0419_M15SALDOSTS1_RESULT_6
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_501])),
            SUM(CHARINDEX('ERR',[VALIDACION_502])),
            SUM(CHARINDEX('ERR',[VALIDACION_503])),
            SUM(CHARINDEX('ERR',[VALIDACION_504])),
            SUM(CHARINDEX('ERR',[VALIDACION_505])),
            SUM(CHARINDEX('ERR',[VALIDACION_506])),
            SUM(CHARINDEX('ERR',[VALIDACION_507])),
            SUM(CHARINDEX('ERR',[VALIDACION_508])),
            SUM(CHARINDEX('ERR',[VALIDACION_509])),
            SUM(CHARINDEX('ERR',[VALIDACION_510])),
            SUM(CHARINDEX('ERR',[VALIDACION_511])),
            SUM(CHARINDEX('ERR',[VALIDACION_512])),
            SUM(CHARINDEX('ERR',[VALIDACION_513])),
            SUM(CHARINDEX('ERR',[VALIDACION_514])),
            SUM(CHARINDEX('ERR',[VALIDACION_515])),
            SUM(CHARINDEX('ERR',[VALIDACION_516])),
            SUM(CHARINDEX('ERR',[VALIDACION_517])),
            SUM(CHARINDEX('ERR',[VALIDACION_518])),
            SUM(CHARINDEX('ERR',[VALIDACION_519])),
            SUM(CHARINDEX('ERR',[VALIDACION_520])),
            SUM(CHARINDEX('ERR',[VALIDACION_521])),
            SUM(CHARINDEX('ERR',[VALIDACION_522])),
            SUM(CHARINDEX('ERR',[VALIDACION_523])),
            SUM(CHARINDEX('ERR',[VALIDACION_524])),
            SUM(CHARINDEX('ERR',[VALIDACION_525])),
            SUM(CHARINDEX('ERR',[VALIDACION_526])),
            SUM(CHARINDEX('ERR',[VALIDACION_527])),
            SUM(CHARINDEX('ERR',[VALIDACION_528])),
            SUM(CHARINDEX('ERR',[VALIDACION_529])),
            SUM(CHARINDEX('ERR',[VALIDACION_530])),
            SUM(CHARINDEX('ERR',[VALIDACION_531])),
            SUM(CHARINDEX('ERR',[VALIDACION_532])),
            SUM(CHARINDEX('ERR',[VALIDACION_533])),
            SUM(CHARINDEX('ERR',[VALIDACION_534])),
            SUM(CHARINDEX('ERR',[VALIDACION_535])),
            SUM(CHARINDEX('ERR',[VALIDACION_536])),
            SUM(CHARINDEX('ERR',[VALIDACION_537])),
            SUM(CHARINDEX('ERR',[VALIDACION_538])),
            SUM(CHARINDEX('ERR',[VALIDACION_539])),
            SUM(CHARINDEX('ERR',[VALIDACION_540])),
            SUM(CHARINDEX('ERR',[VALIDACION_541])),
            SUM(CHARINDEX('ERR',[VALIDACION_542])),
            SUM(CHARINDEX('ERR',[VALIDACION_543])),
            SUM(CHARINDEX('ERR',[VALIDACION_544])),
            SUM(CHARINDEX('ERR',[VALIDACION_545])),
            SUM(CHARINDEX('ERR',[VALIDACION_546])),
            SUM(CHARINDEX('ERR',[VALIDACION_547])),
            SUM(CHARINDEX('ERR',[VALIDACION_548])),
            SUM(CHARINDEX('ERR',[VALIDACION_549])),
            SUM(CHARINDEX('ERR',[VALIDACION_550])),
            SUM(CHARINDEX('ERR',[VALIDACION_551])),
            SUM(CHARINDEX('ERR',[VALIDACION_552])),
            SUM(CHARINDEX('ERR',[VALIDACION_553])),
            SUM(CHARINDEX('ERR',[VALIDACION_554])),
            SUM(CHARINDEX('ERR',[VALIDACION_555])),
            SUM(CHARINDEX('ERR',[VALIDACION_556])),
            SUM(CHARINDEX('ERR',[VALIDACION_557])),
            SUM(CHARINDEX('ERR',[VALIDACION_558])),
            SUM(CHARINDEX('ERR',[VALIDACION_559])),
            SUM(CHARINDEX('ERR',[VALIDACION_560])),
            SUM(CHARINDEX('ERR',[VALIDACION_561])),
            SUM(CHARINDEX('ERR',[VALIDACION_562])),
            SUM(CHARINDEX('ERR',[VALIDACION_563])),
            SUM(CHARINDEX('ERR',[VALIDACION_564])),
            SUM(CHARINDEX('ERR',[VALIDACION_565])),
            SUM(CHARINDEX('ERR',[VALIDACION_566])),
            SUM(CHARINDEX('ERR',[VALIDACION_567])),
            SUM(CHARINDEX('ERR',[VALIDACION_568])),
            SUM(CHARINDEX('ERR',[VALIDACION_569])),
            SUM(CHARINDEX('ERR',[VALIDACION_570])),
            SUM(CHARINDEX('ERR',[VALIDACION_571])),
            SUM(CHARINDEX('ERR',[VALIDACION_572])),
            SUM(CHARINDEX('ERR',[VALIDACION_573])),
            SUM(CHARINDEX('ERR',[VALIDACION_574])),
            SUM(CHARINDEX('ERR',[VALIDACION_575])),
            SUM(CHARINDEX('ERR',[VALIDACION_576])),
            SUM(CHARINDEX('ERR',[VALIDACION_577]))
		from IFRS9_R04A_0419_M15SALDOSTS1_RESULT_6
END

BEGIN
	EXEC SP_IFRS9_R04A_0419_M15SALDOSTS1_VIEW_6
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH