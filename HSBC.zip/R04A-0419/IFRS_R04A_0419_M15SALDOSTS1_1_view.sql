﻿
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en la estimación preventiva para riesgos crediticios */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15SALDOS*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/


CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0419_M15SALDOSTS1_VIEW_1]
AS
BEGIN
	SELECT *
		
	FROM IFRS9_R04A_0419_M15SALDOSTS1_RESULT_1
	    WHERE

        (VALIDACION_1 <> '' ) OR
        (VALIDACION_2 <> '' ) OR
        (VALIDACION_3 <> '' ) OR
        (VALIDACION_4 <> '' ) OR
        (VALIDACION_5 <> '' ) OR
        (VALIDACION_6 <> '' ) OR
        (VALIDACION_7 <> '' ) OR
        (VALIDACION_8 <> '' ) OR
        (VALIDACION_9 <> '' ) OR
        (VALIDACION_10 <> '' ) OR
        (VALIDACION_11 <> '' ) OR
        (VALIDACION_12 <> '' ) OR
        (VALIDACION_13 <> '' ) OR
        (VALIDACION_14 <> '' ) OR
        (VALIDACION_15 <> '' ) OR
        (VALIDACION_16 <> '' ) OR
        (VALIDACION_17 <> '' ) OR
        (VALIDACION_18 <> '' ) OR
        (VALIDACION_19 <> '' ) OR
        (VALIDACION_20 <> '' ) OR
        (VALIDACION_21 <> '' ) OR
        (VALIDACION_22 <> '' ) OR
        (VALIDACION_23 <> '' ) OR
        (VALIDACION_24 <> '' ) OR
        (VALIDACION_25 <> '' ) OR
        (VALIDACION_26 <> '' ) OR
        (VALIDACION_27 <> '' ) OR
        (VALIDACION_28 <> '' ) OR
        (VALIDACION_29 <> '' ) OR
        (VALIDACION_30 <> '' ) OR
        (VALIDACION_31 <> '' ) OR
        (VALIDACION_32 <> '' ) OR
        (VALIDACION_33 <> '' ) OR
        (VALIDACION_34 <> '' ) OR
        (VALIDACION_35 <> '' ) OR
        (VALIDACION_36 <> '' ) OR
        (VALIDACION_37 <> '' ) OR
        (VALIDACION_38 <> '' ) OR
        (VALIDACION_39 <> '' ) OR
        (VALIDACION_40 <> '' ) OR
        (VALIDACION_41 <> '' ) OR
        (VALIDACION_42 <> '' ) OR
        (VALIDACION_43 <> '' ) OR
        (VALIDACION_44 <> '' ) OR
        (VALIDACION_45 <> '' ) OR
        (VALIDACION_46 <> '' ) OR
        (VALIDACION_47 <> '' ) OR
        (VALIDACION_48 <> '' ) OR
        (VALIDACION_49 <> '' ) OR
        (VALIDACION_50 <> '' ) OR
        (VALIDACION_51 <> '' ) OR
        (VALIDACION_52 <> '' ) OR
        (VALIDACION_53 <> '' ) OR
        (VALIDACION_54 <> '' ) OR
        (VALIDACION_55 <> '' ) OR
        (VALIDACION_56 <> '' ) OR
        (VALIDACION_57 <> '' ) OR
        (VALIDACION_58 <> '' ) OR
        (VALIDACION_59 <> '' ) OR
        (VALIDACION_60 <> '' ) OR
        (VALIDACION_61 <> '' ) OR
        (VALIDACION_62 <> '' ) OR
        (VALIDACION_63 <> '' ) OR
        (VALIDACION_64 <> '' ) OR
        (VALIDACION_65 <> '' ) OR
        (VALIDACION_66 <> '' ) OR
        (VALIDACION_67 <> '' ) OR
        (VALIDACION_68 <> '' ) OR
        (VALIDACION_69 <> '' ) OR
        (VALIDACION_70 <> '' ) OR
        (VALIDACION_71 <> '' ) OR
        (VALIDACION_72 <> '' ) OR
        (VALIDACION_73 <> '' ) OR
        (VALIDACION_74 <> '' ) OR
        (VALIDACION_75 <> '' ) OR
        (VALIDACION_76 <> '' ) OR
        (VALIDACION_77 <> '' ) OR
        (VALIDACION_78 <> '' ) OR
        (VALIDACION_79 <> '' ) OR
        (VALIDACION_80 <> '' ) OR
        (VALIDACION_81 <> '' ) OR
        (VALIDACION_82 <> '' ) OR
        (VALIDACION_83 <> '' ) OR
        (VALIDACION_84 <> '' ) OR
        (VALIDACION_85 <> '' ) OR
        (VALIDACION_86 <> '' ) OR
        (VALIDACION_87 <> '' ) OR
        (VALIDACION_88 <> '' ) OR
        (VALIDACION_89 <> '' ) OR
        (VALIDACION_90 <> '' ) OR
        (VALIDACION_91 <> '' ) OR
        (VALIDACION_92 <> '' ) OR
        (VALIDACION_93 <> '' ) OR
        (VALIDACION_94 <> '' ) OR
        (VALIDACION_95 <> '' ) OR
        (VALIDACION_96 <> '' ) OR
        (VALIDACION_97 <> '' ) OR
        (VALIDACION_98 <> '' ) OR
        (VALIDACION_99 <> '' ) OR
        (VALIDACION_100 <> '' ) 
ORDER BY 1
END



