﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en la estimación preventiva para riesgos crediticios */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 15SALDOS*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0419_M15SALDOSTS1_COMP_5]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0419_M15SALDOSTS1_RESULT_5')
BEGIN
DROP TABLE IFRS9_R04A_0419_M15SALDOSTS1_RESULT_5
END 

BEGIN
SELECT DISTINCT
         /*id*/
CONVERT(VARCHAR,ID) AS ID, 
	/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809707108')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809707108')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809707108) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809707108) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_401,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809707109')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809707109')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809707109) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809707109) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_402,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809707110')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809707110')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809707110) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809707110) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_403,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802506098')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802506098')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802506098) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802506098) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_404,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809807111')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809807111')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809807111) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809807111) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_405,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811108164')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811108164')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811108164) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811108164) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_406,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811108165')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811108165')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811108165) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811108165) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_407,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811108166')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811108166')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811108166) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811108166) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_408,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809807112')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809807112')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809807112) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809807112) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_409,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811208167')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811208167')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811208167) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811208167) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_410,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811208168')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811208168')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811208168) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811208168) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_411,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811208169')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811208169')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811208169) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811208169) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_412,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802506099')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802506099')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802506099) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802506099) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_413,

/*Créditos al gobierno federal */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809907113')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809907113')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809907113) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809907113) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_414,

/*Créditos a estados y municipios */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809907114')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809907114')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809907114) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809907114) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_415,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811408170')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811408170')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811408170) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811408170) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_416,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811408171')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811408171')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811408171) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811408171) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_417,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811408172')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811408172')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811408172) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811408172) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_418,

/*Fideicomisos públicos de contratación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811408173')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811408173')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811408173) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811408173) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_419,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811408174')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811408174')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811408174) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811408174) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_420,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809907115')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809907115')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809907115) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809907115) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_421,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811508175')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811508175')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811508175) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811508175) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_422,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811508176')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811508176')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811508176) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811508176) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_423,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811508177')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811508177')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811508177) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811508177) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_424,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811508178')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811508178')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811508178) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811508178) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_425,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809907116')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809907116')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112809907116) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112809907116) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_426,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811608179')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811608179')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811608179) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811608179) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_427,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811608180')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811608180')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811608180) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811608180) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_428,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811608181')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811608181')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811608181) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811608181) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_429,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811608182')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811608182')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811608182) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811608182) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_430,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801105026')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801105026')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801105026) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801105026) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_431,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802606100')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802606100')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802606100) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802606100) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_432,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802606101')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802606101')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802606101) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802606101) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_433,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802606102')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802606102')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802606102) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802606102) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_434,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802606103')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802606103')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802606103) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802606103) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_435,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802606104')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802606104')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802606104) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802606104) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_436,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802606105')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802606105')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802606105) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802606105) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_437,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802606106')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802606106')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802606106) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802606106) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_438,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802606107')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802606107')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802606107) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802606107) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_439,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801105027')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801105027')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801105027) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801105027) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_440,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802706108')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802706108')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802706108) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802706108) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_441,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802706109')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802706109')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802706109) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802706109) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_442,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802706110')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802706110')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802706110) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802706110) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_443,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811007117')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811007117')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811007117) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811007117) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_444,

/*Cartera en prórroga*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811007118')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811007118')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811007118) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811007118) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_445,

/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811007119')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811007119')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811007119) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811007119) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_446,

/*Remodelación o mejoramiento con garantía otorgada por la Banca de Desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802706111')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802706111')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802706111) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802706111) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_447,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802706112')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802706112')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802706112) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802706112) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_448,

/*Estimaciones derivadas de adquisiciones de: */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800304012')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800304012')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112800304012) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112800304012) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_449,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801205029')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801205029')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801205029) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801205029) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_450,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802906113')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802906113')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802906113) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802906113) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_451,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811307120')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811307120')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811307120) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811307120) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_452,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112812008183')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112812008183')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112812008183) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112812008183) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_453,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112812008184')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112812008184')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112812008184) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112812008184) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_454,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811307121')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811307121')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811307121) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811307121) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_455,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112812108185')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112812108185')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112812108185) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112812108185) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_456,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112812108186')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112812108186')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112812108186) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112812108186) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_457,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112812108187')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112812108187')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112812108187) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112812108187) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_458,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811307122')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811307122')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811307122) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811307122) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_459,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112812208188')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112812208188')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112812208188) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112812208188) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_460,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112812208189')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112812208189')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112812208189) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112812208189) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_461,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811307123')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811307123')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811307123) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811307123) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_462,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811307124')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811307124')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811307124) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811307124) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_463,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811307125')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811307125')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811307125) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811307125) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_464,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811307126')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811307126')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811307126) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811307126) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_465,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811307127')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811307127')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811307127) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811307127) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_466,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802906114')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802906114')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802906114) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802906114) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_467,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811407128')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811407128')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811407128) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811407128) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_468,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112812808190')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112812808190')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112812808190) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112812808190) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_469,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112812808191')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112812808191')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112812808191) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112812808191) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_470,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112812808192')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112812808192')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112812808192) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112812808192) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_471,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811407129')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811407129')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811407129) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811407129) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_472,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112812908193')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112812908193')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112812908193) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112812908193) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_473,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112812908194')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112812908194')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112812908194) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112812908194) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_474,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112812908195')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112812908195')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112812908195) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112812908195) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_475,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802906115')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802906115')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112802906115) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112802906115) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_476,

/*Créditos al gobierno federal o con su garantía*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811507130')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811507130')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811507130) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811507130) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_477,

/*Créditos a estados y municipios o con su garantía*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811507131')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811507131')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811507131) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811507131) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_478,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112813108196')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813108196')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112813108196) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112813108196) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_479,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112813108197')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813108197')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112813108197) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112813108197) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_480,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112813108198')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813108198')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112813108198) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112813108198) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_481,

/*Fideicomisos públicos de contratación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112813108199')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813108199')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112813108199) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112813108199) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_482,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112813108200')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813108200')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112813108200) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112813108200) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_483,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811507132')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811507132')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811507132) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811507132) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_484,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112813208201')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813208201')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112813208201) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112813208201) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_485,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112813208202')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813208202')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112813208202) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112813208202) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_486,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112813208203')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813208203')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112813208203) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112813208203) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_487,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112813208204')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813208204')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112813208204) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112813208204) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_488,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811507133')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811507133')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112811507133) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112811507133) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_489,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112813308205')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813308205')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112813308205) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112813308205) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_490,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112813308206')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813308206')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112813308206) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112813308206) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_491,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112813308207')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813308207')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112813308207) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112813308207) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_492,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112813308208')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813308208')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112813308208) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112813308208) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_493,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801205030')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801205030')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112801205030) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112801205030) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_494,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803006116')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803006116')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803006116) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803006116) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_495,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803006117')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803006117')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803006117) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803006117) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_496,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803006118')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803006118')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803006118) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803006118) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_497,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803006119')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803006119')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803006119) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803006119) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_498,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803006120')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803006120')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803006120) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803006120) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_499,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803006121')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('15')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803006121')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1', '4', '9')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (112803006121) con Moneda 15 y Tipo de Saldo 1 sea igual a la suma del Concepto (112803006121) con Moneda 1, 4, 9 y Tipo de Saldo 1 ')    
AS VALIDACION_500
	
INTO IFRS9_R04A_0419_M15SALDOSTS1_RESULT_5
FROM IFRS9_R04A_0419

END

BEGIN
	INSERT INTO IFRS9_R04A_0419_M15SALDOSTS1_RESULT_5
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_401])),
            SUM(CHARINDEX('ERR',[VALIDACION_402])),
            SUM(CHARINDEX('ERR',[VALIDACION_403])),
            SUM(CHARINDEX('ERR',[VALIDACION_404])),
            SUM(CHARINDEX('ERR',[VALIDACION_405])),
            SUM(CHARINDEX('ERR',[VALIDACION_406])),
            SUM(CHARINDEX('ERR',[VALIDACION_407])),
            SUM(CHARINDEX('ERR',[VALIDACION_408])),
            SUM(CHARINDEX('ERR',[VALIDACION_409])),
            SUM(CHARINDEX('ERR',[VALIDACION_410])),
            SUM(CHARINDEX('ERR',[VALIDACION_411])),
            SUM(CHARINDEX('ERR',[VALIDACION_412])),
            SUM(CHARINDEX('ERR',[VALIDACION_413])),
            SUM(CHARINDEX('ERR',[VALIDACION_414])),
            SUM(CHARINDEX('ERR',[VALIDACION_415])),
            SUM(CHARINDEX('ERR',[VALIDACION_416])),
            SUM(CHARINDEX('ERR',[VALIDACION_417])),
            SUM(CHARINDEX('ERR',[VALIDACION_418])),
            SUM(CHARINDEX('ERR',[VALIDACION_419])),
            SUM(CHARINDEX('ERR',[VALIDACION_420])),
            SUM(CHARINDEX('ERR',[VALIDACION_421])),
            SUM(CHARINDEX('ERR',[VALIDACION_422])),
            SUM(CHARINDEX('ERR',[VALIDACION_423])),
            SUM(CHARINDEX('ERR',[VALIDACION_424])),
            SUM(CHARINDEX('ERR',[VALIDACION_425])),
            SUM(CHARINDEX('ERR',[VALIDACION_426])),
            SUM(CHARINDEX('ERR',[VALIDACION_427])),
            SUM(CHARINDEX('ERR',[VALIDACION_428])),
            SUM(CHARINDEX('ERR',[VALIDACION_429])),
            SUM(CHARINDEX('ERR',[VALIDACION_430])),
            SUM(CHARINDEX('ERR',[VALIDACION_431])),
            SUM(CHARINDEX('ERR',[VALIDACION_432])),
            SUM(CHARINDEX('ERR',[VALIDACION_433])),
            SUM(CHARINDEX('ERR',[VALIDACION_434])),
            SUM(CHARINDEX('ERR',[VALIDACION_435])),
            SUM(CHARINDEX('ERR',[VALIDACION_436])),
            SUM(CHARINDEX('ERR',[VALIDACION_437])),
            SUM(CHARINDEX('ERR',[VALIDACION_438])),
            SUM(CHARINDEX('ERR',[VALIDACION_439])),
            SUM(CHARINDEX('ERR',[VALIDACION_440])),
            SUM(CHARINDEX('ERR',[VALIDACION_441])),
            SUM(CHARINDEX('ERR',[VALIDACION_442])),
            SUM(CHARINDEX('ERR',[VALIDACION_443])),
            SUM(CHARINDEX('ERR',[VALIDACION_444])),
            SUM(CHARINDEX('ERR',[VALIDACION_445])),
            SUM(CHARINDEX('ERR',[VALIDACION_446])),
            SUM(CHARINDEX('ERR',[VALIDACION_447])),
            SUM(CHARINDEX('ERR',[VALIDACION_448])),
            SUM(CHARINDEX('ERR',[VALIDACION_449])),
            SUM(CHARINDEX('ERR',[VALIDACION_450])),
            SUM(CHARINDEX('ERR',[VALIDACION_451])),
            SUM(CHARINDEX('ERR',[VALIDACION_452])),
            SUM(CHARINDEX('ERR',[VALIDACION_453])),
            SUM(CHARINDEX('ERR',[VALIDACION_454])),
            SUM(CHARINDEX('ERR',[VALIDACION_455])),
            SUM(CHARINDEX('ERR',[VALIDACION_456])),
            SUM(CHARINDEX('ERR',[VALIDACION_457])),
            SUM(CHARINDEX('ERR',[VALIDACION_458])),
            SUM(CHARINDEX('ERR',[VALIDACION_459])),
            SUM(CHARINDEX('ERR',[VALIDACION_460])),
            SUM(CHARINDEX('ERR',[VALIDACION_461])),
            SUM(CHARINDEX('ERR',[VALIDACION_462])),
            SUM(CHARINDEX('ERR',[VALIDACION_463])),
            SUM(CHARINDEX('ERR',[VALIDACION_464])),
            SUM(CHARINDEX('ERR',[VALIDACION_465])),
            SUM(CHARINDEX('ERR',[VALIDACION_466])),
            SUM(CHARINDEX('ERR',[VALIDACION_467])),
            SUM(CHARINDEX('ERR',[VALIDACION_468])),
            SUM(CHARINDEX('ERR',[VALIDACION_469])),
            SUM(CHARINDEX('ERR',[VALIDACION_470])),
            SUM(CHARINDEX('ERR',[VALIDACION_471])),
            SUM(CHARINDEX('ERR',[VALIDACION_472])),
            SUM(CHARINDEX('ERR',[VALIDACION_473])),
            SUM(CHARINDEX('ERR',[VALIDACION_474])),
            SUM(CHARINDEX('ERR',[VALIDACION_475])),
            SUM(CHARINDEX('ERR',[VALIDACION_476])),
            SUM(CHARINDEX('ERR',[VALIDACION_477])),
            SUM(CHARINDEX('ERR',[VALIDACION_478])),
            SUM(CHARINDEX('ERR',[VALIDACION_479])),
            SUM(CHARINDEX('ERR',[VALIDACION_480])),
            SUM(CHARINDEX('ERR',[VALIDACION_481])),
            SUM(CHARINDEX('ERR',[VALIDACION_482])),
            SUM(CHARINDEX('ERR',[VALIDACION_483])),
            SUM(CHARINDEX('ERR',[VALIDACION_484])),
            SUM(CHARINDEX('ERR',[VALIDACION_485])),
            SUM(CHARINDEX('ERR',[VALIDACION_486])),
            SUM(CHARINDEX('ERR',[VALIDACION_487])),
            SUM(CHARINDEX('ERR',[VALIDACION_488])),
            SUM(CHARINDEX('ERR',[VALIDACION_489])),
            SUM(CHARINDEX('ERR',[VALIDACION_490])),
            SUM(CHARINDEX('ERR',[VALIDACION_491])),
            SUM(CHARINDEX('ERR',[VALIDACION_492])),
            SUM(CHARINDEX('ERR',[VALIDACION_493])),
            SUM(CHARINDEX('ERR',[VALIDACION_494])),
            SUM(CHARINDEX('ERR',[VALIDACION_495])),
            SUM(CHARINDEX('ERR',[VALIDACION_496])),
            SUM(CHARINDEX('ERR',[VALIDACION_497])),
            SUM(CHARINDEX('ERR',[VALIDACION_498])),
            SUM(CHARINDEX('ERR',[VALIDACION_499])),
            SUM(CHARINDEX('ERR',[VALIDACION_500]))
            


		from IFRS9_R04A_0419_M15SALDOSTS1_RESULT_5
END

BEGIN
	EXEC SP_IFRS9_R04A_0419_M15SALDOSTS1_VIEW_5
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


