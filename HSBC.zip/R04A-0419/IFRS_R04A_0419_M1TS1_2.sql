﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en la estimación preventiva para riesgos crediticios */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 1*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0419_M1TS1_COMP_2]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0419_M1TS1_RESULT_2')
BEGIN
DROP TABLE IFRS9_R04A_0419_M1TS1_RESULT_2
END 

BEGIN
SELECT DISTINCT

    /*ID*/

    CONVERT(VARCHAR,ID) AS ID,                                    /*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802506097')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809707103','112809707104','112809707105','112809707106','112809707107','112809707108','112809707109','112809707110')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112802506097) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112809707103 + 112809707104 + 112809707105 + 112809707106 + 112809707107 + 112809707108 + 112809707109 + 112809707110) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_101,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809707103')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112810308157','112810308158')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112809707103) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112810308157 + 112810308158) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_102,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809707104')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112810408159','112810408160','112810408161')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112809707104) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112810408159 + 112810408160 + 112810408161) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_103,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809707105')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112810508162','112810508163')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112809707105) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112810508162 + 112810508163) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_104,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802506098')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809807111','112809807112')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112802506098) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112809807111 + 112809807112) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_105,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809807111')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811108164','112811108165','112811108166')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112809807111) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112811108164 + 112811108165 + 112811108166) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_106,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809807112')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811208167','112811208168','112811208169')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112809807112) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112811208167 + 112811208168 + 112811208169) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_107,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802506099')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809907113','112809907114','112809907115','112809907116')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112802506099) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112809907113 + 112809907114 + 112809907115 + 112809907116) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_108,

/*Créditos a estados y municipios */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809907114')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811408170','112811408171','112811408172','112811408173','112811408174')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112809907114) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112811408170 + 112811408171 + 112811408172 + 112811408173 + 112811408174) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_109,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809907115')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811508175','112811508176','112811508177','112811508178')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112809907115) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112811508175 + 112811508176 + 112811508177 + 112811508178) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_110,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112809907116')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811608179','112811608180','112811608181','112811608182')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112809907116) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112811608179 + 112811608180 + 112811608181 + 112811608182) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_111,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801105026')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802606100','112802606101','112802606102','112802606103','112802606104','112802606105','112802606106','112802606107')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112801105026) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112802606100 + 112802606101 + 112802606102 + 112802606103 + 112802606104 + 112802606105 + 112802606106 + 112802606107) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_112,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801105027')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802706108','112802706109','112802706110','112802706111','112802706112')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112801105027) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112802706108 + 112802706109 + 112802706110 + 112802706111 + 112802706112) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_113,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802706110')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811007117','112811007118','112811007119')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112802706110) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112811007117 + 112811007118 + 112811007119) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_114,

/*Estimaciones derivadas de adquisiciones de: */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800304012')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801205029','112801205030','112801205031')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800304012) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112801205029 + 112801205030 + 112801205031) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_115,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801205029')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802906113','112802906114','112802906115')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112801205029) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112802906113 + 112802906114 + 112802906115) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_116,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802906113')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811307120','112811307121','112811307122','112811307123','112811307124','112811307125','112811307126','112811307127')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112802906113) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112811307120 + 112811307121 + 112811307122 + 112811307123 + 112811307124 + 112811307125 + 112811307126 + 112811307127) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_117,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811307120')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112812008183','112812008184')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112811307120) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112812008183 + 112812008184) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_118,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811307121')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112812108185','112812108186','112812108187')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112811307121) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112812108185 + 112812108186 + 112812108187) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_119,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811307122')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112812208188','112812208189')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112811307122) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112812208188 + 112812208189) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_120,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802906114')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811407128','112811407129')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112802906114) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112811407128 + 112811407129) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_121,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811407128')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112812808190','112812808191','112812808192')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112811407128) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112812808190 + 112812808191 + 112812808192) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_122,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811407129')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112812908193','112812908194','112812908195')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112811407129) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112812908193 + 112812908194 + 112812908195) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_123,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802906115')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112811507130','112811507131','112811507132','112811507133')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112802906115) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112811507130 + 112811507131 + 112811507132 + 112811507133) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_124,

/*Créditos a estados y municipios o con su garantía*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811507131')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813108196','112813108197','112813108198','112813108199','112813108200')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112811507131) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112813108196 + 112813108197 + 112813108198 + 112813108199 + 112813108200) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_125,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811507132')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813208201','112813208202','112813208203','112813208204')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112811507132) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112813208201 + 112813208202 + 112813208203 + 112813208204) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_126,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112811507133')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813308205','112813308206','112813308207','112813308208')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112811507133) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112813308205 + 112813308206 + 112813308207 + 112813308208) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_127,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801205030')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803006116','112803006117','112803006118','112803006119','112803006120','112803006121','112803006122','112803006123')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112801205030) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112803006116 + 112803006117 + 112803006118 + 112803006119 + 112803006120 + 112803006121 + 112803006122 + 112803006123) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_128,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801205031')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803106124','112803106125','112803106126','112803106127','112803106128')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112801205031) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112803106124 + 112803106125 + 112803106126 + 112803106127 + 112803106128) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_129,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803106126')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112812607134','112812607135','112812607136')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112803106126) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112812607134 + 112812607135 + 112812607136) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_130,

/*Efecto de valuación de estimaciones en ME, VSM, UMA o UDIS por deslizamiento cambiario (3)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800304013')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801305033','112801305034','112801305035')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800304013) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112801305033 + 112801305034 + 112801305035) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_131,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801305033')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803306129','112803306130','112803306131')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112801305033) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112803306129 + 112803306130 + 112803306131) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_132,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803306129')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112812907137','112812907138','112812907139','112812907140','112812907141','112812907142','112812907143','112812907144')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112803306129) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112812907137 + 112812907138 + 112812907139 + 112812907140 + 112812907141 + 112812907142 + 112812907143 + 112812907144) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_133,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112812907137')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813708209','112813708210')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112812907137) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112813708209 + 112813708210) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_134,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112812907138')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813808211','112813808212','112813808213')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112812907138) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112813808211 + 112813808212 + 112813808213) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_135,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112812907139')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813908214','112813908215')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112812907139) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112813908214 + 112813908215) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_136,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803306130')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813007145','112813007146')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112803306130) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112813007145 + 112813007146) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_137,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112813007145')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112814508216','112814508217','112814508218')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112813007145) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112814508216 + 112814508217 + 112814508218) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_138,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112813007146')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112814608219','112814608220','112814608221')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112813007146) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112814608219 + 112814608220 + 112814608221) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_139,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803306131')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112813107147','112813107148','112813107149','112813107150')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112803306131) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112813107147 + 112813107148 + 112813107149 + 112813107150) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_140,

/*Créditos a estados y municipios */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112813107148')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112814808222','112814808223','112814808224','112814808225','112814808226')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112813107148) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112814808222 + 112814808223 + 112814808224 + 112814808225 + 112814808226) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_141,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112813107149')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112814908227','112814908228','112814908229','112814908230')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112813107149) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112814908227 + 112814908228 + 112814908229 + 112814908230) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_142,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112813107150')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112815008231','112815008232','112815008233','112815008234')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112813107150) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112815008231 + 112815008232 + 112815008233 + 112815008234) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_143,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801305034')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803406132','112803406133','112803406134','112803406135','112803406136','112803406137','112803406138','112803406139')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112801305034) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112803406132 + 112803406133 + 112803406134 + 112803406135 + 112803406136 + 112803406137 + 112803406138 + 112803406139) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_144,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801305035')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803506140','112803506141','112803506142','112803506143','112803506144')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112801305035) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112803506140 + 112803506141 + 112803506142 + 112803506143 + 112803506144) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_145,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803506142')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112814207151','112814207152','112814207153')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112803506142) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112814207151 + 112814207152 + 112814207153) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_146,

/*Saldo final del mes*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('101800103003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800103001','112800103002','112800103003')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800103003) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112800103001 + 112800103002 + 112800103003) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_147
	
INTO IFRS9_R04A_0419_M1TS1_RESULT_2
FROM IFRS9_R04A_0419

END

BEGIN
	INSERT INTO IFRS9_R04A_0419_M1TS1_RESULT_2
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_101])),
            SUM(CHARINDEX('ERR',[VALIDACION_102])),
            SUM(CHARINDEX('ERR',[VALIDACION_103])),
            SUM(CHARINDEX('ERR',[VALIDACION_104])),
            SUM(CHARINDEX('ERR',[VALIDACION_105])),
            SUM(CHARINDEX('ERR',[VALIDACION_106])),
            SUM(CHARINDEX('ERR',[VALIDACION_107])),
            SUM(CHARINDEX('ERR',[VALIDACION_108])),
            SUM(CHARINDEX('ERR',[VALIDACION_109])),
            SUM(CHARINDEX('ERR',[VALIDACION_110])),
            SUM(CHARINDEX('ERR',[VALIDACION_111])),
            SUM(CHARINDEX('ERR',[VALIDACION_112])),
            SUM(CHARINDEX('ERR',[VALIDACION_113])),
            SUM(CHARINDEX('ERR',[VALIDACION_114])),
            SUM(CHARINDEX('ERR',[VALIDACION_115])),
            SUM(CHARINDEX('ERR',[VALIDACION_116])),
            SUM(CHARINDEX('ERR',[VALIDACION_117])),
            SUM(CHARINDEX('ERR',[VALIDACION_118])),
            SUM(CHARINDEX('ERR',[VALIDACION_119])),
            SUM(CHARINDEX('ERR',[VALIDACION_120])),
            SUM(CHARINDEX('ERR',[VALIDACION_121])),
            SUM(CHARINDEX('ERR',[VALIDACION_122])),
            SUM(CHARINDEX('ERR',[VALIDACION_123])),
            SUM(CHARINDEX('ERR',[VALIDACION_124])),
            SUM(CHARINDEX('ERR',[VALIDACION_125])),
            SUM(CHARINDEX('ERR',[VALIDACION_126])),
            SUM(CHARINDEX('ERR',[VALIDACION_127])),
            SUM(CHARINDEX('ERR',[VALIDACION_128])),
            SUM(CHARINDEX('ERR',[VALIDACION_129])),
            SUM(CHARINDEX('ERR',[VALIDACION_130])),
            SUM(CHARINDEX('ERR',[VALIDACION_131])),
            SUM(CHARINDEX('ERR',[VALIDACION_132])),
            SUM(CHARINDEX('ERR',[VALIDACION_133])),
            SUM(CHARINDEX('ERR',[VALIDACION_134])),
            SUM(CHARINDEX('ERR',[VALIDACION_135])),
            SUM(CHARINDEX('ERR',[VALIDACION_136])),
            SUM(CHARINDEX('ERR',[VALIDACION_137])),
            SUM(CHARINDEX('ERR',[VALIDACION_138])),
            SUM(CHARINDEX('ERR',[VALIDACION_139])),
            SUM(CHARINDEX('ERR',[VALIDACION_140])),
            SUM(CHARINDEX('ERR',[VALIDACION_141])),
            SUM(CHARINDEX('ERR',[VALIDACION_142])),
            SUM(CHARINDEX('ERR',[VALIDACION_143])),
            SUM(CHARINDEX('ERR',[VALIDACION_144])),
            SUM(CHARINDEX('ERR',[VALIDACION_145])),
            SUM(CHARINDEX('ERR',[VALIDACION_146])),
            SUM(CHARINDEX('ERR',[VALIDACION_147]))
            


		from IFRS9_R04A_0419_M1TS1_RESULT_2
END

BEGIN
	EXEC SP_IFRS9_R04A_0419_M1TS1_VIEW_2
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


