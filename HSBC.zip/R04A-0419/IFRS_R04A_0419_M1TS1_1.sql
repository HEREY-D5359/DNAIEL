﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Movimientos en la estimación preventiva para riesgos crediticios */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 1*/
/*TIPO SALDO: 1*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROC [dbo].[SP_IFRS9_R04A_0419_M1TS1_COMP_1]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0419_M1TS1_RESULT_1')
BEGIN
DROP TABLE IFRS9_R04A_0419_M1TS1_RESULT_1
END 

BEGIN
SELECT DISTINCT

	/*ID*/

	CONVERT(VARCHAR,ID)  AS ID,   
	/*CARGOS*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800103002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800204001','112800204002','112800204003','112800204004','112800204005','112800204006','112800204007','112800204008','112800204009','112800204010')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800103002) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112800204001 + 112800204002 + 112800204003 + 112800204004 + 112800204005 + 112800204006 + 112800204007 + 112800204008 + 112800204009 + 112800204010) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_1,

/*Castigos, eliminaciones y recuperaciones de cartera:*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800204001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800105001','112800105002','112800105003')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800204001) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112800105001 + 112800105002 + 112800105003) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_2,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800105001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800106001','112800106002','112800106003')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800105001) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112800106001 + 112800106002 + 112800106003) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_3,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800106001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800107001','112800107002','112800107003','112800107004','112800107005','112800107006','112800107007','112800107008')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800106001) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112800107001 + 112800107002 + 112800107003 + 112800107004 + 112800107005 + 112800107006 + 112800107007 + 112800107008) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_4,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800107001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800108001','112800108002')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800107001) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112800108001 + 112800108002) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_5,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800107002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800208003','112800208004','112800208005')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800107002) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112800208003 + 112800208004 + 112800208005) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_6,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800107003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800308006','112800308007')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800107003) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112800308006 + 112800308007) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_7,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800106002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800207009','112800207010')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800106002) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112800207009 + 112800207010) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_8,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800207009')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800908008','112800908009','112800908010')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800207009) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112800908008 + 112800908009 + 112800908010) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_9,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800207010')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801008011','112801008012','112801008013')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800207010) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112801008011 + 112801008012 + 112801008013) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_10,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800106003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800307011','112800307012','112800307013','112800307014')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800106003) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112800307011 + 112800307012 + 112800307013 + 112800307014) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_11,

/*Créditos a estados y municipios */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800307012')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801208014','112801208015','112801208016','112801208017','112801208018')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800307012) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112801208014 + 112801208015 + 112801208016 + 112801208017 + 112801208018) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_12,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800307013')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801308019','112801308020','112801308021','112801308022')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800307013) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112801308019 + 112801308020 + 112801308021 + 112801308022) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_13,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800307014')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801408023','112801408024','112801408025','112801408026')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800307014) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112801408023 + 112801408024 + 112801408025 + 112801408026) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_14,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800105002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800206004','112800206005','112800206006','112800206007','112800206008','112800206009','112800206010','112800206011')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800105002) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112800206004 + 112800206005 + 112800206006 + 112800206007 + 112800206008 + 112800206009 + 112800206010 + 112800206011) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_15,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800105003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800306012','112800306013','112800306014','112800306015','112800306016')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800105003) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112800306012 + 112800306013 + 112800306014 + 112800306015 + 112800306016) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_16,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800306014')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801407015','112801407016','112801407017')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800306014) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112801407015 + 112801407016 + 112801407017) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_17,

/*Quitas, condonaciones, bonificaciones y descuentos:*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800204003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800305005','112800305006','112800305007')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800204003) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112800305005 + 112800305006 + 112800305007) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_18,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800305005')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800506017','112800506018','112800506019')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800305005) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112800506017 + 112800506018 + 112800506019) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_19,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800506017')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801707018','112801707019','112801707020','112801707021','112801707022','112801707023','112801707024','112801707025')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800506017) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112801707018 + 112801707019 + 112801707020 + 112801707021 + 112801707022 + 112801707023 + 112801707024 + 112801707025) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_20,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801707018')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801808027','112801808028')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112801707018) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112801808027 + 112801808028) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_21,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801707019')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801908029','112801908030','112801908031')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112801707019) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112801908029 + 112801908030 + 112801908031) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_22,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801707020')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802008032','112802008033')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112801707020) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112802008032 + 112802008033) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_23,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800506018')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801807026','112801807027')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800506018) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112801807026 + 112801807027) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_24,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801807026')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802608034','112802608035','112802608036')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112801807026) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112802608034 + 112802608035 + 112802608036) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_25,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801807027')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802708037','112802708038','112802708039')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112801807027) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112802708037 + 112802708038 + 112802708039) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_26,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800506019')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801907028','112801907029','112801907030','112801907031')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800506019) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112801907028 + 112801907029 + 112801907030 + 112801907031) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_27,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801907029')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802908040','112802908041','112802908042','112802908043','112802908044')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112801907029) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112802908040 + 112802908041 + 112802908042 + 112802908043 + 112802908044) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_28,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801907030')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803008045','112803008046','112803008047','112803008048')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112801907030) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112803008045 + 112803008046 + 112803008047 + 112803008048) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_29,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801907031')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803108049','112803108050','112803108051','112803108052')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112801907031) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112803108049 + 112803108050 + 112803108051 + 112803108052) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_30,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800305006')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800606020','112800606021','112800606022','112800606023','112800606024','112800606025','112800606026','112800606027')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800305006) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112800606020 + 112800606021 + 112800606022 + 112800606023 + 112800606024 + 112800606025 + 112800606026 + 112800606027) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_31,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800305007')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800706028','112800706029','112800706030','112800706031','112800706032')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800305007) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112800706028 + 112800706029 + 112800706030 + 112800706031 + 112800706032) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_32,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800706030')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803007032','112803007033','112803007034')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800706030) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112803007032 + 112803007033 + 112803007034) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_33,

/*Estimaciones traspasadas a otras instituciones por cesiones de:*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800204005')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800505009','112800505010','112800505011')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800204005) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112800505009 + 112800505010 + 112800505011) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_34,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800505009')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800906033','112800906034','112800906035')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800505009) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112800906033 + 112800906034 + 112800906035) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_35,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800906033')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803307035','112803307036','112803307037','112803307038','112803307039','112803307040','112803307041','112803307042')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800906033) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112803307035 + 112803307036 + 112803307037 + 112803307038 + 112803307039 + 112803307040 + 112803307041 + 112803307042) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_36,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803307035')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803508053','112803508054')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112803307035) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112803508053 + 112803508054) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_37,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803307036')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803608055','112803608056','112803608057')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112803307036) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112803608055 + 112803608056 + 112803608057) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_38,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803307037')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803708058','112803708059')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112803307037) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112803708058 + 112803708059) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_39,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800906034')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803407043','112803407044')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800906034) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112803407043 + 112803407044) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_40,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803407043')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112804308060','112804308061','112804308062')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112803407043) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112804308060 + 112804308061 + 112804308062) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_41,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803407044')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112804408063','112804408064','112804408065')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112803407044) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112804408063 + 112804408064 + 112804408065) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_42,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800906035')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112803507045','112803507046','112803507047','112803507048')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800906035) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112803507045 + 112803507046 + 112803507047 + 112803507048) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_43,

/*Créditos a estados y municipios */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803507046')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112804608066','112804608067','112804608068','112804608069','112804608070')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112803507046) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112804608066 + 112804608067 + 112804608068 + 112804608069 + 112804608070) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_44,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803507047')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112804708071','112804708072','112804708073','112804708074')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112803507047) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112804708071 + 112804708072 + 112804708073 + 112804708074) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_45,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112803507048')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112804808075','112804808076','112804808077','112804808078')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112803507048) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112804808075 + 112804808076 + 112804808077 + 112804808078) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_46,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800505010')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801006036','112801006037','112801006038','112801006039','112801006040','112801006041','112801006042','112801006043')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800505010) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112801006036 + 112801006037 + 112801006038 + 112801006039 + 112801006040 + 112801006041 + 112801006042 + 112801006043) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_47,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800505011')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801106044','112801106045','112801106046','112801106047','112801106048')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800505011) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112801106044 + 112801106045 + 112801106046 + 112801106047 + 112801106048) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_48,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801106046')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112804607049','112804607050','112804607051')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112801106046) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112804607049 + 112804607050 + 112804607051) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_49,

/*Cancelación de estimaciones por cobro de cartera, adjudicación o recepción de bienes como dación en pago en:*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800204006')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800605013','112800605014','112800605015')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800204006) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112800605013 + 112800605014 + 112800605015) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_50,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800605013')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801306049','112801306050','112801306051')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800605013) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112801306049 + 112801306050 + 112801306051) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_51,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801306049')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112804907052','112804907053','112804907054','112804907055','112804907056','112804907057','112804907058','112804907059')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112801306049) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112804907052 + 112804907053 + 112804907054 + 112804907055 + 112804907056 + 112804907057 + 112804907058 + 112804907059) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_52,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112804907052')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112805208079','112805208080')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112804907052) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112805208079 + 112805208080) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_53,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112804907053')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112805308081','112805308082','112805308083')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112804907053) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112805308081 + 112805308082 + 112805308083) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_54,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112804907054')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112805408084','112805408085')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112804907054) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112805408084 + 112805408085) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_55,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801306050')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112805007060','112805007061')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112801306050) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112805007060 + 112805007061) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_56,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112805007060')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112806008086','112806008087','112806008088')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112805007060) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112806008086 + 112806008087 + 112806008088) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_57,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112805007061')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112806108089','112806108090','112806108091')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112805007061) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112806108089 + 112806108090 + 112806108091) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_58,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801306051')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112805107062','112805107063','112805107064','112805107065')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112801306051) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112805107062 + 112805107063 + 112805107064 + 112805107065) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_59,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112805107063')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112806308092','112806308093','112806308094','112806308095','112806308096')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112805107063) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112806308092 + 112806308093 + 112806308094 + 112806308095 + 112806308096) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_60,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112805107064')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112806408097','112806408098','112806408099','112806408100')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112805107064) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112806408097 + 112806408098 + 112806408099 + 112806408100) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_61,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112805107065')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112806508101','112806508102','112806508103','112806508104')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112805107065) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112806508101 + 112806508102 + 112806508103 + 112806508104) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_62,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800605014')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801406052','112801406053','112801406054','112801406055','112801406056','112801406057','112801406058','112801406059')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800605014) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112801406052 + 112801406053 + 112801406054 + 112801406055 + 112801406056 + 112801406057 + 112801406058 + 112801406059) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_63,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800605015')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801506060','112801506061','112801506062','112801506063','112801506064')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800605015) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112801506060 + 112801506061 + 112801506062 + 112801506063 + 112801506064) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_64,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801506062')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112806207066','112806207067','112806207068')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112801506062) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112806207066 + 112806207067 + 112806207068) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_65,

/*Cancelación de estimaciones por calificación de:*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800204007')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800705017','112800705018','112800705019')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800204007) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112800705017 + 112800705018 + 112800705019) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_66,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800705017')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801706065','112801706066','112801706067')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800705017) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112801706065 + 112801706066 + 112801706067) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_67,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801706065')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112806507069','112806507070','112806507071','112806507072','112806507073','112806507074','112806507075','112806507076')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112801706065) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112806507069 + 112806507070 + 112806507071 + 112806507072 + 112806507073 + 112806507074 + 112806507075 + 112806507076) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_68,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112806507069')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112806908105','112806908106')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112806507069) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112806908105 + 112806908106) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_69,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112806507070')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112807008107','112807008108','112807008109')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112806507070) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112807008107 + 112807008108 + 112807008109) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_70,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112806507071')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112807108110','112807108111')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112806507071) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112807108110 + 112807108111) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_71,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801706066')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112806607077','112806607078')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112801706066) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112806607077 + 112806607078) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_72,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112806607077')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112807708112','112807708113','112807708114')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112806607077) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112807708112 + 112807708113 + 112807708114) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_73,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112806607078')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112807808115','112807808116','112807808117')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112806607078) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112807808115 + 112807808116 + 112807808117) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_74,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801706067')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112806707079','112806707080','112806707081','112806707082')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112801706067) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112806707079 + 112806707080 + 112806707081 + 112806707082) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_75,

/*Créditos a estados y municipios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112806707080')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112808008118','112808008119','112808008120','112808008121')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112806707080) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112808008118 + 112808008119 + 112808008120 + 112808008121) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_76,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112806707081')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112808108122','112808108123','112808108124','112808108125','112808108126')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112806707081) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112808108122 + 112808108123 + 112808108124 + 112808108125 + 112808108126) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_77,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112806707082')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112808208127','112808208128','112808208129','112808208130')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112806707082) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112808208127 + 112808208128 + 112808208129 + 112808208130) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_78,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800705018')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801806068','112801806069','112801806070','112801806071','112801806072','112801806073','112801806074','112801806075')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800705018) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112801806068 + 112801806069 + 112801806070 + 112801806071 + 112801806072 + 112801806073 + 112801806074 + 112801806075) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_79,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800705019')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112801906076','112801906077','112801906078','112801906079','112801906080')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800705019) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112801906076 + 112801906077 + 112801906078 + 112801906079 + 112801906080) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_80,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801906078')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112807807083','112807807084','112807807085')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112801906078) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112807807083 + 112807807084 + 112807807085) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_81,

/*Efecto de valuación de estimaciones en ME, VSM, UMA o UDIS por deslizamiento cambiario (2)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800204008')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800805021','112800805022','112800805023')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800204008) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112800805021 + 112800805022 + 112800805023) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_82,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800805021')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802106081','112802106082','112802106083')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800805021) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112802106081 + 112802106082 + 112802106083) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_83,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802106081')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112808107086','112808107087','112808107088','112808107089','112808107090','112808107091','112808107092','112808107093')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112802106081) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112808107086 + 112808107087 + 112808107088 + 112808107089 + 112808107090 + 112808107091 + 112808107092 + 112808107093) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_84,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112808107086')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112808608131','112808608132')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112808107086) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112808608131 + 112808608132) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_85,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112808107087')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112808708133','112808708134','112808708135')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112808107087) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112808708133 + 112808708134 + 112808708135) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_86,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112808107088')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112808808136','112808808137')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112808107088) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112808808136 + 112808808137) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_87,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802106082')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112808207094','112808207095')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112802106082) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112808207094 + 112808207095) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_88,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112808207094')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809408138','112809408139','112809408140')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112808207094) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112809408138 + 112809408139 + 112809408140) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_89,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112808207095')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809508141','112809508142','112809508143')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112808207095) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112809508141 + 112809508142 + 112809508143) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_90,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802106083')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112808307096','112808307097','112808307098','112808307099')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112802106083) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112808307096 + 112808307097 + 112808307098 + 112808307099) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_91,

/*Créditos a estados y municipios */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112808307097')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809708144','112809708145','112809708146','112809708147','112809708148')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112808307097) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112809708144 + 112809708145 + 112809708146 + 112809708147 + 112809708148) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_92,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112808307098')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809808149','112809808150','112809808151','112809808152')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112808307098) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112809808149 + 112809808150 + 112809808151 + 112809808152) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_93,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112808307099')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809908153','112809908154','112809908155','112809908156')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112808307099) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112809908153 + 112809908154 + 112809908155 + 112809908156) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_94,

/*Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800805022')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802206084','112802206085','112802206086','112802206087','112802206088','112802206089','112802206090','112802206091')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800805022) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112802206084 + 112802206085 + 112802206086 + 112802206087 + 112802206088 + 112802206089 + 112802206090 + 112802206091) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_95,

/*Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800805023')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802306092','112802306093','112802306094','112802306095','112802306096')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800805023) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112802306092 + 112802306093 + 112802306094 + 112802306095 + 112802306096) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_96,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802306094')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809407100','112809407101','112809407102')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112802306094) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112809407100 + 112809407101 + 112809407102) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_97,

/*ABONOS*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112802306094')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112809407100','112809407101','112809407102')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112802306094) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112809407100 + 112809407101 + 112809407102) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_98,

/*Creación de estimaciones preventivas para riesgo crediticio por calificación de:*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112800103003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112800304011','112800304012','112800304013','112800304014','112800304015')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112800103003) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112800304011 + 112800304012 + 112800304013 + 112800304014 + 112800304015) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_99,

/*Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0419   
WHERE [c04_CONCEPTO] IN ('112801105025')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('1')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0419     
WHERE [c04_CONCEPTO] IN ('112802506097','112802506098','112802506099')
AND c06_tipo_saldo IN ('1')     
AND c05_moneda IN ('1')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (112801105025) con Moneda 1, Tipo de Saldo 1, debe ser igual a la sumatoria de las cuentas (112802506097 + 112802506098 + 112802506099) con Moneda 1, Tipo de Saldo 1.')    
AS VALIDACION_100
	
INTO IFRS9_R04A_0419_M1TS1_RESULT_1
FROM IFRS9_R04A_0419

END

BEGIN
	INSERT INTO IFRS9_R04A_0419_M1TS1_RESULT_1
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_1])),
            SUM(CHARINDEX('ERR',[VALIDACION_2])),
            SUM(CHARINDEX('ERR',[VALIDACION_3])),
            SUM(CHARINDEX('ERR',[VALIDACION_4])),
            SUM(CHARINDEX('ERR',[VALIDACION_5])),
            SUM(CHARINDEX('ERR',[VALIDACION_6])),
            SUM(CHARINDEX('ERR',[VALIDACION_7])),
            SUM(CHARINDEX('ERR',[VALIDACION_8])),
            SUM(CHARINDEX('ERR',[VALIDACION_9])),
            SUM(CHARINDEX('ERR',[VALIDACION_10])),
            SUM(CHARINDEX('ERR',[VALIDACION_11])),
            SUM(CHARINDEX('ERR',[VALIDACION_12])),
            SUM(CHARINDEX('ERR',[VALIDACION_13])),
            SUM(CHARINDEX('ERR',[VALIDACION_14])),
            SUM(CHARINDEX('ERR',[VALIDACION_15])),
            SUM(CHARINDEX('ERR',[VALIDACION_16])),
            SUM(CHARINDEX('ERR',[VALIDACION_17])),
            SUM(CHARINDEX('ERR',[VALIDACION_18])),
            SUM(CHARINDEX('ERR',[VALIDACION_19])),
            SUM(CHARINDEX('ERR',[VALIDACION_20])),
            SUM(CHARINDEX('ERR',[VALIDACION_21])),
            SUM(CHARINDEX('ERR',[VALIDACION_22])),
            SUM(CHARINDEX('ERR',[VALIDACION_23])),
            SUM(CHARINDEX('ERR',[VALIDACION_24])),
            SUM(CHARINDEX('ERR',[VALIDACION_25])),
            SUM(CHARINDEX('ERR',[VALIDACION_26])),
            SUM(CHARINDEX('ERR',[VALIDACION_27])),
            SUM(CHARINDEX('ERR',[VALIDACION_28])),
            SUM(CHARINDEX('ERR',[VALIDACION_29])),
            SUM(CHARINDEX('ERR',[VALIDACION_30])),
            SUM(CHARINDEX('ERR',[VALIDACION_31])),
            SUM(CHARINDEX('ERR',[VALIDACION_32])),
            SUM(CHARINDEX('ERR',[VALIDACION_33])),
            SUM(CHARINDEX('ERR',[VALIDACION_34])),
            SUM(CHARINDEX('ERR',[VALIDACION_35])),
            SUM(CHARINDEX('ERR',[VALIDACION_36])),
            SUM(CHARINDEX('ERR',[VALIDACION_37])),
            SUM(CHARINDEX('ERR',[VALIDACION_38])),
            SUM(CHARINDEX('ERR',[VALIDACION_39])),
            SUM(CHARINDEX('ERR',[VALIDACION_40])),
            SUM(CHARINDEX('ERR',[VALIDACION_41])),
            SUM(CHARINDEX('ERR',[VALIDACION_42])),
            SUM(CHARINDEX('ERR',[VALIDACION_43])),
            SUM(CHARINDEX('ERR',[VALIDACION_44])),
            SUM(CHARINDEX('ERR',[VALIDACION_45])),
            SUM(CHARINDEX('ERR',[VALIDACION_46])),
            SUM(CHARINDEX('ERR',[VALIDACION_47])),
            SUM(CHARINDEX('ERR',[VALIDACION_48])),
            SUM(CHARINDEX('ERR',[VALIDACION_49])),
            SUM(CHARINDEX('ERR',[VALIDACION_50])),
            SUM(CHARINDEX('ERR',[VALIDACION_51])),
            SUM(CHARINDEX('ERR',[VALIDACION_52])),
            SUM(CHARINDEX('ERR',[VALIDACION_53])),
            SUM(CHARINDEX('ERR',[VALIDACION_54])),
            SUM(CHARINDEX('ERR',[VALIDACION_55])),
            SUM(CHARINDEX('ERR',[VALIDACION_56])),
            SUM(CHARINDEX('ERR',[VALIDACION_57])),
            SUM(CHARINDEX('ERR',[VALIDACION_58])),
            SUM(CHARINDEX('ERR',[VALIDACION_59])),
            SUM(CHARINDEX('ERR',[VALIDACION_60])),
            SUM(CHARINDEX('ERR',[VALIDACION_61])),
            SUM(CHARINDEX('ERR',[VALIDACION_62])),
            SUM(CHARINDEX('ERR',[VALIDACION_63])),
            SUM(CHARINDEX('ERR',[VALIDACION_64])),
            SUM(CHARINDEX('ERR',[VALIDACION_65])),
            SUM(CHARINDEX('ERR',[VALIDACION_66])),
            SUM(CHARINDEX('ERR',[VALIDACION_67])),
            SUM(CHARINDEX('ERR',[VALIDACION_68])),
            SUM(CHARINDEX('ERR',[VALIDACION_69])),
            SUM(CHARINDEX('ERR',[VALIDACION_70])),
            SUM(CHARINDEX('ERR',[VALIDACION_71])),
            SUM(CHARINDEX('ERR',[VALIDACION_72])),
            SUM(CHARINDEX('ERR',[VALIDACION_73])),
            SUM(CHARINDEX('ERR',[VALIDACION_74])),
            SUM(CHARINDEX('ERR',[VALIDACION_75])),
            SUM(CHARINDEX('ERR',[VALIDACION_76])),
            SUM(CHARINDEX('ERR',[VALIDACION_77])),
            SUM(CHARINDEX('ERR',[VALIDACION_78])),
            SUM(CHARINDEX('ERR',[VALIDACION_79])),
            SUM(CHARINDEX('ERR',[VALIDACION_80])),
            SUM(CHARINDEX('ERR',[VALIDACION_81])),
            SUM(CHARINDEX('ERR',[VALIDACION_82])),
            SUM(CHARINDEX('ERR',[VALIDACION_83])),
            SUM(CHARINDEX('ERR',[VALIDACION_84])),
            SUM(CHARINDEX('ERR',[VALIDACION_85])),
            SUM(CHARINDEX('ERR',[VALIDACION_86])),
            SUM(CHARINDEX('ERR',[VALIDACION_87])),
            SUM(CHARINDEX('ERR',[VALIDACION_88])),
            SUM(CHARINDEX('ERR',[VALIDACION_89])),
            SUM(CHARINDEX('ERR',[VALIDACION_90])),
            SUM(CHARINDEX('ERR',[VALIDACION_91])),
            SUM(CHARINDEX('ERR',[VALIDACION_92])),
            SUM(CHARINDEX('ERR',[VALIDACION_93])),
            SUM(CHARINDEX('ERR',[VALIDACION_94])),
            SUM(CHARINDEX('ERR',[VALIDACION_95])),
            SUM(CHARINDEX('ERR',[VALIDACION_96])),
            SUM(CHARINDEX('ERR',[VALIDACION_97])),
            SUM(CHARINDEX('ERR',[VALIDACION_98])),
            SUM(CHARINDEX('ERR',[VALIDACION_99])),
            SUM(CHARINDEX('ERR',[VALIDACION_100]))
            


		from IFRS9_R04A_0419_M1TS1_RESULT_1
END

BEGIN
	EXEC SP_IFRS9_R04A_0419_M1TS1_VIEW_1
END

COMMIT




END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


