﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Cartera por tipo de crédito, saldo promedio, intereses y comisiones */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 14*/
/*TIPO SALDO: SALDOS*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROCEDURE  [dbo].[SP_IFRS9_R04A_0411_M14TSSALDOS_COMP_4]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0411_M14TSSALDOS_RESULT_4')
BEGIN
DROP TABLE IFRS9_R04A_0411_M14TSSALDOS_RESULT_4
END 

BEGIN
SELECT DISTINCT

   /*ID*/

    CONVERT(VARCHAR, ID) AS ID,

	/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801206042')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801206042')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801206042) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801206042) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_301,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801206043')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801206043')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801206043) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801206043) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_302,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801206044')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801206044')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801206044) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801206044) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_303,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801206045')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801206045')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801206045) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801206045) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_304,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801206046')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801206046')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801206046) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801206046) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_305,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801206047')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801206047')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801206047) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801206047) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_306,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801206048')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801206048')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801206048) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801206048) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_307,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801206049')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801206049')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801206049) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801206049) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_308,

/*3. Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800405013')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800405013')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800405013) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800405013) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_309,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801306050')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801306050')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801306050) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801306050) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_310,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801306051')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801306051')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801306051) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801306051) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_311,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801306052')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801306052')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801306052) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801306052) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_312,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101805207079')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101805207079')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805207079) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101805207079) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_313,

/*Cartera en prórroga*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101805207080')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101805207080')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805207080) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101805207080) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_314,

/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101805207081')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101805207081')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805207081) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101805207081) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_315,

/*Remodelación o mejoramiento con garantía otorgada por la Banca de Desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801306053')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801306053')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801306053) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801306053) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_316,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801306054')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801306054')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801306054) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801306054) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_317
	
INTO IFRS9_R04A_0411_M14TSSALDOS_RESULT_4
FROM IFRS9_R04A_0411

END

BEGIN
	INSERT INTO IFRS9_R04A_0411_M14TSSALDOS_RESULT_4
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_1])),
            SUM(CHARINDEX('ERR',[VALIDACION_2])),
            SUM(CHARINDEX('ERR',[VALIDACION_3])),
            SUM(CHARINDEX('ERR',[VALIDACION_4])),
            SUM(CHARINDEX('ERR',[VALIDACION_5])),
            SUM(CHARINDEX('ERR',[VALIDACION_6])),
            SUM(CHARINDEX('ERR',[VALIDACION_7])),
            SUM(CHARINDEX('ERR',[VALIDACION_8])),
            SUM(CHARINDEX('ERR',[VALIDACION_9])),
            SUM(CHARINDEX('ERR',[VALIDACION_10])),
            SUM(CHARINDEX('ERR',[VALIDACION_11])),
            SUM(CHARINDEX('ERR',[VALIDACION_12])),
            SUM(CHARINDEX('ERR',[VALIDACION_13])),
            SUM(CHARINDEX('ERR',[VALIDACION_14])),
            SUM(CHARINDEX('ERR',[VALIDACION_15])),
            SUM(CHARINDEX('ERR',[VALIDACION_16])),
            SUM(CHARINDEX('ERR',[VALIDACION_17])),
            SUM(CHARINDEX('ERR',[VALIDACION_18])),
            SUM(CHARINDEX('ERR',[VALIDACION_19])),
            SUM(CHARINDEX('ERR',[VALIDACION_20])),
            SUM(CHARINDEX('ERR',[VALIDACION_21])),
            SUM(CHARINDEX('ERR',[VALIDACION_22])),
            SUM(CHARINDEX('ERR',[VALIDACION_23])),
            SUM(CHARINDEX('ERR',[VALIDACION_24])),
            SUM(CHARINDEX('ERR',[VALIDACION_25])),
            SUM(CHARINDEX('ERR',[VALIDACION_26])),
            SUM(CHARINDEX('ERR',[VALIDACION_27])),
            SUM(CHARINDEX('ERR',[VALIDACION_28])),
            SUM(CHARINDEX('ERR',[VALIDACION_29])),
            SUM(CHARINDEX('ERR',[VALIDACION_30])),
            SUM(CHARINDEX('ERR',[VALIDACION_31])),
            SUM(CHARINDEX('ERR',[VALIDACION_32])),
            SUM(CHARINDEX('ERR',[VALIDACION_33])),
            SUM(CHARINDEX('ERR',[VALIDACION_34])),
            SUM(CHARINDEX('ERR',[VALIDACION_35])),
            SUM(CHARINDEX('ERR',[VALIDACION_36])),
            SUM(CHARINDEX('ERR',[VALIDACION_37])),
            SUM(CHARINDEX('ERR',[VALIDACION_38])),
            SUM(CHARINDEX('ERR',[VALIDACION_39])),
            SUM(CHARINDEX('ERR',[VALIDACION_40])),
            SUM(CHARINDEX('ERR',[VALIDACION_41])),
            SUM(CHARINDEX('ERR',[VALIDACION_42])),
            SUM(CHARINDEX('ERR',[VALIDACION_43])),
            SUM(CHARINDEX('ERR',[VALIDACION_44])),
            SUM(CHARINDEX('ERR',[VALIDACION_45])),
            SUM(CHARINDEX('ERR',[VALIDACION_46])),
            SUM(CHARINDEX('ERR',[VALIDACION_47])),
            SUM(CHARINDEX('ERR',[VALIDACION_48])),
            SUM(CHARINDEX('ERR',[VALIDACION_49])),
            SUM(CHARINDEX('ERR',[VALIDACION_50])),
            SUM(CHARINDEX('ERR',[VALIDACION_51])),
            SUM(CHARINDEX('ERR',[VALIDACION_52])),
            SUM(CHARINDEX('ERR',[VALIDACION_53])),
            SUM(CHARINDEX('ERR',[VALIDACION_54])),
            SUM(CHARINDEX('ERR',[VALIDACION_55])),
            SUM(CHARINDEX('ERR',[VALIDACION_56])),
            SUM(CHARINDEX('ERR',[VALIDACION_57])),
            SUM(CHARINDEX('ERR',[VALIDACION_58])),
            SUM(CHARINDEX('ERR',[VALIDACION_59])),
            SUM(CHARINDEX('ERR',[VALIDACION_60])),
            SUM(CHARINDEX('ERR',[VALIDACION_61])),
            SUM(CHARINDEX('ERR',[VALIDACION_62])),
            SUM(CHARINDEX('ERR',[VALIDACION_63])),
            SUM(CHARINDEX('ERR',[VALIDACION_64])),
            SUM(CHARINDEX('ERR',[VALIDACION_65])),
            SUM(CHARINDEX('ERR',[VALIDACION_66])),
            SUM(CHARINDEX('ERR',[VALIDACION_67])),
            SUM(CHARINDEX('ERR',[VALIDACION_68])),
            SUM(CHARINDEX('ERR',[VALIDACION_69])),
            SUM(CHARINDEX('ERR',[VALIDACION_70])),
            SUM(CHARINDEX('ERR',[VALIDACION_71])),
            SUM(CHARINDEX('ERR',[VALIDACION_72])),
            SUM(CHARINDEX('ERR',[VALIDACION_73])),
            SUM(CHARINDEX('ERR',[VALIDACION_74])),
            SUM(CHARINDEX('ERR',[VALIDACION_75])),
            SUM(CHARINDEX('ERR',[VALIDACION_76])),
            SUM(CHARINDEX('ERR',[VALIDACION_77])),
            SUM(CHARINDEX('ERR',[VALIDACION_78])),
            SUM(CHARINDEX('ERR',[VALIDACION_79])),
            SUM(CHARINDEX('ERR',[VALIDACION_80])),
            SUM(CHARINDEX('ERR',[VALIDACION_81])),
            SUM(CHARINDEX('ERR',[VALIDACION_82])),
            SUM(CHARINDEX('ERR',[VALIDACION_83])),
            SUM(CHARINDEX('ERR',[VALIDACION_84])),
            SUM(CHARINDEX('ERR',[VALIDACION_85])),
            SUM(CHARINDEX('ERR',[VALIDACION_86])),
            SUM(CHARINDEX('ERR',[VALIDACION_87])),
            SUM(CHARINDEX('ERR',[VALIDACION_88])),
            SUM(CHARINDEX('ERR',[VALIDACION_89])),
            SUM(CHARINDEX('ERR',[VALIDACION_90])),
            SUM(CHARINDEX('ERR',[VALIDACION_91])),
            SUM(CHARINDEX('ERR',[VALIDACION_92])),
            SUM(CHARINDEX('ERR',[VALIDACION_93])),
            SUM(CHARINDEX('ERR',[VALIDACION_94])),
            SUM(CHARINDEX('ERR',[VALIDACION_95])),
            SUM(CHARINDEX('ERR',[VALIDACION_96])),
            SUM(CHARINDEX('ERR',[VALIDACION_97])),
            SUM(CHARINDEX('ERR',[VALIDACION_98])),
            SUM(CHARINDEX('ERR',[VALIDACION_99])),
            SUM(CHARINDEX('ERR',[VALIDACION_100]))


		from IFRS9_R04A_0411_M14TSSALDOS_RESULT_4
END

BEGIN
	EXEC SP_IFRS9_R04A_0411_M14TSSALDOS_VIEW_4
END

COMMIT
END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


