﻿
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Cartera por tipo de crédito, saldo promedio, intereses y comisiones */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 2*/
/*TIPO SALDO: SALDOS*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/


CREATE OR ALTER PROCEDURE [dbo].[SP_IFRS9_R04A_0411_M2TSSALDOS_VIEW_4]
AS
BEGIN
	SELECT *
		
	FROM IFRS9_R04A_0411_M2TSSALDOS_RESULT_4
	WHERE

        (VALIDACION_301 <> '' ) OR
        (VALIDACION_302 <> '' ) OR
        (VALIDACION_303 <> '' ) OR
        (VALIDACION_304 <> '' ) OR
        (VALIDACION_305 <> '' ) OR
        (VALIDACION_306 <> '' ) OR
        (VALIDACION_307 <> '' ) OR
        (VALIDACION_308 <> '' ) OR
        (VALIDACION_309 <> '' ) OR
        (VALIDACION_310 <> '' ) OR
        (VALIDACION_311 <> '' ) OR
        (VALIDACION_312 <> '' ) OR
        (VALIDACION_313 <> '' ) OR
        (VALIDACION_314 <> '' ) OR
        (VALIDACION_315 <> '' ) OR
        (VALIDACION_316 <> '' ) OR
        (VALIDACION_317 <> '' ) 

ORDER BY 1
END


