﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Cartera por tipo de crédito, saldo promedio, intereses y comisiones */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 2*/
/*TIPO SALDO: SALDOS*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROCEDURE  [dbo].[SP_IFRS9_R04A_0411_M2TSSALDOS_COMP_4]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0411_M2TSSALDOS_RESULT_4')
BEGIN
DROP TABLE IFRS9_R04A_0411_M2TSSALDOS_RESULT_4
END 

BEGIN
SELECT DISTINCT

   /*ID*/

    CONVERT(VARCHAR, ID) AS ID,

	/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801206042')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801206042')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801206042) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801206042) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_301,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801206043')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801206043')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801206043) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801206043) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_302,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801206044')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801206044')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801206044) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801206044) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_303,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801206045')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801206045')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801206045) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801206045) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_304,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801206046')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801206046')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801206046) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801206046) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_305,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801206047')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801206047')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801206047) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801206047) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_306,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801206048')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801206048')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801206048) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801206048) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_307,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801206049')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801206049')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801206049) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801206049) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_308,

/*3. Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800405013')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800405013')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800405013) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800405013) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_309,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801306050')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801306050')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801306050) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801306050) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_310,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801306051')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801306051')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801306051) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801306051) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_311,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801306052')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801306052')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801306052) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801306052) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_312,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101805207079')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101805207079')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805207079) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101805207079) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_313,

/*Cartera en prórroga*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101805207080')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101805207080')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805207080) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101805207080) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_314,

/*Régimen especial de amortización*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101805207081')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101805207081')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805207081) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101805207081) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_315,

/*Remodelación o mejoramiento con garantía otorgada por la Banca de Desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801306053')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801306053')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801306053) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801306053) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_316,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801306054')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801306054')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801306054) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801306054) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_317
	
INTO IFRS9_R04A_0411_M2TSSALDOS_RESULT_4
FROM IFRS9_R04A_0411

END

BEGIN
	INSERT INTO IFRS9_R04A_0411_M2TSSALDOS_RESULT_4
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_301])),
            SUM(CHARINDEX('ERR',[VALIDACION_302])),
            SUM(CHARINDEX('ERR',[VALIDACION_303])),
            SUM(CHARINDEX('ERR',[VALIDACION_304])),
            SUM(CHARINDEX('ERR',[VALIDACION_305])),
            SUM(CHARINDEX('ERR',[VALIDACION_306])),
            SUM(CHARINDEX('ERR',[VALIDACION_307])),
            SUM(CHARINDEX('ERR',[VALIDACION_308])),
            SUM(CHARINDEX('ERR',[VALIDACION_309])),
            SUM(CHARINDEX('ERR',[VALIDACION_310])),
            SUM(CHARINDEX('ERR',[VALIDACION_311])),
            SUM(CHARINDEX('ERR',[VALIDACION_312])),
            SUM(CHARINDEX('ERR',[VALIDACION_313])),
            SUM(CHARINDEX('ERR',[VALIDACION_314])),
            SUM(CHARINDEX('ERR',[VALIDACION_315])),
            SUM(CHARINDEX('ERR',[VALIDACION_316])),
            SUM(CHARINDEX('ERR',[VALIDACION_317]))

		from IFRS9_R04A_0411_M2TSSALDOS_RESULT_4
END

BEGIN
	EXEC SP_IFRS9_R04A_0411_M2TSSALDOS_VIEW_4
END

COMMIT
END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


