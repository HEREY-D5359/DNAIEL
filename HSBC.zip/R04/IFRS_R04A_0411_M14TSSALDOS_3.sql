﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Cartera por tipo de crédito, saldo promedio, intereses y comisiones */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 14*/
/*TIPO SALDO: SALDOS*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROCEDURE  [dbo].[SP_IFRS9_R04A_0411_M14TSSALDOS_COMP_3]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0411_M14TSSALDOS_RESULT_3')
BEGIN
DROP TABLE IFRS9_R04A_0411_M14TSSALDOS_RESULT_3
END 

BEGIN
SELECT DISTINCT

   /*ID*/

    CONVERT(VARCHAR, ID) AS ID,

	/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101805008068')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101805008068')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805008068) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101805008068) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_201,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101805008069')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101805008069')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805008069) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101805008069) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_202,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802307051')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802307051')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802307051) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802307051) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_203,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101805108070')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101805108070')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805108070) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101805108070) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_204,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101805108071')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101805108071')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805108071) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101805108071) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_205,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802307052')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802307052')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802307052) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802307052) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_206,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802307053')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802307053')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802307053) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802307053) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_207,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802307054')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802307054')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802307054) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802307054) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_208,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802307055')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802307055')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802307055) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802307055) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_209,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802307056')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802307056')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802307056) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802307056) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_210,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800806024')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800806024')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800806024) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800806024) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_211,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802407057')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802407057')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802407057) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802407057) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_212,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101805708073')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101805708073')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805708073) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101805708073) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_213,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101805708074')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101805708074')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805708074) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101805708074) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_214,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101805708075')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101805708075')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805708075) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101805708075) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_215,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802407058')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802407058')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802407058) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802407058) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_216,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101805808078')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101805808078')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805808078) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101805808078) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_217,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101805808079')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101805808079')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805808079) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101805808079) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_218,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101805808080')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101805808080')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805808080) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101805808080) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_219,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800806025')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800806025')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800806025) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800806025) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_220,

/*Créditos al gobierno federal*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802507059')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802507059')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802507059) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802507059) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_221,

/*Créditos a estados y municipios */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802507060')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802507060')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802507060) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802507060) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_222,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101806008082')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101806008082')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806008082) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101806008082) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_223,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101806008083')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101806008083')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806008083) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101806008083) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_224,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101806008084')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101806008084')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806008084) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101806008084) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_225,

/*Fideicomisos públicos de contratación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101806008085')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101806008085')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806008085) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101806008085) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_226,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101806008086')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101806008086')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806008086) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101806008086) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_227,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802507061')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802507061')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802507061) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802507061) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_228,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101806108087')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101806108087')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806108087) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101806108087) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_229,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101806108088')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101806108088')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806108088) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101806108088) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_230,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101806108089')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101806108089')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806108089) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101806108089) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_231,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101806108090')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101806108090')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806108090) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101806108090) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_232,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802507062')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802507062')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802507062) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802507062) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_233,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101806208091')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101806208091')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806208091) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101806208091) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_234,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101806208092')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101806208092')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806208092) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101806208092) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_235,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101806208093')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101806208093')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806208093) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101806208093) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_236,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101806208094')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101806208094')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806208094) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101806208094) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_237,

/*2. Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800305009')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800305009')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800305009) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800305009) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_238,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800906026')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800906026')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800906026) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800906026) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_239,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800906027')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800906027')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800906027) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800906027) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_240,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800906028')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800906028')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800906028) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800906028) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_241,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800906029')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800906029')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800906029) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800906029) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_242,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800906030')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800906030')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800906030) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800906030) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_243,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800906031')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800906031')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800906031) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800906031) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_244,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800906032')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800906032')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800906032) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800906032) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_245,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800906033')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800906033')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800906033) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800906033) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_246,

/*3. Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800305010')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800305010')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800305010) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800305010) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_247,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801006034')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801006034')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801006034) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801006034) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_248,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801006035')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801006035')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801006035) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801006035) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_249,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801006036')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801006036')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801006036) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801006036) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_250,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101803607063')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101803607063')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101803607063) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101803607063) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_251,

/*Régimen especial de amortización */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101803607064')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101803607064')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101803607064) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101803607064) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_252,

/*Remodelación o mejoramiento con garantía otorgada por la Banca de Desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801006037')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801006037')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801006037) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801006037) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_253,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801006038')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801006038')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801006038) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801006038) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_254,

/*Cartera de crédito valuada a valor razonable
Total (1+2+3)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800104004')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800104004')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800104004) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800104004) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_255,

/*1. Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800405011')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800405011')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800405011) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800405011) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_256,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801106039')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801106039')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801106039) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801106039) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_257,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101803907065')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101803907065')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101803907065) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101803907065) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_258,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101806508095')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101806508095')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806508095) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101806508095) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_259,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101806508096')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101806508096')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806508096) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101806508096) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_260,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101803907066')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101803907066')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101803907066) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101803907066) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_261,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101806608097')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101806608097')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806608097) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101806608097) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_262,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101806608098')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101806608098')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806608098) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101806608098) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_263,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101806608099')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101806608099')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806608099) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101806608099) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_264,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101803907067')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101803907067')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101803907067) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101803907067) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_265,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101806708100')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101806708100')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806708100) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101806708100) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_266,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101806708101')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101806708101')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101806708101) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101806708101) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_267,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101803907068')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101803907068')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101803907068) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101803907068) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_268,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101803907069')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101803907069')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101803907069) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101803907069) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_269,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101803907070')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101803907070')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101803907070) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101803907070) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_270,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101803907071')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101803907071')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101803907071) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101803907071) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_271,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101803907072')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101803907072')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101803907072) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101803907072) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_272,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801106040')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801106040')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801106040) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801106040) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_273,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101804007073')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804007073')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804007073) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101804007073) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_274,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101807308103')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101807308103')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807308103) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101807308103) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_275,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101807308104')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101807308104')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807308104) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101807308104) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_276,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101807308105')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101807308105')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807308105) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101807308105) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_277,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101804007074')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804007074')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804007074) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101804007074) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_278,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101807408108')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101807408108')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807408108) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101807408108) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_279,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101807408109')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101807408109')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807408109) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101807408109) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_280,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101807408110')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101807408110')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807408110) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101807408110) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_281,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801106041')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801106041')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801106041) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801106041) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_282,

/*Créditos al gobierno federal */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101804107075')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804107075')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804107075) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101804107075) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_283,

/*Créditos a estados y municipios */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101804107076')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804107076')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804107076) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101804107076) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_284,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101807608112')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101807608112')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807608112) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101807608112) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_285,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101807608113')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101807608113')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807608113) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101807608113) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_286,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101807608114')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101807608114')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807608114) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101807608114) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_287,

/*Fideicomisos públicos de contratación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101807608115')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101807608115')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807608115) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101807608115) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_288,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101807608116')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101807608116')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807608116) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101807608116) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_289,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101804107077')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804107077')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804107077) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101804107077) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_290,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101807708117')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101807708117')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807708117) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101807708117) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_291,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101807708118')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101807708118')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807708118) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101807708118) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_292,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101807708119')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101807708119')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807708119) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101807708119) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_293,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101807708120')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101807708120')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807708120) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101807708120) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_294,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101804107078')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804107078')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804107078) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101804107078) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_295,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101807808121')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101807808121')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807808121) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101807808121) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_296,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101807808122')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101807808122')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807808122) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101807808122) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_297,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101807808123')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101807808123')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807808123) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101807808123) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_298,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101807808124')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101807808124')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101807808124) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101807808124) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_299,

/*2. Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800405012')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800405012')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800405012) con Moneda 14 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800405012) con Moneda 14 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_300
	
INTO IFRS9_R04A_0411_M14TSSALDOS_RESULT_3
FROM IFRS9_R04A_0411

END

BEGIN
	INSERT INTO IFRS9_R04A_0411_M14TSSALDOS_RESULT_3
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_1])),
            SUM(CHARINDEX('ERR',[VALIDACION_2])),
            SUM(CHARINDEX('ERR',[VALIDACION_3])),
            SUM(CHARINDEX('ERR',[VALIDACION_4])),
            SUM(CHARINDEX('ERR',[VALIDACION_5])),
            SUM(CHARINDEX('ERR',[VALIDACION_6])),
            SUM(CHARINDEX('ERR',[VALIDACION_7])),
            SUM(CHARINDEX('ERR',[VALIDACION_8])),
            SUM(CHARINDEX('ERR',[VALIDACION_9])),
            SUM(CHARINDEX('ERR',[VALIDACION_10])),
            SUM(CHARINDEX('ERR',[VALIDACION_11])),
            SUM(CHARINDEX('ERR',[VALIDACION_12])),
            SUM(CHARINDEX('ERR',[VALIDACION_13])),
            SUM(CHARINDEX('ERR',[VALIDACION_14])),
            SUM(CHARINDEX('ERR',[VALIDACION_15])),
            SUM(CHARINDEX('ERR',[VALIDACION_16])),
            SUM(CHARINDEX('ERR',[VALIDACION_17])),
            SUM(CHARINDEX('ERR',[VALIDACION_18])),
            SUM(CHARINDEX('ERR',[VALIDACION_19])),
            SUM(CHARINDEX('ERR',[VALIDACION_20])),
            SUM(CHARINDEX('ERR',[VALIDACION_21])),
            SUM(CHARINDEX('ERR',[VALIDACION_22])),
            SUM(CHARINDEX('ERR',[VALIDACION_23])),
            SUM(CHARINDEX('ERR',[VALIDACION_24])),
            SUM(CHARINDEX('ERR',[VALIDACION_25])),
            SUM(CHARINDEX('ERR',[VALIDACION_26])),
            SUM(CHARINDEX('ERR',[VALIDACION_27])),
            SUM(CHARINDEX('ERR',[VALIDACION_28])),
            SUM(CHARINDEX('ERR',[VALIDACION_29])),
            SUM(CHARINDEX('ERR',[VALIDACION_30])),
            SUM(CHARINDEX('ERR',[VALIDACION_31])),
            SUM(CHARINDEX('ERR',[VALIDACION_32])),
            SUM(CHARINDEX('ERR',[VALIDACION_33])),
            SUM(CHARINDEX('ERR',[VALIDACION_34])),
            SUM(CHARINDEX('ERR',[VALIDACION_35])),
            SUM(CHARINDEX('ERR',[VALIDACION_36])),
            SUM(CHARINDEX('ERR',[VALIDACION_37])),
            SUM(CHARINDEX('ERR',[VALIDACION_38])),
            SUM(CHARINDEX('ERR',[VALIDACION_39])),
            SUM(CHARINDEX('ERR',[VALIDACION_40])),
            SUM(CHARINDEX('ERR',[VALIDACION_41])),
            SUM(CHARINDEX('ERR',[VALIDACION_42])),
            SUM(CHARINDEX('ERR',[VALIDACION_43])),
            SUM(CHARINDEX('ERR',[VALIDACION_44])),
            SUM(CHARINDEX('ERR',[VALIDACION_45])),
            SUM(CHARINDEX('ERR',[VALIDACION_46])),
            SUM(CHARINDEX('ERR',[VALIDACION_47])),
            SUM(CHARINDEX('ERR',[VALIDACION_48])),
            SUM(CHARINDEX('ERR',[VALIDACION_49])),
            SUM(CHARINDEX('ERR',[VALIDACION_50])),
            SUM(CHARINDEX('ERR',[VALIDACION_51])),
            SUM(CHARINDEX('ERR',[VALIDACION_52])),
            SUM(CHARINDEX('ERR',[VALIDACION_53])),
            SUM(CHARINDEX('ERR',[VALIDACION_54])),
            SUM(CHARINDEX('ERR',[VALIDACION_55])),
            SUM(CHARINDEX('ERR',[VALIDACION_56])),
            SUM(CHARINDEX('ERR',[VALIDACION_57])),
            SUM(CHARINDEX('ERR',[VALIDACION_58])),
            SUM(CHARINDEX('ERR',[VALIDACION_59])),
            SUM(CHARINDEX('ERR',[VALIDACION_60])),
            SUM(CHARINDEX('ERR',[VALIDACION_61])),
            SUM(CHARINDEX('ERR',[VALIDACION_62])),
            SUM(CHARINDEX('ERR',[VALIDACION_63])),
            SUM(CHARINDEX('ERR',[VALIDACION_64])),
            SUM(CHARINDEX('ERR',[VALIDACION_65])),
            SUM(CHARINDEX('ERR',[VALIDACION_66])),
            SUM(CHARINDEX('ERR',[VALIDACION_67])),
            SUM(CHARINDEX('ERR',[VALIDACION_68])),
            SUM(CHARINDEX('ERR',[VALIDACION_69])),
            SUM(CHARINDEX('ERR',[VALIDACION_70])),
            SUM(CHARINDEX('ERR',[VALIDACION_71])),
            SUM(CHARINDEX('ERR',[VALIDACION_72])),
            SUM(CHARINDEX('ERR',[VALIDACION_73])),
            SUM(CHARINDEX('ERR',[VALIDACION_74])),
            SUM(CHARINDEX('ERR',[VALIDACION_75])),
            SUM(CHARINDEX('ERR',[VALIDACION_76])),
            SUM(CHARINDEX('ERR',[VALIDACION_77])),
            SUM(CHARINDEX('ERR',[VALIDACION_78])),
            SUM(CHARINDEX('ERR',[VALIDACION_79])),
            SUM(CHARINDEX('ERR',[VALIDACION_80])),
            SUM(CHARINDEX('ERR',[VALIDACION_81])),
            SUM(CHARINDEX('ERR',[VALIDACION_82])),
            SUM(CHARINDEX('ERR',[VALIDACION_83])),
            SUM(CHARINDEX('ERR',[VALIDACION_84])),
            SUM(CHARINDEX('ERR',[VALIDACION_85])),
            SUM(CHARINDEX('ERR',[VALIDACION_86])),
            SUM(CHARINDEX('ERR',[VALIDACION_87])),
            SUM(CHARINDEX('ERR',[VALIDACION_88])),
            SUM(CHARINDEX('ERR',[VALIDACION_89])),
            SUM(CHARINDEX('ERR',[VALIDACION_90])),
            SUM(CHARINDEX('ERR',[VALIDACION_91])),
            SUM(CHARINDEX('ERR',[VALIDACION_92])),
            SUM(CHARINDEX('ERR',[VALIDACION_93])),
            SUM(CHARINDEX('ERR',[VALIDACION_94])),
            SUM(CHARINDEX('ERR',[VALIDACION_95])),
            SUM(CHARINDEX('ERR',[VALIDACION_96])),
            SUM(CHARINDEX('ERR',[VALIDACION_97])),
            SUM(CHARINDEX('ERR',[VALIDACION_98])),
            SUM(CHARINDEX('ERR',[VALIDACION_99])),
            SUM(CHARINDEX('ERR',[VALIDACION_100]))


		from IFRS9_R04A_0411_M14TSSALDOS_RESULT_3
END

BEGIN
	EXEC SP_IFRS9_R04A_0411_M14TSSALDOS_VIEW_3
END

COMMIT
END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


