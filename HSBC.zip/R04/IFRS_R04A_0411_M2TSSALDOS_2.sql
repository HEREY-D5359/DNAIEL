﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Cartera por tipo de crédito, saldo promedio, intereses y comisiones */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 2*/
/*TIPO SALDO: SALDOS*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROCEDURE  [dbo].[SP_IFRS9_R04A_0411_M2TSSALDOS_COMP_2]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0411_M2TSSALDOS_RESULT_2')
BEGIN
DROP TABLE IFRS9_R04A_0411_M2TSSALDOS_RESULT_2
END 

BEGIN
SELECT DISTINCT

   /*ID*/

    CONVERT(VARCHAR, ID) AS ID,

	/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800307013')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800307013')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800307013) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800307013) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_101,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800307014')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800307014')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800307014) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800307014) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_102,

/*Créditos de consumo restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800206004')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800206004')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800206004) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800206004) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_103,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800407015')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800407015')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800407015) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800407015) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_104,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800407016')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800407016')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800407016) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800407016) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_105,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800407017')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800407017')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800407017) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800407017) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_106,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800407018')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800407018')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800407018) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800407018) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_107,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800407019')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800407019')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800407019) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800407019) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_108,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800407020')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800407020')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800407020) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800407020) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_109,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800407021')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800407021')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800407021) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800407021) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_110,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800407022')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800407022')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800407022) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800407022) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_111,

/*3. Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800105003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800105003')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800105003) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800105003) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_112,

/*Créditos a la vivienda sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800306005')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800306005')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800306005) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800306005) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_113,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800507023')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800507023')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800507023) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800507023) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_114,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800507024')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800507024')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800507024) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800507024) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_115,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800507025')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800507025')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800507025) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800507025) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_116,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802508029')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802508029')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802508029) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802508029) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_117,

/*Cartera en prórroga*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802508030')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802508030')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802508030) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802508030) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_118,

/*Régimen especial de amortización */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802508031')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802508031')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802508031) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802508031) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_119,

/*Remodelación o mejoramiento con garantía otorgada por la Banca de Desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800507026')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800507026')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800507026) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800507026) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_120,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800507027')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800507027')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800507027) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800507027) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_121,

/*Créditos a la vivienda restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800306006')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800306006')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800306006) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800306006) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_122,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800607028')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800607028')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800607028) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800607028) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_123,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800607029')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800607029')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800607029) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800607029) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_124,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800607030')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800607030')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800607030) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800607030) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_125,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101803008032')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101803008032')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101803008032) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101803008032) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_126,

/*Cartera en prórroga*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101803008033')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101803008033')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101803008033) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101803008033) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_127,

/*Régimen especial de amortización */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101803008034')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101803008034')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101803008034) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101803008034) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_128,

/*Remodelación o mejoramiento con garantía otorgada por la Banca de Desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800607031')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800607031')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800607031) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800607031) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_129,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800607032')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800607032')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800607032) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800607032) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_130,

/*Cartera etapa 2 
Total (1+2+3)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800104002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800104002')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800104002) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800104002) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_131,

/*1. Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800205005')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800205005')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800205005) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800205005) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_132,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800506007')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800506007')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800506007) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800506007) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_133,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800707033')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800707033')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800707033) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800707033) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_134,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101803308035')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101803308035')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101803308035) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101803308035) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_135,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101803308036')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101803308036')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101803308036) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101803308036) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_136,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800707034')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800707034')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800707034) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800707034) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_137,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101803408037')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101803408037')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101803408037) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101803408037) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_138,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101803408038')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101803408038')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101803408038) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101803408038) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_139,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101803408039')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101803408039')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101803408039) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101803408039) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_140,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800707035')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800707035')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800707035) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800707035) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_141,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101803508040')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101803508040')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101803508040) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101803508040) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_142,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101803508041')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101803508041')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101803508041) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101803508041) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_143,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800707036')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800707036')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800707036) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800707036) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_144,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800707037')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800707037')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800707037) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800707037) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_145,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800707038')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800707038')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800707038) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800707038) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_146,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800707039')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800707039')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800707039) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800707039) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_147,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800707040')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800707040')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800707040) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800707040) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_148,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800506008')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800506008')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800506008) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800506008) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_149,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800807041')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800807041')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800807041) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800807041) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_150,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101804108043')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804108043')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804108043) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101804108043) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_151,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101804108044')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804108044')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804108044) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101804108044) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_152,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101804108045')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804108045')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804108045) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101804108045) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_153,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800807042')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800807042')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800807042) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800807042) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_154,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101804208048')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804208048')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804208048) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101804208048) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_155,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101804208049')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804208049')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804208049) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101804208049) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_156,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101804208050')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804208050')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804208050) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101804208050) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_157,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800506009')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800506009')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800506009) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800506009) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_158,

/*Créditos al gobierno federal*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800907043')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800907043')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800907043) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800907043) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_159,

/*Créditos a estados y municipios */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800907044')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800907044')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800907044) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800907044) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_160,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101804408052')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804408052')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804408052) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101804408052) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_161,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101804408053')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804408053')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804408053) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101804408053) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_162,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101804408054')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804408054')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804408054) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101804408054) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_163,

/*Fideicomisos públicos de contratación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101804408055')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804408055')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804408055) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101804408055) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_164,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101804408056')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804408056')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804408056) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101804408056) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_165,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800907045')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800907045')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800907045) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800907045) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_166,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101804508057')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804508057')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804508057) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101804508057) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_167,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101804508058')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804508058')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804508058) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101804508058) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_168,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101804508059')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804508059')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804508059) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101804508059) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_169,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101804508060')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804508060')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804508060) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101804508060) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_170,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800907046')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800907046')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800907046) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800907046) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_171,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101804608061')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804608061')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804608061) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101804608061) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_172,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101804608062')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804608062')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804608062) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101804608062) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_173,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101804608063')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804608063')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804608063) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101804608063) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_174,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101804608064')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804608064')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804608064) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101804608064) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_175,

/*2. Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800205006')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800205006')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800205006) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800205006) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_176,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800606010')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800606010')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800606010) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800606010) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_177,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800606011')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800606011')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800606011) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800606011) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_178,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800606012')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800606012')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800606012) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800606012) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_179,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800606013')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800606013')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800606013) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800606013) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_180,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800606014')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800606014')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800606014) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800606014) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_181,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800606015')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800606015')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800606015) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800606015) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_182,

/*Microcréditos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800606016')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800606016')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800606016) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800606016) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_183,

/*Otros créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800606017')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800606017')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800606017) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800606017) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_184,

/*3. Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800205007')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800205007')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800205007) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800205007) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_185,

/*Media y residencial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800706018')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800706018')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800706018) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800706018) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_186,

/*De interés social*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800706019')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800706019')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800706019) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800706019) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_187,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800706020')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800706020')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800706020) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800706020) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_188,

/*Cartera ordinaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802007047')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802007047')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802007047) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802007047) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_189,

/*Régimen especial de amortización */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802007048')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802007048')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802007048) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802007048) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_190,

/*Remodelación o mejoramiento con garantía otorgada por la Banca de Desarrollo o fideicomisos públicos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800706021')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800706021')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800706021) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800706021) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_191,

/*Remodelación o mejoramiento con garantía de la subcuenta de vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800706022')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800706022')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800706022) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800706022) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_192,

/*Cartera etapa 3 
Total (1+2+3)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800104003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800104003')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800104003) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800104003) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_193,

/*1. Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800305008')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800305008')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800305008) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800305008) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_194,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800806023')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800806023')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800806023) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800806023) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_195,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802307049')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802307049')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802307049) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802307049) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_196,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101804908065')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804908065')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804908065) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101804908065) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_197,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101804908066')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804908066')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101804908066) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101804908066) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_198,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802307050')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802307050')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802307050) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802307050) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_199,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101805008067')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101805008067')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101805008067) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101805008067) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_200
	
INTO IFRS9_R04A_0411_M2TSSALDOS_RESULT_2
FROM IFRS9_R04A_0411

END

BEGIN
	INSERT INTO IFRS9_R04A_0411_M2TSSALDOS_RESULT_2
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_101])),
            SUM(CHARINDEX('ERR',[VALIDACION_102])),
            SUM(CHARINDEX('ERR',[VALIDACION_103])),
            SUM(CHARINDEX('ERR',[VALIDACION_104])),
            SUM(CHARINDEX('ERR',[VALIDACION_105])),
            SUM(CHARINDEX('ERR',[VALIDACION_106])),
            SUM(CHARINDEX('ERR',[VALIDACION_107])),
            SUM(CHARINDEX('ERR',[VALIDACION_108])),
            SUM(CHARINDEX('ERR',[VALIDACION_109])),
            SUM(CHARINDEX('ERR',[VALIDACION_110])),
            SUM(CHARINDEX('ERR',[VALIDACION_111])),
            SUM(CHARINDEX('ERR',[VALIDACION_112])),
            SUM(CHARINDEX('ERR',[VALIDACION_113])),
            SUM(CHARINDEX('ERR',[VALIDACION_114])),
            SUM(CHARINDEX('ERR',[VALIDACION_115])),
            SUM(CHARINDEX('ERR',[VALIDACION_116])),
            SUM(CHARINDEX('ERR',[VALIDACION_117])),
            SUM(CHARINDEX('ERR',[VALIDACION_118])),
            SUM(CHARINDEX('ERR',[VALIDACION_119])),
            SUM(CHARINDEX('ERR',[VALIDACION_120])),
            SUM(CHARINDEX('ERR',[VALIDACION_121])),
            SUM(CHARINDEX('ERR',[VALIDACION_122])),
            SUM(CHARINDEX('ERR',[VALIDACION_123])),
            SUM(CHARINDEX('ERR',[VALIDACION_124])),
            SUM(CHARINDEX('ERR',[VALIDACION_125])),
            SUM(CHARINDEX('ERR',[VALIDACION_126])),
            SUM(CHARINDEX('ERR',[VALIDACION_127])),
            SUM(CHARINDEX('ERR',[VALIDACION_128])),
            SUM(CHARINDEX('ERR',[VALIDACION_129])),
            SUM(CHARINDEX('ERR',[VALIDACION_130])),
            SUM(CHARINDEX('ERR',[VALIDACION_131])),
            SUM(CHARINDEX('ERR',[VALIDACION_132])),
            SUM(CHARINDEX('ERR',[VALIDACION_133])),
            SUM(CHARINDEX('ERR',[VALIDACION_134])),
            SUM(CHARINDEX('ERR',[VALIDACION_135])),
            SUM(CHARINDEX('ERR',[VALIDACION_136])),
            SUM(CHARINDEX('ERR',[VALIDACION_137])),
            SUM(CHARINDEX('ERR',[VALIDACION_138])),
            SUM(CHARINDEX('ERR',[VALIDACION_139])),
            SUM(CHARINDEX('ERR',[VALIDACION_140])),
            SUM(CHARINDEX('ERR',[VALIDACION_141])),
            SUM(CHARINDEX('ERR',[VALIDACION_142])),
            SUM(CHARINDEX('ERR',[VALIDACION_143])),
            SUM(CHARINDEX('ERR',[VALIDACION_144])),
            SUM(CHARINDEX('ERR',[VALIDACION_145])),
            SUM(CHARINDEX('ERR',[VALIDACION_146])),
            SUM(CHARINDEX('ERR',[VALIDACION_147])),
            SUM(CHARINDEX('ERR',[VALIDACION_148])),
            SUM(CHARINDEX('ERR',[VALIDACION_149])),
            SUM(CHARINDEX('ERR',[VALIDACION_150])),
            SUM(CHARINDEX('ERR',[VALIDACION_151])),
            SUM(CHARINDEX('ERR',[VALIDACION_152])),
            SUM(CHARINDEX('ERR',[VALIDACION_153])),
            SUM(CHARINDEX('ERR',[VALIDACION_154])),
            SUM(CHARINDEX('ERR',[VALIDACION_155])),
            SUM(CHARINDEX('ERR',[VALIDACION_156])),
            SUM(CHARINDEX('ERR',[VALIDACION_157])),
            SUM(CHARINDEX('ERR',[VALIDACION_158])),
            SUM(CHARINDEX('ERR',[VALIDACION_159])),
            SUM(CHARINDEX('ERR',[VALIDACION_160])),
            SUM(CHARINDEX('ERR',[VALIDACION_161])),
            SUM(CHARINDEX('ERR',[VALIDACION_162])),
            SUM(CHARINDEX('ERR',[VALIDACION_163])),
            SUM(CHARINDEX('ERR',[VALIDACION_164])),
            SUM(CHARINDEX('ERR',[VALIDACION_165])),
            SUM(CHARINDEX('ERR',[VALIDACION_166])),
            SUM(CHARINDEX('ERR',[VALIDACION_167])),
            SUM(CHARINDEX('ERR',[VALIDACION_168])),
            SUM(CHARINDEX('ERR',[VALIDACION_169])),
            SUM(CHARINDEX('ERR',[VALIDACION_170])),
            SUM(CHARINDEX('ERR',[VALIDACION_171])),
            SUM(CHARINDEX('ERR',[VALIDACION_172])),
            SUM(CHARINDEX('ERR',[VALIDACION_173])),
            SUM(CHARINDEX('ERR',[VALIDACION_174])),
            SUM(CHARINDEX('ERR',[VALIDACION_175])),
            SUM(CHARINDEX('ERR',[VALIDACION_176])),
            SUM(CHARINDEX('ERR',[VALIDACION_177])),
            SUM(CHARINDEX('ERR',[VALIDACION_178])),
            SUM(CHARINDEX('ERR',[VALIDACION_179])),
            SUM(CHARINDEX('ERR',[VALIDACION_180])),
            SUM(CHARINDEX('ERR',[VALIDACION_181])),
            SUM(CHARINDEX('ERR',[VALIDACION_182])),
            SUM(CHARINDEX('ERR',[VALIDACION_183])),
            SUM(CHARINDEX('ERR',[VALIDACION_184])),
            SUM(CHARINDEX('ERR',[VALIDACION_185])),
            SUM(CHARINDEX('ERR',[VALIDACION_186])),
            SUM(CHARINDEX('ERR',[VALIDACION_187])),
            SUM(CHARINDEX('ERR',[VALIDACION_188])),
            SUM(CHARINDEX('ERR',[VALIDACION_189])),
            SUM(CHARINDEX('ERR',[VALIDACION_190])),
            SUM(CHARINDEX('ERR',[VALIDACION_191])),
            SUM(CHARINDEX('ERR',[VALIDACION_192])),
            SUM(CHARINDEX('ERR',[VALIDACION_193])),
            SUM(CHARINDEX('ERR',[VALIDACION_194])),
            SUM(CHARINDEX('ERR',[VALIDACION_195])),
            SUM(CHARINDEX('ERR',[VALIDACION_196])),
            SUM(CHARINDEX('ERR',[VALIDACION_197])),
            SUM(CHARINDEX('ERR',[VALIDACION_198])),
            SUM(CHARINDEX('ERR',[VALIDACION_199])),
            SUM(CHARINDEX('ERR',[VALIDACION_200]))


		from IFRS9_R04A_0411_M2TSSALDOS_RESULT_2
END

BEGIN
	EXEC SP_IFRS9_R04A_0411_M2TSSALDOS_VIEW_2
END

COMMIT
END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


