﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Cartera por tipo de crédito, saldo promedio, intereses y comisiones */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 2*/
/*TIPO SALDO: SALDOS*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROCEDURE  [dbo].[SP_IFRS9_R04A_0411_M2TSSALDOS_COMP_1]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0411_M2TSSALDOS_RESULT_1')
BEGIN
DROP TABLE IFRS9_R04A_0411_M2TSSALDOS_RESULT_1
END 

BEGIN
SELECT DISTINCT

   /*ID*/

    CONVERT(VARCHAR, ID) AS ID,

	/*Cartera etapa 1 
Total (1+2+3+4)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800104001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800104001')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800104001) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800104001) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_1,

/*1. Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800105001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800105001')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800105001) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800105001) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_2,

/*Créditos comerciales sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800106001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800106001')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800106001) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800106001) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_3,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800107001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800107001')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800107001) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800107001) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_4,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800108001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800108001')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800108001) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800108001) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_5,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800109001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800109001')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800109001) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800109001) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_6,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800109002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800109002')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800109002) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800109002) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_7,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800108002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800108002')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800108002) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800108002) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_8,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800209003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800209003')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800209003) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800209003) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_9,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800209004')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800209004')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800209004) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800209004) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_10,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800209005')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800209005')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800209005) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800209005) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_11,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800108003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800108003')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800108003) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800108003) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_12,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800309006')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800309006')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800309006) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800309006) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_13,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800309007')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800309007')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800309007) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800309007) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_14,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800108004')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800108004')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800108004) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800108004) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_15,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800108005')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800108005')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800108005) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800108005) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_16,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800108006')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800108006')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800108006) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800108006) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_17,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800108007')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800108007')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800108007) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800108007) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_18,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800108008')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800108008')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800108008) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800108008) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_19,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800107002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800107002')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800107002) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800107002) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_20,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800208009')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800208009')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800208009) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800208009) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_21,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800909009')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800909009')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800909009) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800909009) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_22,

/*Banca múltiple*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('111800910001')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('111800910001')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111800910001) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (111800910001) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_23,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800909010')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800909010')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800909010) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800909010) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_24,

/*Banca múltiple*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('111801010003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('111801010003')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (111801010003) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (111801010003) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_25,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800909011')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800909011')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800909011) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800909011) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_26,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800208010')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800208010')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800208010) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800208010) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_27,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801009014')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801009014')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801009014) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801009014) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_28,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801009015')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801009015')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801009015) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801009015) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_29,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801009016')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801009016')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801009016) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801009016) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_30,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800107003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800107003')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800107003) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800107003) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_31,

/*Créditos al gobierno federal*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800308011')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800308011')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800308011) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800308011) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_32,

/*Créditos a estados y municipios */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800308012')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800308012')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800308012) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800308012) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_33,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801209018')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801209018')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801209018) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801209018) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_34,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801209019')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801209019')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801209019) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801209019) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_35,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801209020')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801209020')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801209020) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801209020) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_36,

/*Fideicomisos públicos de contratación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801209021')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801209021')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801209021) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801209021) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_37,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801209022')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801209022')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801209022) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801209022) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_38,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800308013')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800308013')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800308013) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800308013) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_39,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801309023')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801309023')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801309023) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801309023) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_40,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801309024')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801309024')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801309024) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801309024) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_41,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801309025')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801309025')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801309025) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801309025) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_42,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801309026')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801309026')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801309026) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801309026) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_43,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800308014')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800308014')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800308014) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800308014) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_44,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801409027')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801409027')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801409027) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801409027) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_45,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801409028')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801409028')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801409028) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801409028) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_46,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801409029')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801409029')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801409029) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801409029) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_47,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801409030')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801409030')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801409030) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801409030) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_48,

/*Créditos comerciales restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800106002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800106002')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800106002) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800106002) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_49,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800207004')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800207004')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800207004) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800207004) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_50,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800408015')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800408015')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800408015) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800408015) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_51,

/*Créditos en cuenta corriente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801509031')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801509031')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801509031) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801509031) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_52,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801509032')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801509032')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801509032) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801509032) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_53,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800408016')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800408016')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800408016) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800408016) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_54,

/*Operaciones de habilitación o avío*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801609033')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801609033')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801609033) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801609033) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_55,

/*Operaciones refaccionarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801609034')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801609034')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801609034) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801609034) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_56,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801609035')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801609035')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801609035) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801609035) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_57,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800408017')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800408017')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800408017) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800408017) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_58,

/*Créditos puente a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801709036')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801709036')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801709036) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801709036) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_59,

/*Otros créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801709037')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801709037')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101801709037) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101801709037) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_60,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800408018')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800408018')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800408018) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800408018) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_61,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800408019')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800408019')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800408019) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800408019) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_62,

/*Operaciones con garantía hipotecaria*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800408020')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800408020')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800408020) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800408020) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_63,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800408021')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800408021')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800408021) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800408021) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_64,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800408022')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800408022')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800408022) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800408022) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_65,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800207005')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800207005')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800207005) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800207005) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_66,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800508023')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800508023')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800508023) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800508023) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_67,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802309039')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802309039')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802309039) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802309039) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_68,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802309040')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802309040')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802309040) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802309040) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_69,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802309041')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802309041')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802309041) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802309041) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_70,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800508024')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800508024')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800508024) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800508024) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_71,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802409044')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802409044')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802409044) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802409044) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_72,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802409045')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802409045')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802409045) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802409045) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_73,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802409046')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802409046')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802409046) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802409046) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_74,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800207006')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800207006')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800207006) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800207006) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_75,

/*Créditos al gobierno federal */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800608025')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800608025')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800608025) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800608025) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_76,

/*Créditos a estados y municipios */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800608026')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800608026')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800608026) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800608026) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_77,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802609048')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802609048')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802609048) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802609048) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_78,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802609049')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802609049')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802609049) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802609049) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_79,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802609050')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802609050')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802609050) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802609050) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_80,

/*Fideicomisos públicos de contratación*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802609051')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802609051')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802609051) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802609051) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_81,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802609052')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802609052')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802609052) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802609052) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_82,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800608027')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800608027')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800608027) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800608027) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_83,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802709053')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802709053')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802709053) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802709053) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_84,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802709054')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802709054')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802709054) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802709054) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_85,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802709055')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802709055')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802709055) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802709055) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_86,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802709056')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802709056')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802709056) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802709056) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_87,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800608028')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800608028')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800608028) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800608028) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_88,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802809057')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802809057')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802809057) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802809057) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_89,

/*Operaciones de factoraje financiero, descuento o cesión de derechos de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802809058')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802809058')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802809058) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802809058) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_90,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802809059')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802809059')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802809059) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802809059) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_91,

/*Otros*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802809060')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802809060')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101802809060) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101802809060) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_92,

/*2. Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800105002')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800105002')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800105002) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800105002) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_93,

/*Créditos de consumo sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800206003')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800206003')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800206003) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800206003) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_94,

/*Tarjeta de crédito*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800307007')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800307007')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800307007) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800307007) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_95,

/*Personales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800307008')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800307008')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800307008) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800307008) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_96,

/*Nómina*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800307009')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800307009')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800307009) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800307009) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_97,

/*Automotriz*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800307010')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800307010')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800307010) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800307010) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_98,

/*Adquisición de bienes muebles*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800307011')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800307011')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800307011) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800307011) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_99,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800307012')   
AND c06_tipo_saldo IN ('1')    
AND c05_moneda IN ('2')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800307012')
AND c06_tipo_saldo IN ('2','3')     
AND c05_moneda IN ('2')), 0))     
BETWEEN -1 AND 1,'', 'Valida que el Dato en el Concepto (101800307012) con Moneda 2 y Tipo de Saldo 1 sea igual a la suma del Concepto (101800307012) con Moneda 2 y Tipo de Saldo 2 y 3 ')    
AS VALIDACION_100
	
INTO IFRS9_R04A_0411_M2TSSALDOS_RESULT_1
FROM IFRS9_R04A_0411

END

BEGIN
	INSERT INTO IFRS9_R04A_0411_M2TSSALDOS_RESULT_1
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_1])),
            SUM(CHARINDEX('ERR',[VALIDACION_2])),
            SUM(CHARINDEX('ERR',[VALIDACION_3])),
            SUM(CHARINDEX('ERR',[VALIDACION_4])),
            SUM(CHARINDEX('ERR',[VALIDACION_5])),
            SUM(CHARINDEX('ERR',[VALIDACION_6])),
            SUM(CHARINDEX('ERR',[VALIDACION_7])),
            SUM(CHARINDEX('ERR',[VALIDACION_8])),
            SUM(CHARINDEX('ERR',[VALIDACION_9])),
            SUM(CHARINDEX('ERR',[VALIDACION_10])),
            SUM(CHARINDEX('ERR',[VALIDACION_11])),
            SUM(CHARINDEX('ERR',[VALIDACION_12])),
            SUM(CHARINDEX('ERR',[VALIDACION_13])),
            SUM(CHARINDEX('ERR',[VALIDACION_14])),
            SUM(CHARINDEX('ERR',[VALIDACION_15])),
            SUM(CHARINDEX('ERR',[VALIDACION_16])),
            SUM(CHARINDEX('ERR',[VALIDACION_17])),
            SUM(CHARINDEX('ERR',[VALIDACION_18])),
            SUM(CHARINDEX('ERR',[VALIDACION_19])),
            SUM(CHARINDEX('ERR',[VALIDACION_20])),
            SUM(CHARINDEX('ERR',[VALIDACION_21])),
            SUM(CHARINDEX('ERR',[VALIDACION_22])),
            SUM(CHARINDEX('ERR',[VALIDACION_23])),
            SUM(CHARINDEX('ERR',[VALIDACION_24])),
            SUM(CHARINDEX('ERR',[VALIDACION_25])),
            SUM(CHARINDEX('ERR',[VALIDACION_26])),
            SUM(CHARINDEX('ERR',[VALIDACION_27])),
            SUM(CHARINDEX('ERR',[VALIDACION_28])),
            SUM(CHARINDEX('ERR',[VALIDACION_29])),
            SUM(CHARINDEX('ERR',[VALIDACION_30])),
            SUM(CHARINDEX('ERR',[VALIDACION_31])),
            SUM(CHARINDEX('ERR',[VALIDACION_32])),
            SUM(CHARINDEX('ERR',[VALIDACION_33])),
            SUM(CHARINDEX('ERR',[VALIDACION_34])),
            SUM(CHARINDEX('ERR',[VALIDACION_35])),
            SUM(CHARINDEX('ERR',[VALIDACION_36])),
            SUM(CHARINDEX('ERR',[VALIDACION_37])),
            SUM(CHARINDEX('ERR',[VALIDACION_38])),
            SUM(CHARINDEX('ERR',[VALIDACION_39])),
            SUM(CHARINDEX('ERR',[VALIDACION_40])),
            SUM(CHARINDEX('ERR',[VALIDACION_41])),
            SUM(CHARINDEX('ERR',[VALIDACION_42])),
            SUM(CHARINDEX('ERR',[VALIDACION_43])),
            SUM(CHARINDEX('ERR',[VALIDACION_44])),
            SUM(CHARINDEX('ERR',[VALIDACION_45])),
            SUM(CHARINDEX('ERR',[VALIDACION_46])),
            SUM(CHARINDEX('ERR',[VALIDACION_47])),
            SUM(CHARINDEX('ERR',[VALIDACION_48])),
            SUM(CHARINDEX('ERR',[VALIDACION_49])),
            SUM(CHARINDEX('ERR',[VALIDACION_50])),
            SUM(CHARINDEX('ERR',[VALIDACION_51])),
            SUM(CHARINDEX('ERR',[VALIDACION_52])),
            SUM(CHARINDEX('ERR',[VALIDACION_53])),
            SUM(CHARINDEX('ERR',[VALIDACION_54])),
            SUM(CHARINDEX('ERR',[VALIDACION_55])),
            SUM(CHARINDEX('ERR',[VALIDACION_56])),
            SUM(CHARINDEX('ERR',[VALIDACION_57])),
            SUM(CHARINDEX('ERR',[VALIDACION_58])),
            SUM(CHARINDEX('ERR',[VALIDACION_59])),
            SUM(CHARINDEX('ERR',[VALIDACION_60])),
            SUM(CHARINDEX('ERR',[VALIDACION_61])),
            SUM(CHARINDEX('ERR',[VALIDACION_62])),
            SUM(CHARINDEX('ERR',[VALIDACION_63])),
            SUM(CHARINDEX('ERR',[VALIDACION_64])),
            SUM(CHARINDEX('ERR',[VALIDACION_65])),
            SUM(CHARINDEX('ERR',[VALIDACION_66])),
            SUM(CHARINDEX('ERR',[VALIDACION_67])),
            SUM(CHARINDEX('ERR',[VALIDACION_68])),
            SUM(CHARINDEX('ERR',[VALIDACION_69])),
            SUM(CHARINDEX('ERR',[VALIDACION_70])),
            SUM(CHARINDEX('ERR',[VALIDACION_71])),
            SUM(CHARINDEX('ERR',[VALIDACION_72])),
            SUM(CHARINDEX('ERR',[VALIDACION_73])),
            SUM(CHARINDEX('ERR',[VALIDACION_74])),
            SUM(CHARINDEX('ERR',[VALIDACION_75])),
            SUM(CHARINDEX('ERR',[VALIDACION_76])),
            SUM(CHARINDEX('ERR',[VALIDACION_77])),
            SUM(CHARINDEX('ERR',[VALIDACION_78])),
            SUM(CHARINDEX('ERR',[VALIDACION_79])),
            SUM(CHARINDEX('ERR',[VALIDACION_80])),
            SUM(CHARINDEX('ERR',[VALIDACION_81])),
            SUM(CHARINDEX('ERR',[VALIDACION_82])),
            SUM(CHARINDEX('ERR',[VALIDACION_83])),
            SUM(CHARINDEX('ERR',[VALIDACION_84])),
            SUM(CHARINDEX('ERR',[VALIDACION_85])),
            SUM(CHARINDEX('ERR',[VALIDACION_86])),
            SUM(CHARINDEX('ERR',[VALIDACION_87])),
            SUM(CHARINDEX('ERR',[VALIDACION_88])),
            SUM(CHARINDEX('ERR',[VALIDACION_89])),
            SUM(CHARINDEX('ERR',[VALIDACION_90])),
            SUM(CHARINDEX('ERR',[VALIDACION_91])),
            SUM(CHARINDEX('ERR',[VALIDACION_92])),
            SUM(CHARINDEX('ERR',[VALIDACION_93])),
            SUM(CHARINDEX('ERR',[VALIDACION_94])),
            SUM(CHARINDEX('ERR',[VALIDACION_95])),
            SUM(CHARINDEX('ERR',[VALIDACION_96])),
            SUM(CHARINDEX('ERR',[VALIDACION_97])),
            SUM(CHARINDEX('ERR',[VALIDACION_98])),
            SUM(CHARINDEX('ERR',[VALIDACION_99])),
            SUM(CHARINDEX('ERR',[VALIDACION_100]))


		from IFRS9_R04A_0411_M2TSSALDOS_RESULT_1
END

BEGIN
	EXEC SP_IFRS9_R04A_0411_M2TSSALDOS_VIEW_1
END

COMMIT
END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


