﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*DATOS GENERALES*/
/*NOMBRE DEL REPORTE: Situación financiera. Cartera por tipo de crédito, saldo promedio, intereses y comisiones */
/*CREADO POR: BRENDA AVALOS*/
/*FECHA CREACION: 24/06/2021*/
/*MODIFICADO: Héctor Daniel García Sánchez*/
/*FECHA MODIFICACION: 01/08/2021 */
/*RAZON DE MODIFICACION: Integracion de la nueva estructura a manera de comentarios y documentación en los stored procedures*/


/*VALIDACIONES DE IFRS 9*/
/*MONEDA: 14*/
/*TIPO SALDO: 3*/
/*TIPO VALOR: NA*/
/*TIPO MOVIMIENTO: NA*/



CREATE OR ALTER PROCEDURE  [dbo].[SP_IFRS9_R04A_0411_M14TS3_COMP_1]
AS
BEGIN TRY
BEGIN TRAN

IF EXISTS (SELECT NAME FROM sysobjects where name='IFRS9_R04A_0411_M14TS3_RESULT_1')
BEGIN
DROP TABLE IFRS9_R04A_0411_M14TS3_RESULT_1
END 

BEGIN
SELECT DISTINCT

   /*ID*/

    CONVERT(VARCHAR, ID) AS ID,

	/*Cartera etapa 1 Total (1+2+3+4)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800104001')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800105001','101800105002','101800105003')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800104001) con Tipo de Saldo 3, Moneda 14, debe ser igual a la sumatoria de las cuentas (101800105001 + 101800105002 + 101800105003) con Tipo de Saldo 3, Moneda 14.')    
AS VALIDACION_1,

/*1. Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800105001')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800106001','101800106002')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800105001) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101800106001 + 101800106002) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_2,

/*2. Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800105002')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800206003','101800206004')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800105002) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101800206003 + 101800206004) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_3,

/*3. Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800105003')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800306005','101800306006')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800105003) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101800306005 + 101800306006) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_4,

/*Créditos comerciales sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800106001')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800107001','101800107002','101800107003')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800106001) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101800107001 + 101800107002 + 101800107003) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_5,

/*Créditos comerciales restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800106002')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800207004','101800207005','101800207006')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800106002) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101800207004 + 101800207005 + 101800207006) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_6,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800107001')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800108001','101800108002','101800108003','101800108004','101800108005','101800108006','101800108007','101800108008')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800107001) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101800108001 + 101800108002 + 101800108003 + 101800108004 + 101800108005 + 101800108006 + 101800108007 + 101800108008) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_7,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800107002')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800208009','101800208010')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800107002) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101800208009 + 101800208010) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_8,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800107003')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800308011','101800308012','101800308013','101800308014')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800107003) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101800308011 + 101800308012 + 101800308013 + 101800308014) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_9,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800108001')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800109001','101800109002')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800108001) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101800109001 + 101800109002) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_10,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800108002')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800209003','101800209004','101800209005')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800108002) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101800209003 + 101800209004 + 101800209005) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_11,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800108003')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800309006','101800309007')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800108003) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101800309006 + 101800309007) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_12,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800208009')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800909009','101800909010','101800909011','101801009014','101801009015','101801009016')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800208009) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas (1 0 18 009 09 009 + 1 0 18 009 09 010 + 1 0 18 009 09 011 + 1 0 18 010 09 014 + 1 0 18 010 09 015 + 1 0 18 010 09 016 ) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_13,

/*Operaciones de arrendamiento financiero*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800909009')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('111800910001')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (1 0 18 009 09 009)  con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas (1 1 18 009 10 001)  con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_14,

/*Créditos para proyectos de inversión con fuente de pago propia*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800909010')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('111801010003')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (1 0 18 009 09 010)  con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas (1 1 18 010 10 003)  con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_15,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800208010')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801009014','101801009015','101801009016')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (1 0 18 002 08 010)  con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas (1 0 18 010 09 014 + 1 0 18 010 09 015 + 1 0 18 010 09 016 )  con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_16,

/*Créditos a estados y municipios */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800308012')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801209018','101801209019','101801209020','101801209021','101801209022')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (1 0 18 003 08 012)  con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas (1 0 18 012 09 018 + 1 0 18 012 09 019 + 1 0 18 012 09 020 + 1 0 18 012 09 021 + 1 0 18 012 09 022)  con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_17,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800308013')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801309023','101801309024','101801309025','101801309026')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (1 0 18 003 08 013)  con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas (1 0 18 013 09 023 + 1 0 18 013 09 024 + 1 0 18 013 09 025 + 1 0 18 013 09 026)  con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_18,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800308014')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801409027','101801409028','101801409029','101801409030')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (1 0 18 003 08 014)  con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas (1 0 18 014 09 027 + 1 0 18 014 09 028 + 1 0 18 014 09 029 + 1 0 18 014 09 030)  con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_19,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800207004')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800408015','101800408016','101800408017','101800408018','101800408019','101800408020','101800408021','101800408022','101800408023','101800408024','101800408025','101800408026','101800408027','101800408028')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (1 0 18 002 07 004)  con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas (1 0 18 004 08 015 + 1 0 18 004 08 016 + 1 0 18 004 08 017 + 1 0 18 004 08 018 + 1 0 18 004 08 019 + 1 0 18 004 08 020 + 1 0 18 004 08 021 + 1 0 18 004 08 022 + 1 0 18 004 08 023 + 1 0 18 004 08 024 + 1 0 18 004 08 025 + 1 0 18 004 08 026 + 1 0 18 004 08 027 + 1 0 18 004 08 028)  con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_20,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800408015')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801509031','101801509032')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (1 0 18 004 08 015)  con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas (1 0 18 015 09 031 + 1 0 18 015 09 032)  con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_21,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800408016')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801609033','101801609034','101801609035')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (1 0 18 004 08 016)  con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas (1 0 18 016 09 033 + 1 0 18 016 09 034 + 1 0 18 016 09 035)  con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_22,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800408017')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801709036','101801709037')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (1 0 18 004 08 017)  con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas (1 0 18 017 09 036 + 1 0 18 017 09 037)  con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_23,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800207005')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800508023','101800508024')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (1 0 18 002 07 005)  con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas (1 0 18 005 08 023 + 1 0 18 005 08 024)  con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_24,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800508023')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802309039','101802309040','101802309041')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (1 0 18 005 08 023)  con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas (1 0 18 023 09 039 + 1 0 18 023 09 040 + 1 0 18 023 09 041)  con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_25,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800508024')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802409044','101802409045','101802409046')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (1 0 18 005 08 024)  con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas (1 0 18 024 09 044 + 1 0 18 024 09 045 + 1 0 18 024 09 046)  con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_26,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800207006')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800608025','101800608026')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (1 0 18 002 07 006)  con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas (1 0 18 006 08 025 + 1 0 18 006 08 026)  con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_27,

/*Créditos a estados y municipios */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800608026')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802609048','101802609049','101802609050','101802609051','101802609052')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (1 0 18 006 08 026)  con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas (1 0 18 026 09 048 + 1 0 18 026 09 049 + 1 0 18 026 09 050 + 1 0 18 026 09 051 + 1 0 18 026 09 052)  con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_28,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800608027')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802709053','101802709054','101802709055','101802709056')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (1 0 18 006 08 027)  con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas (1 0 18 027 09 053 + 1 0 18 027 09 054 + 1 0 18 027 09 055 + 1 0 18 027 09 056)  con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_29,

/*Créditos a organismos descentralizados o desconcentrados*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800608028')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802809057','101802809058','101802809059','101802809060')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (1 0 18 006 08 028)  con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas (1 0 18 028 09 057 + 1 0 18 028 09 058 + 1 0 18 028 09 059 + 1 0 18 028 09 060)  con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_30,

/*Créditos de consumo sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800206003')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800307007','101800307008','101800307009','101800307010','101800307011','101800307012','101800307013','101800307014')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (1 0 18 002 06 003)  con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas (1 0 18 003 07 007 + 1 0 18 003 07 008 + 1 0 18 003 07 009 + 1 0 18 003 07 010 + 1 0 18 003 07 011 + 1 0 18 003 07 012 + 1 0 18 003 07 013 + 1 0 18 003 07 014)  con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_31,

/*Créditos de consumo restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800206004')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800407015','101800407016','101800407017','101800407018','101800407019','101800407020','101800407021','101800407022')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (1 0 18 002 06 004)  con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas (1 0 18 004 07 015 + 1 0 18 004 07 016 + 1 0 18 004 07 017 + 1 0 18 004 07 018 + 1 0 18 004 07 019 + 1 0 18 004 07 020 + 1 0 18 004 07 021 + 1 0 18 004 07 022)  con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_32,

/*Créditos a la vivienda sin restricción*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800306005')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800507023','101800507024','101800507025','101800507026','101800507027')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (1 0 18 003 06 005)  con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas (1 0 18 005 07 023 + 1 0 18 005 07 024 + 1 0 18 005 07 025 + 1 0 18 005 07 026 + 1 0 18 005 07 027)  con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_33,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800507025')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802508029','101802508030','101802508031')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (1 0 18 005 07 025)  con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas (1 0 18 025 08 029 + 1 0 18 025 08 030 + 1 0 18 025 08 031) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_34,

/*Créditos a la vivienda restringidos*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800306006')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800607028','101800607029','101800607030','101800607031','101800607032')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (1 0 18 003 06 006)  con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas (1 0 18 006 07 028 + 1 0 18 006 07 029 + 1 0 18 006 07 030 + 1 0 18 006 07 031 + 1 0 18 006 07 032) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_35,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800607030')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101803008032','101803008033','101803008034')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (1 0 18 006 07 030)  con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas (1 0 18 030 08 032 + 1 0 18 030 08 033 + 1 0 18 030 08 034) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_36,

/*Cartera etapa 2 Total (1+2+3)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800104002')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800205005','101800205006','101800205007')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800104002) con Tipo de Saldo 3, Moneda 14, debe ser igual a la sumatoria de las cuentas (101800205005 + 101800205006 + 101800205007) con Tipo de Saldo 3, Moneda 14.')    
AS VALIDACION_37,

/*1. Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800205005')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800506007','101800506008','101800506009')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800205005) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101800506007 + 101800506008 + 101800506009) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_38,

/*2. Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800205006')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800606010','101800606011','101800606012','101800606013','101800606014','101800606015','101800606016','101800606017')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800205006) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101800606010 + 101800606011 + 101800606012 + 101800606013 + 101800606014 + 101800606015 + 101800606016 + 101800606017) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_39,

/*3. Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800205007')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800706018','101800706019','101800706020','101800706021','101800706022')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800205007) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101800706018 + 101800706019 + 101800706020 + 101800706021 + 101800706022) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_40,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800506007')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800707033','101800707034','101800707035','101800707036','101800707037','101800707038','101800707039','101800707040')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800506007) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101800707033 + 101800707034 + 101800707035 + 101800707036 + 101800707037 + 101800707038 + 101800707039 + 101800707040) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_41,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800707033')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101803308035','101803308036')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800707033) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101803308035 + 101803308036) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_42,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800707034')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101803408037','101803408038','101803408039')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800707034) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101803408037 + 101803408038 + 101803408039) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_43,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800707035')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101803508040','101803508041')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800707035) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101803508040 + 101803508041) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_44,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800506008')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800807041','101800807042')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800506008) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101800807041 + 101800807042) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_45,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800807041')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804108043','101804108044','101804108045')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (1 0 18 008 07 041) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas (1 0 18 041 08 043 + 1 0 18 041 08 044 + 1 0 18 041 08 045) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_46,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800807042')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804208048','101804208049','101804208050')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (1 0 18 008 07 042) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas (1 0 18 042 08 048 + 1 0 18 042 08 049 + 1 0 18 042 08 050) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_47,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800506009')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800907043','101800907044','101800907045','101800907046')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800506009) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101800907043 + 101800907044 + 101800907045 + 101800907046) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_48,

/*Créditos a estados y municipios */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800907044')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804408052','101804408053','101804408054','101804408055','101804408056')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800907044) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101804408052 + 101804408053 + 101804408054 + 101804408055 + 101804408056) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_49,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800907045')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804508057','101804508058','101804508059','101804508060')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800907045) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101804508057 + 101804508058 + 101804508059 + 101804508060) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_50,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800907046')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804608061','101804608062','101804608063','101804608064')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800907046) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101804608061 + 101804608062 + 101804608063 + 101804608064) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_51,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800706020')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802007047','101802007048')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800706020) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101802007047 + 101802007048) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_52,

/*Cartera etapa 3 Total (1+2+3)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800104003')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800305008','101800305009','101800305010')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800104003) con Tipo de Saldo 3, Moneda 14, debe ser igual a la sumatoria de las cuentas (101800305008 + 101800305009 + 101800305010) con Tipo de Saldo 3, Moneda 14.')    
AS VALIDACION_53,

/*1. Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800305008')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800806023','101800806024','101800806025')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800305008) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101800806023 + 101800806024 + 101800806025) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_54,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800806023')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802307049','101802307050','101802307051','101802307052','101802307053','101802307054','101802307055','101802307056')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800806023) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101802307049 + 101802307050 + 101802307051 + 101802307052 + 101802307053 + 101802307054 + 101802307055 + 101802307056) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_55,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802307049')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804908065','101804908066')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101802307049) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101804908065 + 101804908066) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_56,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802307050')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101805008067','101805008068','101805008069')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101802307050) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101805008067 + 101805008068 + 101805008069) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_57,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802307051')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101805108070','101805108071')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101802307051) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101805108070 + 101805108071) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_58,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800806024')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802407057','101802407058')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800806024) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101802407057 + 101802407058) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_59,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802407057')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101805708073','101805708074','101805708075')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (1 0 18 024 07 057) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas (1 0 18 057 08 073 + 1 0 18 057 08 074 + 1 0 18 057 08 075) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_60,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802407058')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101805808078','101805808079','101805808080')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (1 0 18 024 07 058) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas (1 0 18 058 08 078 + 1 0 18 058 08 079 + 1 0 18 058 08 080) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_61,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800806025')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101802507059','101802507060','101802507061','101802507062')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800806025) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101802507059 + 101802507060 + 101802507061 + 101802507062) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_62,

/*Créditos a estados y municipios */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802507060')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101806008082','101806008083','101806008084','101806008085','101806008086')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101802507060) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101806008082 + 101806008083 + 101806008084 + 101806008085 + 101806008086) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_63,

/*Créditos a empresas productivas del estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802507061')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101806108087','101806108088','101806108089','101806108090')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101802507061) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101806108087 + 101806108088 + 101806108089 + 101806108090) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_64,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101802507062')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101806208091','101806208092','101806208093','101806208094')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101802507062) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101806208091 + 101806208092 + 101806208093 + 101806208094) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_65,

/*2. Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800305009')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800906026','101800906027','101800906028','101800906029','101800906030','101800906031','101800906032','101800906033')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800305009) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101800906026 + 101800906027 + 101800906028 + 101800906029 + 101800906030 + 101800906031 + 101800906032 + 101800906033) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_66,

/*3. Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800305010')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801006034','101801006035','101801006036','101801006037','101801006038')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800305010) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101801006034 + 101801006035 + 101801006036 + 101801006037 + 101801006038) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_67,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801006036')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101803607063','101803607064')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101801006036) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101803607063 + 101803607064) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_68,

/*Cartera de crédito valuada a valor razonable Total (1+2+3)*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800104004')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101800405011','101800405012','101800405013')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800104004) con Tipo de Saldo 3, Moneda 14, debe ser igual a la sumatoria de las cuentas (101800405011 + 101800405012 + 101800405013) con Tipo de Saldo 3, Moneda 14.')    
AS VALIDACION_69,

/*1. Créditos comerciales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800405011')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801106039','101801106040','101801106041')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800405011) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101801106039 + 101801106040 + 101801106041) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_70,

/*Actividad empresarial o comercial*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801106039')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101803907065','101803907066','101803907067','101803907068','101803907069','101803907070','101803907071','101803907072')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101801106039) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101803907065 + 101803907066 + 101803907067 + 101803907068 + 101803907069 + 101803907070 + 101803907071 + 101803907072) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_71,

/*Operaciones quirografarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101803907065')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101806508095','101806508096')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101803907065) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101806508095 + 101806508096) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_72,

/*Operaciones prendarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101803907066')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101806608097','101806608098','101806608099')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101803907066) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101806608097 + 101806608098 + 101806608099) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_73,

/*Créditos puente*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101803907067')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101806708100','101806708101')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101803907067) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101806708100 + 101806708101) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_74,

/*Entidades financieras*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801106040')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804007073','101804007074')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101801106040) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101804007073 + 101804007074) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_75,

/*Créditos interbancarios*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101804007073')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101807308103','101807308104','101807308105')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (1 0 18 040 07 073) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 1 0 18 073 08 103 + 1 0 18 073 08 104 + 1 0 18 073 08 105) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_76,

/*Créditos a entidades financieras no bancarias*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101804007074')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101807408108','101807408109','101807408110')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (1 0 18 040 07 074) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 1 0 18 074 08 108 + 1 0 18 074 08 109 + 1 0 18 074 08 110) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_77,

/*Entidades gubernamentales*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801106041')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101804107075','101804107076','101804107077','101804107078')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101801106041) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101804107075 + 101804107076 + 101804107077 + 101804107078) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_78,

/*Créditos a estados y municipios */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101804107076')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101807608112','101807608113','101807608114','101807608115','101807608116')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101804107076) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101807608112 + 101807608113 + 101807608114 + 101807608115 + 101807608116) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_79,

/*Créditos a empresas productivas del Estado*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101804107077')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101807708117','101807708118','101807708119','101807708120')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101804107077) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101807708117 + 101807708118 + 101807708119 + 101807708120) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_80,

/*Créditos a organismos descentralizados o desconcentrados */
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101804107078')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101807808121','101807808122','101807808123','101807808124')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101804107078) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101807808121 + 101807808122 + 101807808123 + 101807808124) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_81,

/*2. Créditos de consumo*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800405012')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801206042','101801206043','101801206044','101801206045','101801206046','101801206047','101801206048','101801206049')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800405012) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101801206042 + 101801206043 + 101801206044 + 101801206045 + 101801206046 + 101801206047 + 101801206048 + 101801206049) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_82,

/*3. Créditos a la vivienda*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101800405013')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101801306050','101801306051','101801306052','101801306053','101801306054')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101800405013) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101801306050 + 101801306051 + 101801306052 + 101801306053 + 1 0 18 013 06 054) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_83,

/*Créditos adquiridos al INFONAVIT o el FOVISSSTE*/
IIF(ABS(ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)     
FROM IFRS9_R04A_0411   
WHERE [c04_CONCEPTO] IN ('101801306052')   
AND c06_tipo_saldo IN ('3')    
AND c05_moneda IN ('14')), 0)     
-      
ISNULL((SELECT ISNULL(SUM(CAST(c07_dato AS DECIMAL)),0)      
FROM IFRS9_R04A_0411     
WHERE [c04_CONCEPTO] IN ('101805207079','101805207080','101805207081')
AND c06_tipo_saldo IN ('3')     
AND c05_moneda IN ('14')), 0))     
BETWEEN -1 AND 1,'', 'El saldo de la cuenta (101801306052) con Tipo de Saldo 3 y Moneda 14, debe ser igual a la sumatoria de las cuentas ( 101805207079 + 101805207080 + 101805207081) con Tipo de Saldo 3 y Moneda 14.')    
AS VALIDACION_84
	
INTO IFRS9_R04A_0411_M14TS3_RESULT_1
FROM IFRS9_R04A_0411

END

BEGIN
	INSERT INTO IFRS9_R04A_0411_M14TS3_RESULT_1
		SELECT 'TOTAL ERRORES',
            SUM(CHARINDEX('ERR',[VALIDACION_1])),
            SUM(CHARINDEX('ERR',[VALIDACION_2])),
            SUM(CHARINDEX('ERR',[VALIDACION_3])),
            SUM(CHARINDEX('ERR',[VALIDACION_4])),
            SUM(CHARINDEX('ERR',[VALIDACION_5])),
            SUM(CHARINDEX('ERR',[VALIDACION_6])),
            SUM(CHARINDEX('ERR',[VALIDACION_7])),
            SUM(CHARINDEX('ERR',[VALIDACION_8])),
            SUM(CHARINDEX('ERR',[VALIDACION_9])),
            SUM(CHARINDEX('ERR',[VALIDACION_10])),
            SUM(CHARINDEX('ERR',[VALIDACION_11])),
            SUM(CHARINDEX('ERR',[VALIDACION_12])),
            SUM(CHARINDEX('ERR',[VALIDACION_13])),
            SUM(CHARINDEX('ERR',[VALIDACION_14])),
            SUM(CHARINDEX('ERR',[VALIDACION_15])),
            SUM(CHARINDEX('ERR',[VALIDACION_16])),
            SUM(CHARINDEX('ERR',[VALIDACION_17])),
            SUM(CHARINDEX('ERR',[VALIDACION_18])),
            SUM(CHARINDEX('ERR',[VALIDACION_19])),
            SUM(CHARINDEX('ERR',[VALIDACION_20])),
            SUM(CHARINDEX('ERR',[VALIDACION_21])),
            SUM(CHARINDEX('ERR',[VALIDACION_22])),
            SUM(CHARINDEX('ERR',[VALIDACION_23])),
            SUM(CHARINDEX('ERR',[VALIDACION_24])),
            SUM(CHARINDEX('ERR',[VALIDACION_25])),
            SUM(CHARINDEX('ERR',[VALIDACION_26])),
            SUM(CHARINDEX('ERR',[VALIDACION_27])),
            SUM(CHARINDEX('ERR',[VALIDACION_28])),
            SUM(CHARINDEX('ERR',[VALIDACION_29])),
            SUM(CHARINDEX('ERR',[VALIDACION_30])),
            SUM(CHARINDEX('ERR',[VALIDACION_31])),
            SUM(CHARINDEX('ERR',[VALIDACION_32])),
            SUM(CHARINDEX('ERR',[VALIDACION_33])),
            SUM(CHARINDEX('ERR',[VALIDACION_34])),
            SUM(CHARINDEX('ERR',[VALIDACION_35])),
            SUM(CHARINDEX('ERR',[VALIDACION_36])),
            SUM(CHARINDEX('ERR',[VALIDACION_37])),
            SUM(CHARINDEX('ERR',[VALIDACION_38])),
            SUM(CHARINDEX('ERR',[VALIDACION_39])),
            SUM(CHARINDEX('ERR',[VALIDACION_40])),
            SUM(CHARINDEX('ERR',[VALIDACION_41])),
            SUM(CHARINDEX('ERR',[VALIDACION_42])),
            SUM(CHARINDEX('ERR',[VALIDACION_43])),
            SUM(CHARINDEX('ERR',[VALIDACION_44])),
            SUM(CHARINDEX('ERR',[VALIDACION_45])),
            SUM(CHARINDEX('ERR',[VALIDACION_46])),
            SUM(CHARINDEX('ERR',[VALIDACION_47])),
            SUM(CHARINDEX('ERR',[VALIDACION_48])),
            SUM(CHARINDEX('ERR',[VALIDACION_49])),
            SUM(CHARINDEX('ERR',[VALIDACION_50])),
            SUM(CHARINDEX('ERR',[VALIDACION_51])),
            SUM(CHARINDEX('ERR',[VALIDACION_52])),
            SUM(CHARINDEX('ERR',[VALIDACION_53])),
            SUM(CHARINDEX('ERR',[VALIDACION_54])),
            SUM(CHARINDEX('ERR',[VALIDACION_55])),
            SUM(CHARINDEX('ERR',[VALIDACION_56])),
            SUM(CHARINDEX('ERR',[VALIDACION_57])),
            SUM(CHARINDEX('ERR',[VALIDACION_58])),
            SUM(CHARINDEX('ERR',[VALIDACION_59])),
            SUM(CHARINDEX('ERR',[VALIDACION_60])),
            SUM(CHARINDEX('ERR',[VALIDACION_61])),
            SUM(CHARINDEX('ERR',[VALIDACION_62])),
            SUM(CHARINDEX('ERR',[VALIDACION_63])),
            SUM(CHARINDEX('ERR',[VALIDACION_64])),
            SUM(CHARINDEX('ERR',[VALIDACION_65])),
            SUM(CHARINDEX('ERR',[VALIDACION_66])),
            SUM(CHARINDEX('ERR',[VALIDACION_67])),
            SUM(CHARINDEX('ERR',[VALIDACION_68])),
            SUM(CHARINDEX('ERR',[VALIDACION_69])),
            SUM(CHARINDEX('ERR',[VALIDACION_70])),
            SUM(CHARINDEX('ERR',[VALIDACION_71])),
            SUM(CHARINDEX('ERR',[VALIDACION_72])),
            SUM(CHARINDEX('ERR',[VALIDACION_73])),
            SUM(CHARINDEX('ERR',[VALIDACION_74])),
            SUM(CHARINDEX('ERR',[VALIDACION_75])),
            SUM(CHARINDEX('ERR',[VALIDACION_76])),
            SUM(CHARINDEX('ERR',[VALIDACION_77])),
            SUM(CHARINDEX('ERR',[VALIDACION_78])),
            SUM(CHARINDEX('ERR',[VALIDACION_79])),
            SUM(CHARINDEX('ERR',[VALIDACION_80])),
            SUM(CHARINDEX('ERR',[VALIDACION_81])),
            SUM(CHARINDEX('ERR',[VALIDACION_82])),
            SUM(CHARINDEX('ERR',[VALIDACION_83])),
            SUM(CHARINDEX('ERR',[VALIDACION_84]))

		from IFRS9_R04A_0411_M14TS3_RESULT_1
END

BEGIN
	EXEC SP_IFRS9_R04A_0411_M14TS3_VIEW_1
END

COMMIT
END TRY

	BEGIN CATCH
	ROLLBACK
	PRINT ERROR_MESSAGE()

END CATCH


